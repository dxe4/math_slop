# Combined learner upload

Upload exactly TUTOR_PROMPT.md, learner_course.md, exercises.json and UPLOAD_README.md. The entire accepted EXTENSION01 learner text is an exact byte prefix; all 157 exercise objects retain their fields and order. Four optional E04 items are appended, for 161 total. Original 145 registered records and E01–E03 optional status remain unchanged.

This package contains teaching text, figure descriptions/numerical equivalents and prompts. It excludes protected keys, hints, rubrics, executable labs, notebook outputs, raw scientific outputs and evidence. Do not upload the whole repository or reference publication. Separation from ingestion is not authenticated exam security. Upload-only feedback is unverified; no new grading, registration, key service or stored mastery is supplied.
