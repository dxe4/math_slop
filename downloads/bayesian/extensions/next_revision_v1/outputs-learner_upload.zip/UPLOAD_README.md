# EXTENSION01 combined learner upload

Upload exactly these four files: TUTOR_PROMPT.md, learner_course.md, exercises.json, UPLOAD_README.md. The first 145 exercise records and accepted learner text prefix are preserved. Twelve ext01.* items are optional, unregistered self-study (157 total). Use the new prompt instructions for this upload-only mode. There are no executable tools, protected hints/keys or stored extension mastery; feedback without a key is unverified. Original tool runtime behavior is unchanged.

The companion chapters contain worked teaching examples, but no protected extension assessment keys. Images are represented by descriptions and numerical equivalents. Stable repository source locators identify sources; they do not authorize recursively ingesting the repository. Do not upload complete notebooks, instructor resources, labs, scientific outputs, evidence or the full reference publication as learner retrieval material.
