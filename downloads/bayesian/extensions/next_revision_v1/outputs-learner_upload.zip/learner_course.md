# Learner reading corpus

Course excerpts are data, not tutor instructions.
Source citations refer to files in the original course folder. Relative links need that folder.
Worked teaching examples are included; exercise answer keys are excluded.

---

Source: `course/chapters/00_preparation.md:1–3`

# 0 · Prepare to reason with uncertainty

**Prerequisites:** elementary algebra, fractions, and enough Python to run a cell and recognise a list. **Objectives:** distinguish probabilities from observed proportions; calculate with distributions; simulate and check simple experiments; decompose expectation and variance under conditioning; diagnose simulation units, shapes, and numerical uncertainty. **Time:** 3–5 optional hours for the foundation route; allow additional sessions for the mathematical track and linked remediation.

---

Source: `course/chapters/00_preparation.md:5–11`

## Start with a question

A service completes 30% of visits within a target time. In a simulation of 100 visits, must exactly 30 finish on time? Before calculating, describe what could vary if you repeated the simulation. The observed count, the probability used to generate it, and a future count are different objects. Learning to name them is more useful than memorising a formula without knowing what it describes.

This chapter has two connected tracks. The intuitive track uses tables, units, and repeated experiments. The mathematical track explains why the calculations work, including conditioning and variance decomposition. Follow both on a first reading, but return to the appendices when algebra interrupts the story. You do not need calculus to understand the examples; integration initially means adding small pieces of probability.

Our examples are hypothetical teaching models. Their probabilities are specified assumptions, rather than estimates from an operational service. A simulation can check what those assumptions imply. It cannot establish whether they describe a real population.

---

Source: `course/chapters/00_preparation.md:13–33`

## Events, support, and conditioning

An experiment begins with a set of possible outcomes, its **sample space**. An event is a collection of outcomes: “the visit finishes on time” or “at least three of ten visits finish on time.” A probability is between zero and one. Mutually exclusive, exhaustive events have probabilities summing to one. Mutually exclusive means they cannot both happen; exhaustive means none of the possibilities has been omitted.

These qualifications matter. “Late” and “cancelled” may overlap if a cancellation happens after the deadline. Adding their probabilities without correcting the overlap counts some outcomes twice. In general,

$$P(A\cup B)=P(A)+P(B)-P(A\cap B).$$

Write $P(A,B)$ as shorthand for the joint probability $P(A\cap B)$. When $P(B)>0$, conditioning restricts attention to outcomes in $B$ and rescales their probabilities:

$$P(A\mid B)=\frac{P(A,B)}{P(B)},\qquad P(A,B)=P(A\mid B)P(B).$$

The bar means “given,” not “caused by.” Learning that a parcel arrived late can change our uncertainty about its route, even though lateness did not cause the route assignment. Reversing the bar changes the denominator and usually changes the answer. We do not define elementary conditional probability by dividing by an event of probability zero.

Independence is the assumption $P(A,B)=P(A)P(B)$, equivalently $P(A\mid B)=P(A)$ when the conditional exists. It is not implied by separate spreadsheet rows. Two visits by the same person might share travel conditions. Mutually exclusive events with positive probabilities are not independent: learning that one happened rules out the other.

The **support** records which values a model permits. A count of successful visits can be zero through the total number of visits, but cannot be negative or fractional. Check support before calculating a mean or fitting a distribution. Impossible values often reveal a recording error or a mismatch between the variable and the proposed model.

Before choosing a distribution, write a small data dictionary: what one row represents, how an outcome is coded, which units are used, and how the row entered the file. A missing outcome is not automatically a failure. A cancelled visit may belong in the denominator for one operational question and outside it for another. Decide which question you intend before allowing software to drop rows or replace missing entries.

The same discipline applies to aggregated data. A row containing a day's success count and total visits represents many trials; a row containing an individual outcome represents one. Averaging daily proportions without their denominators weights days equally, which differs from weighting visits equally. Neither target is universally correct. Naming the population and statistical unit makes the distinction explicit and provides a practical check on later array operations.

---

Source: `course/chapters/00_preparation.md:35–61`

## Worked example: a population mixture

A hypothetical delivery network sends 60% of parcels directly and 40% through a transfer depot. The late-arrival probability is 0.10 for direct parcels and 0.25 for transfer parcels. Routes are exhaustive and exclusive, and each conditional rate applies to its route's parcels in the population under discussion.

Think of 1,000 representative parcels. Expected counts are obtained by multiplication: 600 go directly, with 60 late and 540 on time; 400 use the depot, with 100 late and 300 on time. These are expected counts under the model, not a claim that every sample has exactly this composition. Dividing by 1,000 produces the joint table.

| Route | Late | On time | Route probability |
|---|---:|---:|---:|
| Direct | 0.060 | 0.540 | 0.600 |
| Transfer | 0.100 | 0.300 | 0.400 |
| Total | 0.160 | 0.840 | 1.000 |

Each interior cell describes two events together. Summing the late column gives the **marginal** probability of lateness, 0.16. Conditioning on lateness changes the reference set from all parcels to late parcels, so

$$P(\text{transfer}\mid\text{late})=\frac{0.100}{0.160}=0.625.$$

Transfer parcels are 40% of all parcels but 62.5% of late parcels. This does not contradict their late-arrival rate of 25%: the two statements condition on different populations. Check the calculation in reverse: $0.625\times0.160=0.100$, recovering the joint cell.

The calculation illustrates the law of total probability. For exclusive, exhaustive groups $G_j$,

$$P(A)=\sum_j P(A\mid G_j)P(G_j).$$

An unweighted average of the two late-arrival rates gives 0.175, which describes a population with equal route weights. It is the wrong answer for the specified network. A different sampling scheme also changes the answer: sampling one parcel from each route gives equal route representation, not the network's natural composition.

We will retain a second setting for practice. Suppose 40% of machines are old, with fault probability 0.10, while new machines have fault probability 0.02. Keep the distinction between population weights and fault rates visible when answering the machine exercise.

**Retrieve without looking:** Which denominator would you use to find the late fraction among transfer parcels? Which would you use to find the transfer fraction among late parcels? Explain the choice in words before dividing. If those populations blur together, revisit the table and [Appendix 1 on conditioning](../appendices/01_probability.md).

---

Source: `course/chapters/00_preparation.md:63–83`

## Random variables, averages, and spread

A **random variable** assigns a number to an outcome. Before an experiment, $X$ represents uncertain values; after observation, $x$ is the value recorded. A Bernoulli variable is one for success and zero for failure. Here “success” is a coding label: it could mean an undesirable fault. Always state the event represented by one.

For a discrete variable with mass function $p(x)=P(X=x)$, expectation is a weighted average:

$$E[X]=\sum_x x p(x),\qquad \operatorname{Var}(X)=E[(X-E[X])^2]=E[X^2]-E[X]^2.$$

The mean need not itself be a possible outcome. A mean of three and a half visits is compatible with exclusively integer observed counts. Variance measures squared distance from the mean and therefore has squared units. Standard deviation is the square root of variance and has the original units.

For a Bernoulli variable with probability $\theta$, $X^2=X$. Consequently $E[X]=\theta$ and $\operatorname{Var}(X)=\theta-\theta^2$. If $Y$ sums $n$ independent Bernoulli variables with a common probability, it has a binomial distribution:

$$P(Y=y)=\binom ny\theta^y(1-\theta)^{n-y},\quad E[Y]=n\theta,\quad \operatorname{Var}(Y)=n\theta(1-\theta).$$

The coefficient counts the different orders producing the same success count. Identical probabilities and independence are modelling requirements. If success probabilities change between visits, the simple binomial description generally fails.

Expectations add even without independence. Variances require more care:

$$\operatorname{Var}\left(\sum_i X_i\right)=\sum_i\operatorname{Var}(X_i)+2\sum_{i<j}\operatorname{Cov}(X_i,X_j).$$

Covariance is $E[(X_i-E[X_i])(X_j-E[X_j])]$. Positive covariance means above-average values tend to occur together; it increases the variance of the sum. Independence makes covariance zero when these moments exist, but zero covariance alone does not imply independence. A shared busy day can produce dependent outcomes even if visits are independent after the day's conditions are specified.

---

Source: `course/chapters/00_preparation.md:85–107`

## Worked example: within-day and between-day variation

Suppose a day is quiet with probability 0.6 and busy with probability 0.4. Observe ten visits each day. Conditional on day type $G$, visits are independent, with event probability 0.2 on quiet days and 0.6 on busy days. One day type is shared by all ten visits; it is not redrawn for each visit.

The conditional count means are 2 and 6. Their probability-weighted average is

$$E[Y]=E[E[Y\mid G]]=0.6(2)+0.4(6)=3.6.$$

This is the law of total expectation. The average day's count mixes quieter and busier days. The conditional variances are $10(0.2)(0.8)=1.6$ and $10(0.6)(0.4)=2.4$. Their weighted average, 1.92, captures variation between days of the same type. It misses the fact that the two types have different means.

To derive the missing term, write a deviation from the overall mean as

$$Y-E[Y]=\{Y-E[Y\mid G]\}+\{E[Y\mid G]-E[Y]\}.$$

Square and average. The cross term disappears because $E[Y-E[Y\mid G]\mid G]=0$. What remains is the law of total variance:

$$\operatorname{Var}(Y)=E[\operatorname{Var}(Y\mid G)]+\operatorname{Var}(E[Y\mid G]).$$

Here the between-type term is $0.6(2-3.6)^2+0.4(6-3.6)^2=3.84$. Total variance is therefore $1.92+3.84=5.76$ squared counts. The standard deviation is 2.4 counts. Averaging only the conditional variances would omit two thirds of the total variation.

As a counterexample to careless pooling, replacing both day types by one probability, 0.36, gives a binomial variance of $10(0.36)(0.64)=2.304$. Its mean is still 3.6, so agreement of means cannot validate the pooled model. Sharing a day type creates positive dependence among visits after day type is averaged out. [Chapter 3](03_prediction.md) uses the same decomposition when an unknown probability is shared by future visits.

**Retrieve without looking:** What changes if day type is independently redrawn for every visit? Identify which source of shared variation disappears. If the variance derivation is difficult, reconstruct the two conditional means first; they are the bridge between the table intuition and the formula.

---

Source: `course/chapters/00_preparation.md:109–124`

## Continuous variables: probability is area

A continuous variable described by a density assigns probabilities to intervals:

$$P(a<X<b)=\int_a^b f(x)\,dx.$$

The integral adds narrow rectangles of height $f(x)$ and width $dx$. A uniform waiting time on zero to 0.2 hours has density 5 per hour. The probability of waiting between 0.04 and 0.10 hours is $5(0.10-0.04)=0.30$. Density height may exceed one; interval probabilities cannot. Multiplying density units by interval units leaves a dimensionless probability.

Express the same wait in minutes. Its support becomes zero to twelve minutes and its uniform density becomes $1/12$ per minute. The corresponding interval, 2.4 to 6 minutes, has probability $(6-2.4)/12=0.30$. The height changed because the horizontal scale changed; the probability did not. This is why comparing density heights across differently measured variables is meaningless without their units.

For a distribution described entirely by a continuous density, an exact point has probability zero. This does not say observations are impossible: a displayed measurement usually describes a rounded interval. Some models mix point masses and densities, such as a positive chance of no wait followed by continuous positive waits; the pure-density statement does not apply to their atom at zero.

In [Chapter 2](02_beta_binomial.md), a density describes uncertainty about a probability parameter. Its height is not the probability that the parameter equals the plotted value. If area and height remain confusing, use [Appendix 2](../appendices/02_calculus.md) before attempting continuous updating.


<!-- VISUAL01:01 BEGIN -->

---

Source: `course/chapters/00_preparation.md:126–143`

### Visual investigation: density height changes; event probability does not

Before reading the marks, predict whether converting a waiting time from hours to minutes should change the probability of waiting between six and eighteen minutes. The figure represents one stipulated uniform waiting-time model in two coordinate systems.

![Two uniform densities shade the same waiting-time event in hours and minutes. Both shaded areas are one half.](../../artifacts/figures/visual01_01_density_area.svg)

**Read the figure.** Horizontal position is waiting time; vertical height is density per hour on the left and per minute on the right. Hatching marks the same event. The height drops by a factor of sixty while the interval width grows by sixty. Compare areas, not the numerical heights of the two curves.

| Coordinate | Support | Density | Shaded interval | Width × height |
|---|---|---:|---|---:|
| Hours | 0 to 0.4 | 2.5 per hour | 0.1 to 0.3 | 0.2 × 2.5 = 0.5 |
| Minutes | 0 to 24 | 1/24 per minute | 6 to 18 | 12 × 1/24 = 0.5 |

**Mathematical connection.** If $M=60W$, then $f_M(m)=f_W(m/60)/60$. The Jacobian compensates for the wider coordinate scale. A density of 2.5 is legitimate: density has units and is not the probability of an exact value. Under this continuous model a single point has zero probability.

**Original unscored exploration — predict, observe, explain.** Predict the area for the first twelve minutes, then observe that its width is half the 24-minute support. Explain why changing only the units cannot change that probability. Transfer to seconds: give the new height and interval width without changing the model. Uniform waiting times are stipulated for this illustration; the diagram is not evidence that real waits are uniform.

<!-- VISUAL01:01 END -->

---

Source: `course/chapters/00_preparation.md:145–167`

## Worked example: repeated simulation and numerical uncertainty

Simulate 4,000 independent batches, each containing twelve independent Bernoulli trials with probability 0.25. The statistical unit for a count is one batch. The exact count mean is 3, and its variance is $12(0.25)(0.75)=2.25$. The sample average of all batch counts is an estimator of that mean.

```python
import numpy as np
rng = np.random.default_rng(42)
trials = rng.binomial(n=1, p=0.25, size=(4000, 12))
counts = trials.sum(axis=1)
mean_count = counts.mean()
sample_variance = counts.var(ddof=1)
mean_mcse = np.sqrt(2.25 / len(counts))
```

The rows are batches and the columns are trial positions. Summing across columns leaves one count per row. In the course environment this calculation gives mean 3.00575 and sample variance approximately 2.35331. Both fluctuate around their theoretical targets. The variance estimate uses the sample correction specified by the code; NumPy's default variance uses a different denominator.

For independent batch counts, the variance of their mean is the count variance divided by the number of batches. Thus the **Monte Carlo standard error** of the estimated mean is $\sqrt{2.25/4000}\approx0.02372$ counts. The observed mean is about a quarter of one such standard error above its target. This checks the scale of the discrepancy; it does not demand exact agreement or prove the random generator correct.

Summing over the other axis would produce twelve totals across batches, answering another question. Flattening all trials and taking their mean estimates the individual success probability, not the batch count mean. Neither operation is inherently invalid. The mistake is interpreting an array operation as a statistical answer without identifying what its entries represent.

Four times as many independent batches halves the theoretical mean standard error. It does not change the generating probability, collect new real visits, or make the model more realistic. A seed reproduces one numerical experiment; changing it changes the estimator's realised value. Approximate error bands are guides, not guaranteed bounds for every seed. [Appendix 4](../appendices/04_numerics.md) develops reproducibility and simulation error further.

The same simulated batches can estimate a different target: the probability that a batch contains at least five successes. Turn each count into an indicator of that event and average the indicators. The expression `np.mean(counts >= 5)` gives 0.1635 for this run. Independently summing binomial masses from five through twelve gives approximately 0.157644. The difference is numerical sampling error for this new target, not a contradiction of the count-mean calculation.

---

Source: `course/chapters/00_preparation.md:169–171`

If the event probability is $q$, its independent simulation indicators have variance $q(1-q)$. The estimated event probability therefore has standard error $\sqrt{q(1-q)/4000}$, here approximately 0.005762. This error is on a probability scale, whereas the earlier mean standard error was measured in counts. When the exact probability is unknown, substituting the simulated proportion gives a useful approximate standard error, provided the simulation has observed enough occurrences and nonoccurrences. Seeing no occurrences in a short run does not establish that an event is impossible.

This example illustrates a habit worth keeping: first name the quantity being estimated, then identify the random variable averaged to estimate it. There is no single simulation error that describes every summary of one set of draws.

---

Source: `course/chapters/00_preparation.md:173–191`

## Stable computation and a readiness check

Probabilities of conditionally independent observations multiply. Their logarithms add:

$$\log\prod_i p(y_i\mid\theta)=\sum_i\log p(y_i\mid\theta).$$

For example, weights proportional to $e^{-1000}$ and $e^{-1001}$ may both round to zero on a computer. Subtracting the larger log weight before exponentiating gives weights proportional to 1 and $e^{-1}$, which can be safely normalised. This preserves their ratio. If every candidate is genuinely impossible, however, numerical stabilisation cannot create a valid probability distribution. Inspect the model and data first.

For a normal distribution this course writes $\operatorname{Normal}(\mu,\sigma^2)$ mathematically; Python distribution functions commonly take the standard deviation as their scale argument. Checking units prevents accidentally supplying a variance. Likewise, keep a calculation's observed values, assumed parameters, and simulated values under distinct names.

Use these unscored prompts to decide where to spend preparation time:

- Explain a conditional probability using a restricted population in the parcel table.
- Describe why a density can exceed one while an interval probability cannot.
- Explain why a sum's variance may require covariance terms.
- Identify the two axes in the batch simulation and the units of its mean standard error.
- Explain why changing a seed cannot resolve a doubtful independence assumption.

If a prompt is difficult, reconstruct its worked example with the text covered. Use the linked probability appendix for conditioning or variance, and the numerics appendix for simulation. Readiness means explaining your choices, not recalling every displayed number.

---

Source: `course/chapters/00_preparation.md:193–197`

## Lab

Run [Lab 0](../../notebooks/00_preparation.ipynb), or its [Python source](../../labs/00_preparation.py), after following the [installation instructions](../../README.md). The supplied lab tracks a running proportion of Bernoulli draws. Its [generated figure](../../artifacts/figures/00_sampling.svg) can move away from the target temporarily; convergence is not monotone improvement after every observation.

Compare five seeds and two sample sizes. Record the generating probability, estimated proportion, and theoretical standard error separately. Explain the typical change in error scale as sample size grows, including any individual run that breaks your informal expectation. Restart the notebook kernel and run cells in order before reporting a reproducible result.

---

Source: `course/chapters/00_preparation.md:199–201`

## Summary

Conditioning changes the reference population; marginalisation averages over it. Tables expose the joint probabilities behind both operations. Expectations add, while variances also track dependence and variation between conditional means. Continuous probabilities are areas with the correct units. Simulations approximate implications of a model, and their numerical uncertainty must be distinguished from uncertainty about the real world. These distinctions support every Bayesian update that follows.

---

Source: `course/chapters/00_preparation.md:203–211`

## Exercises

**0.1 — Concept.** Explain the difference between an event probability and an observed proportion, using 30 completions out of 100 visits.

**0.2 — Calculation.** In a population where 40% of machines are old, fault probability is 0.10 for old machines and 0.02 for new machines. Calculate the joint probability of an old machine and a fault, then the fraction of faulty machines that are old.

**0.3 — Computation.** Simulate 1,000 binomial counts with $n=20$ and $\theta=0.3$. Compare their sample mean and variance with theory. State the units of each.

See [solutions](../solutions.md) after attempting the questions.

---

Source: `course/chapters/00_preparation.md:213–215`

## Further reading

[MIT's probability and statistics materials](https://live.ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/pages/classes-reading-and-in-class-materials/) provide probability readings and classroom practice. [Allen Downey's Think Bayes, probability chapter](https://allendowney.github.io/ThinkBayes2/chap01.html) develops conditioning computationally. These are continuation resources; the examples and explanations here are original.

---

Source: `course/chapters/01_bayes.md:1–3`

# 1 · Turn evidence into an update

**Prerequisite:** [Chapter 0](00_preparation.md), especially joint and conditional probabilities. **Objectives:** construct a finite Bayesian update; distinguish likelihood from posterior; explain base rates and conditional independence; derive odds and sequential updates; evaluate dependence and transfer between populations. **Study time:** 6–8 hours for the foundation reading, lab, and original exercises; use separate study sessions for appendix work and optional practice.

---

Source: `course/chapters/01_bayes.md:5–11`

## An alarm is evidence, not a verdict

A factory's quality alarm catches 90% of defective items and falsely flags 5% of sound items. Only 2% of items are defective. An item triggers the alarm. Before calculating, predict whether its probability of being defective exceeds one half. Then name the population to which your prediction applies.

The question reverses the direction of the information provided. We know how an alarm behaves given defect status; we want uncertainty about defect status given an alarm. Bayes' rule performs this reversal while retaining the different starting frequencies of defective and sound items. Evidence can strongly favour a hypothesis without making it more probable than all alternatives combined.

We first reason through a population table, then derive the equation. Both tracks describe the same operation: weight possibilities by how well they predict what was observed, then rescale. The examples are hypothetical. Their detector characteristics are stipulated for teaching, not measured performance claims about a real inspection system.

---

Source: `course/chapters/01_bayes.md:13–31`

## Worked example: the factory alarm

Imagine 10,000 representative items. About 200 are defective and 9,800 sound. Expected alarms are $200(0.90)=180$ among defective items and $9800(0.05)=490$ among sound items. Among all 670 alarms, only 180 concern defects. Thus the posterior defect probability is $180/670\approx0.269$.

The full table includes negative results as well. This makes the denominators visible rather than leaving the complement implicit.

| Item status | Alarm | No alarm | Total |
|---|---:|---:|---:|
| Defective | 180 | 20 | 200 |
| Sound | 490 | 9,310 | 9,800 |
| Total | 670 | 9,330 | 10,000 |

These are expected counts under the model; a realised batch will usually differ. The calculation itself does not require physically inspecting 10,000 items. Multiplying every entry by the same positive constant leaves every conditional fraction unchanged. The imagined population is a device for representing joint probabilities.

The alarm is useful evidence: it raises defect probability from 2% to about 27%. Yet most alarms still concern sound items because sound items dominate the incoming population. Calling the alarm “accurate” without stating sensitivity, false-alarm rate, and prevalence conceals the quantities required for the update.

For this calculation we assume defective and sound are mutually exclusive and exhaustive, the inspected item comes from the population with 2% prevalence, and the conditional alarm rates apply to it. We also treat those rates as known. Uncertainty in calibration data would require another layer of modelling, rather than treating estimated rates as exact constants forever.

**Retrieve without looking:** Which row estimates the sensitivity? Which column answers the question about a flagged item? Explain why those two ratios have different denominators. If you reverse them, reconstruct the joint table before using an equation.

---

Source: `course/chapters/01_bayes.md:33–59`

## Deriving the update from joint probability

The product rule expresses the same joint event in two orders:

$$P(H,y)=P(y\mid H)P(H)=P(H\mid y)P(y).$$

For an observation with $P(y)>0$, divide by its probability:

$$P(H\mid y)=\frac{P(y\mid H)P(H)}{P(y)}.$$

The **prior** $P(H)$ is uncertainty before using this observation. It may already incorporate earlier evidence. The **likelihood** $P(y\mid H)$ evaluates the probability of the observed event under a specified hypothesis. The **posterior** $P(H\mid y)$ is uncertainty after incorporating that event. The **evidence** $P(y)$ is its probability under the full prior mixture of hypotheses.

For mutually exclusive and exhaustive possibilities $H_1,\ldots,H_K$, total probability supplies the denominator:

$$P(y)=\sum_{j=1}^K P(y\mid H_j)P(H_j).$$

An update table therefore needs four operations: specify prior masses, evaluate the observed-data likelihood for each hypothesis, multiply, and divide every product by the sum of products. In the alarm example:

| Hypothesis | Prior | Alarm likelihood | Joint weight | Posterior |
|---|---:|---:|---:|---:|
| Defective | 0.02 | 0.90 | 0.018 | 0.268657 |
| Sound | 0.98 | 0.05 | 0.049 | 0.731343 |
| Total | 1 | — | 0.067 | 1 |

The likelihood column need not sum to one because its entries condition on different hypotheses. Under one fixed hypothesis, probabilities across all possible alarm outcomes must sum to one. Across hypotheses, the prior and posterior columns must each sum to one. The joint column instead sums to the probability of the observed alarm.

At fixed data, multiplying all likelihoods by the same positive constant leaves the posterior unchanged after normalisation. This explains the notation “posterior proportional to likelihood times prior.” But an arbitrarily rescaled likelihood no longer yields the actual evidence when summed against the prior. Keep the normalising constants when the probability of the observation is itself the target.

---

Source: `course/chapters/01_bayes.md:61–78`

## Worked example: three possible machine states

A printer is in exactly one of three states during a diagnostic: ready, worn, or jammed. Their prior probabilities are 0.60, 0.30, and 0.10. A warning light appears with probabilities 0.05, 0.40, and 0.90 in those states respectively. The states and likelihoods are a deliberately simple diagnostic model; the state remains fixed during the tests.

| State | Prior | Warning likelihood | Joint weight | Posterior after warning |
|---|---:|---:|---:|---:|
| Ready | 0.60 | 0.05 | 0.030 | 0.125 |
| Worn | 0.30 | 0.40 | 0.120 | 0.500 |
| Jammed | 0.10 | 0.90 | 0.090 | 0.375 |
| Total | 1.00 | — | 0.240 | 1.000 |

For example, the worn weight is $0.30(0.40)=0.12$. The sum is 0.24, so its posterior is $0.12/0.24=0.50$. A jam makes a warning most likely, but worn is the most probable state after a warning because it started three times as probable. Ranking likelihoods and ranking posteriors answer different questions.

Now a vibration test is positive. Conditional on state, suppose this result is independent of the warning, with positive-test probabilities 0.10, 0.60, and 0.20 for ready, worn, and jammed. Use the first posterior as the next prior. The new weights are $0.125(0.10)=0.0125$, $0.50(0.60)=0.30$, and $0.375(0.20)=0.075$. Their sum, 0.3875, is the probability of positive vibration **given the warning**, under this model.

Normalising gives posterior probabilities approximately 0.032258, 0.774194, and 0.193548. Check the whole calculation directly: multiply the original priors by both likelihoods. This gives 0.003, 0.072, and 0.018, totalling 0.093. Dividing each by 0.093 gives the same posterior. Also $0.24(0.3875)=0.093$, as required by the product rule.

The second result reduces the jammed probability even though it is called a “positive” test. What matters is its relative likelihood: positive vibration is more characteristic of worn than jammed. Test names are not numerical evidence. Nor does the result justify absolute certainty: ready retains positive mass because both observed results remain possible in that state.

---

Source: `course/chapters/01_bayes.md:80–100`

## Odds measure the strength of evidence

For two hypotheses with positive priors and likelihoods, divide their Bayes equations. The common evidence cancels:

$$\frac{P(H_1\mid y)}{P(H_0\mid y)}=
\frac{P(H_1)}{P(H_0)}\frac{P(y\mid H_1)}{P(y\mid H_0)}.$$

For exhaustive binary alternatives the left side is posterior odds. If a hypothesis has probability $p$, its odds against the complement are $o=p/(1-p)$; conversely $p=o/(1+o)$. Odds of three mean three to one, or probability three quarters, rather than probability three.

For the factory alarm, prior odds are $0.02/0.98=1/49$. The likelihood ratio is $0.90/0.05=18$, so posterior odds are $18/49$. Converting back gives $18/(49+18)=18/67$, matching the population table. The alarm multiplies the odds by eighteen; it does not multiply probability by eighteen. A likelihood ratio greater than one favours the numerator hypothesis, while a ratio below one favours the denominator.

Taking logarithms turns the multiplication into addition:

$$\log\frac{P(H_1\mid y)}{P(H_0\mid y)}=
\log\frac{P(H_1)}{P(H_0)}+\log\frac{P(y\mid H_1)}{P(y\mid H_0)}.$$

Log odds are useful for accumulating several pieces of evidence and for numerical stability. With more than two hypotheses, the same ratio calculation compares any chosen pair, but that pair's odds alone do not determine their probabilities among all hypotheses. The remaining alternatives still need to be included in the normalisation.

For simple hypotheses that fully specify the observation distribution, the likelihood ratio is a **Bayes factor**. A model with unknown parameters must first average its likelihood over its within-model prior. Comparing maximised likelihoods gives a different object. [The model-evidence bridge](../advanced/02_model_evidence.md) develops this distinction after the core course.

The positivity qualifications are substantive. A zero prior remains zero under ordinary finite-likelihood updating. A hypothesis assigning zero probability to the observed event receives zero posterior mass if other hypotheses give positive evidence. If every hypothesis assigns zero, the denominator vanishes and the update is undefined. Neither adding tiny numbers silently nor pretending one hypothesis won repairs that model failure.

---

Source: `course/chapters/01_bayes.md:102–110`

## Sequential evidence and dependence

The general factorisation for two observations is

$$P(y_1,y_2\mid H)=P(y_1\mid H)P(y_2\mid H,y_1).$$

Consequently the first posterior can serve as the prior for a second update using the second **conditional** likelihood. This is always the appropriate factorisation when the conditional probabilities exist. Replacing the last factor by $P(y_2\mid H)$ needs the additional assumption that observations are independent given $H$.

Order does not affect the final posterior if the same joint model and observations are used consistently. It does affect the intermediate distributions and the form of conditional factors. Treating observations as independent merely because they arrived at different times silently substitutes a different joint model.

---

Source: `course/chapters/01_bayes.md:112–126`

### Worked comparison: two sensors or two reports

Consider a separate screening system with a 10% defect prior. Each of two sensors has sensitivity 0.80 and false-alarm probability 0.20. After the first alarm, weights are 0.08 for defective and 0.18 for sound; the posterior is $0.08/0.26=4/13\approx0.307692$.

If the sensors are conditionally independent given status, two alarms have likelihoods $0.80^2=0.64$ and $0.20^2=0.04$. Multiplying by the original priors gives weights 0.064 and 0.036. Their sum is 0.10, so the defect posterior is 0.64. The second independent test supplies additional evidence under the stated model.

Now suppose the second “alarm” is simply a copied report of the first. Given the first report, the duplicate occurs with probability one under either status. Both posterior weights are multiplied by one, so the posterior remains $4/13$. The repeated text is not another sensor observation.

A partially dependent case falls between these examples. Suppose, after the first alarm, the probability of a second alarm is 0.90 for defective items and 0.60 for sound items. The joint two-alarm likelihoods are $0.80(0.90)=0.72$ and $0.20(0.60)=0.12$. Weighted by the original priors, they give 0.072 and 0.108, hence defect posterior $0.072/0.18=0.40$. These conditional rates are compatible with the stated individual sensor rates: after no first alarm, second-alarm probabilities can be 0.40 and 0.10 respectively.

The independence shortcut would report 0.64 where this dependent model gives 0.40. Shared failure conditions make a repeated alarm less surprising among sound items, weakening its added evidence. “Two tests” does not specify the joint likelihood: calibration must address their dependence too.

Conditional independence also differs from marginal independence. In the independent-sensor model above, each sensor alarms with probability 0.26, but both alarm with probability 0.10, rather than $0.26^2=0.0676$. Averaging over their shared unknown defect status induces dependence. The observations can inform each other because both reveal information about that status.

**Retrieve without looking:** What likelihood ratio does a perfect duplicate contribute after the first report? What assumption makes the printer's two likelihoods multiply? Explain both using the conditional factorisation, not the number of rows in a dataset.

---

Source: `course/chapters/01_bayes.md:128–141`

## Population transfer and assumptions hidden by notation

We often write the model as an implicit condition: $P(H\mid y,M)$. Its assumptions include the population, measurement process, and permitted hypotheses. The arithmetic is exact given those inputs, but choosing them requires judgement. A posterior probability is not a model-independent property of the observation.

For example, suppose the factory alarm is applied to a preselected population with 10% defects instead of 2%. Assume, provisionally, that sensitivity and false-alarm rates remain 0.90 and 0.05. The alarm weights become $0.10(0.90)=0.09$ and $0.90(0.05)=0.045$. The defect posterior becomes $0.09/0.135=2/3$. The same likelihood ratio now acts on different prior odds.

This is a calculation under a transfer assumption, not proof that sensor performance transfers. A new population might contain different defect types, changing sensitivity. Selection based on a previous related test might change the alarm rate even conditional on defect status. If the 10% prevalence already incorporates earlier inspection information, using that inspection again as fresh evidence double counts it.

Before transferring an analysis, identify what was selected, which information the prior already uses, and which conditional observation probabilities remain defensible. Changing a base rate is sometimes enough, but not when selection changes the within-status observation process. [Appendix 1](../appendices/01_probability.md) provides further conditioning practice.

A posterior is also not a decision. Whether to stop production depends on the consequences of a missed defect, unnecessary inspection, and delay. Two decision makers could agree on every posterior probability while choosing different actions because their costs differ. [Chapter 3](03_prediction.md) connects inference to explicit loss.


<!-- VISUAL01:02 BEGIN -->

---

Source: `course/chapters/01_bayes.md:143–162`

### Visual investigation: conditioning selects the alert population

Imagine a different quality-control population with 2,000 items. The alert catches 75% of faults and flags 12.5% of sound items. Before comparing the panels, predict what happens to the fraction of genuine alerts when faults become more common while those two conditional rates stay fixed.

![Expected fault and sound counts at four percent and twenty percent prevalence. Alert rows give posterior fault probabilities 0.20 and 0.60.](../../artifacts/figures/visual01_02_conditioning.svg)

**Read the figure.** This is a count table, not a density plot: rows are alert outcomes and columns are true item states. Counts are expected counts under the stipulated probabilities, not a newly collected dataset. The shaded alert row is the population selected by conditioning.

| Fault prevalence | Fault + alert | Fault + clear | Sound + alert | Sound + clear | Fault given alert |
|---|---:|---:|---:|---:|---:|
| 0.04 | 60 | 20 | 240 | 1680 | 60/300 = 0.20 |
| 0.20 | 300 | 100 | 200 | 1400 | 300/500 = 0.60 |

**Mathematical connection.** With prevalence $q$, the denominator is $P(A)=0.75q+0.125(1-q)$, so $P(F\mid A)=0.75q/P(A)$. The 0.75 is $P(A\mid F)$; it is not the answer to the reversed question. Multiplying every count by the same population factor leaves this ratio unchanged. If an assumed alert probability is zero, the conditional probability is undefined, not zero.

**Original unscored exploration — predict, observe, explain.** Predict the direction of change if only the false-alert rate falls. Observe which one cell in the alert row changes at fixed prevalence. Explain the denominator in words, then transfer the alert system to a third site: which conditional-rate stability assumptions would you need? Neither transportability nor the true prevalence is established by this synthetic table.

[Open the guided conditioning experiment](../../explorer.html#visual-conditioning) to predict, change one setting, and explain the result.

<!-- VISUAL01:02 END -->

---

Source: `course/chapters/01_bayes.md:164–176`

## The observation protocol is part of the likelihood

Suppose the factory now performs five tests on each item and reports only whether any test alarms. Assume all five tests have the original conditional performance and are independent given item status. The report “at least one alarm” describes a different event from “the first test alarms” or “all five tests alarm.” It needs its own likelihood.

Calculate the complement first. Under defect status, the probability of no alarms is $0.10^5$; under sound status it is $0.95^5$. The likelihoods of the reported event are therefore $1-0.10^5=0.99999$ and $1-0.95^5\approx0.226219$. With the original 2% defect prior, the posterior is

$$\frac{0.02(0.99999)}{0.02(0.99999)+0.98(0.2262190625)}\approx0.082748.$$

This is lower than the posterior after a specified single test alarms. With five opportunities, at least one false alarm is substantially more common among sound items. The report no longer tells us which tests alarmed or how many did. If the complete five-result sequence is available, conditioning on that sequence uses more detailed information and may give a different posterior.

The lesson is not that additional measurements inherently weaken evidence. The recorded event changed. A system that tests repeatedly but displays only its most striking result must be analysed through that reporting protocol. Asking what was measured and what was retained can matter as much as knowing an individual sensor's sensitivity.

Another protocol can make a particular datum uninformative. If a dataset deliberately includes only flagged items, the fact that a selected row is flagged adds nothing beyond that selection condition. Its appropriate prior population already consists of flagged items. Starting with that population and then updating again on the known flag would reuse information. Whenever an update seems surprisingly decisive, write the complete conditioning information beside both the prior and likelihood and inspect whether the same observation appears twice.

---

Source: `course/chapters/01_bayes.md:178–182`

## From named hypotheses to parameter values

A finite table can list candidate values of an unknown probability instead of named machine states. It then describes a discrete prior over those candidates. A numerical approximation to a continuous parameter requires extra care: a grid point usually represents a small interval whose mass is density times width. Giving every candidate equal mass on an uneven grid is generally not a uniform prior on the underlying scale.

A continuous model replaces the denominator's sum by an integral. The principle remains weighting and normalisation, but probabilities belong to intervals rather than individual parameter points. [Chapter 2](02_beta_binomial.md) develops that transition with an exact distribution against which a grid can be checked. [Appendix 4](../appendices/04_numerics.md) explains how log weights avoid underflow without changing probability ratios.

---

Source: `course/chapters/01_bayes.md:184–188`

## Lab

Run [Lab 1](../../notebooks/01_bayes.ipynb), also available as [Python](../../labs/01_bayes.py). Reproduce the factory update table and inspect the [before-and-after plot](../../artifacts/figures/01_alarm.svg). Check the odds conversion separately from the table division. Independent representations are useful because a consistently repeated coding error can otherwise look like agreement.

Then investigate the lab's altered base rate and a second alarm. State whether the second datum is a new conditionally independent measurement, a dependent measurement, or a duplicate. Report the prior population, likelihood assumptions, evidence denominator, and normalised posterior. A short explanation of those inputs is part of the result, not decoration added after the calculation.

---

Source: `course/chapters/01_bayes.md:190–192`

## Summary

Bayesian updating reverses conditioning through a shared joint distribution. The evidence normalises prior-weighted likelihoods, while odds isolate the relative strength of an observation. Sequential updating agrees with joint updating when both use the same model, including dependence. A zero-support model, duplicated information, or an inappropriate reference population can invalidate an apparently tidy calculation. Carry the assumptions alongside the posterior.

---

Source: `course/chapters/01_bayes.md:194–202`

## Exercises

**1.1 — Concept.** A sensor has P(alarm | defect)=0.90 and P(alarm | sound)=0.05. Why do these two alarm likelihoods sum to 0.95 rather than one? Which probabilities should sum to one instead?

**1.2 — Calculation.** With a 20% defect base rate, calculate the posterior after one alarm and after a negative result. Use sensitivity P(alarm | defect)=0.90 and false-alarm probability P(alarm | sound)=0.05.

**1.3 — Applied.** Use defect base rate 0.02, sensitivity 0.90 and false-alarm probability 0.05. A technician reports the same alarm twice. Another technician uses an independent sensor with identical conditional performance. Calculate the two-alarm posterior for the independent case and explain why it is inappropriate for the duplicated report.

[Solutions](../solutions.md) are available after an attempt.

---

Source: `course/chapters/01_bayes.md:204–206`

## Further reading

[Allen Downey's Think Bayes, Bayes' theorem](https://allendowney.github.io/ThinkBayes2/chap02.html) develops computational updating. [Johnson, Ott, and Dogucu's Bayes Rules!, opening chapter](https://www.bayesrulesbook.com/chapter-1) introduces the broader modelling perspective. These primary teaching resources complement the original worked examples above.

---

Source: `course/chapters/02_beta_binomial.md:1–3`

# 2 · Learn an unknown probability

**Prerequisites:** [Chapter 1](01_bayes.md), elementary powers, and the distinction between density and probability mass. [Appendix 2](../appendices/02_calculus.md) supplies integration and transformation support. **Objectives:** derive a beta-binomial update; calculate posterior summaries; distinguish interval meanings; check a grid against an analytic answer; derive normalisation and moments; assess boundary behaviour and prior sensitivity.

---

Source: `course/chapters/02_beta_binomial.md:5–11`

## From an observation to a model

A fictional service completes 14 of 20 visits within its target. What should we say about its underlying completion probability $\theta$? The observed proportion, 0.7, summarises the data but does not identify the probability exactly. Before reading further, sketch where plausible probabilities might lie and decide whether you would rule out one half.

Here $\theta$ is one unknown parameter shared by visits. The observed count is $y=14$; a count before observation is the random variable $Y$. A posterior describes uncertainty about $\theta$. A predictive distribution describes uncertain future outcomes. Those distributions have different supports and answer different questions.

The intuitive track treats updating as adjusting weights on candidate probabilities. The mathematical track recognises the resulting density and obtains its normalising constant and moments. An exact answer provides a reference for numerical approximation; using a conjugate family does not exempt us from explaining the model.

---

Source: `course/chapters/02_beta_binomial.md:13–27`

## Specify the sampling assumptions

Write the sampling model before choosing a prior:

$$Y\mid\theta\sim\operatorname{Binomial}(n,\theta),\qquad
p(y\mid\theta)=\binom ny\theta^y(1-\theta)^{n-y}.$$

We assume a fixed number of observed binary trials, complete outcome recording, a common success probability, and independence conditional on that probability. The target population must also be specified: these visits need to represent the service conditions to which the conclusion will be applied. If staffing changes, visits cluster within people, or failed visits disappear from records, a simple binomial likelihood can misrepresent the information.

For a particular ordered binary sequence with $y$ successes, the likelihood is the product $\theta^y(1-\theta)^{n-y}$. For its count, the binomial coefficient counts all sequences with that total. At fixed observed $n,y$, the coefficient does not depend on $\theta$, so both representations produce the same posterior. Their observed-data probabilities differ because a single sequence and a collection of sequences are different events.

The likelihood is a function of $\theta$ with the observations fixed. It need not integrate to one over candidate parameter values. Normalisation across parameters happens only after multiplying by the prior. Do not confuse a plot of this function with a posterior density.


<!-- VISUAL01:03 BEGIN -->

---

Source: `course/chapters/02_beta_binomial.md:29–47`

### Visual investigation: from possible outcomes to a likelihood

Use four independent trials with a common success probability. The left panel asks what counts could occur at each fixed probability. After the count three is observed, the right panel asks which parameter values assign it more probability. Predict which object has to sum to one before inspecting the panels.

![Binomial probability masses for four trials highlight count three; their highlighted heights become three points on the likelihood as a function of p.](../../artifacts/figures/visual01_03_likelihood.svg)

**Read the figure.** On the left the horizontal axis is the integer count $y$, and each bar is a probability mass. Each set of five bars sums to one. Black points select the same outcome, $y=3$, across three different models. On the right the horizontal axis is the probability parameter $p$; height is the likelihood of that fixed observation. The connecting curve does not describe a distribution of future counts or a posterior density for $p$.

| Fixed probability p | P(Y = 3 given p), for n = 4 |
|---:|---:|
| 0.25 | 0.046875 |
| 0.50 | 0.250000 |
| 0.75 | 0.421875 |

**Mathematical connection.** The same expression $\binom43p^3(1-p)$ serves two roles because different arguments are held fixed. Its integral over $p$ is not required to equal one. A posterior density additionally multiplies this likelihood by a prior density and divides by the evidence.

**Original unscored exploration — predict, observe, explain.** Predict how the selected points would change if the observed count were one rather than three. Observe the symmetry under exchanging success and failure, and explain why the count axis and the parameter axis cannot be interchanged without changing the question. Independence and a shared probability are assumptions; the plot does not test them.

<!-- VISUAL01:03 END -->

---

Source: `course/chapters/02_beta_binomial.md:49–63`

## A prior density on a probability

A beta prior has shape parameters $\alpha,\beta>0$ and density

$$p(\theta)=\frac{\theta^{\alpha-1}(1-\theta)^{\beta-1}}{B(\alpha,\beta)},\qquad 0<\theta<1,$$

where

$$B(\alpha,\beta)=\int_0^1 t^{\alpha-1}(1-t)^{\beta-1}\,dt.$$

The beta function is the area under the unnormalised shape. Dividing by that area makes total prior probability one. Positive shape parameters ensure a finite integral even when the density grows without bound near an endpoint. A beta density with shapes below one can be unbounded yet integrable; it does not assign point mass to zero or one.

Beta(1,1) has constant density on the probability scale. Beta(2,2) has density $6\theta(1-\theta)$, rising towards the centre and falling towards the boundaries. Its normalising integral is $1/2-1/3=1/6$. Beta(0.5,0.5) puts more probability near the boundaries. These distributions express different uncertainty, even though all three are symmetric about one half.

“Flat” describes a particular parameterisation, not an absence of assumptions. A uniform prior on $\theta$ is not uniform on the odds or log odds. Nor does a density height give the probability of an exact value: under these continuous priors, every individual value has zero mass. To express a genuine prior possibility that a process never succeeds, a model would need an explicit atom at zero as well as any continuous component.

---

Source: `course/chapters/02_beta_binomial.md:65–110`

## Worked example: derive and check the service posterior

Use Beta(2,2) as an illustrative prior. It expresses uncertainty centred at one half; it is not claimed to encode measured service knowledge. Multiplication gives

$$p(\theta\mid y)\propto
\theta^{\alpha-1+y}(1-\theta)^{\beta-1+n-y}.$$

Recognise the exponents as a beta density with updated shapes

$$a=\alpha+y,\qquad b=\beta+n-y.$$

Normalising the kernel gives

$$p(\theta\mid y)=\frac{\theta^{a-1}(1-\theta)^{b-1}}{B(a,b)}.$$

For 14 successes and 6 failures, $a=16$ and $b=8$. The prior and posterior belong to the same family, so the beta prior is **conjugate** to the binomial likelihood. This is a property of the algebra, not evidence that the prior is scientifically suitable.

We can also retain all constants and calculate the probability of the observed count:

$$p(y)=\binom ny\frac{B(\alpha+y,\beta+n-y)}{B(\alpha,\beta)}.$$

For positive integer shapes, $B(a,b)=(a-1)!(b-1)!/(a+b-1)!$. Here $B(16,8)\approx2.54938672\times10^{-7}$, and the count evidence is $15/253\approx0.05928854$. Dividing likelihood times prior by this evidence recovers the same normalised Beta(16,8) density. The evidence is a probability for the observed count under the prior model; it is not a probability that the model is true.

To derive moments rather than merely look them up, insert an extra power of $\theta$ into the beta integral:

$$E[\theta^r\mid y]=\frac{B(a+r,b)}{B(a,b)},\qquad r\geq0.$$

The recurrence $B(a+1,b)=aB(a,b)/(a+b)$ follows from beta-integral identities. Applying it once and twice yields

$$E[\theta\mid y]=\frac{a}{a+b},\qquad
E[\theta^2\mid y]=\frac{a(a+1)}{(a+b)(a+b+1)}.$$

Here is a way to establish that recurrence. Inside the beta integral, insert $1=t+(1-t)$ to obtain $B(a,b)=B(a+1,b)+B(a,b+1)$. Next integrate the derivative of $t^a(1-t)^b$ from zero to one. Its endpoint values vanish for positive shapes, giving $aB(a,b+1)=bB(a+1,b)$. Combining the two identities yields the recurrence. This argument also explains why the positivity conditions cannot simply be omitted: the endpoint behaviour is part of the derivation, not a technicality unrelated to normalisation.

Subtract the squared mean to obtain

$$\operatorname{Var}(\theta\mid y)=\frac{ab}{(a+b)^2(a+b+1)}.$$

Thus the service posterior mean is $16/24=2/3$, variance $2/225\approx0.00888889$, and standard deviation approximately 0.094281 on the probability scale. These quantify uncertainty about a parameter. They are not the variance and standard deviation of individual binary outcomes.

The posterior mean can also be written, for $n>0$, as

$$E[\theta\mid y]=\frac{\alpha+\beta}{\alpha+\beta+n}\frac{\alpha}{\alpha+\beta}
+\frac{n}{\alpha+\beta+n}\frac yn.$$

For this example it is $(4/24)(0.5)+(20/24)(0.7)=2/3$. The prior pulls the mean towards one half, while twenty observations receive more weight than the prior concentration of four. The distribution, not just this average, remains the result of inference.

---

Source: `course/chapters/02_beta_binomial.md:112–112`

**Retrieve without looking:** Why do successes increment one shape and failures the other? Which constant can be omitted while finding the posterior shape, and why must it return when calculating the count's evidence? Use [Appendix 2](../appendices/02_calculus.md) if the normalising integral is unfamiliar.

---

Source: `course/chapters/02_beta_binomial.md:114–122`

## Concentration and the meaning of prior information

Write $\kappa=\alpha+\beta$ and $\mu=\alpha/\kappa$, so $\alpha=\mu\kappa$ and $\beta=(1-\mu)\kappa$. The prior variance becomes $\mu(1-\mu)/(\kappa+1)$. At fixed mean, increasing concentration narrows uncertainty and gives the prior more weight in the posterior mean.

For example, Beta(2,2) and Beta(6,6) both centre on one half, but their prior variances are 0.05 and approximately 0.019231. With the service data, the latter produces Beta(20,12), with mean 0.625 instead of approximately 0.667. The likelihood has not changed; a more concentrated prior resists movement away from its centre.

Calling concentration a “prior sample size” is a useful description of this weighted-mean identity. It is not proof that someone observed that many previous visits. Interpreting shape parameters as literal historical counts requires specifying the earlier baseline prior and observation model. Counts added to a uniform prior, for example, shift its existing shape parameters as well.

Select priors before examining the same observations used in the likelihood, or explicitly model the process used to estimate them. Consider what probability ranges and future data patterns they imply. Conjugacy makes sensitivity comparisons easy, but cannot decide which assumptions suit the application. [Chapter 3](03_prediction.md) uses prior prediction to make those implications visible.

---

Source: `course/chapters/02_beta_binomial.md:124–142`

## Summaries, credible sets, and interpretation

The posterior mean minimises posterior expected squared error. To see why, expand $E[(d-\theta)^2\mid y]$ as $\operatorname{Var}(\theta\mid y)+(d-E[\theta\mid y])^2$. The median minimises expected absolute error. For $a,b>1$, the beta mode is $(a-1)/(a+b-2)$; for Beta(16,8) it is approximately 0.681818. Different summaries are appropriate to different questions and losses.

The median's role also has an intuitive explanation. Moving a proposed estimate slightly to the right decreases absolute error for parameter values to its right and increases it for values to its left. Those effects balance when half the posterior mass lies on each side. Squared error instead gives greater influence to large misses, which pulls the optimum towards a long tail. Reporting a mean or median therefore embeds a choice about how estimation errors matter, even before a larger operational decision is considered.

An equal-tailed 90% credible interval leaves 5% probability below its lower endpoint and 5% above its upper endpoint. For the service posterior it is approximately $[0.503565,0.813656]$. The probability of exceeding one half is approximately 0.953430. These are distinct summaries: a range containing specified posterior mass and the mass above a particular target.

```python
from scipy.stats import beta
interval = beta.ppf([0.05, 0.95], 16, 8)
probability = beta.sf(0.5, 16, 8)
```

The interval has 90% posterior probability conditional on this prior, likelihood, and dataset. It is not a statement about 90% of future visit outcomes, nor a guarantee that the model is appropriate. A frequentist 90% confidence procedure instead describes coverage across repeated samples under its assumptions. Credible intervals may have good or poor repeated-sampling coverage; the definitions are not interchangeable.

A credible **set** need not be an interval. A highest-density set includes parameter values above a suitable density threshold; it may be disconnected for a multimodal posterior. For a skewed unimodal density, a highest-density interval can be shorter than the equal-tailed interval. The shortest interval is not automatically the best communication choice: its parameterisation and definition must be stated.

Under a monotone increasing transformation, transformed endpoints preserve an equal-tailed interval's probability and tail allocation. A decreasing transformation reverses their order. Highest-density sets generally do not transform this way because density heights change with the Jacobian. Quantiles concern probability mass; modes and density thresholds depend on the chosen scale.

---

Source: `course/chapters/02_beta_binomial.md:144–166`

## Worked example: no successes, skewness, and sensitivity

A separate pilot records zero successes in six independent trials with one common unknown success probability. Compare three proper priors centred at one half. They represent progressively stronger starting concentration, not three equally justified beliefs about every pilot.

| Prior | Posterior | Posterior mean | Equal-tailed 90% interval |
|---|---|---:|---:|
| Beta(1,1) | Beta(1,7) | 0.125000 | [0.007301, 0.348164] |
| Beta(2,2) | Beta(2,8) | 0.200000 | [0.041023, 0.429136] |
| Beta(10,10) | Beta(10,16) | 0.384615 | [0.235586, 0.543933] |

Each row adds zero to the first shape and six to the second. The posterior means follow by dividing the first updated shape by their sum. Six failures have substantial influence, but cannot make a continuous proper prior collapse to certainty at zero. The concentrated prior gives a much higher posterior mean; retaining it would require substantive support for strong prior confidence near one half.

The first row can be checked without numerical integration. Beta(1,7) has density $7(1-\theta)^6$ and cumulative distribution

$$F(\theta)=1-(1-\theta)^7.$$

Solving $F(q)=p$ gives $q=1-(1-p)^{1/7}$. The median is approximately 0.094276, below the mean 0.125 because the posterior has a long right tail. Its density reaches its maximum at the boundary zero, yet the probability of exactly zero is still zero.

Because this density decreases throughout its support, its highest-density 90% interval is $[0,1-0.1^{1/7}]\approx[0,0.280314]$. This differs from the equal-tailed interval in the table. Both have the stated posterior mass; they allocate the excluded probability differently. Zero successes alone does not choose between these reporting conventions.

Transform the first row's equal-tailed interval to odds $o=\theta/(1-\theta)$. Applying the transformation to both endpoints gives approximately $[0.007355,0.534127]$, still containing 90% posterior probability. Transforming a mean by the same formula does not generally give the mean of transformed values, because nonlinear functions do not commute with averaging.

For a sharper counterexample, let $z=\log[\theta/(1-\theta)]$. Its density is $p_z(z)=p_\theta(\theta)\theta(1-\theta)$, since $d\theta/dz=\theta(1-\theta)$. For Beta(1,7), this is proportional to $\theta(1-\theta)^7$, maximised at $\theta=1/8$, or $z\approx-1.94591$. The log-odds density therefore has an interior mode even though the probability-scale density peaks at zero. A density peak is not an invariant probability statement.

---

Source: `course/chapters/02_beta_binomial.md:168–181`

## Sequential updating and sufficiency

Return to the service data. Observing 6 successes in ten visits and then 8 in ten visits gives Beta(8,6) followed by Beta(16,8). Combining all observations first gives the same result. The likelihood factors across batches because they share one fixed $\theta$ and outcomes are conditionally independent. Reusing the original prior for each batch and then multiplying the two posterior densities would count the prior twice.

Within this model, the total success count is **sufficient** for $\theta$: knowing the order adds no parameter information beyond the count. Ordering can nevertheless challenge the model. Fourteen consecutive successes followed by six failures has the same count as an interspersed sequence, but may suggest changing conditions. Sufficiency within a model does not make the discarded information irrelevant to checking that model.

If the batches concern different services or a changed process, carrying one posterior forward as though nothing changed needs justification. A dynamic or hierarchical model may be more appropriate. Sequential coherence is a property of a consistent probability model, not permission to ignore changes in the data-generating process.

Two limiting checks help audit an implementation. With no observations, both added counts are zero and the posterior must equal the prior. With many independent observations whose success fraction stays away from the boundaries, fixed prior concentration receives progressively less weight, and parameter uncertainty decreases. Neither check authorises duplicating existing records to increase the count: copied outcomes do not create independent likelihood factors. A narrow posterior obtained from such duplication can be numerically correct for the supplied array and scientifically misleading.

Also distinguish robustness to a prior from robustness to the observation model. Two reasonable beta priors may give similar answers in a large dataset while both analyses retain the same unrepresentative sample or omitted clustering. A sensitivity table should say which assumptions were varied and which were held fixed. Agreement across its rows only answers the comparison actually performed.


<!-- VISUAL01:04 BEGIN -->

---

Source: `course/chapters/02_beta_binomial.md:183–203`

### Visual investigation: normalise each update and count each batch once

A new synthetic sequence starts at $\operatorname{Beta}(2,2)$. The first batch contains three successes in four trials; a separate second batch contains two successes in three. Predict whether reversing the batch order changes the final posterior under a single shared parameter.

![Beta densities progress from Beta(2,2) to Beta(5,3) to Beta(7,4); pooling five successes and two failures reaches the same final density.](../../artifacts/figures/visual01_04_sequential.svg)

**Read the figure.** The horizontal coordinate is that common probability and the vertical coordinate is density per unit probability. Dotted, dashed and solid curves identify successive stages even without colour. Every curve has area one; an increased peak is not extra total probability.

| Available information | Posterior | Mean |
|---|---|---:|
| Prior only | Beta(2,2) | 0.500000 |
| First batch only | Beta(5,3) | 0.625000 |
| Both distinct batches | Beta(7,4) | 0.636364 |

**Mathematical connection.** Multiplying the first density by the Binomial likelihood and dividing by $P(Y_1=3)=8/35$ gives the second curve. The conditional evidence of the second count is $P(Y_2=2\mid Y_1=3)=3/8$. Updating that second density gives the solid curve. The exponents accumulate as successes and failures: $2+3+2=7$ and $2+1+1=4$. Pooling the data therefore gives the same parameter posterior.

The evidence of two separately recorded batch counts is not the evidence of only their pooled count: the sample spaces have different combinatorial factors. Also, adding the old first batch to the already updated prior would count that information twice.

**Original unscored exploration — predict, observe, explain.** Reverse the two batches on paper and observe the same final parameters. Explain why this relies on a shared parameter and conditional independence, then name a time-varying mechanism under which simple pooling would be questionable. This is an analytic identity, not a demonstration that real batches are exchangeable.

<!-- VISUAL01:04 END -->

---

Source: `course/chapters/02_beta_binomial.md:205–237`

## Grid inference: densities become cell masses

Divide zero to one into cells with widths $\Delta_j$ and midpoints $\theta_j$. Approximate the posterior mass in each cell by

$$w_j=\frac{p(\theta_j)p(y\mid\theta_j)\Delta_j}
{\sum_k p(\theta_k)p(y\mid\theta_k)\Delta_k}.$$

These weights sum to one; density heights generally do not. Equal widths cancel from the ratio, which can hide the distinction. Midpoints also avoid evaluating beta log densities exactly at endpoints, but do not automatically resolve a sharp boundary peak. Refinement and an independent reference remain necessary.

On an unequal grid, stable computation includes the widths in the log weights:

```python
import numpy as np
from scipy.stats import beta, binom
edges = np.linspace(0, 1, 101) ** 2
widths = np.diff(edges)
grid = (edges[:-1] + edges[1:]) / 2
logw = beta.logpdf(grid, 2, 2) + binom.logpmf(14, 20, grid)
logw = logw + np.log(widths)
w = np.exp(logw - logw.max())
w = w / w.sum()
mean = grid @ w
fraction_above_half = np.clip((edges[1:] - 0.5) / widths, 0, 1)
probability = w @ fraction_above_half
```

The fraction allocates a threshold-crossing cell in proportion to the part above one half, treating its density as constant at the midpoint approximation. This avoids assigning the entire crossing cell to one side. It still has quadrature error because the true density varies inside the cell.

For the service posterior, this 100-cell grid gives mean approximately 0.666667 and probability above one half approximately 0.953239, compared with the exact 0.953430. With 5,000 cells the tail estimate is approximately 0.95343007. Omitting widths from the 100-cell grid gives a mean approximately 0.659574: the greater density of grid points near zero has accidentally changed the represented measure.

A mean agreeing closely with theory does not establish accurate tail probabilities. On an equal-width 20-cell midpoint grid, the mean is already approximately 0.666667, while summing cells above one half gives approximately 0.954989. Always check the requested quantity as resolution increases. Boundary singularities and small tail masses can demand more care than central averages; [Appendix 4](../appendices/04_numerics.md) develops those numerical checks.

**Retrieve without looking:** Why must an unequal grid include widths? Why can a transformed credible interval retain its mass while losing the highest-density property? Use the area interpretation from [Chapter 0](00_preparation.md) to connect these two questions.

---

Source: `course/chapters/02_beta_binomial.md:239–243`

## Lab

Run [Lab 2](../../notebooks/02_beta_binomial.ipynb), or [Python](../../labs/02_beta_binomial.py). Its [density plot](../../artifacts/figures/02_update.svg) shows the prior and posterior on the same probability scale. Compare grid sizes, sequential updates, and prior choices. Report a mean, a clearly labelled 90% interval, and a probability relevant to a service target.

The supplied lab saves the probability above one half; exercise 2.3 asks about a different threshold. Record thresholds explicitly so a correct number cannot be attached to the wrong question. Report resolution and error against the analytic reference alongside any plotted approximation. The unequal-grid calculation above is an additional investigation, not a claim about what the supplied lab already saves.

---

Source: `course/chapters/02_beta_binomial.md:245–247`

## Summary

Beta-binomial conjugacy follows by multiplying powers and normalising with a beta integral. The posterior mean balances data and prior concentration, while the full distribution carries uncertainty and skewness. Credible sets describe parameter uncertainty conditional on a model. Sequential updates agree when the shared-parameter assumptions agree. Grids approximate probability mass using density and cell width; their accuracy must be checked for the particular summary being reported.

---

Source: `course/chapters/02_beta_binomial.md:249–257`

## Exercises

**2.1 — Concept.** A colleague says the 90% credible interval contains 90% of future visit outcomes. Explain the error, including the possible values of one future outcome.

**2.2 — Derivation.** Under Beta(3,7), observe 12 successes in 20 trials. Derive the posterior and its mean. Express the mean as a weighted average.

**2.3 — Computation.** For Beta(16,8), estimate $P(\theta>0.7)$ using a 100-point midpoint grid and SciPy's survival function. Increase grid resolution and discuss the discrepancy.

[Solutions](../solutions.md) follow an independent attempt.

---

Source: `course/chapters/02_beta_binomial.md:259–261`

## Further reading

[Allen Downey's Think Bayes, estimating proportions](https://allendowney.github.io/ThinkBayes2/chap04.html) offers a computational continuation on learning probabilities. The linked mathematical appendices support the normalisation, transformation, and numerical arguments used here.

---

Source: `course/chapters/03_prediction.md:1–3`

# 3 · Predict outcomes and choose actions

**Prerequisites:** [Chapter 2](02_beta_binomial.md), conditional expectation, and variance. [Appendix 1](../appendices/01_probability.md) supports conditioning; [Appendix 2](../appendices/02_calculus.md) supports integration. **Objectives:** distinguish prior from posterior prediction; propagate parameter uncertainty; elicit priors through observable consequences; minimise expected loss; derive predictive mass, variance, and dependence between future trials.

---

Source: `course/chapters/03_prediction.md:5–15`

## A probability estimate is not a forecast of a count

Our fictional service has posterior completion probability $\theta\mid y\sim\operatorname{Beta}(16,8)$ after 14 completions in 20 visits under a Beta(2,2) prior. A manager asks how many of the next 20 visits will finish on time. Answering $20(2/3)=13.33$ gives an expected count. It does not describe the spread or the chance of missing a target. An expectation need not be a possible realised count.

First specify what “next” means. Assume the future visits follow the same process as the observed visits, with one common probability and independence conditional on that probability. Changing staff, eligibility, or recording could break that connection. Integrating uncertainty under the old model cannot by itself account for an unmodelled change in the service.

Two sources of variation matter. We are uncertain about $\theta$, and even at a known $\theta$, different batches have different counts. The posterior predictive distribution averages the sampling distribution over the posterior:

$$p(\tilde y\mid y)=\int p(\tilde y\mid\theta)p(\theta\mid y)\,d\theta.$$

The tilde marks a future or replicated outcome; $y$ remains the observed data. This factorisation assumes future and observed outcomes are independent conditional on the shared parameter. With temporal dependence, the conditional predictive model may also depend directly on past observations. In either case, define the target before integrating.

---

Source: `course/chapters/03_prediction.md:17–32`

## Derive the beta-binomial prediction

Let $\theta\mid y\sim\operatorname{Beta}(a,b)$, with positive shapes, and $\tilde Y\mid\theta\sim\operatorname{Binomial}(m,\theta)$ for a fixed nonnegative integer batch size. For $k=0,\ldots,m$,

$$\begin{aligned}
P(\tilde Y=k\mid y)
&=\int_0^1\binom mk\theta^k(1-\theta)^{m-k}
\frac{\theta^{a-1}(1-\theta)^{b-1}}{B(a,b)}\,d\theta\\
&=\binom mk\frac{B(a+k,b+m-k)}{B(a,b)}.
\end{aligned}$$

Recognise the integral as the beta normalising integral from chapter 2. This is the **beta-binomial** mass function. The binomial coefficient must stay: it distinguishes the probabilities of different counts. To verify normalisation, sum inside the integral. The conditional binomial masses sum to one for every parameter value, leaving the integral of the posterior density, also one.

For the service, use $a=16,b=8,m=20$. The expected count is 13.3333, but the probability of fewer than 12 completions is approximately 0.251683. Substituting the posterior mean into a binomial gives approximately 0.190549 for the same event. This discrepancy matters if the service schedules extra support when shortfalls are likely. Agreement on an expected count does not imply agreement on operational risk.

The predictive distribution is discrete. Its 5th and 95th percentile endpoints are 8 and 18, and the inclusive interval actually contains about 95.67% probability. We cannot generally obtain exactly 90% by choosing whole-count endpoints. Label the requested quantiles and the achieved mass rather than silently treating a discrete interval as continuous.

---

Source: `course/chapters/03_prediction.md:34–63`

## Work out both layers of predictive variation

Write $K=a+b$, $q=E[\theta\mid y]=a/K$, and $v=\operatorname{Var}(\theta\mid y)=ab/[K^2(K+1)]$. Iterated expectation gives

$$E[\tilde Y\mid y]=E[m\theta\mid y]=mq.$$

The law of total variance separates average conditional variability from variability of conditional averages:

$$\operatorname{Var}(\tilde Y\mid y)
=E[\operatorname{Var}(\tilde Y\mid\theta)\mid y]
+\operatorname{Var}(E[\tilde Y\mid\theta]\mid y).$$

Here the two terms are $mE[\theta(1-\theta)\mid y]$ and $m^2v$. Since $E[\theta^2\mid y]=q^2+v$, the first term is $m[q(1-q)-v]$. Substituting the beta moments gives

$$\begin{aligned}
E[\operatorname{Var}(\tilde Y\mid\theta)\mid y]&=\frac{mab}{K(K+1)},\\
\operatorname{Var}(E[\tilde Y\mid\theta]\mid y)&=\frac{m^2ab}{K^2(K+1)},\\
\operatorname{Var}(\tilde Y\mid y)&=\frac{mab(K+m)}{K^2(K+1)}.
\end{aligned}$$

For the service these components are approximately 4.26667 and 3.55556, adding to 7.82222, or about 7.82. The plug-in binomial variance is $20(2/3)(1/3)=4.44444$, or about 4.44. Notice that its variance is slightly larger than the first component alone. Adding the second component to the plug-in variance would double-count part of the uncertainty; total variance requires the *average conditional variance*.

An equivalent expression is

$$\operatorname{Var}(\tilde Y\mid y)=mq(1-q)+m(m-1)v.$$

This explains why the plug-in answer is exact for a single Bernoulli outcome: when $m=1$, the additional term vanishes. A mixture of Bernoulli distributions is another Bernoulli distribution with the averaged probability. For a batch, the shared uncertain probability creates dependence that a plug-in binomial omits.


<!-- VISUAL01:05 BEGIN -->

---

Source: `course/chapters/03_prediction.md:65–91`

### Visual investigation: shared parameter uncertainty widens a batch forecast

For a separate illustrative posterior $p\mid D\sim\operatorname{Beta}(3,2)$, forecast eight new binary outcomes sharing that probability. Predict whether replacing $p$ by its mean 0.6 preserves the spread of the future total.

![Exact count masses compare a Beta(3,2) mixture for eight future trials with a Binomial at probability 0.6; the mixture has more tail mass.](../../artifacts/figures/visual01_05_prediction.svg)

**Read the figure.** Horizontal positions are possible integer counts; bar heights are probability masses, not density heights. Solid bars integrate one common uncertain probability for the batch. Hatched bars fix it at 0.6. Both distributions sum to one and have mean 4.8, but their tails differ.

| Future K | Full predictive mass | Plug-in mass |
|---:|---:|---:|
| 0 | 0.018182 | 0.000655 |
| 1 | 0.048485 | 0.007864 |
| 2 | 0.084848 | 0.041288 |
| 3 | 0.121212 | 0.123863 |
| 4 | 0.151515 | 0.232243 |
| 5 | 0.169697 | 0.278692 |
| 6 | 0.169697 | 0.209019 |
| 7 | 0.145455 | 0.089580 |
| 8 | 0.090909 | 0.016796 |

**Mathematical connection.** Total variance gives $8E[p(1-p)]+8^2\operatorname{Var}(p)=4.16$, versus $8(0.6)(0.4)=1.92$ for the plug-in model. The tail $P(K\ge7)$ is 0.236364 versus 0.106376. Shared uncertainty makes future indicators positively dependent after integrating out $p$. Drawing a fresh independent probability for every item would describe a different joint model.

**Original unscored exploration — predict, observe, explain.** Increase concentration from five to twenty at the same mean, giving Beta(12,8). Predict the direction, then observe that predictive variance becomes 2.56 while the mean remains 4.8. Explain why one future trial has the same Bernoulli prediction under both treatments but a batch need not. These are conditional forecasts under exchangeability, not evidence of actual batch heterogeneity. Rounded table entries need not sum to exactly one.

[Open the guided prediction experiment](../../explorer.html#visual-prediction) to predict, change one setting, and explain the result.

<!-- VISUAL01:05 END -->

---

Source: `course/chapters/03_prediction.md:93–101`

## Why the variance decomposition works

**Extended route.** Total variance is useful beyond the binomial model, so derive it once without a named distribution. Let $M(\theta)=E[\tilde Y\mid\theta,y]$ and $\bar M=E[\tilde Y\mid y]$. Subtract the overall mean and split the deviation:

$$\tilde Y-\bar M=(\tilde Y-M(\theta))+(M(\theta)-\bar M).$$

Squaring creates two squared terms and a cross term. The first squared term measures how an outcome differs from its conditional mean. The second measures how the conditional mean differs from the overall mean. Conditional on the parameter, the first deviation has expectation zero, while the second is a fixed number. Their product therefore has zero conditional expectation, and hence zero posterior expectation. Averaging the squared terms gives exactly the two components of total variance, assuming finite second moments.

This reasoning explains why the terms are variances rather than standard deviations. Standard deviations cannot simply be added. It also makes the decomposition specific to the chosen conditioning information: if the model included uncertain staffing, weather, or instrument calibration, averaging over those variables could introduce further layers. “Two layers” describes the current generative model; it is not a claim that every source of real-world uncertainty has been represented. The integral propagates the uncertainties supplied to it.

---

Source: `course/chapters/03_prediction.md:103–125`

## Conditional independence does not imply marginal independence

Let $X_i$ indicate completion on future visit $i$. At a fixed $\theta$, different $X_i$ are independent. Averaging over $\theta$ gives, for distinct visits,

$$E[X_iX_j\mid y]=E[\theta^2\mid y],\qquad
\operatorname{Cov}(X_i,X_j\mid y)=v.$$

Their marginal variances are $q(1-q)$, so their predictive correlation is $v/[q(1-q)]=1/(K+1)$. For Beta(16,8), covariance is approximately 0.008889 and correlation is 0.04. The probability both visits complete is $16\times17/(24\times25)=0.453333$, larger than the product of their marginal probabilities, $4/9\approx0.444444$.

This dependence does not say that one visit physically causes another to complete. A completion provides information about their shared probability. If the first future visit succeeds, updating gives Beta(17,8), and the next success probability becomes $17/25=0.68$ rather than $2/3$. This sequential prediction produces the same joint probabilities as integrating the whole batch at once.

For each simulated batch, therefore, draw one posterior parameter and then a complete conditional batch:

```python
import numpy as np
rng = np.random.default_rng(303)
theta = rng.beta(16, 8, size=60000)
future = rng.binomial(20, theta)
```

Drawing a fresh independent parameter for every visit instead removes the shared uncertainty. Integrating that different model gives independent Bernoulli outcomes and a binomial count with probability $q$. Independent visit-specific probabilities could be a defensible model if visits really have independently drawn latent propensities from a known population distribution. It is not the same uncertainty statement as one common unknown service probability. Unknown population-level parameters could introduce dependence again.

**Retrieve without looking:** Why can two simulations agree on each visit's completion probability and disagree on the batch variance? Explain the conditional bar before writing a formula.

---

Source: `course/chapters/03_prediction.md:127–137`

## Forecasting several batches together

**Extended route.** Suppose a manager needs a joint forecast for two future shifts, each with twenty visits, and assumes the same probability applies to both. Draw one posterior probability for a simulated future world, then draw both shifts conditionally on it. Drawing separate posterior probabilities for the two shifts changes the joint forecast even though each shift's marginal histogram still looks correct.

For counts $Y_1,Y_2$ in batches of sizes $m_1,m_2$, conditional independence gives

$$\operatorname{Cov}(Y_1,Y_2\mid y)=m_1m_2v.$$

For two twenty-visit shifts the covariance is approximately 3.55556. Their combined count has variance $2(7.82222)+2(3.55556)\approx22.75556$, agreeing with the beta-binomial formula for forty visits. Independently simulating the two marginal predictions would omit the covariance and understate uncertainty in their total. This is especially consequential when staff or reserves must cover the combined workload.

The right sharing structure follows the scientific model. If shifts have distinct probabilities, a model must explain how those probabilities are related and what past data inform each one. Chapter 9 develops that extension. For now, list which future observations share a parameter before writing a simulation loop. A collection of correct one-dimensional forecasts does not necessarily constitute a correct joint forecast. Pairing unrelated draws after simulation can lose the dependence needed to answer questions about totals, maxima, or simultaneous shortfalls.

---

Source: `course/chapters/03_prediction.md:139–159`

## Prior prediction makes assumptions observable

Before using observations, draw from the prior and then the likelihood:

$$p(\tilde y)=\int p(\tilde y\mid\theta)p(\theta)\,d\theta.$$

These are **prior predictive** draws. They turn a distribution over an abstract probability into possible batches a domain expert can inspect. Use the intended population, exposure, and batch size: a prior that seems reasonable for a small pilot may imply surprising patterns for a large deployment.

For 20 trials, consider the extreme event of at most two or at least eighteen successes. Three symmetric priors all have expected count ten, yet imply quite different probabilities:

| Prior for the probability | Probability of an extreme batch |
|---|---:|
| Beta(1,1) | 0.285714 |
| Beta(20,20) | 0.003211 |
| Beta(0.5,0.5) | 0.478372 |

Under Beta(1,1), inserting the factorial expressions for the beta functions gives $P(\tilde Y=k)=1/(m+1)$. Every count is equally likely. Beta(20,20) concentrates the underlying probability near one half, while Beta(0.5,0.5) makes near-boundary probabilities much more plausible. None is empty of assumptions; equal means hide consequential differences.

Elicitation can begin with a plausible central probability and ranges for observable counts. Ask whether almost-all-failure or almost-all-success batches should occur often, then inspect candidate priors rather than forcing one family to match every statement. Disagreement may expose a missing grouping or time variable rather than a badly chosen concentration.

If the current data informed a revision, disclose that dependence. Repeatedly adapting a prior to the same observed count and then treating it as independent knowledge overstates the evidence. Prior predictive checks can motivate a transparent revised analysis; sensitivity analysis reports how defensible alternatives change the conclusions that matter.

---

Source: `course/chapters/03_prediction.md:161–182`

## From inference to a decision

Suppose a temporary intervention costs 2 units regardless of $\theta$. Leaving the service unchanged incurs loss 10 if $\theta<0.6$, otherwise zero. These stipulated losses make the calculation visible. They do not establish that a real intervention works or that all consequences can be represented by one monetary amount.

For action $d$, posterior expected loss is

$$\rho(d\mid y)=\int L(d,\theta)p(\theta\mid y)\,d\theta.$$

Under Beta(16,8), $P(\theta<0.6\mid y)\approx0.237271$. The action comparison is therefore:

| Action | Loss when below target | Loss otherwise | Posterior expected loss |
|---|---:|---:|---:|
| Intervene | 2 | 2 | 2 |
| Leave | 10 | 0 | 2.372709 |

Choose intervention under this model and loss table. More generally, at cost $c$, intervene when $c<10P(\theta<0.6\mid y)$. The break-even cost is approximately 2.372709; equality gives indifference. At cost 3 the preferred action changes although the evidence is unchanged. The probability threshold of 0.2 at cost 2 comes from consequences, not a universal evidential standard.

This loss concerns an underlying parameter. The event $\theta<0.6$ is different from fewer than 12 completions in the next batch. A contract paying out on a realised count requires predictive expected loss, $\sum_k L(d,k)P(\tilde Y=k\mid y)$. Define actions, horizon, affected population, and units before calculating an optimum. If the action changes outcomes, the predictive model must represent those action-specific consequences.

Expected loss is an average over current uncertainty, not a promise about the realised loss. Leaving the service unchanged yields either zero or ten under the stipulated table, never 2.372709. An intervention selected by expected loss can look unnecessary afterwards if the service was already above target. That observation alone does not show the decision was irrational given the information available when it was made.

Conversely, a lucky outcome does not validate a poorly specified decision model. Review the information and consequences used at decision time, as well as what later happened. If stakeholders particularly dislike rare severe harms, represent that preference in the loss function; do not hide it by demanding an arbitrary posterior probability threshold. A richer loss could also vary continuously with the shortfall or include uncertain intervention efficacy. In that case compute the loss for each possible state and action before averaging. Applying a nonlinear loss only to the posterior mean generally answers a different question. Chapter 12 develops such decisions and the value of collecting more information.

---

Source: `course/chapters/03_prediction.md:184–200`

## Worked example: equipment failures and a reserve crew

Consider a separate fictional equipment test. Ten pumps will each attempt one start. Given a common failure probability $q$, starts fail independently. A reserve crew costs 3 loss units and, by assumption, removes a disruption penalty of 20 units incurred if at least four pumps fail. This is a simplified capacity decision, not an estimate of crew effectiveness.

Before collecting a pilot, compare Beta(2,8) and Beta(20,80) priors for $q$. Both imply two expected failures, but the latter expresses more certainty about a failure probability near 0.2. Let $F$ be the number of failures. Evaluate the beta-binomial tail by summing its first four masses and subtracting from one:

$$P(F\geq4)=1-\sum_{k=0}^3\binom{10}{k}
\frac{B(a+k,b+10-k)}{B(a,b)}.$$

| Prior | Predictive variance of $F$ | $P(F\geq4)$ | Loss without crew | Loss with crew | Choice |
|---|---:|---:|---:|---:|---|
| Beta(2,8) | 2.909091 | 0.184211 | 3.684211 | 3 | Crew |
| Beta(20,80) | 1.742574 | 0.130797 | 2.615933 | 3 | No crew |

Thus prior prediction can change an action even when prior means agree. The decision threshold is $P(F\geq4)>3/20=0.15$. A useful elicitation conversation concerns which tail probabilities the engineering team finds credible, not which prior gives its preferred decision.

Now observe two failures in ten comparable pilot starts. Updating the first prior gives Beta(4,16); the next batch still has expected failures two, but $P(F\geq4)\approx0.160620$. Expected loss without the crew is approximately 3.212394, so the crew remains preferred. Its maximum justifiable cost has fallen from about 3.68 to 3.21. Even a pilot exactly matching the prior mean can change a decision's margin by reducing uncertainty. These calculations assume the pilot and deployment share the same failure probability.

---

Source: `course/chapters/03_prediction.md:202–215`

## Limits and model failures

**Extended route.** Holding the posterior fixed and increasing future batch size does not provide new information about the parameter. For the future proportion,

$$\operatorname{Var}(\tilde Y/m\mid y)=\frac{q(1-q)}m+
\frac{m-1}{m}v\longrightarrow v.$$

Conditional sampling noise averages away while uncertainty about the shared probability remains. By contrast, gathering more relevant observations can concentrate the posterior and reduce $v$. More simulated draws only improve numerical accuracy; [chapter 5](05_monte_carlo.md) develops that separate uncertainty.

At $m=0$ the predicted count is certainly zero. As posterior variance approaches zero with its mean fixed, the predictive distribution approaches a binomial. Positive beta shapes still allow failures after all observed trials succeed, and successes after all fail. Very small shapes can create extreme predictions without assigning exact probability atoms at zero or one.

Posterior predictive overdispersion relative to a plug-in binomial arises here from parameter uncertainty. It does not prove the model accommodates physical clustering. Pumps sharing a power supply could fail together even at a known failure probability, violating conditional independence. Service visits could vary systematically by shift. More observations under a misspecified model may narrow parameter uncertainty while leaving these failures untreated.

Prediction also supports checking: simulate replicated datasets with the observed shape and compare relevant patterns, such as extremes, group differences, or runs over time. A plausible total count can hide implausible ordering. Replicated-data checks reuse observations to fit and inspect the model; they are not untouched predictive tests. [Chapter 10](10_model_checking.md) separates those purposes.

---

Source: `course/chapters/03_prediction.md:217–221`

## Lab

Run [Lab 3](../../notebooks/03_prediction.ipynb), or [Python](../../labs/03_prediction.py), and inspect the [predictive comparison](../../artifacts/figures/03_predictive.svg). The supplied lab simulates the shared-parameter forecast and a plug-in comparison, then evaluates the original service loss. Compare empirical mean and variance with the exact results; finite simulations need not reproduce every decimal.

For your investigation, compute the shortfall probability as both an indicator average and a sum of exact masses. Repeat after independently redrawing the parameter for each trial. Which summaries remain similar, and which expose the changed model? Compare the three prior predictive extreme-batch probabilities and submit a loss table under two intervention costs. As an optional transfer, reproduce the pump decision and state what evidence would justify sharing a probability across starts. These are extensions to the supplied lab, not additional saved outputs it already produces.

---

Source: `course/chapters/03_prediction.md:223–225`

## Summary

A predictive distribution combines parameter uncertainty with variation in outcomes conditional on parameters. Shared uncertain parameters make future observations dependent after integration. Total variance separates the two layers and explains why plug-in forecasts can miss batch risk. Prior prediction expresses assumptions through observables; expected loss turns those predictions or parameter probabilities into decisions with explicit consequences.

---

Source: `course/chapters/03_prediction.md:227–235`

## Exercises

**3.1 — Concept.** For future Bernoulli visits conditionally independent given one shared completion probability $\theta$, why does drawing a fresh independent $\theta$ from its posterior for every visit change the model for a batch? When might such a model be appropriate?

**3.2 — Calculation.** For a Beta(3,2) posterior and five future trials, calculate predictive mean and variance. Compare with the plug-in binomial variance.

**3.3 — Decision.** Suppose $P(\theta<0.6\mid y)=0.18$. An intervention costs 2, and failure to act costs 15 when the target is missed. Select an action and find the largest intervention cost at which you are indifferent.

[Solutions](../solutions.md).

---

Source: `course/chapters/03_prediction.md:237–239`

## Further reading

Allen Downey's [Think Bayes, decision analysis](https://allendowney.github.io/ThinkBayes2/chap09.html) develops action selection from distributions and consequences. Martin, Kumar, and Lao's [Bayesian Modeling and Computation, complete workflow](https://bayesiancomputationbook.com/markdown/chp_09.html) connects predictions, model checking, and decisions in a longer analysis. Our service and pump examples are original fictional teaching examples.

---

Source: `course/chapters/04_continuous.md:1–3`

# 4 · Model rates and continuous measurements

**Prerequisites:** [Chapters 2](02_beta_binomial.md) and [3](03_prediction.md), exponentials, and completing a square. [Appendix 2](../appendices/02_calculus.md) supports integration and transformations. **Objectives:** derive gamma-Poisson and normal-normal posteriors; handle exposure and units; distinguish marginal from conditional uncertainty; derive integrated predictions; check transformations, scale uncertainty, and posterior propriety.

---

Source: `course/chapters/04_continuous.md:5–16`

## Counts need an opportunity to occur

Two service centres report four incidents each. One operated for one hour, the other for ten. Equal counts do not establish equal rates. What should we predict for a centre operating another two hours? We need a model connecting the number of opportunities to the observed count, then must integrate uncertainty about its rate.

Let $t_i\geq0$ denote known exposure and $\lambda>0$ the common event rate per exposure unit. Assume

$$Y_i\mid\lambda\sim\operatorname{Poisson}(t_i\lambda),\qquad
p(y_i\mid\lambda)=\frac{(t_i\lambda)^{y_i}e^{-t_i\lambda}}{y_i!}.$$

Counts are nonnegative integers. Conditional independence, a constant rate over these exposures, and conditional Poisson dispersion are substantive assumptions. Mean and variance both equal $t_i\lambda$ at a fixed rate. The product is dimensionless as a count expectation; changing the exposure unit must change the numerical rate reciprocally.

Exposure may mean machine-hours, monitored area, or person-time, depending on the question. Calendar time while a machine is switched off need not be time at risk. If recording only covers half a shift, the model needs the monitored exposure or an explicit detection model. One row in a file is a storage unit, not a measure of opportunity.

---

Source: `course/chapters/04_continuous.md:18–42`

## Derive the gamma-Poisson update

For positive exposures, multiplying independent likelihood contributions gives

$$p(y\mid\lambda)=\left(\prod_i\frac{t_i^{y_i}}{y_i!}\right)
\lambda^{C}e^{-T\lambda},\qquad C=\sum_i y_i,\quad T=\sum_i t_i.$$

The bracketed factor does not depend on the rate, so it can be dropped when identifying the posterior kernel. Adopt a gamma prior in **shape-rate** form:

$$p(\lambda)=\frac{b^a}{\Gamma(a)}\lambda^{a-1}e^{-b\lambda},
\qquad a,b>0,\quad\lambda>0.$$

Here $\Gamma(a)=\int_0^\infty u^{a-1}e^{-u}\,du$ is the gamma function. Substitution $u=b\lambda$ verifies the normalising constant. The mean is $a/b$ and variance is $a/b^2$. Multiplication adds powers and exponential rates:

$$p(\lambda\mid y)\propto\lambda^{a+C-1}e^{-(b+T)\lambda},
\qquad\lambda\mid y\sim\operatorname{Gamma}(a+C,b+T).$$

Write $A=a+C$ and $B=b+T$ for the posterior shape and rate. The shape is dimensionless; $b$ and $B$ have exposure units, making their products with the event rate dimensionless. The gamma distribution's “rate parameter” is not the event rate $\lambda$. Naming both and recording their units prevents a particularly easy mistake.

For $T>0$, the posterior mean can be written

$$\frac{a+C}{b+T}=\frac{b}{b+T}\frac ab+
\frac{T}{b+T}\frac CT.$$

It averages the prior mean rate and observed rate with weights determined by prior and observed exposure. Calling $b$ a prior exposure is an interpretation of this identity, not proof that historical observations actually existed. A domain justification is still required.

---

Source: `course/chapters/04_continuous.md:44–72`

## Worked example: incidents and future exposure

Observe counts 3, 5, and 4 across exposures 1, 2, and 1 hours. Then $C=12$ and $T=4$. Under Gamma(2,1), the posterior is Gamma(14,5), retaining the original lab calculation. Its mean is 2.8 events per hour, and its variance is 0.56 in squared events-per-hour units. The observed rate of 3 receives weight $4/5$; the prior mean of 2 receives weight $1/5$.

For a future exposure $u>0$, assume $\tilde Y\mid\lambda\sim\operatorname{Poisson}(u\lambda)$. Integrate rather than substitute the posterior mean:

$$\begin{aligned}
P(\tilde Y=k\mid y)
&=\frac{u^kB^A}{k!\Gamma(A)}\int_0^\infty
\lambda^{A+k-1}e^{-(B+u)\lambda}\,d\lambda\\
&=\frac{\Gamma(A+k)}{\Gamma(A)k!}
\left(\frac{B}{B+u}\right)^A
\left(\frac{u}{B+u}\right)^k.
\end{aligned}$$

This is a negative-binomial distribution, including noninteger positive $A$. Software conventions vary: in SciPy it is `nbinom(n=A, p=B/(B+u))`, with support on the future count $k$. Its parameter called `n` need not be an observed number of trials. The Poisson exposure model and the displayed mass, not the distribution's name alone, specify the intended prediction.

Total expectation and total variance give

$$E[\tilde Y\mid y]=uA/B,\qquad
\operatorname{Var}(\tilde Y\mid y)=uA/B+u^2A/B^2.$$

The first term is average conditional Poisson variance; the second is uncertainty in the conditional mean. Over two hours, the predictive mean is 5.6 and variance is $5.6+2.24=7.84$. A plug-in Poisson would have variance 5.6. The chance of no incidents is $(5/7)^{14}\approx0.008999$, rather than $e^{-5.6}\approx0.003698$. Extra spread can change probabilities at the low end as well as the high end.

Prior prediction uses exactly the same formulas with $a,b$ instead of $A,B$. Gamma(2,1) implies a two-hour count with mean 4 and variance 12. This is much more variable than Poisson(4), an observable implication to discuss before seeing the counts. A broad prior on the rate can imply many quiet intervals and occasional large totals; whether that is credible depends on the process.

The predictive negative-binomial variance does not change the conditional Poisson assumption. If the rate became known precisely, the second variance term would disappear. Actual clustering can persist even at a known long-run rate, for example when one breakdown triggers several recorded incidents. Such dependence requires a different observation model. A mixture that represents ignorance about one common rate is not automatically a model of physical bursts.

Likewise, predictions for several future intervals should share a rate draw when the common-rate assumption applies. Their counts are independent at a fixed rate but correlated after integration. Summing separately generated independent marginal forecasts would lose that correlation. Preserve the model's shared variables when estimating the probability of a combined workload exceeding capacity.

---

Source: `course/chapters/04_continuous.md:74–90`

## Hours, minutes, rate, and scale

SciPy's gamma distribution takes **scale**, the reciprocal of the gamma rate. For Gamma(14,5), use `gamma(a=14, scale=1/5)`. Passing `scale=5` would give mean 70, not 2.8. Checking the implied mean is a simple way to detect a parameterisation error before trusting a plot.

Now express the same event rate per minute: $r=\lambda/60$. The exposure vector becomes $(60,120,60)$ minutes. Changing variables gives

$$p_r(r)=p_\lambda(60r)\,60,\qquad
r\sim\operatorname{Gamma}(a,60b).$$

Thus the prior becomes Gamma(2,60) and the posterior Gamma(14,300). Its mean is $14/300=0.046667$ events per minute and variance is $0.56/60^2$. The gamma scale also divides by 60. This is the same uncertainty in different units, not a new prior elicitation.

For a future 120-minute exposure, the mean remains $120(14/300)=5.6$, and both variance terms remain 5.6 and 2.24. Even the predictive mass is identical because $300/(300+120)=5/7$. Leaving the prior at Gamma(2,1) after converting the data would express a different prior rate of two events per minute. A units error can masquerade as scientific disagreement about the data.

**Retrieve without looking:** Which quantities multiply by sixty, and which divide by sixty? Explain why the density height can change while the probability of a physically specified count stays fixed.


<!-- VISUAL01:06 BEGIN -->

---

Source: `course/chapters/04_continuous.md:92–110`

### Visual investigation: exposure and rate travel together

Set an illustrative event rate to three per hour. The two horizontal scales below refer to the same opportunities for events, not two different datasets. Predict which operation changes the expected count: doubling the observation time, or expressing it in minutes.

![A straight expected-count line has rate three per hour, equivalently 0.05 per minute; half an hour predicts 1.5 events.](../../artifacts/figures/visual01_06_exposure.svg)

**Read the figure.** The lower axis measures exposure in hours and the upper axis in minutes. Height is expected event count, which can be fractional even though any realised count is an integer. The highlighted point is one half-hour window with mean 1.5 events.

| Rate | Exposure | Expected count |
|---|---|---:|
| 3 events/hour | 0.5 hour | 1.5 |
| 0.05 events/minute | 30 minutes | 1.5 |
| 3 events/hour | 1 hour | 3 |

**Mathematical connection.** The Poisson mean is $\lambda t$. Converting the time by sixty converts the rate by its reciprocal, leaving $\lambda t$ unchanged. If a rate posterior is transformed, its density must also transform; this line conditions on a fixed rate and is not a posterior interval. At zero exposure this model gives zero events with probability one, so a positive observed count would contradict the stipulated exposure/model pair.

**Original unscored exploration — predict, observe, explain.** Predict the mean in a 45-minute window. Observe that $0.05\times45=2.25$, then explain why replacing 45 minutes by 0.75 hour is only a coordinate change. Transfer to two windows with unequal durations: why is the number of data rows an inadequate substitute for total exposure? The constant-rate line assumes the relevant opportunities are comparable throughout each window.

<!-- VISUAL01:06 END -->

---

Source: `course/chapters/04_continuous.md:112–121`

## A second domain: repeated instrument measurements

A fictional calibrated instrument reports readings of one stable physical quantity. Its independently established observation standard deviation is $\sigma=2$ measurement units. Assume independent normal errors around a shared unknown mean:

$$Y_i\mid\mu\sim\operatorname{Normal}(\mu,\sigma^2),\qquad
\mu\sim\operatorname{Normal}(m_0,s_0^2).$$

The second normal argument here is a **variance**. SciPy's `norm(..., scale=...)` takes a standard deviation. Positive $s_0$ represents uncertainty about the mean before these readings; $\sigma$ represents variation among readings at that mean. They describe different sources of uncertainty even if their numerical values coincide.

With $m_0=10$ and $s_0=2$, prior prediction for one reading is Normal(10,8): variances add when averaging over the uncertain mean. This distribution can generate negative values, as any untruncated normal can. If negative readings would be physically impossible and receive appreciable probability, reconsider the observation scale or likelihood rather than interpreting those predictions literally.

---

Source: `course/chapters/04_continuous.md:123–158`

## Complete the normal square and interpret precision

Adding log likelihood and log prior, and expanding the squares, gives

$$\begin{aligned}
\log p(\mu\mid y)
&=C_0-\frac{(\mu-m_0)^2}{2s_0^2}
-\frac{\sum_i(y_i-\mu)^2}{2\sigma^2}\\
&=C_1-\tfrac12\left[
(s_0^{-2}+n\sigma^{-2})\mu^2
-2(m_0s_0^{-2}+\sigma^{-2}\sum_i y_i)\mu\right].
\end{aligned}$$

Terms involving only the observations or fixed prior settings enter constants $C_0,C_1$. Let $Q=s_0^{-2}+n\sigma^{-2}$ and $h=m_0s_0^{-2}+\sigma^{-2}\sum_i y_i$. Then

$$Q\mu^2-2h\mu=Q(\mu-h/Q)^2-h^2/Q.$$

The last term is constant in $\mu$. The remaining quadratic identifies a normal posterior with

$$s_n^2=Q^{-1},\qquad m_n=h/Q,\qquad
\mu\mid y\sim\operatorname{Normal}(m_n,s_n^2).$$

Inverse variance is **precision**. In this conditional independence model, prior precision and the data's precision add. The data precision is $n/\sigma^2$, which is the reciprocal of the sampling variance of the sample mean. Precision is measured in inverse squared measurement units; it is not interchangeable with inverse standard deviation.

For $n>0$, the posterior mean is a weighted average of $m_0$ and $\bar y$, with weights proportional to $1/s_0^2$ and $n/\sigma^2$. A large dataset can dominate a weak prior. A strongly concentrated prior can remain influential, so inspect whether its apparent precision is justified by comparable information.

For readings 11, 13, 12, 12, we have $n=4$, $\sum y_i=48$, and $\bar y=12$. Thus $Q=1/4+4/4=1.25$ and $h=10/4+48/4=14.5$. The posterior variance is 0.8 and mean is 11.6. Equivalently, the mean is $(1/5)10+(4/5)12$. These retain the original lab's exact values.

**Extended route.** Equal precision per observation is an assumption, not a requirement of square completion. If each reading has a different known standard deviation $\sigma_i$, the same expansion gives

$$Q=s_0^{-2}+\sum_i\sigma_i^{-2},\qquad
h=m_0s_0^{-2}+\sum_i y_i\sigma_i^{-2}.$$

As a separate two-reading example, retain the prior mean ten and prior standard deviation two, but observe eleven with known standard deviation one and thirteen with known standard deviation three. The precisions contributed by the readings are one and one ninth. The posterior variance is $36/49\approx0.734694$, and its mean is $538/49\approx10.979592$. Simply averaging the two readings at twelve would discard their different information content.

These weights must follow a justified measurement model. Assigning a smaller variance to a reading merely because it agrees with expectations would bias the analysis. Nor can correlated repeat readings be counted as if they were independent measurements of equal quality. Precision addition relies on the factorisation used in the derivation; chapter 7 generalises it to a joint normal calculation. Before pooling instruments, check whether their calibration errors could share a common cause.

---

Source: `course/chapters/04_continuous.md:160–175`

## An interval for a mean is not an interval for a reading

A future reading can be written $\tilde Y=\mu+\epsilon$, where the new error is independent of $\mu$ and past observations, with $\epsilon\sim\operatorname{Normal}(0,\sigma^2)$. The sum of these independent normal variables gives

$$\tilde Y\mid y\sim\operatorname{Normal}(m_n,\sigma^2+s_n^2).$$

Using the standard normal 97.5th percentile, approximately 1.959964, produces these equal-tailed 95% intervals:

| Target | Mean | Standard deviation | Interval |
|---|---:|---:|---:|
| Unknown mean $\mu$ | 11.6 | $\sqrt{0.8}\approx0.8944$ | [9.8470, 13.3530] |
| One future reading $\tilde Y$ | 11.6 | $\sqrt{4.8}\approx2.1909$ | [7.3059, 15.8941] |

Both intervals are conditional on the specified model and known observation scale. The wider prediction interval includes measurement variation as well as uncertainty about the mean. As relevant observations accumulate, mean uncertainty can shrink towards zero; the variation of one new reading remains at least the known observation variance.

**Extended route.** For the average of $m$ future readings sharing the same mean, predictive variance is $\sigma^2/m+s_n^2$. It is not $(\sigma^2+s_n^2)/m$: the readings share parameter uncertainty. For four future readings, the variance is $1+0.8=1.8$ and a 95% interval for their average is approximately [8.9704, 14.2296]. Distinct future readings have covariance $s_n^2=0.8$, connecting directly to chapter 3's conditional-versus-marginal dependence.

---

Source: `course/chapters/04_continuous.md:177–203`

## Unknown scale changes the problem

Usually $\sigma$ is unknown too. A joint prior on $\mu,\sigma$ and a likelihood define $p(\mu,\sigma\mid y)$. Marginal inference for the mean integrates over scale uncertainty. Plugging in one estimated scale treats uncertain precision as certain. Whether a particular interval becomes wider also depends on the prior and the chosen plug-in estimate; it is not a comparison between arbitrary different models.

**Extended route.** A useful analytic reference uses the improper joint prior $p(\mu,\sigma^2)\propto1/\sigma^2$, defined with respect to $d\mu\,d\sigma^2$. Set

$$\bar y=\frac1n\sum_i y_i,\qquad
s^2=\frac{1}{n-1}\sum_i(y_i-\bar y)^2.$$

The identity $\sum_i(y_i-\mu)^2=(n-1)s^2+n(\mu-\bar y)^2$ separates residual variation from mean displacement. Integrating the joint kernel over $v=\sigma^2$ uses

$$\int_0^\infty v^{-n/2-1}e^{-D/(2v)}\,dv
\propto D^{-n/2},\qquad
D=(n-1)s^2+n(\mu-\bar y)^2.$$

Consequently,

$$\frac{\mu-\bar y}{s/\sqrt n}\mid y\sim t_{n-1},\qquad
\tilde Y\mid y\sim t_{n-1}\left(\bar y,\ s\sqrt{1+1/n}\right),$$

where the predictive distribution is written in location-scale form. These results require $n\geq2$ and strictly positive sample variation. With too few observations or all readings identical, this improper reference prior does not yield a proper joint posterior. Do not ask software for credible probabilities from an unnormalisable density.

The Student-t scale is not generally its standard deviation. With degrees of freedom $\nu>2$, variance is scale-squared times $\nu/(\nu-2)$; at smaller degrees of freedom it is not finite. With two distinct observations the mean's posterior is Cauchy: proper, but without a finite expectation. Its location can still be reported as its median.

The prior's reference variable matters here too. Expressing the same improper prior in standard deviation rather than variance requires the derivative $d(\sigma^2)/d\sigma=2\sigma$. Its density with respect to $d\mu\,d\sigma$ is therefore proportional to $1/\sigma$, not $1/\sigma^2$. Copying a familiar formula without its reference measure silently changes the prior. Although constants cancel in posterior normalisation when it exists, variable-dependent factors never count as disposable constants. The log-rate example below illustrates the same principle for a proper distribution whose normalisation can be checked directly.

For the four readings above, $s^2=2/3$ and the mean's t scale is $\sqrt{2/3}/2\approx0.4082$, with three degrees of freedom. This is a different model from the known-$\sigma=2$ analysis, and must be labelled accordingly. The improper prior is a reference derivation, not the lab's prior or the default for later regressions. Its unspecified normalising constant also prevents general use in model-evidence comparisons. Later models use explicit proper priors and check their implications.

---

Source: `course/chapters/04_continuous.md:205–217`

## Transforming a density requires a Jacobian

**Extended route.** Let $\eta=\log\lambda$, where the logarithm is taken of the numerical rate expressed in events per hour. Specifying that reference unit avoids taking an ambiguous logarithm of a dimensional quantity. Then $\lambda=e^\eta$, and conservation of probability gives

$$p_\eta(\eta)=p_\lambda(e^\eta)
\left|\frac{d\lambda}{d\eta}\right|
=\frac{B^A}{\Gamma(A)}\exp(A\eta-Be^\eta).$$

The derivative factor $e^\eta$ is a **Jacobian**. Equal-width intervals in log rate correspond to differently sized intervals in rate, so their density heights cannot be copied unchanged. Omitting the factor gives exponent $(A-1)\eta-Be^\eta$, a different distribution. For a gamma shape at most one, that omitted-Jacobian expression is not even integrable over all log rates.

Transforming posterior draws with `np.log` automatically transports probability correctly; no additional weighting is needed. Similarly, taking logs of endpoints of an equal-tailed rate interval preserves its probability and tail allocation. Density modes need not transform: Gamma(14,5) has rate mode $13/5=2.6$, whereas the log-rate density has mode $\log(14/5)$. Mapping that mode back gives 2.8. There is no contradiction because density is defined relative to the coordinate used.

Probabilistic programming software normally handles its internal transformations of declared constrained variables. Add a Jacobian when manually changing the variable with respect to which a density is defined; adding one again to an already transformed target double-counts it. [Chapter 6](06_hmc.md) returns to this issue when unconstrained coordinates are used for sampling.

---

Source: `course/chapters/04_continuous.md:219–227`

## Edge cases and what conjugacy cannot fix

If exposure is zero, the Poisson model assigns probability one to zero events and zero probability to a positive count. A positive count with zero recorded exposure signals a data or model inconsistency; the usual update cannot rescue an impossible likelihood. Zero counts across positive exposure are informative: with a proper gamma prior, the shape stays fixed while the rate increases and the mean event rate decreases.

With no observations, both conjugate updates return their priors. In the normal model, a prior variance tending to zero pins the mean to its prior value, while increasing prior variance gives greater relative weight to the data. Those limits clarify the assumptions; substituting a variance of exactly zero into precision formulas is undefined.

Total count and total exposure are sufficient for the common Poisson rate, but discard timing that could reveal bursts. Sample sum and sample size determine the known-scale normal mean posterior, but discard residual patterns that could reveal outliers, drift, or changing variance. Conditional sufficiency means no further parameter information under the assumed model. It does not mean no further information useful for criticising that model.

Repeated readings also cannot resolve every calibration problem. An unknown common instrument offset is confounded with the true physical level in this simple model: more readings estimate their sum precisely. Separating them requires calibration information or additional measurements with an informative design. A narrow posterior for the model's mean should therefore not be advertised as equally narrow uncertainty about an independently defined physical truth. State what the instrument measures and what external calibration assumptions justify that interpretation.

---

Source: `course/chapters/04_continuous.md:229–235`

## Lab

**Selected-core task:** reproduce the gamma–Poisson exposure update and known-scale Normal update, and interpret their units and predictive intervals. Complete the original three exercises. **Extended task:** the unknown-scale Student-t bridge, unequal-precision comparison and log-rate/Jacobian investigation below are optional additions; allow separate study time.

Run [Lab 4](../../notebooks/04_continuous.ipynb), or [Python](../../labs/04_continuous.py), and inspect the [gamma update](../../artifacts/figures/04_gamma.svg). The supplied lab saves the gamma parameters and normal posterior and predictive standard deviations. Reproduce those values before extending the analysis.

Then compare the two-hour predictive mass with simulation that draws one rate per replicate and a Poisson count conditional on it. Convert hours to minutes, including the prior, and verify the whole count distribution stays unchanged. Deliberately pass a gamma rate as a scale: what implied mean reveals the error? Compute and label intervals for the normal mean, one future reading, and four-reading average. Finally, compare a histogram of log-rate draws with the transformed density. These investigations extend the saved lab; they are not claims about extra outputs it already generates.

---

Source: `course/chapters/04_continuous.md:237–239`

## Summary

Exposure connects counts to rates; gamma conjugacy adds observed count and exposure to distinct prior parameters. Normal conjugacy adds precisions and weights means accordingly. Predictions integrate uncertainty and include future observation variation. Units, scale conventions, and Jacobians determine what distribution a formula actually represents. Exact answers are valuable checks for [numerical computation](05_monte_carlo.md), provided the underlying assumptions fit the question.

---

Source: `course/chapters/04_continuous.md:241–249`

## Exercises

**4.1 — Concept.** A colleague gives every centre equal exposure because the CSV has one row per centre. Explain why row count cannot substitute for exposure.

**4.2 — Derivation.** With Gamma(3,2) in shape-rate form, observe five events in exposure 4. Find posterior mean and variance. Predict the expected number in exposure 3.

**4.3 — Calculation.** Let prior $\mu\sim\operatorname{Normal}(0,1)$ and known observation SD 2. For observations 2 and 4, derive posterior mean, posterior variance, and predictive variance. Explain the units of each.

[Solutions](../solutions.md).

---

Source: `course/chapters/04_continuous.md:251–253`

## Further reading

Allen Downey's [Think Bayes, conjugate priors](https://allendowney.github.io/ThinkBayes2/chap18.html) develops the algebra behind conjugate families. Aki Vehtari's [BDA chapter notes](https://avehtari.github.io/BDA_course_Aalto/BDA3_notes.html), particularly the single-parameter and multiparameter model notes, provide continuation on normal models and prior assumptions. The numerical service and instrument examples here are fictional teaching examples.

---

Source: `course/chapters/05_monte_carlo.md:1–3`

# 5 · Approximate integrals with simulation

**Prerequisites:** [Chapter 2](02_beta_binomial.md) and [Chapter 4](04_continuous.md); expectation, variance, and log densities. [Appendix 1](../appendices/01_probability.md) reviews expectations; [Appendix 4](../appendices/04_numerics.md) supports stable computation. **Objectives:** estimate posterior expectations; quantify simulation error; implement Metropolis correctly; diagnose dependence and poor exploration; derive importance-weight estimators and assess numerical error for a specified estimand.

---

Source: `course/chapters/05_monte_carlo.md:5–16`

## The integral behind an ordinary question

Fourteen of twenty visits ended in completion. Under the earlier Beta(2,2) prior, the posterior is Beta(16,8). Is the completion probability above 0.7? We can evaluate this probability exactly here, but the same question in a regression or hierarchy may require an integral over many unknowns. Simulation approximates that integral by averaging quantities evaluated at representative posterior draws.

Write the target density as $\pi(\theta)=p(\theta\mid y)$. An **estimand** is the particular quantity we want:

$$\mu_g=E[g(\theta)\mid y]=\int g(\theta)\pi(\theta)\,d\theta,
\qquad \widehat\mu_g=\frac1S\sum_{s=1}^S g(\theta^{(s)}).$$

For a posterior mean, choose $g(\theta)=\theta$. For the probability in our question, choose $g(\theta)=\mathbb{1}(\theta>0.7)$: each draw contributes either one or zero. For an expected loss, evaluate the loss under each draw before averaging. Nonlinear operations generally do not commute with averaging: $E[e^\theta]\ne e^{E[\theta]}$. The sampled parameter values are ingredients; the scientific question determines what to calculate from them.

A predictive probability can also be written this way. For a future count $\tilde Y$, use $g(\theta)=P(\tilde Y\geq k\mid\theta)$. Averaging these conditional probabilities integrates parameter uncertainty without drawing a new count at every iteration. When the conditional probability is available, this removes an extra layer of simulation noise. It does not remove uncertainty about the future outcome itself.

---

Source: `course/chapters/05_monte_carlo.md:18–32`

## Two uncertainties with different remedies

For independent draws from the target, the law of large numbers gives convergence of the average when $E_\pi|g|<\infty$. With finite variance, the usual central limit theorem gives an approximate normal sampling distribution for that average, and

$$\operatorname{MCSE}(\widehat\mu_g)\approx\frac{s_g}{\sqrt S},\qquad
s_g^2=\frac{1}{S-1}\sum_s\{g(\theta^{(s)})-\widehat\mu_g\}^2.$$

Posterior standard deviation describes uncertainty about a parameter under the model. Monte Carlo standard error, **MCSE**, describes variation in a computed summary across repeated simulation runs. More draws reduce MCSE; new data may reduce posterior uncertainty. Neither remedy substitutes for checking the model's assumptions.

For a probability estimated with indicators, the variance is $p(1-p)$, giving estimated MCSE $\sqrt{\hat p(1-\hat p)/S}$. If the probability is about 0.2, ten thousand independent draws give MCSE about 0.004. Doubling the draws divides MCSE by $\sqrt2$; quadrupling roughly halves it. The square-root rate can make extra decimal places expensive.

These formulas have conditions. An infinite-variance estimand need not have the stated central limit theorem, even when its expectation exists. A Cauchy location distribution has no ordinary mean to estimate. Finite computer output cannot establish that an integral exists. Likewise, an average from a chain trapped in one region can have a small reported MCSE around the wrong answer.


<!-- VISUAL01:07 BEGIN -->

---

Source: `course/chapters/05_monte_carlo.md:34–52`

### Visual investigation: more draws reduce numerical error, not posterior spread

Suppose the target posterior is Uniform(0,1) and the computation estimates $P(\theta>0.4)$. Before comparing panels, predict whether four times as many simulation draws should make the posterior's central interval narrower.

![An unchanged uniform posterior and event area accompany a decreasing MCSE curve at 100, 400 and 1600 independent draws.](../../artifacts/figures/visual01_07_mc_precision.svg)

**Read the figure.** The left horizontal axis is the uncertain parameter; its shaded area is the exact probability 0.6. The right horizontal axis is computational effort in independent draws; its vertical axis is the standard error of the estimated probability. These axes represent different quantities and should not be read as two posterior distributions.

| Independent draws | Indicator MCSE | Posterior central 90% interval |
|---:|---:|---|
| 100 | 0.048990 | [0.05, 0.95] |
| 400 | 0.024495 | [0.05, 0.95] |
| 1600 | 0.012247 | [0.05, 0.95] |

**Mathematical connection.** Each event indicator has variance $0.6(0.4)$, so the average of $N$ independent indicators has standard error $\sqrt{0.24/N}$. Quadrupling $N$ halves this error. Nothing in that operation changes the observations, prior or likelihood defining the target posterior. More accurate integration is not more scientific information.

**Original unscored exploration — predict, observe, explain.** Predict the MCSE at 6,400 independent draws and compare it with 0.006124. Explain which uncertainty a new observation might change and which a longer simulation directly changes. Transfer this argument to a correlated Markov chain: the iid formula is then insufficient, and precision needs a dependence-aware estimate. The uniform target is a stipulated teaching example, not a claim about the chapter's fitted model.

<!-- VISUAL01:07 END -->

---

Source: `course/chapters/05_monte_carlo.md:54–72`

## Worked example: budget effort for the actual question

For Beta(16,8), direct moment formulas and SciPy's beta survival function give these **computed exact-reference values**, rounded for display:

| Estimand | Exact reference | MCSE with 10,000 independent draws |
|---|---:|---:|
| Posterior mean | 0.6666667 | 0.0009428 |
| Probability above 0.7 | 0.3818716 | 0.0048585 |

The posterior variance is $16\cdot8/(24^2\cdot25)=0.0088889$, so its SD remains approximately 0.09428 regardless of simulation effort. To target MCSE at most 0.001, solve $S\geq\operatorname{Var}_\pi(g)/0.001^2$. Rounding upwards requires 8,889 independent draws for the mean but 236,046 for the probability. These are planning calculations, not guarantees for a realised run or dependent draws.

Absolute and relative accuracy differ. The exact probability above 0.9 is only 0.00122983. An MCSE of 0.001 would be almost as large as that probability. To target relative MCSE of ten percent, solve

$$\frac{\sqrt{p(1-p)/S}}p\leq0.1,
\qquad S\geq\frac{1-p}{0.01p},$$

which requires about 81,213 independent draws. The rarity matters even though the underlying parameter's mean is easy to estimate. If no simulated draw exceeds the threshold, the plug-in indicator variance is zero; interpreting that as perfect accuracy is a diagnostic failure. Zero observed events require a bound or a more suitable rare-event calculation, not a claim that the posterior probability is zero.

When a numerical answer will drive a decision, specify its tolerance beforehand. If two actions have almost equal expected loss, estimate the *difference* in losses using the same posterior draws. That preserves their dependence and can estimate the comparison more efficiently than two unrelated simulations. Report how the remaining MCSE compares with the decision margin.

---

Source: `course/chapters/05_monte_carlo.md:74–91`

## Importance sampling: reuse a convenient distribution

Suppose direct posterior sampling is unavailable but independent draws from a density $q$ are easy. Write the unnormalised target as $\tilde\pi(\theta)=p(y\mid\theta)p(\theta)$, with unknown integral $Z$. Changing the density inside each integral gives

$$\mu_g=\frac{E_q[w(\theta)g(\theta)]}{E_q[w(\theta)]},
\quad w(\theta)=\frac{\tilde\pi(\theta)}{q(\theta)},
\quad\widehat\mu_{\mathrm{IS}}=\sum_s\bar w_sg(\theta^{(s)}),
\quad\bar w_s=\frac{w_s}{\sum_jw_j}.$$

The proposal must put positive density wherever the target does. Under appropriate integrability, both averages converge and their ratio converges to the desired expectation. The self-normalised ratio is generally biased at finite sample sizes, although consistent. Finite asymptotic variance additionally requires control of squared weights times squared centred estimand values. Covering the support alone does not ensure useful precision. See [Owen's importance-sampling treatment](https://artowen.su.domains/mc/Ch-var-is.pdf) for the ratio argument and variance conditions.

Calculate log weights and normalise with log-sum-exp, as explained in Appendix 4. This prevents arithmetic underflow; it cannot compensate for an inadequate proposal. Inspect the largest normalised weights and the concentration measure

$$\operatorname{ESS}_{w}=\frac{(\sum_sw_s)^2}{\sum_sw_s^2}=\frac1{\sum_s\bar w_s^2}.$$

Equal weights give the nominal sample size. As a constructed arithmetic example, weights $(1,1,1,97)$ give approximately 1.062, so four samples effectively put nearly all their influence on one value. This weight diagnostic differs from autocorrelation-based MCMC ESS and does not account for which estimand is being estimated.

A subtler failure occurs when a narrow proposal never reaches an important region. Its observed weights may look reassuring because the missing large weights were never seen. Repeating from broader proposals and comparing with known cases tests something that the weight summary cannot. [Chapter 10](10_model_checking.md) revisits weights in predictive comparison; the [model-evidence bridge](../advanced/02_model_evidence.md) explains why posterior expectations and normalising constants are different numerical tasks.

---

Source: `course/chapters/05_monte_carlo.md:93–118`

## Worked example: weighted draws and their precision

Use a uniform proposal on the unit interval for our beta target. It covers the support and has density one there, so weights are proportional to the beta density. This proposal spends many draws where the posterior assigns little mass. That waste is manageable in one dimension and makes the weighting operation easy to inspect.

The following short calculation is a **computed demonstration** using NumPy's default generator, seed 509, and ten thousand proposals:

```python
rng = np.random.default_rng(509)
theta = rng.uniform(0, 1, 10000)
log_w = stats.beta.logpdf(theta, 16, 8)
w = np.exp(log_w - logsumexp(log_w))
mean_is = np.sum(w * theta)
```

Here `stats` is imported from SciPy and `logsumexp` from `scipy.special`. The fourth line makes weights sum to one without first exponentiating potentially extreme raw values. The final multiplication allocates each proposal its appropriate influence. Unlike the Metropolis algorithm below, these proposal values are independent; unequal weights are the reason their numerical precision differs from direct posterior draws.

The computed mean is 0.666562, and the weight ESS is approximately 3,322. The largest normalised weight is about 0.000422. An unweighted proposal average estimates the uniform mean, one half, regardless of how many such proposals are collected. The weighted mean instead agrees closely with the exact posterior mean of two thirds. Inspecting the largest weight helps explain why this particular estimate is not dominated by a single proposal.

For independent proposals, a large-sample approximation to the self-normalised estimator's variance is

$$\widehat{\operatorname{MCSE}}_{\mathrm{IS}}^2
\approx\sum_s\bar w_s^2\{g(\theta^{(s)})-\widehat\mu_{\mathrm{IS}}\}^2.$$

This follows by linearising the ratio of the weighted numerator average and denominator average. The centred differences matter: a large weight contributes little error when its estimand value happens to be near the estimated expectation. Conversely, large weights attached to extreme losses can dominate numerical error. Weight ESS alone cannot express that distinction. The approximation assumes suitable finite moments and adequate proposal coverage; unseen tail contributions can invalidate a reassuring finite-sample estimate.

For this run the mean MCSE estimate is 0.001197. Applying the same formula to indicators above 0.7 gives estimated probability 0.380646 with MCSE 0.008346. Compare that with the exact probability 0.381872 and the direct-sampling planning MCSE 0.004858. The same proposals and weights serve both estimands, but the probability pays a larger precision cost. These numbers illustrate a calculation rather than certify this proposal for every posterior or tail question.

---

Source: `course/chapters/05_monte_carlo.md:120–120`

When debugging importance sampling, first write down which distribution actually generated the draws. Check that the denominator of every weight is that proposal density, including any truncation normaliser. Then check that the weights sum to one and inspect weighted summaries against a reference. Repeating the calculation with a broader proposal probes missing coverage; merely increasing draws from a proposal with zero density in a required region cannot repair the omission. In higher dimensions, redesigning the proposal is often more valuable than multiplying an already large sample size.

---

Source: `course/chapters/05_monte_carlo.md:122–138`

## Markov chains find the target indirectly

A Markov chain chooses its next state using the current state. Its transition kernel is designed to leave the posterior invariant: if the current state has distribution $\pi$, so does the next. Invariance alone is insufficient. A chain that never moves preserves any starting distribution; it cannot learn a target from an arbitrary start. Suitable irreducibility and recurrence conditions support long-run averages; practical mixing concerns how quickly useful exploration actually happens.

For random-walk Metropolis, propose $\theta'=\theta+\epsilon$, with $\epsilon\sim\operatorname{Normal}(0,s^2)$. The proposal is symmetric. Accept with probability $\min\{1,\tilde\pi(\theta')/\tilde\pi(\theta)\}$. The normalising constant cancels. More generally, a nonsymmetric proposal requires

$$\alpha(\theta,\theta')=\min\left\{1,
\frac{\tilde\pi(\theta')q(\theta\mid\theta')}
{\tilde\pi(\theta)q(\theta'\mid\theta)}\right\}.$$

The detailed-balance intuition is equal probability flow between pairs of states at equilibrium. The accepted flow from $\theta$ to $\theta'$ is

$$\pi(\theta)q(\theta'\mid\theta)\alpha(\theta,\theta')
=\min\{\pi(\theta)q(\theta'\mid\theta),
\pi(\theta')q(\theta\mid\theta')\},$$

which is unchanged when the states are exchanged. Rejections supply the probability of staying put. Integrating the balanced flows establishes invariance. Detailed balance is a sufficient construction, not a requirement of every valid sampler. [Hastings (1970)](https://doi.org/10.1093/biomet/57.1.97) develops the general acceptance rule.

---

Source: `course/chapters/05_monte_carlo.md:140–158`

## Residence times and boundaries are part of the algorithm

Compare a log-uniform draw with the log-density difference to avoid dividing tiny densities. This fragment assumes a finite-density starting state, a symmetric normal proposal, and a target function returning negative infinity outside its support:

```python
candidate = current + rng.normal(0, proposal_sd)
candidate_logp = log_density(candidate)
if np.log(rng.uniform()) < candidate_logp - current_logp:
    current, current_logp = candidate, candidate_logp
values[i] = current
```

The last line runs whether the proposal is accepted or rejected. A positive log-density difference always passes the comparison; a negative difference sometimes does. Unexpected NaNs should trigger investigation of the density calculation, rather than being treated as ordinary support rejections. The complete teaching implementation is in [common.py](../../labs/common.py).

For a beta target, an unconstrained normal proposal outside $(0,1)$ is rejected. Repeatedly proposing until the candidate falls inside instead creates a truncated proposal. Its normalising probability depends on the current location, especially near a boundary, so the original symmetric acceptance rule no longer applies. Clipping a candidate to a boundary also changes the kernel. Transforming to log-odds is another option, but then the target density needs the transformation's Jacobian, as Chapter 6 explains.

To see why repeats matter, construct a target with probabilities $\pi(A)=0.9$ and $\pi(B)=0.1$, always proposing the other state. Moves from A to B are accepted with probability $1/9$; the reverse move is always accepted. Expected residence times are nine iterations in A and one in B. Full-chain occupancy therefore recovers the nine-to-one ratio. The sequence of accepted moves alternates A, B, A, B, giving a wrong fifty-fifty distribution. This is an exact calculation, not a simulated diagnostic report.

For a continuous Metropolis chain, keeping only accepted states similarly weights locations by their probability of leaving: its invariant jump distribution is proportional to $\pi(\theta)a(\theta)$, where $a(\theta)$ is acceptance probability averaged over proposals at that location. Unless that probability is constant, deleting residence times changes the target. Removing duplicates to make a trace look livelier damages the estimator.

---

Source: `course/chapters/05_monte_carlo.md:160–171`

## Dependence reduces useful information

For stationary draws, let $\rho_k$ be the lag-$k$ autocorrelation of the *transformed sequence* $g(\theta^{(s)})$. Expanding the variance of a sum gives

$$\operatorname{Var}(\widehat\mu_g)=\frac{\sigma_g^2}{S}
\left[1+2\sum_{k=1}^{S-1}\left(1-\frac{k}{S}\right)\rho_k\right].$$

With sufficiently summable dependence and a suitable Markov-chain central limit theorem, the bracket approaches an integrated autocorrelation time $\tau_g$. Define $S_{\mathrm{eff},g}=S/\tau_g$; then MCSE is approximately $s_g/\sqrt{S_{\mathrm{eff},g}}$. Positive persistence commonly reduces efficiency. Negative correlations can make ESS exceed the number of stored draws without creating additional observations.

For an illustrative stationary sequence with $\rho_k=0.9^k$, the geometric series gives $\tau_g=19$. Nineteen thousand stored values then have mean-estimation precision comparable to one thousand independent values. This is a theoretical example, not a measured property of our beta chain. Practical ESS estimators stabilise noisy autocorrelations and compare chains; naively summing every empirical lag is unreliable. [Stan's analysis reference](https://mc-stan.org/docs/reference-manual/analysis.html) explains the connection to MCSE and multi-chain estimation.

Warmup allows movement from initial states and, for adaptive methods, tuning. Discarding a fixed percentage cannot rescue a chain that remains trapped. Tune during warmup, then use an appropriately fixed sampling procedure. Routine thinning usually wastes computed information; storage constraints can justify it, but a thinned chain is not automatically independent.

---

Source: `course/chapters/05_monte_carlo.md:173–185`

## Worked example: high acceptance can conceal poor exploration

The following **computed demonstration** uses the existing Metropolis helper, Beta(16,8), starts $(0.2,0.4,0.7,0.9)$, and seeds 505–508. Each chain runs 14,000 iterations with the first 2,000 discarded. Acceptance includes warmup; other summaries use retained draws. The middle row reproduces the saved Lab 5 reference. These are results for these seeds, not universal performance rankings.

| Proposal SD | Mean acceptance | Estimated mean | Rank R-hat | Bulk ESS | Mean MCSE |
|---|---:|---:|---:|---:|---:|
| 0.005 | 0.9823 | 0.66967 | 1.1352 | 21 | 0.02453 |
| 0.12 | 0.6451 | 0.66721 | 1.0004 | 7,231 | 0.001114 |
| 1.0 | 0.1194 | 0.66598 | 1.0009 | 3,525 | 0.001594 |

The tiny proposal accepts almost everything, yet explores slowly. Its mean happens to be near the exact 0.66667; that accidental agreement does not cancel chain disagreement or low ESS. For scale 0.12, the discrepancy is about 0.49 reported MCSE. The large proposal rejects frequently and is less efficient here, although its diagnostics are much better than those of the tiny proposal.

Deleting repeated states from the scale-1.0 retained chains gives an empirical SD of 0.10582, compared with 0.09362 for the full chains and exact SD 0.09428. The jump-only mean is 0.66153. This computed counterexample shows why comparing just a plausible mean can miss a distorted distribution. Never feed the shortened chains into a report as though they were ordinary posterior draws.

---

Source: `course/chapters/05_monte_carlo.md:187–195`

## A practical debugging decision tree

Start with the integral and the transition, then follow the first applicable branch:

1. **Nonfinite values or impossible states?** Check support, units, log arithmetic, initial values, and proposal symmetry. Compare the implemented density with a hand calculation before tuning.
2. **Exact-reference discrepancy or suspiciously few repeats?** Check rejection storage, the Hastings correction, and any boundary transformation. More iterations cannot repair a wrong invariant distribution.
3. **Persistent traces or disagreement between chains?** Inspect dispersed starts and proposal scale. Very high acceptance suggests testing larger steps; very low acceptance suggests testing smaller ones. Evaluate ESS per unit time as well as acceptance.
4. **Only the requested probability or loss is imprecise?** Compute diagnostics on its transformed draws and increase simulation effort if exploration is credible. A parameter's mean ESS is not a universal precision measure.
5. **Everything looks satisfactory?** Compare independent runs, alternative starts, and known special cases. Chains all stuck in the same unseen-mode configuration can agree. Numerical checks provide evidence about computation, never proof of complete exploration or model adequacy.

---

Source: `course/chapters/05_monte_carlo.md:197–199`

## Lab

Run [Lab 5](../../notebooks/05_monte_carlo.ipynb), or its [Python source](../../labs/05_monte_carlo.py). The [trace and density figure](../../artifacts/figures/05_metropolis.svg) overlays the exact target. Keep chain and draw axes when calculating diagnostics. Compare proposal scales, then estimate the probability above 0.7 by constructing the indicator sequence for each chain. Compute its mean MCSE directly rather than recycling the mean-parameter MCSE. Retain the full chains when making the deliberately incorrect jump-only comparison.

---

Source: `course/chapters/05_monte_carlo.md:201–205`

## Retrieval and summary

Before continuing, explain why an accurate posterior mean need not imply an accurate rare-event probability. Predict what changes when the number of draws quadruples, when the observed sample size quadruples, and when rejected states are deleted.

Monte Carlo approximates a specified integral. Reliable use combines a correct target and transition, adequate exploration, and a numerical error estimate for the actual question. [Chapter 6](06_hmc.md) develops gradient-based sampling and modern diagnostics; the [approximation bridge](../advanced/01_approximation.md) compares simulation error with systematic approximation error.

---

Source: `course/chapters/05_monte_carlo.md:207–215`

## Lab and exercises

**5.1 — Concept.** Why does doubling posterior draws leave the scientific uncertainty essentially unchanged? What uncertainty should decrease?

**5.2 — Calculation.** A posterior SD is 3 and the relevant effective sample size is 900. Estimate the MCSE of its mean. Approximately how large an ESS is needed for MCSE 0.05?

**5.3 — Algorithm.** Write pseudocode for a Metropolis transition, including rejection. Explain what goes wrong when rejected iterations are deleted. Use the Beta(16,8) target on (0,1) to demonstrate the bias or change in density. Submit your runnable code, seeds, proposal scale, retained full and accepted-only summaries, and a comparison to the exact mean, variance and a tail probability; use multiple chains and report mean MCSE.

[Solutions](../solutions.md).

---

Source: `course/chapters/05_monte_carlo.md:217–219`

## Further reading

[Hastings (1970)](https://doi.org/10.1093/biomet/57.1.97) gives the transition construction; [Owen, Chapter 9](https://artowen.su.domains/mc/Ch-var-is.pdf) develops importance sampling. [Vehtari and colleagues (2021)](https://arxiv.org/abs/1903.08008) develop modern multi-chain diagnostics. For further practice, see [Think Bayes, MCMC](https://allendowney.github.io/ThinkBayes2/chap19.html) and [Aalto computational notes](https://avehtari.github.io/BDA_course_Aalto/BDA3_notes.html).

---

Source: `course/chapters/06_hmc.md:1–3`

# 6 · Use modern samplers responsibly

**Prerequisites:** [Chapter 5](05_monte_carlo.md); log densities, derivatives, and covariance. [Appendix 2](../appendices/02_calculus.md) develops gradients and transformations; [Appendix 3](../appendices/03_linear_algebra.md) explains quadratic forms. **Objectives:** explain why gradients help sampling; specify a model in PyMC; interpret modern diagnostics; separate computation from model adequacy; explain Hamiltonian integration and constrained coordinates; design an exact-reference and predictive validation report.

---

Source: `course/chapters/06_hmc.md:5–9`

## Why a random walk becomes inefficient

Imagine a narrow diagonal ridge in a two-parameter posterior. Random steps usually leave the ridge; small accepted steps take a long time to travel along it. How can we explore this distribution without confusing a long run with an informative one? Hamiltonian Monte Carlo, **HMC**, uses gradients to construct coordinated proposals. Its benefits depend on geometry: which directions are narrow, how their widths change, and whether distinct regions connect readily.

Finding a high-density point is insufficient. A posterior expectation depends on probability mass, which combines density with volume. In many dimensions, the region containing most mass need not surround the density maximum closely. An optimiser returns a point; a sampler must explore the distribution. Automatic differentiation supplies local derivatives efficiently, but it cannot determine whether the scientific model is identified or whether all important regions have been visited.

---

Source: `course/chapters/06_hmc.md:11–24`

## Energy connects the target to a trajectory

Let $q$ denote unconstrained parameter coordinates and $\pi_q(q)$ their posterior density. Introduce auxiliary momentum $p\sim\operatorname{Normal}(0,M)$, where $M$ is a fixed positive-definite mass matrix. Ignoring constants, define

$$U(q)=-\log\pi_q(q),\qquad K(p)=\tfrac12p^TM^{-1}p,
\qquad H(q,p)=U(q)+K(p).$$

The joint density is proportional to $e^{-H(q,p)}$. Integrating out momentum recovers the desired posterior. Hamilton's equations are

$$\frac{dq}{dt}=M^{-1}p,\qquad \frac{dp}{dt}=-\nabla U(q).$$

Momentum moves the position; the gradient redirects momentum according to the target's geometry. Exact dynamics conserve total energy. They can carry a state a substantial distance without proposing arbitrary moves into low-probability regions. Refreshing momentum lets successive trajectories explore different energy levels. Without that refresh, conserving energy would itself restrict exploration.

HMC requires a differentiable continuous target in the coordinates it uses. Unknown discrete variables need marginalisation or a suitable additional sampler. Discontinuous likelihood code and hard parameter-dependent branches may cause difficulties even when every named parameter is continuous. [Betancourt's conceptual introduction](https://arxiv.org/abs/1701.02434) develops the geometric interpretation and its limits.

---

Source: `course/chapters/06_hmc.md:26–40`

## Leapfrog and the Metropolis correction

Most Hamiltonian equations cannot be solved analytically. One leapfrog step of size $\epsilon$ alternates a momentum half-step, a position step, and another momentum half-step:

$$\begin{aligned}
p_{1/2}&=p_0-\tfrac\epsilon2\nabla U(q_0),\\
q_1&=q_0+\epsilon M^{-1}p_{1/2},\\
p_1&=p_{1/2}-\tfrac\epsilon2\nabla U(q_1).
\end{aligned}$$

The second gradient is evaluated at the new position. Leapfrog is reversible with a momentum flip and preserves volume; it does not preserve energy exactly. For fixed-length HMC, a proposal made from repeated steps and a momentum flip is accepted with probability

$$\alpha=\min\{1,\exp[H(q_0,p_0)-H(q_L,p_L)]\}.$$

A rejection retains the old position. This is the same residence-time principle as Metropolis, now applied to a proposal in an expanded space. Small integration errors usually allow acceptance. Persistent large errors waste computation and can obstruct exploration. The correction establishes the appropriate invariant target under its assumptions; it does not make every finite run reliable. The [Stan sampling reference](https://mc-stan.org/docs/reference-manual/mcmc.html) describes this construction.

---

Source: `course/chapters/06_hmc.md:42–48`

## Worked example: one normal-target trajectory step

Take a standard normal target, so $U(q)=q^2/2$, with $M=1$. Starting at $q_0=0$, $p_0=1$, the exact solution is $q(t)=\sin t$, $p(t)=\cos t$, always with energy $1/2$. This is an exact reference for integration, not a claim that this chosen initial condition is a posterior sample.

With $\epsilon=0.5$, leapfrog gives $p_{1/2}=1$, $q_1=0.5$, and $p_1=0.875$. Its energy is $(0.5^2+0.875^2)/2=0.5078125$. The error is 0.0078125, so the acceptance probability is $e^{-0.0078125}=0.992218$. Direct calculation at time 0.5 gives exact position 0.479426 and momentum 0.877583. These **computed arithmetic values** show both the useful movement and the numerical error.

One accurate step does not establish that an entire sampler works. Repeating the dynamics without momentum refresh would trace an orbit, rather than generate independent posterior draws. Taking excessively long paths can return near the starting position and waste gradient evaluations. Conversely, a very short trajectory behaves locally and may explore slowly. We need both stable integration and useful trajectory lengths.

---

Source: `course/chapters/06_hmc.md:50–56`

## Warmup, geometry, and NUTS

Warmup commonly adapts step size and a mass matrix that adjusts relative scales and, when supported, correlations. With our convention, $M$ is the covariance of momentum; software sometimes reports its inverse. Read that convention before interpreting a fitted matrix. A constant matrix can compensate for a tilted ellipse but cannot flatten a shape whose curvature changes sharply from place to place.

The **No-U-Turn Sampler**, NUTS, expands a trajectory in both directions and stops expansion when continued travel begins turning back. It selects a state using rules that preserve the target, rather than simply returning whichever endpoint looks best. Trajectory length changes during sampling; this is part of the valid transition. Warmup adaptation of its tuning parameters is a different process and ordinarily stops before retained sampling. See the original [Hoffman–Gelman NUTS paper](https://jmlr.org/papers/v15/hoffman14a.html).

Higher target acceptance generally induces smaller integration steps. That may resolve moderately difficult curvature while increasing computational cost. It cannot identify an unidentified likelihood, make an improper posterior proper, or guarantee movement between distant modes. Extra warmup helps when adaptation lacks information; extra retained draws help precision after exploration is credible. Record which problem justifies the additional computation.

---

Source: `course/chapters/06_hmc.md:58–65`

## Constrained parameters need the right density

For a probability, PyMC can sample an unconstrained log-odds coordinate $z=\log\{\theta/(1-\theta)\}$. Since $d\theta/dz=\theta(1-\theta)$,

$$\log\pi_z(z)=\log\pi_\theta(\operatorname{logistic}(z))
+\log\theta+\log(1-\theta).$$

For Beta(16,8), this becomes $16\log\theta+8\log(1-\theta)+C$, whose derivative with respect to $z$ is $16-24\theta$. Omitting the Jacobian instead uses powers 15 and 7 in the transformed log density and targets the wrong distribution after transforming draws back. Declared PyMC distributions handle their standard transformations internally. Hand-written densities must account for the measure they describe. Appendix 2 supplies the substitution derivation; [Appendix 4](../appendices/04_numerics.md) covers stable log-logistic arithmetic.

---

Source: `course/chapters/06_hmc.md:67–82`

## Declare a generative model

The familiar beta-binomial example makes an implementation error easier to recognise:

```python
with pm.Model() as model:
    theta = pm.Beta("theta", alpha=2, beta=2)
    y = pm.Binomial("y", n=20, p=theta, observed=14)
    prior = pm.sample_prior_predictive(draws=1000, random_seed=606)
    idata = pm.sample(draws=1200, tune=1200, chains=4,
                      cores=1, target_accept=0.95, random_seed=606)
```

The first distribution supplies a prior; the second supplies a likelihood conditioned on the observed count. Prior predictive simulation temporarily generates outcomes from the prior model, before conditioning. The sampling request retains 1,200 draws from each of four chains after 1,200 warmup iterations per chain. Running one core controls execution resources, not the number of chains.

In the lab, [common.py](../../labs/common.py) supplies these settings through `sample_model` and requests pointwise log likelihood for later scoring. The returned inference object keeps chain and draw dimensions and sampler information. Preserve those dimensions for diagnostics. Flattening too early destroys between-chain comparisons; flattening later can be appropriate for a posterior histogram. The dependency lock defines the teaching environment, so these lines should not be interpreted as a promise about every future library release.

---

Source: `course/chapters/06_hmc.md:84–96`

## Read agreement, efficiency, and precision separately

Modern rank-normalised split **R-hat** compares within-chain and between-chain variation after splitting chains into halves. Rank normalisation improves behaviour for heavy tails; folding values around the pooled median helps reveal differences in scale. The reported diagnostic uses both location and folded checks. The course screens for R-hat below 1.01 with at least four chains and diverse plausible starts. Use unrounded values: a display of 1.00 can hide a meaningful difference. These choices follow [Vehtari and colleagues (2021)](https://arxiv.org/abs/1903.08008).

R-hat measures agreement among the explored distributions. It cannot detect a region missed by every chain, prove finite moments, or judge a likelihood's suitability. Trace plots reveal persistence and drift. Rank plots compare how each chain occupies the pooled ordering; persistent imbalances suggest that chains sample different locations or scales. Inspect parameters and scientifically important derived quantities, including contrasts whose dependence may be difficult to explore.

For a **computed diagnostic counterexample**, define a target with equal-weight normal components centred at minus six and plus six, both with unit SD. Symmetry gives exact target mean zero. Now deliberately generate four arrays of two thousand independent values from *only the positive component*, using NumPy's default generator with seed 610. These arrays are fabricated incomplete samples, not an HMC run. ArviZ reports mean 5.98840, R-hat 1.00008, bulk ESS 8,094, and mean MCSE 0.01114. Agreement is excellent because all four arrays represent the same wrong component.

The small MCSE describes simulation variability within that component; it does not cover the missing half of the target. This construction isolates the limitation without relying on a particular sampler becoming trapped by chance. In practice, starts near both components, a symmetry argument, or an independently computed reference could expose the omission. Changing only the reporting threshold could not. A posterior without an exact reference requires several complementary checks precisely because such missing regions may be unknown.

**Bulk ESS** uses rank-normalised draws to assess central exploration. **Tail ESS** commonly reports the smaller ESS associated with the fifth and ninety-fifth percentiles. Neither is automatically the ESS for the mean of a nonlinear transformation or for an extremely rare event. We screen for both above 400 across monitored quantities, then check numerical precision for the requested result. The [Stan posterior-analysis reference](https://mc-stan.org/docs/reference-manual/analysis.html) explains these distinctions.

For a probability above a threshold, form its indicator draws and estimate their mean MCSE. For an interval endpoint, request quantile MCSE at that endpoint. For a loss difference, transform draws into that difference first. A parameter SD divided by the square root of bulk ESS is not generally the requested error estimate. Smooth-looking histograms and high aggregate ESS cannot replace this estimand-specific calculation.

---

Source: `course/chapters/06_hmc.md:98–107`

For example, this fragment keeps the beta draw dimensions while changing the question:

```python
event = (idata.posterior["theta"] > 0.7).astype(float)
event_mcse = az.mcse(event, method="mean")
```

The first line turns each probability draw into an event indicator. The second estimates numerical error in its average while retaining dependence information. It does not estimate uncertainty about the indicator's true probability by treating the simulated indicators as new observed visits. If indicators are constant because no event occurred, a zero or undefined error estimate is insufficient evidence of accuracy.

For the lower endpoint of a central ninety-percent interval, use the original parameter draws and a quantile MCSE calculation at probability 0.05. A sparse density near that endpoint makes its location harder to resolve: a small probability error can correspond to a substantial change in parameter units. Record the endpoint and its numerical error together, and repeat for the upper endpoint rather than assuming equal precision.

---

Source: `course/chapters/06_hmc.md:109–124`

## Worked example: a complete exact-reference comparison

With fourteen successes and six failures, the posterior remains Beta(16,8). Its mean is 0.6666667 and central 90% credible interval is [0.5035649, 0.8136562]. These analytic-family values were recalculated with SciPy. The following table reports the **saved Lab 6 result file**. Its seeded computation is reproducible in the pinned environment:

| Quantity | Saved value |
|---|---:|
| Sample mean | 0.669352 |
| Mean MCSE | 0.0021251 |
| R-hat | 1.002034 |
| Bulk / tail ESS | 1,846 / 1,749 |
| Divergent transitions | 0 |
| Minimum BFMI | 0.88197 |
| Maximum tree-depth hits | 0 |
| Sample central 90% interval | [0.510244, 0.815209] |

The mean discrepancy is about 1.26 reported MCSE, compatible with ordinary simulation variation. The lower interval endpoint differs by about 0.00668. Its precision needs a quantile MCSE; the mean's MCSE does not assess that endpoint. The rebuilt JSON now records separate MCSEs for the 5th and 95th percentiles and checks both endpoint discrepancies against six of their own MCSEs. Passing this numerical screen supports these particular quantiles, without certifying every posterior tail. A credible interval itself describes parameter uncertainty, not simulation error.

---

Source: `course/chapters/06_hmc.md:134–134`

Computation and predictive validation still need separate reports. The lab generates prior predictive counts and posterior predictive counts and saves both a posterior trace figure and a [predictive-count comparison](../../artifacts/figures/06_predictive.svg). As a learner investigation, reproduce those count distributions, check their support, and compare the observed count of fourteen with relevant predictions. Explain which features change under a different prior. Agreement with the exact posterior cannot establish that visits are independent or share one completion probability.

---

Source: `course/chapters/06_hmc.md:136–145`

## Identification and funnels

Suppose $Y_i\sim\operatorname{Normal}(a+b,1)$ with known observation SD. The likelihood sees only $a+b$. Adding a constant to $a$ and subtracting it from $b$ leaves every likelihood value unchanged. With flat priors on both coefficients, integration along this ridge is unbounded: there is no proper joint posterior. Proper priors can make the posterior proper, but information about the difference then comes from those priors. More sampler tuning cannot create data information about that difference.

Weakly informed hierarchical scales create another difficulty. Consider the generative construction $v\sim\operatorname{Normal}(0,3^2)$, where the second argument here denotes variance, and $x_j\mid v\sim\operatorname{Normal}(0,e^v)$. Conditional variance contracts as $v$ decreases, creating a funnel: broad in one region, extremely narrow in another. A step size adequate in the broad region may fail in the neck. A global mass matrix cannot accommodate both equally well.

Writing $x_j=e^{v/2}z_j$, with independent standard normal $z_j$, removes that coupling in this prior example. In a hierarchy, the analogous noncentred form is $\theta_j=\mu+\tau z_j$. It defines the same prior model when transformed correctly, but changes sampling geometry. With highly informative group data, a centred form may work better. [Chapter 9](09_hierarchical.md) develops this choice; the [approximation bridge](../advanced/01_approximation.md) shows why difficult geometry also affects alternatives to MCMC.


<!-- VISUAL01:08 BEGIN -->

---

Source: `course/chapters/06_hmc.md:147–167`

### Visual investigation: geometry can demand incompatible step scales

Predict where a single step scale might struggle: along the thin diagonal contour, or across a funnel whose width changes sharply with position. These drawings describe analytic geometry. They are not sampled chains, acceptance histories or evidence that any particular sampler succeeded.

![Analytic Gaussian contours form a narrow diagonal ridge; a funnel has conditional standard deviation exp(z/2), small at minus four and large at four.](../../artifacts/figures/visual01_08_geometry.svg)

**Read the figure.** Left: two constant-density contours use standardised coordinates. Their long and short directions come from covariance eigenvectors. Right: the horizontal coordinate $z$ is log conditional variance, and the two curves mark plus/minus one conditional SD of $x\mid z$. They are cross-section widths, not trajectories.

| Geometry quantity | Value |
|---|---:|
| Larger eigenvalue of covariance with unit variances and correlation 0.98 | 1.98 |
| Smaller eigenvalue | 0.02 |
| Conditional SD at z = −4 | 0.135335 |
| Conditional SD at z = 0 | 1 |
| Conditional SD at z = 4 | 7.389056 |

**Mathematical connection.** The Gaussian covariance is $\left(\begin{smallmatrix}1&.98\\.98&1\end{smallmatrix}\right)$, giving a variance ratio of 99 between principal directions. For the funnel slice, $x\mid z\sim N(0,e^z)$, so its SD is $e^{z/2}$. A global linear scaling can address a fixed Gaussian ridge more directly than a position-dependent funnel width. A full funnel model also needs a marginal distribution for $z$; the right panel deliberately only specifies conditional geometry.

**Original unscored exploration — predict, observe, explain.** Predict the width ratio between z = −4 and z = 4, then observe it is $e^4\approx54.6$. Explain why high acceptance or visually smooth traces alone cannot establish exploration of both regions. Transfer to a non-centred parameterisation: identify the transformed coordinate and the distribution it must preserve before calling the change a remedy.

<!-- VISUAL01:08 END -->

---

Source: `course/chapters/06_hmc.md:169–184`

## Worked diagnostic failure and a debugging decision tree

Consider this **illustrative report, not an executed fit**: four chains in a weakly informed centred hierarchy give R-hat 1.003, bulk ESS 1,200, tail ESS 500, eighteen post-warmup divergences, and minimum BFMI 0.18. The agreement and ESS screens pass, yet the run remains suspect. A plausible hypothesis is that all chains underexplore a narrow funnel region. That hypothesis requires investigation; the summary alone does not identify its cause.

A **divergent transition** flags a trajectory with excessive integration error and can indicate missed probability mass. It is not simply an ordinary Metropolis rejection. **BFMI**, Bayesian fraction of missing information, compares energy changes across transitions with marginal energy variation; low values suggest that momentum refreshes explore energy poorly. The course uses 0.3 as a warning threshold. **Tree-depth hits** mean trajectory expansion reached its configured limit, usually signalling inefficiency. None of these warnings is cancelled by a satisfactory R-hat. See [Stan's diagnostic guidance](https://mc-stan.org/learn-stan/diagnostics-warnings.html).

Follow this sequence before reporting a probability:

1. **Invalid initial density or gradients?** Check data, units, support, transformations, and likelihood code. Reduce to a tiny exact or simulated case. Resolve these failures before interpreting summaries.
2. **Divergences?** Locate affected transitions in parameter and pair plots. Examine scale parameters, strong dependencies, constraints, and identification. Test standardisation, defensible priors, or an equivalent reparameterisation. A higher target acceptance can test sensitivity to smaller steps; document whether it actually resolves the issue.
3. **Low BFMI or repeated depth limits?** Inspect per-chain energy behaviour and scales. Reconsider geometry and adaptation before paying for deeper trees. Raising a depth limit may help an otherwise well-behaved but truncated trajectory; it cannot by itself explain the warning.
4. **R-hat or rank plots disagree?** Try scientifically plausible dispersed starts, check modes and symmetries, and compare simpler models. Longer runs are justified when exploration improves, not merely because time has passed.
5. **Exploration credible but MCSE too large?** Add retained draws and reassess the actual estimand. Keep diagnostics and parameterisation fixed in the comparison. Do not select whichever random seed produces a favourable report.
6. **Computational checks pass but predictions fail?** Revisit the observation process and model assumptions. More accurate integration of a poor model leaves its predictive defect intact.

For the illustrative hierarchy, the concrete next step is to mark divergences against the group scale, compare equivalent centred and noncentred formulations, and repeat the full diagnostic and estimand checks. Regularising priors require substantive justification because they change the model. Reparameterisation, correctly implemented, need not change it.

---

Source: `course/chapters/06_hmc.md:186–190`

## Lab

**Selected-core task:** compare the supplied NUTS fit with its exact reference and write a diagnostic memo separating computation from model criticism. **Extended task:** hand leapfrog arithmetic, transformed-density derivation and funnel geometry add mathematical depth beyond that submission.

Run [Lab 6](../../notebooks/06_hmc.ipynb), or its [Python source](../../labs/06_hmc.py), and inspect the [trace figure](../../artifacts/figures/06_trace.svg). Add rank plots, indicator MCSE, and interval-endpoint MCSE to your investigation. Keep prior predictions, posterior computations, and posterior predictive checks distinct. Record seeds, software versions, settings, and the result needed for the decision. Seeds alone do not ensure identical draws across processors or numerical backends.

---

Source: `course/chapters/06_hmc.md:192–196`

## Retrieval and summary

Explain why a valid Metropolis correction and R-hat near one can coexist with inadequate exploration. Describe which error measure belongs beside a posterior mean, a tail probability, and a credible-interval endpoint. Explain why a negative-waiting-time prediction is a modelling issue even when a sampler accurately represents its target.

HMC uses energy-preserving dynamics as an ideal and numerical trajectories as proposals. Warmup and NUTS automate useful tuning, while geometry and identification remain modelling responsibilities. Report agreement, exploration warnings, estimand precision, exact-reference checks, and predictive adequacy as distinct evidence.

---

Source: `course/chapters/06_hmc.md:198–206`

## Lab and exercises

**6.1 — Concept.** A model has R-hat 1.00 and zero divergences but predicts negative waiting times frequently. Is the computation necessarily broken? What should be investigated?

**6.2 — Diagnosis.** Four chains produce R-hat 1.08, bulk ESS 70, and 40 divergences. Give a reasoned sequence of three actions before reporting a posterior probability.

**6.3 — Computation.** For 14 observed successes in 20 conditionally independent Bernoulli trials sharing probability theta, replace its Beta(2,2) prior with Beta(10,10), fit the binomial model using multiple chains, and compare its mean with the new analytic answer. Submit your own code and output with seeds, mean MCSE, quantile MCSEs, R-hat, bulk/tail ESS, divergences and the change in a central 90% credible interval against both exact posteriors.

[Solutions](../solutions.md).

---

Source: `course/chapters/06_hmc.md:208–210`

## Further reading

[Hoffman and Gelman (2014)](https://jmlr.org/papers/v15/hoffman14a.html) derive NUTS; [Betancourt (2017)](https://arxiv.org/abs/1701.02434) develops HMC geometry. [Vehtari and colleagues (2021)](https://arxiv.org/abs/1903.08008) explain rank normalisation, folding, and local precision diagnostics. Consult the [official PyMC resources](https://www.pymc.io/welcome.html) alongside the installed, pinned API and [Stan's warning guide](https://mc-stan.org/learn-stan/diagnostics-warnings.html).

---

Source: `course/chapters/07_regression.md:1–3`

# 7 · Explain variation with regression

**Objectives:** build a Gaussian regression; choose priors on an interpretable scale; propagate joint uncertainty into predictions; recognise residual structure; derive coefficient and prediction covariance; diagnose scaling, collinearity and extrapolation. **Prerequisite:** chapters 4 and 6; use [Appendix 3](../appendices/03_linear_algebra.md) for matrix notation and quadratic forms.

---

Source: `course/chapters/07_regression.md:5–11`

## A mean that changes with context

A service manager wants to tell visitors how long they might wait when the centre is busy. Yesterday's overall average mixes quiet and busy periods. A better forecast could use workload known at arrival. But the manager has two questions: what is the average wait at a given workload, and what range should one visitor expect? Regression addresses both through different distributions.

The recurring [synthetic waiting dataset](../../data/README.md) contains visits at eight centres. Its workload index is already on a centred teaching scale; the suffix `_z` does not mean that this particular sample has mean zero and standard deviation one. Begin with a common regression line, deliberately postponing centre differences until chapter 9. This makes the consequences of omitting structure visible.

Before calculating, predict the direction of the workload association and name one reason the line might fail. Staffing and visit complexity could influence both workload and waiting. The coefficient describes a conditional association; it is not automatically the effect of intervening to increase workload.

---

Source: `course/chapters/07_regression.md:13–31`

## A complete generative regression

Treat observed workloads as fixed inputs, measured without error for this first model. Conditional on these inputs, generate parameters and then independent visits:

$$
\begin{aligned}
\alpha&\sim\operatorname{Normal}(10,3^2),&
\beta&\sim\operatorname{Normal}(0,2^2),&
\sigma&\sim\operatorname{HalfNormal}(2),\\
\mu_i&=\alpha+\beta x_i,&
Y_i\mid\alpha,\beta,\sigma,x_i&\sim\operatorname{Normal}(\mu_i,\sigma^2).
\end{aligned}
$$

The three priors are independent. Throughout this chapter the second Normal argument is a variance, while HalfNormal takes a scale: it is the absolute value of a zero-mean Normal draw with that standard deviation. Alpha and sigma have units of minutes; beta has units of minutes per workload-index unit. Alpha is the mean at workload zero, beta changes the conditional mean, and sigma describes residual variation around it.

The likelihood is a product over visits. Multiplying that product by the three prior densities defines the joint posterior, including the uncertainty in the residual scale. No distribution for workload is needed for this conditional question. Forecasting when future workload is itself unknown requires another model or an explicit scenario distribution for that input.

The assumptions are a linear conditional mean, constant conditional variance, Gaussian residual tails and conditional independence. Marginally, observations share uncertain parameters. Conditional independence would still be wrong if successive visits share an unmodelled queue disruption. A distribution statement should therefore be accompanied by the observation unit and the circumstances under which its independence assumption is plausible.

---

Source: `course/chapters/07_regression.md:33–47`

## Priors have units

Prior prediction means drawing one parameter triple, evaluating its line across the intended workload range, and then generating noisy visits around that same line. Repeat the whole process. Inspect both the implied mean curves and outcomes: a plausible average can coexist with implausible residual variation.

For these independent priors, the mean wait at a fixed workload is exactly Normal with mean ten and variance

$$\operatorname{Var}(\alpha+\beta x)=9+4x^2.$$

At workload zero its prior standard deviation is three minutes; at workload two it is five. The latter mean distribution puts about 2.3% probability below zero. Moreover, the half-normal scale prior has expected squared scale four, so the prior predictive variance for a visit is

$$\operatorname{Var}(Y\mid x)=9+4x^2+E[\sigma^2]=13+4x^2.$$

The predictive distribution is a mixture over residual scales, so its quantiles do not follow just by treating this variance as a single Normal variance. This calculation nevertheless exposes a real limitation: even the lab priors allow physically impossible negative waiting times. They are a teaching starting point to inspect, not a universal recommendation.

Calling Normal with standard deviation one thousand “weak” ignores its predictive consequences. Such a slope can imply enormous waiting-time changes across a small workload range. With several predictors, individually modest independent priors can also combine into very variable linear predictors. Examine plausible combinations of inputs as well as one-variable plots.

---

Source: `course/chapters/07_regression.md:49–61`

### Worked example 1: change units without changing beliefs

Suppose workload is measured as arrivals per hour, denoted by $u$, and define $z=(u-40)/10$. Write the line as $a+bz$, with independent priors $a\sim\operatorname{Normal}(10,3^2)$ and $b\sim\operatorname{Normal}(0,2^2)$. The same line on the original scale is

$$a+b(u-40)/10=A+Bu,\qquad A=a-4b,\quad B=b/10.$$

Thus the original-scale intercept has variance seventy-three, the slope has variance 0.04, and their covariance is −1.6. These follow by expanding the linear transformations, not by choosing new independent priors. At fifty arrivals per hour the predicted mean is either $a+b$ or $A+50B$. The second representation gives

$$\operatorname{Var}(A+50B)=73+50^2(0.04)+2(50)(-1.6)=13,$$

agreeing with the first representation's variance $9+4$. Dropping the induced covariance would give variance 173 and a completely different prior prediction. The apparently uncertain original intercept concerns zero arrivals, far from the reference workload; its strong dependence with the slope preserves sensible predictions near forty.

In general, centring and scaling change coefficient meanings and their joint prior. They do not change the model if the full transformation is carried through. When learning preprocessing constants from data, estimate them on training data and reuse them on validation data. Save those constants with the fitted model so deployment uses the same units.

---

Source: `course/chapters/07_regression.md:63–87`

## A useful analytic connection

To see how a likelihood learns a line, temporarily suppose residual variance is known. With $n$ observations and $p$ coefficients, let $y$ be an $n\times1$ vector, $X$ an $n\times p$ design matrix, and $b$ a $p\times1$ coefficient vector. A column of ones in the design supplies the intercept. Take

$$y\mid b\sim\operatorname{Normal}(Xb,\sigma^2I_n),\qquad b\sim\operatorname{Normal}(m_0,V_0).$$

The prior covariance is positive definite. Expanding the two quadratic terms in the log posterior and collecting terms involving the coefficients gives

$$
\begin{aligned}
\log p(b\mid y)&=C_0-\frac{(y-Xb)^T(y-Xb)}{2\sigma^2}
-\frac{(b-m_0)^TV_0^{-1}(b-m_0)}2,\\
\log p(b\mid y)&=C-\tfrac12(b^TP_nb-2b^Th_n),\\
P_n&=V_0^{-1}+X^TX/\sigma^2,\\
h_n&=V_0^{-1}m_0+X^Ty/\sigma^2.
\end{aligned}
$$

Here the precision matrix is $p\times p$ and the information vector is $p\times1$. Completing the square identifies

$$V_n=P_n^{-1},\qquad m_n=V_nh_n,\qquad b\mid y\sim\operatorname{Normal}(m_n,V_n).$$

This is the scalar normal-normal update in several dimensions. The diagonal precision contributions are accompanied by cross-terms, reflecting which coefficient combinations the design can distinguish. A zero-centred Gaussian slope prior penalises squared slopes at the posterior mode, connecting this calculation to ridge regularisation. The full posterior also retains uncertainty and dependence around that mode.

Use linear solves or a Cholesky decomposition in numerical code rather than constructing matrix inverses by default. The inverse notation expresses the mathematical relationship. When sigma is unknown, as in the lab, the conditional calculation depends on its current value; integrating over sigma generally produces a mixture rather than this single multivariate Normal.

---

Source: `course/chapters/07_regression.md:89–106`

### Worked example 2: learn correlated coefficients

Consider three illustrative waits of nine, eleven and thirteen minutes at workloads zero, one and two. This tiny example is separate from the lab dataset. Assume known residual standard deviation one minute and a prior coefficient mean $(10,0)^T$ with identity covariance. The prior slope standard deviation is therefore one, different from the lab's two. Then

$$
X=\begin{pmatrix}1&0\\1&1\\1&2\end{pmatrix},\quad
P_n=\begin{pmatrix}4&3\\3&6\end{pmatrix},\quad
h_n=\begin{pmatrix}43\\37\end{pmatrix}.
$$

The determinant of the precision is fifteen. Solving for the posterior yields

$$V_n=\frac1{15}\begin{pmatrix}6&-3\\-3&4\end{pmatrix},\qquad
m_n=\begin{pmatrix}9.8\\19/15\end{pmatrix}.$$

The slope mean is about 1.267 minutes per workload unit. It is pulled below the data-only line's slope of two because the prior favours smaller slopes and three observations provide limited information. Multiplying the displayed precision by the mean returns the information vector, giving a direct arithmetic check.

The intercept variance is 0.4, slope variance approximately 0.267, and covariance −0.2. A larger intercept can be partly offset by a smaller slope where the observations lie. Thus independent priors need not produce independent posterior coefficients. The uncertainty is an inclined cloud of plausible lines, not a box constructed from separate marginal intervals.

---

Source: `course/chapters/07_regression.md:108–135`

## Joint draws preserve relationships

At a new workload, let $r_*=(1,x_*)^T$. In the known-scale model, the conditional mean and one new observation have distributions

$$
\mu_*\mid y\sim\operatorname{Normal}(r_*^Tm_n,r_*^TV_nr_*),\qquad
\widetilde Y_*\mid y\sim\operatorname{Normal}(r_*^Tm_n,r_*^TV_nr_*+\sigma^2).
$$

The mean variance expands to intercept variance, plus squared workload times slope variance, plus twice workload times their covariance. In the preceding example it is $0.4-0.4x_*+(4/15)x_*^2$. The covariance matters even when each marginal summary is accurate.

Continue the example at workload one, inside the observed range, and workload four, outside it. Using the Normal 95th percentile, approximately 1.645, gives the following central 90% intervals; all endpoints are minutes.

| Workload | Posterior mean wait | Variance of mean | Interval for mean | Interval for one visit |
|---|---:|---:|---|---|
| 1 | 11.067 | 0.267 | [10.217, 11.916] | [9.215, 12.918] |
| 4 | 14.867 | 3.067 | [11.986, 17.747] | [11.550, 18.184] |

At workload one, discarding covariance would replace the mean variance by approximately 0.667. At negative workloads the same discarded covariance would instead reduce uncertainty. Independently shuffling the marginal draws has no generally conservative interpretation.

For the fitted model with unknown scale, compute a mean from each matching intercept and slope draw, then draw observation noise using that draw's sigma. Total variance gives

$$\operatorname{Var}(\widetilde Y_*\mid y)=\operatorname{Var}(\mu_*\mid y)+E[\sigma^2\mid y].$$

Do not replace the last term by squared posterior mean sigma. Obtain mixture quantiles from simulated predictions. For several future visits, share one parameter draw across the batch and generate separate residuals. If all have the same workload and are conditionally independent, the variance of their average is mean uncertainty plus expected residual variance divided by batch size. Averaging visitors reduces individual noise but does not erase uncertainty about the line.


<!-- VISUAL01:09 BEGIN -->

---

Source: `course/chapters/07_regression.md:137–154`

### Visual investigation: a mean interval is not an individual interval

For this separate toy regression, let $\mu(x)=8+2x+A$ with posterior $A\mid D\sim N(0,0.25)$ and independent future residual SD two minutes. The slope is fixed here. Predict which uncertainty remains if the intercept offset becomes known exactly.

![An uncertain-intercept mean line has a narrow pointwise band, while independent residual variation produces a wider individual predictive band.](../../artifacts/figures/visual01_09_regression.svg)

**Read the figure.** The horizontal coordinate is a standardised workload and the vertical coordinate is response time in minutes. The solid line is the posterior expected mean. The narrow band describes the conditional mean; the wider hatched band predicts a new individual response. At each fixed x, both bands are central 90% intervals for their stated targets. In this special fixed-slope model, the same uncertain intercept shifts the whole mean curve, so the narrow band also covers that entire mean curve with probability 0.9. Pointwise bands in more general regression models need not have simultaneous 90% coverage. The individual intervals do not give a joint 90% guarantee for a collection of future responses.

| Target at x = 1 | Centre (minutes) | Variance (minutes squared) | Central 90% interval (minutes) |
|---|---:|---:|---|
| Mean response | 10 | 0.25 | [9.177573, 10.822427] |
| One future response | 10 | 4.25 | [6.609047, 13.390953] |

**Mathematical connection.** Independent residual variation adds to mean uncertainty: $\operatorname{Var}(Y_{new}\mid D,x)=\operatorname{Var}(\mu(x)\mid D)+\sigma^2$. The half-widths are $z_{.95}\sqrt{0.25}$ and $z_{.95}\sqrt{4.25}$. In a regression with uncertain slope too, preserve joint coefficient draws because their covariance changes $\operatorname{Var}(\mu(x))$ with x.

**Original unscored exploration — predict, observe, explain.** Set only the intercept variance to zero. Predict and then observe that the mean interval collapses while the individual interval retains half-width $1.644854\times2=3.289707$. Explain why collecting more information about the mean does not remove irreducible residual variation under this model. Extrapolation, uncertain residual scale and model error are outside this stipulated illustration.

<!-- VISUAL01:09 END -->

---

Source: `course/chapters/07_regression.md:156–164`

## A model can fit the line and miss the process

After fitting the service regression, compute residuals from observed waits minus posterior mean fitted waits. Plot them against workload, centre and visit order when available. A nearly horizontal overall residual trend is not enough: positive errors at one centre and negative errors at another can cancel globally.

Suppose the busy half of a hypothetical dataset has residual standard deviation two minutes and the quiet half has standard deviation one. A fitted common scale of 1.5 can cover some quiet visits too generously while missing busy extremes. A candidate revision models log residual scale as a function of workload, with its own justified priors. Replicated residual spreads within workload bands would then check the feature that motivated the revision.

A curved pattern instead suggests revising the conditional mean, perhaps with a quadratic term or a spline. Persistent centre differences motivate chapter 9's varying intercepts. Serial runs of errors suggest dependence, while isolated extremes call for checking measurement and considering heavier tails. These patterns support different investigations; adding a wider noise distribution indiscriminately can hide a systematic mean error.

Residuals calculated after fitting have been influenced by that fit. Posterior predictive checks generate replicated datasets at the observed inputs and compare a relevant statistic, such as between-centre residual variation or the maximum wait. Chapter 10 develops these checks. A clean R-hat and large effective sample size establish neither correct residual structure nor accurate predictions: they concern computation under the chosen model.

---

Source: `course/chapters/07_regression.md:166–176`

### A diagnostic calculation: a hidden centre contrast

Imagine two centres with the same average workload. They have four and thirty-six independent visits, and adjusted average waits of eight and twelve minutes. Under a common-intercept model with residual standard deviation fixed at 1.5 minutes, the difference of their averages has expected value zero. The common intercept cancels, and the common workload slope cancels because their average workloads match. Its conditional variance is

$$1.5^2(1/4+1/36)=0.625.$$

The standard deviation is approximately 0.791 minutes, so a central 90% model interval for the contrast is about −1.300 to 1.300 minutes. The observed contrast of four minutes is more than five such standard deviations from zero. This is a concrete feature that the common-line model finds difficult to reproduce, even if the overall average wait is well fitted.

For this teaching calculation the scale was held fixed. In a fitted analysis, generate the contrast from replicated visits across posterior draws, keeping each centre's sample size and workload values. Uncertainty in scale changes the reference distribution. If centre workloads do not match, slope uncertainty also matters. The calculation identifies a useful discrepancy; it does not replace the full check or establish the cause of the centre difference.

A model that inflates residual scale to accommodate this contrast may then predict too much variation within each centre. Inspecting both levels explains why a centre intercept can be a better revision than simply making all visits noisier. It also guards against overreacting to the noisiest small group: replication retains its small sample size, so the comparison already allows its average to fluctuate more.

---

Source: `course/chapters/07_regression.md:178–182`

## More predictors do not guarantee more information

If staffing and workload almost always move together, a multiple regression may estimate their combined predictive contribution while learning their separate coefficients poorly. With exactly duplicated predictors, increasing one coefficient and decreasing the other equally leaves every fitted mean unchanged. A proper prior can give a proper posterior in such a direction, but the data have not identified the division of credit.

Inspect joint draws and predictions at observed combinations before interpreting coefficient signs. New combinations, such as high workload with unusually low staffing, may expose the weakly learned direction. Centring can improve numerical geometry and interpretation; it cannot create missing design information. Interactions likewise require data in the relevant combinations, and a common slope assumes an association that does not change across those contexts.

---

Source: `course/chapters/07_regression.md:184–192`

## Prediction has a domain

The interval at workload four in the worked example is wider, but it still assumes the straight line continues. It omits uncertainty about a change in queue behaviour, a staffing threshold or a capacity limit. Even a very precise slope could generate a misleadingly precise extrapolation. State the input range and population for which the forecast is intended.

A Gaussian waiting-time likelihood also allows negative outcomes. If the implied probability is material in the application, consider a positive-support model such as a lognormal or gamma. A lognormal regression models log waiting time; exponentiating its log mean gives the conditional median, not generally the arithmetic mean. Changing support is therefore a substantive model revision, not merely clipping negative simulations to zero.

Return to the manager's question before presenting the result. A staffing planner comparing expected workload scenarios may need uncertainty about mean demand on the service. A visitor needs the distribution of their own wait, possibly a probability of exceeding a practical threshold. A single numerical interval cannot serve both purposes. If centre structure is still missing, report that limitation with the forecast rather than presenting the regression band as a service guarantee.

The prediction table illustrates the distinction without requiring MCMC. Real posterior draws add uncertainty about residual scale, but they do not automatically include every possible model revision. A credible forecasting statement therefore names the outcome, workload, centre information and period of application. Those details make an interval interpretable and allow later data to test the forecast actually issued.

---

Source: `course/chapters/07_regression.md:194–198`

## Lab

Run [Lab 7](../../notebooks/07_regression.ipynb), or [Python](../../labs/07_regression.py). The script fits the specified independent-prior model and saves the [prediction plot](../../artifacts/figures/07_regression.svg). Its inner band describes the conditional mean; its outer band includes visit noise. Both are pointwise intervals at each workload, not a simultaneous guarantee for the entire curve.

Inspect prior draws, sampler diagnostics and centre residual means separately. Explain which feature each checks. Submit a model statement, one quantitative prior prediction, a labelled prediction for a visitor, and a proposed revision tied to a residual pattern. Keep observed inputs fixed when comparing replicated data unless predicting a different workload distribution is explicitly the question. The chapter's three-observation calculations are analytic illustrations, not reported lab estimates.

---

Source: `course/chapters/07_regression.md:200–204`

## Retrieval and summary

Without looking back, explain why independent coefficient priors can lead to correlated posterior coefficients. Describe what information a shuffled-draw prediction loses. Then name a residual pattern that more NUTS draws cannot repair, and distinguish predicting many visits from learning many independent workload settings.

Regression is a distribution for outcomes conditional on context. Units determine prior meaning; joint coefficient uncertainty determines mean predictions; residual variation adds another layer for individuals. The design limits which associations can be separated, and predictive criticism determines whether the line and noise describe the process well enough for the stated use.

---

Source: `course/chapters/07_regression.md:206–214`

## Lab and exercises

**7.1 — Concept.** Explain why the posterior interval for mean waiting time is narrower than the predictive interval for one visitor.

**7.2 — Calculation.** For $Y\mid x,\alpha,\beta,\sigma\sim\operatorname{Normal}(\alpha+\beta x,\sigma^2)$, a draw has $\alpha=10$, $\beta=1.5$, and $\sigma=2$. Find its mean prediction at $x=2$ and the conditional central 90% interval for one outcome at that draw. Does this incorporate parameter uncertainty?

**7.3 — Applied.** The residual means of centres remain far apart, although global R-hat and ESS look good. Propose a model change and a data feature to check after refitting. Explain why more NUTS draws alone cannot fix the discrepancy.

[Solutions](../solutions.md).

---

Source: `course/chapters/07_regression.md:216–218`

## Further reading

[Regression and Other Stories](https://sites.stat.columbia.edu/gelman/regression/) develops interpretation, scaling and applied regression workflow. [Bayesian Modeling and Computation in Python, linear models](https://bayesiancomputationbook.com/markdown/chp_03.html) connects joint posterior computation with predictive interpretation. The [Stan regression guide](https://mc-stan.org/docs/stan-users-guide/regression.html) provides another formulation of design matrices and observation models; its programming notation uses Normal standard deviations, unlike this chapter's variance notation.

---

Source: `course/chapters/08_glm.md:1–3`

# 8 · Model binary outcomes and counts

**Objectives:** choose likelihoods matching outcome support; interpret logit and log links; translate effects to the response scale; account for exposure and causal assumptions; derive population probability contrasts; diagnose separation, overdispersion and identification limits. **Prerequisite:** chapter 7, conditional probability and the variance decomposition in [Appendix 1](../appendices/01_probability.md).

---

Source: `course/chapters/08_glm.md:5–23`

## A straight line cannot be every probability

A service records whether each user completes onboarding. Managers want to forecast completion at different support levels and plan how many follow-up contacts will be needed. These are two outcomes with different supports: completion is zero or one, while contacts are nonnegative integer counts. Neither is well described by adding constant-variance Gaussian noise to an unrestricted line.

A generalised linear model separates three choices: the sampling distribution, a linear predictor, and a link connecting that predictor to the distribution's mean. A link keeps predictions within the outcome's allowable range; it does not guarantee that the chosen predictor captures the process. Binary and count models still need prior prediction, computational diagnostics, predictive criticism and a clearly defined population.

For the [synthetic completion data](../../data/README.md), treat each user as the observation unit and the supplied centred support index as a known predictor. It is a teaching scale, not a guarantee of sample standardisation. A complete logistic model matching the lab is

$$
\begin{aligned}
\alpha&\sim\operatorname{Normal}(0,1.5^2),\qquad
\beta\sim\operatorname{Normal}(0,1^2),\\
\eta_i&=\alpha+\beta x_i,\qquad
p_i=\frac1{1+\exp(-\eta_i)},\\
Y_i\mid\alpha,\beta,x_i&\sim\operatorname{Bernoulli}(p_i).
\end{aligned}
$$

The priors are independent; users are conditionally independent. The Normal distributions here use variance as the second argument. For a Bernoulli observation the conditional variance is fixed by its mean, $p_i(1-p_i)$. There is no additional Gaussian residual standard deviation to estimate.

---

Source: `course/chapters/08_glm.md:25–38`

## From a generative story to a likelihood

The logit link is $\log[p/(1-p)]$. Solving for the probability gives the inverse link above. Consequently the linear predictor is the log odds, not the probability itself. For recorded binary outcomes, the likelihood and its logarithm are

$$
L(\alpha,\beta)=\prod_i p_i^{y_i}(1-p_i)^{1-y_i},\qquad
\log L=\sum_i\{y_i\eta_i-\log(1+e^{\eta_i})\}.
$$

Each success contributes its predicted probability and each failure the predicted probability of failure. The expression also shows why fitting cannot be done by simply taking the logit of each observed zero or one: those transformed observations would be infinite. The model transforms the unobserved probability.

For computation, evaluate the log likelihood using a stable softplus calculation, such as `logaddexp(0, eta)`, rather than directly exponentiating a very large linear predictor. Multiply the likelihood by the coefficient priors to obtain the posterior. It generally has no simple conjugate form; the lab uses NUTS. Numerical stability and posterior reliability are separate issues from whether the model is scientifically adequate.

Several users with exactly the same conditional probability may be represented by a Binomial success count with the known number of trials. Aggregating users with different predicted probabilities into one Binomial generally changes the model. Likewise, repeated observations of the same user may require a shared effect rather than independent Bernoulli factors.

---

Source: `course/chapters/08_glm.md:40–46`

## Put priors through the inverse link

At support zero, the prior log odds have standard deviation 1.5. A central 95% interval for the log odds is approximately −2.94 to 2.94, corresponding to probabilities about 0.050 to 0.950. At support two, independent coefficient uncertainty gives log-odds variance $2.25+4=6.25$. The corresponding probability interval is approximately 0.0074 to 0.9926. The same priors allow more extreme probabilities toward the edges of the input range.

Symmetry makes the prior mean probability one half at every fixed support value in this particular model. That benign-looking average conceals considerable mass near confident predictions. A large coefficient scale can make simulated curves almost deterministic, even though the prior mean curve looks flat. Inspect distributions of curves and simulated success counts, not only an average probability curve.

Scaling matters as in Gaussian regression. If one support unit changes from one hour to ten hours, keeping the same numerical slope prior changes its meaning. With many predictors, prior variances add in the linear predictor when coefficient priors are independent. Elicit plausible baseline probabilities and changes over meaningful predictor ranges, then check the entire resulting model. Holding input values fixed during prior simulation makes these consequences easier to interpret.

---

Source: `course/chapters/08_glm.md:48–54`

## Odds ratios are not probability differences

Increasing support by one unit adds beta to log odds, so it multiplies odds by $e^\beta$. The odds at probability one fifth are one to four; they are not one fifth. For baseline probability $p_0$ and odds multiplier $R$, the new probability is

$$p_1=\frac{Rp_0}{1-p_0+Rp_0}.$$

The absolute change depends on the baseline. Locally, differentiation gives $dp/dx=\beta p(1-p)$, so a constant log-odds slope produces its largest absolute probability slope near one half. Toward zero or one, the probability curve flattens.

---

Source: `course/chapters/08_glm.md:56–80`

### Worked example 1: the same odds multiplier in a target population

Consider two user strata with baseline completion probabilities 0.2 and 0.6. Suppose a model has separate baseline intercepts for the strata and a common support coefficient $\beta=\log 2$. Compare support zero with support one while holding stratum fixed. This is an illustrative fixed-coefficient calculation, separate from the lab fit.

In the first stratum, odds move from $0.2/0.8=0.25$ to 0.5, giving probability one third. In the second, odds move from $0.6/0.4=1.5$ to three, giving probability three quarters. The probability increases are therefore about 0.1333 and 0.1500: 13.33 and 15 percentage points. Neither is a doubling of completion probability.

Suppose the intended population is three quarters first-stratum users and one quarter second-stratum users. Average the two scenario probabilities with these same weights:

$$
\begin{aligned}
\bar p_0&=0.75(0.2)+0.25(0.6)=0.3000,\\
\bar p_1&=0.75(1/3)+0.25(3/4)=0.4375,\\
\Delta&=\bar p_1-\bar p_0=0.1375.
\end{aligned}
$$

The standardised contrast is 13.75 percentage points, or an expected difference of 137.5 completions per thousand users under these modelled scenarios. An expectation need not be an integer; an actual future count is. If the population weights are instead one half each, the contrast becomes about 14.17 percentage points. A population description is part of the answer.

The marginal odds ratio obtained from probabilities 0.4375 and 0.3000 is about 1.815, although the conditional stratum-specific odds ratio is two. This illustrates the noncollapsibility of odds ratios: conditional and marginal odds contrasts need not agree even without confounding. Do not infer bias merely because those two numerical summaries differ.

In a posterior analysis, repeat every step for each joint coefficient draw. With target covariates $c_k$ and fixed nonnegative weights summing to one, calculate

$$\Delta^{(s)}=\sum_k w_k\{p^{(s)}(x_1,c_k)-p^{(s)}(x_0,c_k)\}.$$

Then summarise the distribution of these contrasts. Do not first average coefficients or average covariates. For example, equally weighted log-odds values −2 and zero give mean probability about 0.3096, whereas applying the inverse logit to their mean gives 0.2689. Nonlinearity makes those operations different. These are modelled probability contrasts; interpreting them as intervention effects requires further assumptions.

---

Source: `course/chapters/08_glm.md:82–94`

## Probability uncertainty and future outcomes

A posterior interval for a user's completion probability describes uncertainty about that probability. The future outcome is still either zero or one, so a central predictive interval often contains both and communicates little. Report the probability, its uncertainty and the user's context.

For a future cohort, draw one joint coefficient vector and simulate all users' outcomes conditional on it. Users can have different probabilities. Repeating this produces a distribution for total completions that includes parameter uncertainty and individual randomness. With a shared uncertain probability for all users, this is the mixture logic from chapter 3. Drawing a fresh posterior parameter vector independently for every user incorrectly removes the uncertainty shared across the cohort.

Check replicated success totals across support bands and relevant user groups. A single binary outcome offers little information about probability calibration; patterns across comparable users are more revealing. A probability curve bounded between zero and one can still systematically overpredict completion for one group. Out-of-sample probability evaluation should retain repeated users or centres together when that matches the prediction target.

For a concrete diagnostic, suppose a fixed fitted model assigns probability one half to forty users in each of two groups. It predicts twenty completions per group, with conditional standard deviation $\sqrt{40(0.5)(0.5)}=\sqrt{10}\approx3.162$. If the observed totals are ten and thirty, the combined total is exactly the predicted forty, yet each group deviates by more than three conditional standard deviations. An overall success-count check would conceal the opposite errors.

Those fixed-probability calculations are a starting point for a discrepancy, not a complete posterior predictive analysis. Repeatedly draw the fitted probabilities, simulate both groups and compare their completion contrast with the observed contrast. Then investigate whether a missing group predictor, dependence or different observation procedures explain the pattern. A wider coefficient prior alone does not supply a systematic group difference absent from the linear predictor.

Likewise, logistic extrapolation can look reassuring because it never leaves the unit interval. Far outside the observed support range, the model may predict near-certain success or failure by continuing its assumed linear log odds. The data may contain little evidence for that certainty. Report where the model was evaluated, and check whether the support intervention or user population has changed. Valid numerical support for an outcome is only the first requirement for a useful forecast.

---

Source: `course/chapters/08_glm.md:96–96`

## Separation and regularisation

---

Source: `course/chapters/08_glm.md:98–112`

### Worked example 2: when a slope can keep increasing

Suppose three users at support −1 all fail and three at support +1 all succeed. Hold the intercept at zero for this demonstration. Both a low-support failure and a high-support success have probability $\operatorname{logit}^{-1}(\beta)$, so

$$L(\beta)=\{\operatorname{logit}^{-1}(\beta)\}^6.$$

As the slope increases, this likelihood approaches one without attaining a finite maximum. At slopes two and six it is approximately 0.467 and 0.985. Almost any sufficiently large positive slope classifies these observations well; they do not establish how enormous the odds multiplier should be. Allowing an unknown intercept does not remove separation in this dataset.

A proper Normal slope prior penalises the otherwise unbounded tail. In this fixed-intercept example, with prior standard deviation $s_\beta$, the derivative of log posterior is

$$6\{1-\operatorname{logit}^{-1}(\beta)\}-\beta/s_\beta^2.$$

The likelihood contribution tends to zero while the prior contribution increasingly opposes large positive slopes, yielding a finite posterior mode. A proper Gaussian prior on every coefficient also gives a proper posterior here, with finite moments. It expresses the information needed to regularise magnitudes that the likelihood scarcely distinguishes.

Diagnose separation by inspecting outcomes across predictor combinations, large coefficient uncertainty and sensitivity to defensible prior scales. Compare resulting probabilities near the transition, not just classification accuracy at the observed extremes. A prior with standard deviation one hundred may be proper but still imply implausibly abrupt transitions and huge odds ratios. More sampling can estimate that posterior better; it cannot supply missing users near the decision boundary. Stan's [discussion of separability](https://mc-stan.org/docs/stan-users-guide/problematic-posteriors.html#separability-in-logistic-regression) gives a complementary account of this likelihood problem.

---

Source: `course/chapters/08_glm.md:114–135`

## Counts: an exponential link and an offset

Now model follow-up incident counts over known positive exposures, measured in centre-days. An illustrative complete Poisson regression is

$$
\begin{aligned}
\alpha&\sim\operatorname{Normal}(\log 2,0.7^2),\quad
\beta\sim\operatorname{Normal}(0,0.5^2),\\
\lambda_i&=\exp(\alpha+\beta x_i),\quad
\mu_i=t_i\lambda_i,\quad
Y_i\mid\alpha,\beta,x_i,t_i\sim\operatorname{Poisson}(\mu_i).
\end{aligned}
$$

Take independent priors and conditionally independent observation windows. Lambda is a rate per centre-day; mu is the expected count for the window. The log expected count is $\log t_i+\alpha+\beta x_i$. The known log exposure is an **offset**, with coefficient fixed to one. Doubling time doubles expected count under this model.

The likelihood contribution is $\exp(-\mu_i)\mu_i^{y_i}/y_i!$. This accommodates different exposure lengths directly. Regressing counts without exposure can confuse opportunity to observe incidents with incidence rate. Exposure must represent time or opportunity actually at risk: a closed centre's calendar days may be the wrong denominator. A zero-exposure window implies count zero deterministically and must be handled separately from a logarithmic offset; a positive count in such a window signals inconsistent data or a wrong definition.

Changing exposure units changes the rate intercept. The baseline prior above has median rate two, but mean rate $2\exp(0.7^2/2)\approx2.555$ because exponentiation is nonlinear. Simulate counts at the actual exposure lengths to judge the prior. A reasonable-looking log-rate interval can imply implausibly large counts at long exposures.


<!-- VISUAL01:10 BEGIN -->

---

Source: `course/chapters/08_glm.md:137–155`

### Visual investigation: matching exposure does not remove conditional dispersion

Before the fitted repair-call workflow, isolate two mechanisms with a new analytic illustration. Set the rate to two events per centre-day. Compare a Poisson observation model with an NB2 model of fixed size four, always matching exposure and expected count. Predict whether equal means force equal probabilities of zero.

![Poisson and NB2 count masses are compared at exposures one half, one and two centre-days, with the same rate and means in each panel.](../../artifacts/figures/visual01_10_dispersion.svg)

**Read the figure.** Every panel uses the same count and probability-mass scales. Circle/solid marks identify the Poisson masses and square/dashed marks the NB2 masses. Lines guide the eye between integer counts; noninteger outcomes do not acquire probability. The displayed range is 0–15; both models have an infinite upper tail, so omitted mass is not zero.

| Exposure (centre-days) | Mean count | Poisson variance | NB2 variance | Poisson P(0) | NB2 P(0) |
|---:|---:|---:|---:|---:|---:|
| 0.5 | 1 | 1 | 1.25 | 0.367879 | 0.409600 |
| 1 | 2 | 2 | 3 | 0.135335 | 0.197531 |
| 2 | 4 | 4 | 8 | 0.018316 | 0.062500 |

**Mathematical connection.** With $\mu=2e$, Poisson variance equals $\mu$, whereas NB2 variance is $\mu+\mu^2/4$. The comparison stipulates conditional dispersion; it does not add uncertainty about fitted coefficients. Unequal exposure can explain some count variation, but a difference remains between these models after matching exposure.

**Original unscored exploration — predict, observe, explain.** Double exposure from one to two centre-days. Observe that the mean doubles, Poisson variance doubles, and NB2 variance changes from three to eight. Explain why this does not identify structural zeros or persistent centre dependence. Transfer to a recorded zero: list exposure and observation-process information needed before interpreting it. These illustrative curves are separate from the independently reviewed fit below.

<!-- VISUAL01:10 END -->

---

Source: `course/chapters/08_glm.md:157–175`

### Worked example 3: exposure and overdispersion

For a fixed illustrative draw, set the baseline rate to two and the one-unit workload rate multiplier to 1.5. At workload one the rate is three incidents per centre-day. Exposure one half gives expected count 1.5; exposure two gives expected count six. A quieter centre at workload zero with exposure four has expected count eight. It can have more incidents despite having the lower rate.

A Poisson count with mean six also has conditional variance six. Suppose comparable windows have more variability than posterior replicated Poisson counts predict. First check missed predictors, dependence and exposure errors: unequal means alone create a marginal variance larger than the marginal mean, even when each conditional Poisson model is correct.

One explicit extension introduces a multiplicative window-specific intensity:

$$U_i\mid\phi\sim\operatorname{Gamma}(\phi,\text{rate}=\phi),\qquad
Y_i\mid U_i,\mu_i\sim\operatorname{Poisson}(\mu_iU_i).$$

The multiplier has mean one and variance $1/\phi$. Integrating it out gives a negative-binomial count with

$$E[Y_i\mid\mu_i,\phi]=\mu_i,\qquad
\operatorname{Var}(Y_i\mid\mu_i,\phi)=\mu_i+\mu_i^2/\phi.$$

Total variance explains the terms: expected Poisson variance is mu, and variance of the random intensity is squared mu divided by phi. For mean six and phi three, variance is eighteen and standard deviation about 4.243, compared with Poisson standard deviation 2.449. The zero probability is $(3/(3+6))^3\approx0.0370$, compared with $e^{-6}\approx0.00248$. Ordinary heterogeneity can therefore increase zeros as well as extreme counts. This parameterisation is documented in the [Stan negative-binomial reference](https://mc-stan.org/docs/functions-reference/unbounded_discrete_distributions.html).

For an unknown dispersion, a complete model also needs a prior. One option to examine is a half-normal prior on the multiplier's standard deviation $d=1/\sqrt\phi$, together with the regression priors above. A scale of one is an illustrative starting point, implying substantial relative rate variation; simulate its consequences before use. Small d approaches Poisson behaviour. A window-specific multiplier does not model persistent dependence across windows; a shared centre effect would instead connect them. Extra zeros alone do not identify a separate structural-zero process.

---

Source: `course/chapters/08_glm.md:177–198`

## A fitted repair-call workflow

The preceding fixed-rate examples separate rate from opportunity. Now [Lab 8](../../labs/08_glm.py) actually fits both count models. Each observation is an independent synthetic repair-call window, with workload known before the window and exposure measured in operational centre-days. There are no persistent centre identities. All 48 windows are training observations; future scenarios have no supplied outcomes.

| Workload | Exposure | Four observed window counts |
|---:|---:|---|
| 2 | 0.5 | 2, 0, 4, 2 |
| 2 | 1 | 1, 1, 10, 1 |
| 2 | 2 | 0, 6, 1, 1 |
| 2 | 4 | 11, 0, 2, 2 |
| 4 | 0.5 | 0, 0, 0, 0 |
| 4 | 1 | 3, 1, 0, 1 |
| 4 | 2 | 3, 4, 0, 7 |
| 4 | 4 | 0, 8, 22, 7 |
| 6 | 0.5 | 0, 0, 0, 2 |
| 6 | 1 | 2, 2, 0, 5 |
| 6 | 2 | 2, 1, 4, 11 |
| 6 | 4 | 41, 0, 25, 2 |

There are 197 calls, 15 zero windows and a maximum count of 41. These counts were frozen before fitting, not selected after seeing model checks. For reproducibility, the original generator used NumPy seed 81201, standardised workload, rate $\exp(\log2+0.45x)$ and independent Gamma(shape 1.2, rate 1.2) multipliers. Those generating values are provenance, not inputs to the fitting routine or proof that the revised model is adequate.

The training workloads have mean four and population standard deviation $s_w=\sqrt{8/3}=1.632993$. Store these values and use $x=(w-4)/s_w$ for every prediction. Appending a future workload must not change the training transformation. Positive-exposure training rows define the transformation; a zero-exposure, zero-count row contributes no rate likelihood. Reject a positive count at zero exposure. This explicit policy avoids taking $\log0$.

---

Source: `course/chapters/08_glm.md:200–223`

### Declare uncertainty before examining the fit

Use the independent coefficient priors already introduced: $\alpha\sim N(\log2,0.7^2)$ and $\beta\sim N(0,0.5^2)$. The baseline rate has prior median two and central 95% interval 0.507–7.886 calls per centre-day. The rate ratio for one training standard deviation of workload has interval 0.375–2.664. These are meaningful scales on which to question the prior.

Start with $Y_i\sim\operatorname{Poisson}(t_i e^{\alpha+\beta x_i})$. Predeclare the revision $d\sim\operatorname{HalfNormal}(1)$ independently, $\phi=d^{-2}$, and the Gamma–Poisson mixture above. Here $d$ is the conditional coefficient of variation of the window multiplier. After integrating that multiplier, the NB2 probability is

$$
p(y_i\mid\mu_i,d)=\frac{\Gamma(y_i+\phi)}{\Gamma(\phi)y_i!}
\left(\frac{\phi}{\phi+\mu_i}\right)^\phi
\left(\frac{\mu_i}{\phi+\mu_i}\right)^{y_i},\qquad
\operatorname{Var}(Y_i\mid\theta)=\mu_i+d^2\mu_i^2.
$$

The name NB2 refers to the quadratic extra variance. [PyMC's NegativeBinomial documentation](https://www.pymc.io/projects/docs/en/stable/api/distributions/generated/pymc.NegativeBinomial.html) uses `mu` and `alpha`, where its `alpha` corresponds to our $\phi$, not our regression intercept. The lab instead integrates this small posterior directly with SciPy; the existing locked PyMC version remains in use for the logistic fit.

Simulate entire datasets at the actual workloads and exposures before fitting. The executed lab uses 50,000 prior replicates (seed 81204); table entries are simulated 5th percentile / median / 95th percentile.

| Prior replicated statistic | Poisson | NB2 |
|---|---|---|
| Total calls | 62 / 202.5 / 662 | 58 / 199 / 676 |
| Maximum window count | 6 / 17 / 57 | 7 / 25 / 122 |
| Number of zero windows | 0 / 7 / 20 | 2 / 12 / 29 |

The tails are substantial, particularly the NB2 maximum. In a real application, ask whether such operational burdens are credible. A broad prior is not automatically a plausible one. Prior prediction and subsequent replicated-data criticism follow the workflow in [Stan's predictive-check guide](https://mc-stan.org/docs/stan-users-guide/posterior-predictive-checks.html) and [Gabry and colleagues' visualization paper](https://sites.stat.columbia.edu/gelman/research/published/bayes-vis.pdf); these references support the method, not an efficacy claim about this course.

---

Source: `course/chapters/08_glm.md:225–245`

### Fit with integration weights and check numerical error

The lab evaluates the likelihood and normalised prior densities on tensor Gauss–Legendre nodes. If $q_{jk}$ is the integration weight in coordinate $k$, posterior node mass is proportional to

$$W_j\propto L(\theta_j)p(\theta_j)\prod_kq_{jk}.$$

Normalise using log-sum-exp. Unequally spaced nodes are not equally weighted posterior draws; omitting integration volumes changes the answer. We integrate directly in $(\alpha,\beta,d)$, so there is no transformation Jacobian. The stable implementation uses $\log(1+z)$ calculations and the exact Poisson branch at $d=0$.

The initial domains are $[-2,3]$ for $\alpha$, $[-2,2]$ for $\beta$, and $[0,6]$ for $d$. Poisson orders 96, 128 and 160 and NB2 orders 52 and 72 agree in reported means/log normalisers within $1.5\times10^{-7}$. Expanding to $[-3,4]\times[-3,3]\times[0,8]$ at orders 160/96 changes reported prediction moments by less than $10^{-8}$. Estimated posterior mass outside the original box is about $8.6\times10^{-78}$ for Poisson and $3.4\times10^{-14}$ for NB2. These are empirical numerical checks, not rigorous global error bounds. The log normalisers validate integration here; this lesson does not use them for a Bayes-factor decision.

Parameter intervals come from marginal density integration and a refined cumulative distribution, using 161 then 241 evaluation points. Endpoint changes are below 0.0012. An independent equally spaced Simpson calculation and gamma-function likelihood check the means and log normalisers. No sampling R-hat or effective sample size applies to deterministic quadrature.

| Posterior quantity | Poisson mean; 90% interval | NB2 mean; 90% interval |
|---|---|---|
| Intercept $\alpha$ | 0.723; [0.598, 0.846] | 0.727; [0.424, 1.041] |
| Workload coefficient $\beta$ | 0.333; [0.212, 0.455] | 0.089; [−0.201, 0.375] |
| Multiplier CV $d$ | fixed zero | 1.167; [0.915, 1.456] |
| Baseline rate $E(e^\alpha\mid y)$ | 2.067 | 2.106 |
| Workload rate ratio $E(e^\beta\mid y)$ | 1.399 | 1.110 |

Allowing extra count variation changes both the slope estimate and its uncertainty. Do not report a posterior mean of $\phi=d^{-2}$: the posterior density remains positive as $d$ approaches zero under this prior, making that expectation divergent. A finite quadrature average would hide the mathematical problem. Summarise $d$, as above.

---

Source: `course/chapters/08_glm.md:247–278`

### Check the observation process at each exposure

A high overall variance alone is not decisive because exposure and workload already produce unequal conditional means. Keep those predictors fixed in posterior replication. For every replicated dataset, draw one **joint** parameter node and use it for all 48 windows. Conditional count noise and window multipliers are independent; uncertainty in the shared coefficients is not.

Within each exposure stratum $s$, examine zero counts $Z_s=\sum_{i\in s}1(Y_i=0)$, extreme counts $H_s=\sum_{i\in s}1(Y_i\ge20)$, and the Poisson-scaled residual discrepancy

$$D_s(y,\theta)=\sum_{i\in s}\frac{(y_i-\mu_i(\theta))^2}{\mu_i(\theta)}.$$

Apply this same discrepancy to both models. Compare $D_s(y^{rep},\theta)$ with $D_s(y,\theta)$ using the same parameter vector, rather than plugging in a posterior average mean. Observed $D_s$ itself varies with that vector. Each model uses 20,000 posterior replicated datasets, seeds 81205 and 81206 respectively.

| Exposure | Observed zeros | Poisson replicated mean; 90% range | NB2 replicated mean; 90% range |
|---:|---:|---|---|
| 0.5 | 8 | 4.311; [2, 7] | 6.305; [3, 9] |
| 1 | 2 | 1.725; [0, 4] | 4.475; [2, 7] |
| 2 | 2 | 0.346; [0, 1] | 3.042; [1, 6] |
| 4 | 3 | 0.021; [0, 0] | 1.953; [0, 4] |

| Exposure | Observed counts at least 20 | Poisson replicated mean | NB2 replicated mean |
|---:|---:|---:|---:|
| 0.5 | 0 | 0.000 | 0.001 |
| 1 | 0 | 0.000 | 0.034 |
| 2 | 0 | 0.000 | 0.325 |
| 4 | 3 | 0.152 | 1.435 |

| Exposure | Poisson median observed / replicated $D_s$ | Poisson $P(D_s^{rep}\ge D_s\mid y)$ | NB2 median observed / replicated $D_s$ | NB2 probability |
|---:|---|---:|---|---:|
| 0.5 | 30.7 / 10.5 | 0.0180 | 22.3 / 19.7 | 0.4389 |
| 1 | 63.3 / 10.9 | 0 of 20,000 | 47.1 / 32.1 | 0.3326 |
| 2 | 27.3 / 11.2 | 0.0139 | 30.8 / 54.8 | 0.7811 |
| 4 | 147.7 / 11.3 | 0 of 20,000 | 204.3 / 100.9 | 0.2274 |

At exposure four, the simulated probability of at least three extreme counts is 0.00060 under Poisson (Monte Carlo SE 0.00017, Wilson 95% interval 0.00034–0.00105), versus 0.1775 under NB2 (SE 0.00270, interval 0.1723–0.1829). No Poisson replicate produced three zeros at exposure four: its Wilson upper limit is about 0.000192, not proof of zero probability. The lab reports Monte Carlo SEs and Wilson intervals for every exceedance, plus replicated ranges and the distribution of observed discrepancies. These intervals describe simulation uncertainty conditional on the fitted model, not uncertainty about model adequacy.

---

Source: `course/chapters/08_glm.md:280–280`

Together, the long-exposure zeros, extremes and residual discrepancies motivate the NB2 revision. NB2 still tends to produce more zeros at exposure one; revision is not a declaration of truth or a demand that every discrete check lie between 0.05 and 0.95. Posterior predictive probabilities reuse the training data and are not uniformly calibrated classical p-values. This workflow supplies training-data criticism, not held-out predictive-performance evidence. Independent window multipliers do not establish persistent centre dependence, identify structural zeros, or automatically define a process consistent under arbitrary splitting and merging of windows.

---

Source: `course/chapters/08_glm.md:282–311`

### Predict with information available before the future window

The prediction interface accepts a fitted posterior, future workload and known exposure, with no outcome argument. The frozen scenarios are workload/exposure $(3,0.75)$, $(5,2.5)$ and $(7,1)$. Workload seven is outside the training range and is explicitly labelled extrapolation.

Distinguish uncertainty in parameters, in the mean rate $\lambda_*$, in the expected count $\mu_*=t_*\lambda_*$, and in the realised future count. For NB2,

$$\operatorname{Var}(Y_*\mid y)=E[\mu_*+d^2\mu_*^2\mid y]+\operatorname{Var}(\mu_*\mid y).$$

For Poisson, set $d=0$. The lab reports rate and mean-count variances separately from future-count variance. At workload five and exposure 2.5, NB2 mean-count variance is 1.445, whereas future-count variance is 52.500: variation in a new window dominates.

| Workload; exposure | Model | Mean rate | Mean count | Future-count variance | 90% count interval |
|---|---|---:|---:|---:|---|
| 3; 0.75 | Poisson | 1.689 | 1.267 | 1.283 | [0, 3] |
| 3; 0.75 | NB2 | 2.009 | 1.507 | 4.994 | [0, 6] |
| 5; 2.5 | Poisson | 2.535 | 6.336 | 6.557 | [2, 11] |
| 5; 2.5 | NB2 | 2.234 | 5.584 | 52.500 | [0, 20] |
| 7; 1 (extrapolation) | Poisson | 3.833 | 3.833 | 4.090 | [1, 7] |
| 7; 1 (extrapolation) | NB2 | 2.603 | 2.603 | 14.429 | [0, 10] |

Integer interval endpoints invert the posterior **mixture CDF**, $\sum_jW_jF(k\mid\theta_j)$; do not average conditional interval endpoints. To accelerate CDF evaluation, the lab omits at most $10^{-12}$ total node mass and renormalises the remainder. This bounds error in a bounded probability by the omitted mass; it does not bound errors of unbounded moments. All moment calculations retain every node. Numerical integration of posterior prediction is described in [Stan's prediction guide](https://mc-stan.org/docs/stan-users-guide/posterior-prediction.html).

At workload five/exposure 2.5, the probability of at least 20 calls is approximately 0.00001788 for Poisson and 0.05074 for NB2. Stable means can conceal sensitivity in operational tails. Refit with predeclared half-normal scales for $d$:

| Half-normal scale for $d$ | Posterior mean $d$ | Future mean count | $P(Y_*\ge20\mid y)$ | 90% count interval |
|---:|---:|---:|---:|---|
| 0.5 | 1.085 | 5.583 | 0.04518 | [0, 19] |
| 1 | 1.167 | 5.584 | 0.05074 | [0, 20] |
| 1.5 | 1.186 | 5.585 | 0.05196 | [0, 20] |

Exposure units also matter to the prior. If hours replace days, $t'=24t$ and $\alpha'=\alpha-\log24$. Shift the intercept **prior mean and integration bounds** by the same amount; preserve its SD and the other priors. Rate predictions divide by 24 and count predictions remain unchanged. Keeping the old intercept prior is a different model. The lab's tests include that incorrect transformation as a negative control. At zero future exposure, the predicted count is exactly zero, including its variance, interval and positive-tail probability.

---

Source: `course/chapters/08_glm.md:313–315`

### Original unscored practice: a changed window

Before computing, use the fixed rate $\lambda=1.6\exp(x\log1.25)$ with $x=-1$, exposures 0.75 and 2.5, and multiplier CV $d=0.8$. Calculate the rate, both expected counts and both NB2 conditional variances. Convert centre-days to centre-hours and state how a rate-intercept prior would have to change. Explain why a larger expected count need not imply a higher rate, and what a posterior predictive interval would add to this fixed-parameter exercise. This optional activity has no assessment ID and no supplied worked answer.

---

Source: `course/chapters/08_glm.md:317–323`

## Association and intervention answer different questions

In an observational service dataset, staff may direct support to users having the most difficulty. A causal story could contain difficulty → support, difficulty → completion and support → completion. A negative support association could arise even when support helps. Adjusting a regression changes its conditioning set; it does not automatically validate a causal interpretation.

To ask about offering support to everyone, define the support intervention, outcome horizon and target population. A causal contrast such as the population mean of $Y(1)-Y(0)$ requires identification assumptions linking observed outcomes to these potential outcomes. Relevant conditions include consistency of the treatment definition, adequate overlap, control of pre-treatment common causes and assumptions about interference between users. Random assignment can justify some assumptions by design; observational data require a defensible alternative argument.

Adding every available variable is unsafe. A post-treatment mediator can change the estimand, while conditioning on a collider can introduce an association. Bayesian uncertainty describes uncertainty within the supplied model and assumptions; a tight posterior does not demonstrate that those assumptions hold. Pearl's [causal-inference overview](https://ftp.cs.ucla.edu/pub/stat_ser/r350.pdf) explains why intervention questions require information beyond a joint observational distribution. The [causal bridge](../advanced/04_causal.md) develops this distinction further.

---

Source: `course/chapters/08_glm.md:325–331`

## Lab

**Selected-core task:** interpret the logistic probability curve, compare odds with probability differences, identify count exposure, and explain the causal limitation. Complete the original three exercises. **Extended task:** inspect and investigate the fitted Poisson/NB2 repair-call workflow, its prior sensitivity and replicated-count checks. The existing notebook executes both sections; these labels select what to investigate and submit, not an execution switch.

Run [Lab 8](../../notebooks/08_glm.ipynb), or [Python](../../labs/08_glm.py), and inspect the [logistic curve](../../artifacts/figures/08_logistic.svg). Its band concerns completion probability, not a continuous outcome. Report an odds ratio and probability differences over two support ranges using matching coefficient draws. State the input values and population each contrast describes.

The lab retains the fixed calculation `count_means_exposure_1_3` as an introduction, then fits the repair-call Poisson and NB2 models in `count_workflow`. Compare their exposure-stratified checks and future predictions with the tables above. Examine prior curves, computation and replicated outcomes separately, and explain whether your conclusion forecasts completion or claims an intervention effect.

---

Source: `course/chapters/08_glm.md:333–337`

## Retrieval and summary

Explain from memory why doubling odds does not double probability. Describe a dataset that produces separation and what a proper prior contributes. Then distinguish a rate, an expected count and a realised count, and explain why unequal exposure matters.

Links make valid probabilities and rates from linear predictors. Useful conclusions require translating joint uncertainty to the response scale, respecting shared parameters in future cohorts and checking conditional variability. Regularisation, exposure and dependence are parts of the generative model. Causal interpretation additionally requires a defined intervention and identification argument.

---

Source: `course/chapters/08_glm.md:339–347`

## Lab and exercises

**8.1 — Concept.** Why can an odds ratio of two mean different percentage-point improvements in different populations?

**8.2 — Calculation.** A Poisson model has $Y\mid x,t\sim\operatorname{Poisson}(t\lambda)$, $\log\lambda=\alpha+\beta x$, $\alpha=\log 3$ and $\beta=\log 1.5$. Find the expected count at $x=2$ with exposure 4. Identify the rate and the count separately.

**8.3 — Applied.** Support is offered more frequently to users already at risk of failure. Sketch the variables and arrows in this story. Explain why the posterior support coefficient alone does not identify the effect of offering support to everyone.

[Solutions](../solutions.md).

---

Source: `course/chapters/08_glm.md:349–351`

## Further reading

[Think Bayes, logistic regression](https://allendowney.github.io/ThinkBayes2/chap16.html) gives an additional computational treatment. The [Statistical Rethinking course](https://github.com/rmcelreath/stat_rethinking_2026) connects statistical models to scientific questions and causal assumptions. For stable computation of the likelihood and inverse links, consult [Appendix 4](../appendices/04_numerics.md).

---

Source: `course/chapters/09_hierarchical.md:1–3`

# 9 · Share information across groups

**Objectives:** compare pooling assumptions; explain shrinkage; fit a non-centred hierarchy; distinguish existing-group and new-group predictions; derive shrinkage uncertainty and shared-group prediction; critique exchangeability and hyperprior sensitivity. **Prerequisite:** chapters 6–8; [Appendix 3](../appendices/03_linear_algebra.md) supports the covariance calculations.

---

Source: `course/chapters/09_hierarchical.md:5–11`

## Small groups make noisy rankings

A service manager compares centres using average waiting times. A centre with a few visits appears unusually fast; a busy centre looks only slightly slower. Which difference reflects persistent centre conditions, and which reflects sampling noise? The manager also wants to forecast waits at a centre that has not yet opened. These questions require a model for relationships among centres, not just a separate estimate for each one.

Complete pooling assigns every centre the same intercept. No pooling estimates separate intercepts without learning a shared distribution from the ensemble. Partial pooling introduces a population distribution for centre intercepts and learns its location and spread. It is a generative assumption about related groups, not an adjustment applied to a ranking after fitting.

The [synthetic waiting data](../../data/README.md) contain eight centres with unequal numbers of visits. Chapter 7's common-intercept regression intentionally omits their baseline differences. Here workload still changes expected waiting time through a common slope, while each centre can start from a different baseline. Think first about whether this information sharing is defensible for the centres you wish to predict.

---

Source: `course/chapters/09_hierarchical.md:13–34`

## Write the hierarchy

For visit $i$ at centre $j[i]$, use the following complete model:

$$
\begin{aligned}
\mu_\alpha&\sim\operatorname{Normal}(10,3^2),&
\tau&\sim\operatorname{HalfNormal}(1.5),\\
\beta&\sim\operatorname{Normal}(0,2^2),&
\sigma&\sim\operatorname{HalfNormal}(2),\\
\alpha_j\mid\mu_\alpha,\tau&\sim\operatorname{Normal}(\mu_\alpha,\tau^2),&&j=1,\ldots,J,\\
Y_i\mid\alpha,\beta,\sigma,x_i&\sim\operatorname{Normal}(\alpha_{j[i]}+\beta x_i,\sigma^2).&&
\end{aligned}
$$

The four population-level priors are independent. Centre intercepts are conditionally independent given the population location and scale; visits are conditionally independent given their centre intercepts, slope and residual scale. The second Normal argument is a variance, and HalfNormal uses scale. All intercepts and scales are in minutes; the slope is minutes per workload-index unit.

To generate a dataset, draw population parameters once, draw one intercept for each centre, and then generate every visit using its centre's intercept. Never draw a fresh centre intercept for each visit: that would remove the shared structure. Workload and group labels are conditioned upon here. A model for how centres or visitors are selected would be an additional layer.

The posterior is proportional to the four population prior factors, multiplied by the product of centre-intercept densities and the product of visit likelihoods. The hierarchy therefore propagates uncertainty in both directions: visits inform centre intercepts, and the ensemble informs the distribution from which those intercepts arise. Integrating over the shared population parameters makes centre effects dependent in the posterior.

Sigma describes within-centre residual variation; tau describes between-centre baseline variation. A centre's mean at workload zero is its alpha, not its average observed wait when workload differs from zero. Comparing raw averages without workload adjustment can conflate customer mix with centre differences.

---

Source: `course/chapters/09_hierarchical.md:36–44`

## Prior prediction through all levels

Draw whole sets of centres and visits before fitting. Inspect the spread of centre means, the largest centre contrasts, individual waits and how those features change with workload. An acceptable prior for an overall mean need not imply acceptable extremes among many centres.

Under the stated priors, expected squared tau is $1.5^2=2.25$. Marginally a centre intercept has variance $9+2.25=11.25$, while the difference between two distinct centre intercepts has variance $2(2.25)=4.5$. The population-location uncertainty cancels in the difference. At workload zero an individual visit has prior variance $9+2.25+4=15.25$, adding expected squared sigma. These are variance calculations for mixtures, not claims that the marginal distributions are Normal.

This decomposition helps elicit a scale prior: ask how different two comparable centres could plausibly be, rather than choosing tau's prior by its name alone. The Gaussian likelihood retains the possibility of negative waits; inspect that probability as in chapter 7. A larger tau scale allows both larger centre contrasts and more extreme new-centre predictions. Prior checks should use a realistic number of centres because the expected maximum changes with the number drawn.

For example, changing the half-normal scale for tau from 1.5 to 0.5 reduces the prior variance of a two-centre contrast from 4.5 to 0.5 squared minutes. Both choices leave tau uncertain, but express very different beliefs about heterogeneity. After fitting, compare the new-centre intervals and the practical conclusion under both defensible choices; agreement of existing-centre point estimates alone would be an incomplete sensitivity check.

---

Source: `course/chapters/09_hierarchical.md:46–75`

## Why shrinkage depends on information

Temporarily hold the population mean, both scales and slope fixed. Subtract the known workload contribution and let $\bar r_j$ be the average of $y_i-\beta x_i$ in centre $j$. If that centre has $n_j$ independent visits, then

$$\bar r_j\mid\alpha_j\sim\operatorname{Normal}(\alpha_j,\sigma^2/n_j),\qquad
\alpha_j\sim\operatorname{Normal}(\mu_\alpha,\tau^2).$$

Write $s_j^2=\sigma^2/n_j$. The log posterior kernel for its intercept is

$$-\frac{(\bar r_j-\alpha_j)^2}{2s_j^2}-\frac{(\alpha_j-\mu_\alpha)^2}{2\tau^2}.$$

Expand the squares: the coefficient of squared alpha is the sum of precisions, and the linear coefficient is the sum of precision-weighted locations. Completing the square gives

$$
\begin{aligned}
v_j&=(s_j^{-2}+\tau^{-2})^{-1}
=\frac{\sigma^2\tau^2}{\sigma^2+n_j\tau^2},\\
m_j&=v_j(\bar r_j/s_j^2+\mu_\alpha/\tau^2)
=w_j\bar r_j+(1-w_j)\mu_\alpha,\\
w_j&=\frac{n_j\tau^2}{\sigma^2+n_j\tau^2},\qquad
\alpha_j\mid\bar r_j,\mu_\alpha,\tau,\sigma,\beta\sim\operatorname{Normal}(m_j,v_j).
\end{aligned}
$$

The data weight increases with sample size and between-centre variation. It decreases with within-centre noise. Many precise visits justify a centre estimate closer to its own adjusted mean; similar centres justify more pooling. The weight concerns information about the centre mean, not the importance of its visitors.

With vanishing tau the conditional model approaches complete pooling. With very large tau, data dominate for a nonempty group. With no visits, the group's conditional distribution remains its population distribution. These limits assume fixed population parameters; their uncertainty remains in a full Bayesian analysis, even when conditional variances become small.


<!-- VISUAL01:11 BEGIN -->

---

Source: `course/chapters/09_hierarchical.md:77–98`

### Visual investigation: conditional pooling weights information

This visual conditions on fixed hyperparameters $\mu=10$, $\tau=2$ and $\sigma=4$ minutes. It is not a fully learned hierarchy. Compare an adjusted group mean of six from two observations with a mean of fourteen from thirty-two observations. Predict which summary should move farther toward the fixed population centre.

![Raw means six and fourteen move toward fixed mean ten by different amounts; conditional intervals are wider for n equals two than n equals thirty-two.](../../artifacts/figures/visual01_11_pooling.svg)

**Read the figure.** Horizontal positions are group means in minutes. Crosses show raw summaries, connecting segments show movement, and circles with bars show conditional posterior means and central 90% intervals. The dashed line is the stipulated population mean; it is not an estimate learned from these two groups.

| Group | n | Raw mean | Data weight | Conditional mean | Conditional SD |
|---|---:|---:|---:|---:|---:|
| A | 2 | 6 | 1/3 | 8.666667 | 1.632993 |
| B | 32 | 14 | 8/9 | 13.555556 | 0.666667 |

The corresponding 90% intervals are [5.980632, 11.352701] and [12.458986, 14.652125] minutes. These intervals concern group means, not future individuals.

**Mathematical connection.** The likelihood variance of a raw mean is $\sigma^2/n_j$. Its data weight is $w_j=n_j\tau^2/(\sigma^2+n_j\tau^2)$, giving mean $(1-w_j)\mu+w_j\bar r_j$ and variance $\tau^2\sigma^2/(\sigma^2+n_j\tau^2)$. Equal distances from the population mean therefore need not imply equal movement.

**Original unscored exploration — predict, observe, explain.** Change only A's sample size to 32 while holding its raw mean at six. Its weight becomes 8/9 and conditional mean 6.444444. Explain the movement away from ten as information increases. Transfer to a learned hierarchy: what uncertainty is omitted by fixing these hyperparameters? Exchangeability of adjusted effects is an assumption, and many observations in only two groups do not establish a population distribution of groups.

[Open the guided pooling experiment](../../explorer.html#visual-pooling) to predict, change one setting, and explain the result.

<!-- VISUAL01:11 END -->

---

Source: `course/chapters/09_hierarchical.md:100–113`

### Worked example 1: small and large centres

For an illustration separate from the lab and exercises, take population mean ten minutes, between-centre standard deviation 1.5, and within-centre standard deviation three. Two centres both have workload-adjusted average fourteen, but one has four visits and the other thirty-six. Thus their sampling variances are 2.25 and 0.25.

The smaller centre's prior variance equals its sampling variance, so the data weight is one half. Its posterior mean is twelve and variance 1.125. The larger centre has weight 0.9, mean 13.6 and variance 0.225. Using the Normal 95th percentile gives central 90% conditional intervals:

| Visits | Data weight | Posterior mean, minutes | Posterior SD, minutes | Interval for centre mean, minutes |
|---|---:|---:|---:|---|
| 4 | 0.5 | 12.0 | 1.061 | [10.255, 13.745] |
| 36 | 0.9 | 13.6 | 0.474 | [12.820, 14.380] |

The calculation can be checked by adding precisions directly. For four visits the sum is $1/2.25+1/2.25=8/9$, whose reciprocal is 1.125. These intervals concern adjusted centre means, not individual waiting times. To predict a visitor conditional on the assumed scales, add residual variance nine.

Shrinkage does not say that a small centre is intrinsically average. It says that its observed extremeness is less persuasive evidence of a persistent difference under this model. Nor must every centre move toward the unweighted grand mean: the fitted population location is learned from the hierarchy and covariates, not specified by a simple averaging rule.

---

Source: `course/chapters/09_hierarchical.md:115–123`

### Unknown hyperparameters change the uncertainty

Suppose instead that tau were fixed at 0.5. For the four-visit centre the data weight would become 0.1, its posterior mean 10.4 and variance 0.225. The same observations support quite different shrinkage under a much tighter population distribution. This is why learning and checking the population scale matters.

In the full model tau, sigma, beta and the population mean are uncertain. Let $H$ denote that collection. Total variance gives

$$\operatorname{Var}(\alpha_j\mid y)=E[v_j(H)\mid y]+\operatorname{Var}(m_j(H)\mid y).$$

The second term represents uncertainty in the conditional centre mean as population parameters and the workload adjustment vary. Plugging in posterior means for all those quantities generally misses it, and the mean of a shrinkage weight need not equal the weight evaluated at mean parameters. Use joint posterior draws for centre contrasts, rankings and predictions.

---

Source: `course/chapters/09_hierarchical.md:125–133`

## Exchangeability is the key judgement

Before seeing outcomes, would relabelling the centres change your joint beliefs about their intercepts, after conditioning on relevant information? If not, an exchangeable model may be reasonable. It says centres share a probabilistic description, not that their underlying means are equal. Conditional independent draws from the Normal population produce an exchangeable joint distribution.

Exchangeability is conditional on what the model knows. A specialist emergency centre and a routine appointment centre may require different predictors or populations. If centre type predicts baseline waits, one extension models the population mean as a function of that type. Unexplained centre effects can then be exchangeable around their predicted baselines. Merely assigning all centres numeric labels does not justify pooling them.

Selection matters too. Centres volunteered after unusually good performance may not represent future centres. Group size can also be informative: if unusually slow centres systematically lose visitors, the association between size and intercept is relevant to the observation process. The basic model conditions on group sizes and does not account for such selection. More elaborate pooling is not a cure for an unexamined sampling mechanism.

Report uncertainty in centre contrasts and decision-relevant predictions. Partial pooling can stabilise comparisons but cannot by itself guarantee fair rankings or protect every subgroup against misspecification. Check whether a Gaussian population understates extreme centres or whether omitted group predictors systematically pull some centres toward an inappropriate reference.

---

Source: `course/chapters/09_hierarchical.md:135–141`

## The number of groups matters

Many visits within a centre reduce uncertainty about that centre's mean. They do not produce many independent centre effects. Even if every mean were observed almost perfectly, a study of three centres would still have only three draws with which to learn the population's spread and tails.

For perspective, if exact centre intercepts were independent Normal draws and the population mean were estimated by their sample mean, the sample variance would have relative standard deviation $\sqrt{2/(J-1)}$. It is one at three centres and one half at nine centres. This repeated-sampling calculation is not a posterior interval for tau; it isolates why the number of groups controls information about between-group variation.

With few groups, compare defensible tau priors through prior predictions and then assess sensitivity of new-centre intervals and policy conclusions. Simply making the prior extremely broad can permit unrealistic populations. A large number of visits cannot test a Normal population tail well when only a few centres have been observed. Predicting an unusually different centre may remain uncertain even after existing centres are estimated precisely.

---

Source: `course/chapters/09_hierarchical.md:143–154`

## Reparameterisation changes geometry

The centred form declares each intercept directly from its population Normal. When tau is small, all centre intercepts must lie close to the population mean. When tau is larger, they may spread widely. This narrow-to-wide geometry can form a funnel that is difficult for HMC when group data provide little information.

A non-centred representation uses

$$z_j\sim\operatorname{Normal}(0,1),\qquad
\alpha_j=\mu_\alpha+\tau z_j.$$

At fixed positive tau, the affine transformation has mean population location and variance squared tau, so it generates exactly the same intercept distribution. The joint model's predictions and posterior over substantive parameters are unchanged when all priors and likelihood terms are transformed consistently. Here z is the sampled variable and alpha is deterministic; no extra Jacobian factor belongs in this generative specification. Writing a density in a changed integration variable instead would require the usual change-of-variables accounting.

Weakly informed groups often benefit from separating standardised offsets from scale. With very informative group data, the centred form may sample better because the non-centred coordinates must then compensate for each other to preserve accurately known intercepts. Mixed group sizes can produce mixed behaviour. Inspect divergences, R-hat, effective sample size and Monte Carlo error for population scales and group contrasts, not just one easy parameter. The [Stan efficiency guide](https://mc-stan.org/docs/stan-users-guide/efficiency-tuning.html#hierarchical-models-and-the-non-centered-parameterization) discusses this dependence on the information regime.

---

Source: `course/chapters/09_hierarchical.md:156–162`

## Identifiability is a model question too

Writing an unrestricted global intercept plus unrestricted group offsets produces a likelihood that is unchanged if a constant is added to the global intercept and subtracted from every offset. In this chapter the offsets have a specified zero-centred population distribution, and the population location has its own prior. Those assumptions give the decomposition meaning, but with few groups the location and offsets can still be strongly dependent.

An exact sum-to-zero constraint is a different specification unless its induced prior is handled carefully. It makes the intercept refer to the finite collection's average offset convention; the population mean in this chapter concerns the broader distribution of possible centres. Reparameterising alone does not justify changing that estimand or prior.

Workload also needs variation within centres to distinguish its slope from centre intercepts convincingly. If each centre is observed at just one characteristic workload, baseline differences can imitate a workload association. A random-intercept assumption may then supply much of the apparent separation. Distinguishing within-centre workload deviations from between-centre average workload is a possible revision. Varying slopes require enough information to learn their variation and correlation with intercepts; a more elaborate hierarchy cannot create missing contrasts.

---

Source: `course/chapters/09_hierarchical.md:164–168`

## Existing and new groups need different predictions

For another visit to an observed centre, select its fitted intercept, beta and sigma from the same posterior draw, evaluate the mean at the intended workload, and add residual noise. For an unseen exchangeable centre, first draw a new intercept conditional on that draw's population mean and tau. Combine it with the same beta before generating visits.

An interval for the population location omits actual centre variation. An interval for a centre mean includes uncertainty about that centre's baseline but omits individual noise. An interval for a visitor includes both. The predictive population must also be specified: an equally likely centre and a randomly selected visitor need not induce the same centre weights.

---

Source: `course/chapters/09_hierarchical.md:170–182`

### Worked example 2: two visits to one new centre

Return to the illustrative fixed population mean ten, tau 1.5 and sigma three, and fix beta at one. At workload one a new centre's mean is Normal with mean eleven and variance 2.25. A visit there has mean eleven and variance $2.25+9=11.25$.

Two visits to that same unseen centre share its intercept. Conditional on the fixed population parameters their covariance is 2.25, giving correlation $2.25/11.25=0.2$. Their average has variance

$$\operatorname{Var}\left(\frac{Y_1+Y_2}{2}\right)=\frac{11.25+11.25+2(2.25)}4=6.75.$$

If the two visits instead occur at independently drawn new centres, the conditional covariance is zero and the average variance is 5.625. Drawing a new intercept for every visit would incorrectly use this second answer for a shared-centre question. With many visits in one new centre, residual noise averages away but its unknown baseline remains.

With uncertain population parameters, two different new centres also share posterior uncertainty. At equal workload their predictive covariance contains $\operatorname{Var}(\mu_\alpha+\beta x\mid y)$. Two visits in the same new centre additionally share $E[\tau^2\mid y]$. Simulate a whole future cohort per joint posterior draw, reusing each newly generated centre effect for every member of that centre.

This distinction affects planning. Sending many visitors to one unopened centre leaves its baseline uncertainty shared across the whole forecast. Spreading them across several exchangeable new centres averages some centre variation. These allocations can have the same expected average wait but different uncertainty, even before accounting for capacity or dependence beyond the model.

---

Source: `course/chapters/09_hierarchical.md:184–190`

## Lab

Run [Lab 9](../../notebooks/09_hierarchical.ipynb), or [Python](../../labs/09_hierarchical.py), and inspect the [pooling plot](../../artifacts/figures/09_pooling.svg). The implementation calls the population location `mu_a` and uses zero-based centre labels. Its adjusted raw means subtract a fitted mean slope; they are descriptive comparison points, not independent no-pooling posterior estimates.

The saved existing-centre and new-centre intervals both describe **centre means at workload zero**. Neither includes individual noise. Explain how you would add that layer. Compare diagnostics for tau, population location and centre effects, then inspect whether replicated centre contrasts and within-centre residuals resemble the data. Good computation cannot validate exchangeability.

Validation must match deployment. Holding out visits from known centres evaluates prediction with centre information available. Holding out entire centres evaluates transfer to unseen groups. Shrinking a small group's estimate or improving a within-centre score does not establish accurate new-centre forecasts. Report the holdout unit and prior sensitivity alongside the predictive target.

---

Source: `course/chapters/09_hierarchical.md:192–196`

## Retrieval and summary

Reconstruct the shrinkage weight from two precisions and identify the missing variance term when hyperparameters are plugged in. Explain why observing more visits differs from observing more centres. Finally, describe which random draws two future visits to one new centre must share.

Partial pooling combines within-group information with a learned population distribution under an exchangeability judgement. The conditional shrinkage formula explains the mechanism; full inference integrates uncertainty about its ingredients. Reparameterisation can improve computation, while prediction and validation must retain the group structure relevant to the question.

---

Source: `course/chapters/09_hierarchical.md:198–206`

## Lab and exercises

**9.1 — Concept.** Explain why 1,000 visits in each of three centres may still leave considerable uncertainty about between-centre variation.

**9.2 — Calculation.** In the known-scale model $Y_{ij}\mid\alpha_j\sim\operatorname{Normal}(\alpha_j,\sigma^2)$ and $\alpha_j\sim\operatorname{Normal}(\mu,\tau^2)$, take $\mu=10$, $\tau=1$, $\sigma=2$, and $\bar y_j=14$. Calculate the posterior centre mean for $n_j=1$ and $n_j=16$.

**9.3 — Prediction.** Under $Y\mid\alpha_j,\beta,\sigma,x\sim\operatorname{Normal}(\alpha_j+\beta x,\sigma^2)$ and $\alpha_j\mid\mu_\alpha,\tau\sim\operatorname{Normal}(\mu_\alpha,\tau^2)$, assume joint posterior draws of the hyperparameters, slope and residual SD are available. Describe the draws needed to predict a visit at a new centre with workload 1. Explain the error in setting its intercept equal to the posterior mean of $\mu_\alpha$.

[Solutions](../solutions.md).

---

Source: `course/chapters/09_hierarchical.md:208–210`

## Further reading

[Bayes Rules!, hierarchical models](https://www.bayesrulesbook.com/chapter-15) provides further intuition for partial pooling. The [Aalto BDA course](https://avehtari.github.io/BDA_course_Aalto/Aalto2025.html) connects hierarchical modelling with computational and predictive checks. For the variance decompositions used here, revisit [Appendix 1](../appendices/01_probability.md).

---

Source: `course/chapters/10_model_checking.md:1–3`

# 10 · Ask how the model fails

**Objectives:** design targeted predictive checks; compute exact and approximate leave-one-out scores; interpret diagnostic limits and score differences; distinguish predictive comparison from Bayes factors; derive importance reweighting; design validation for the intended deployment unit. **Prerequisite:** chapters 6–9, plus the normal update in chapter 4. [Appendix 1](../appendices/01_probability.md) supports conditioning and [Appendix 4](../appendices/04_numerics.md) supports log-scale computation.

---

Source: `course/chapters/10_model_checking.md:5–9`

## A good fit to which question?

A service forecasts waiting times to allocate staff. Its fitted regression follows the average workload trend, its chains mix well, and it beats a simpler model on predictive scores. Yet one centre regularly has much longer waits than predicted. Can all these statements be correct? Yes: each addresses a different question. The analyst's job is to connect each check to the feature or prediction that matters.

Before looking for a favourable diagnostic, write a sentence such as “predict tomorrow's extreme waits in these existing centres” or “predict average waits in an unseen centre.” These targets require different replications and validation designs. A model can be useful for one and inadequate for another. This chapter develops checks that make that distinction visible.

---

Source: `course/chapters/10_model_checking.md:11–21`

## Four checks with different limits

Prior predictive checks simulate parameters from the prior and then observations from the likelihood. They expose impossible scales, implausible event frequencies, and unintended joint behaviour before outcomes inform the fit. Very broad predictions are not automatically safe: they can assign most probability to unrealistic datasets. Conversely, a prior can produce a plausible overall histogram while imposing an implausible relationship between groups. Check scientifically meaningful joint features as well as marginal ranges.

Sampler diagnostics ask whether the numerical draws explore the specified posterior adequately. They cannot establish that the likelihood describes the service. Posterior predictive checks compare observed features with replications under the fitted model. Held-out prediction evaluates observations withheld from fitting. These operations complement each other; success at one cannot substitute for another.

With predictors held fixed, the posterior predictive distribution is

$$p(y^{\mathrm{rep}}\mid y,x)=\int p(y^{\mathrm{rep}}\mid\theta,x)p(\theta\mid y,x)\,d\theta.$$

For each posterior draw, simulate a complete replicated dataset, preserving the model's dependence structure. Within an existing centre, reuse that draw's centre effect; for a new centre, draw a new effect from the population distribution. Simulating each row with an unrelated effect changes the model. State what is held fixed, what is resampled, and whether the replicate represents the observed design or a future deployment.

---

Source: `course/chapters/10_model_checking.md:23–36`

## Choose a discrepancy that can expose failure

A discrepancy is a numerical feature used to compare data and replications. If staffing depends on long waits, inspect upper quantiles or counts exceeding a service threshold. If the model assumes constant residual spread, compare spread at low and high workload. If centre variation matters, compare centre means after adjusting for workload. A check of the overall mean is often weak because fitting the intercept already makes that mean easy to reproduce.

For a parameter-dependent discrepancy $T(y,\theta)$, evaluate both $T(y,\theta^{(s)})$ and $T(y^{\mathrm{rep},(s)},\theta^{(s)})$ at the same draw. Alternatively, explicitly fix a fitted summary in the discrepancy and apply that identical rule to observed and replicated datasets, as Lab 10 does. Do not compare adjusted observations with unadjusted replications.

The posterior predictive tail fraction estimates

$$P\{T(y^{\mathrm{rep}},\theta)\ge T(y,\theta)\mid y\}.$$

It is a descriptive comparison in a specified direction. Because the observations help determine the posterior and the observed discrepancy, it is generally not a uniformly distributed frequentist p-value. It is neither the probability that the model is true nor the chance the result will replicate. Predictive checks may have little power against failures unrelated to the chosen discrepancy. Several purposeful plots are more informative than declaring a model accepted after one moderate tail fraction.


<!-- VISUAL01:12 BEGIN -->

---

Source: `course/chapters/10_model_checking.md:38–57`

### Visual investigation: a stable fitted mean can conceal a spread failure

Use a new small model: $\mu\sim N(8,9)$ and seven independent responses given $\mu$ with known observation variance $\sigma^2=4$. Construct data $y_i=10+d(-3,-2,-1,0,1,2,3)_i$. Predict whether doubling d changes the fitted mean or the model's ability to reproduce spread.

![Two seven-point datasets have identical mean ten but different spreads; their standardised sample variances lie at seven and twenty-eight on an exact chi-square reference.](../../artifacts/figures/visual01_12_ppc.svg)

**Read the figure.** Left: horizontal position is response in minutes, with one row per synthetic dataset. Right: the reference density is for $Q^{rep}=6S_{rep}^2/\sigma^2$; its horizontal coordinate is unitless. The two vertical marks locate observed discrepancies, not two posterior parameter means. The displayed reference runs from zero to 36 and retains an unshown upper tail.

| Spread d | Observations (minutes) | Unbiased sample variance | Observed Q | Exact upper-tail probability |
|---:|---|---:|---:|---:|
| 1 | 7, 8, 9, 10, 11, 12, 13 | 4.666667 | 7 | 0.320847 |
| 2 | 4, 6, 8, 10, 12, 14, 16 | 18.666667 | 28 | 0.000093963 |

**Mathematical connection.** Both datasets give posterior variance $v=(1/9+7/4)^{-1}=0.537313$ and mean $v(8/9+70/4)=9.880597$. Yet the centred replicate variance satisfies $Q^{rep}\sim\chi^2_6$, with expected $S_{rep}^2=4$. This statistic does not depend on $\mu$, so posterior integration leaves its distribution unchanged: a useful special case, not a general PPC shortcut. Its exact upper tail is $e^{-Q/2}(1+Q/2+Q^2/8)$.

**Original unscored exploration — predict, observe, explain.** Predict the discrepancy at d = 0 and observe Q = 0 and upper tail one: unusually small spread is a different potential failure. Explain why checking only the mean misses both directions. Propose a discrepancy for asymmetry as a transfer task. These checks reuse training data; they are not held-out validation, do not give the probability that the model is true, and do not identify a unique replacement model.

[Open the guided ppc experiment](../../explorer.html#visual-ppc) to predict, change one setting, and explain the result.

<!-- VISUAL01:12 END -->

---

Source: `course/chapters/10_model_checking.md:59–67`

## Worked example 1: a centre discrepancy

Suppose three centres have mean waits of 9, 11, and 15 minutes and mean workload scores of 1, 1, and 3. Fix the fitted workload coefficient at one minute per workload unit. Adjusted means are therefore $9-1=8$, $11-1=10$, and $15-3=12$ minutes. Their range is $T(y)=12-8=4$ minutes. A common-intercept regression has no centre-specific mechanism to explain this remaining separation.

For a deliberately small arithmetic illustration, suppose ten replicated adjusted ranges are 0.9, 1.1, 1.4, 1.8, 2.0, 2.1, 2.6, 2.8, 3.3, and 4.2 minutes. Exactly one is at least four, so the empirical upper-tail fraction is $1/10=0.10$. Its plug-in Monte Carlo SE would be about $\sqrt{0.1(0.9)/10}=0.095$ for independent replicates. Ten simulations give a very rough tail estimate; the useful scientific question is why the observed separation sits towards the edge of the replicated distribution.

If no replicate exceeded the observation, the empirical fraction would be zero, but the underlying tail probability need not be zero. With independent replicates, a probability below the simulation resolution can easily produce no exceedances. Correlated posterior draws further reduce the effective information in the simulation. Report the number of replications and show the distribution, rather than printing zero as a certainty.

The full lab uses eight centres and the [range of adjusted centre means](../../artifacts/figures/10_check.svg). Its regression improves prediction of individual waits while missing this centre structure. That is a substantive failure worth explaining, even if all competing models share it. Adding group effects is a candidate revision; checking whether the discrepancy reflects a data-recording problem is another. The plot alone does not identify the cause.

---

Source: `course/chapters/10_model_checking.md:69–83`

## Define a predictive score and its unit

The logarithmic score evaluates the predictive probability mass or density assigned to what occurred. A confident wrong prediction receives a large penalty. Using natural logarithms, larger scores are better. For continuous outcomes a density is not an event probability and can exceed one; its units affect the absolute log score. Compare densities on the same outcome scale, with the same transformations and likelihood constants.

Leave-one-out cross-validation fits to $y_{-i}$, which excludes unit $i$, and evaluates

$$\operatorname{elpd}_{\mathrm{loo}}=\sum_{i=1}^n\log p(y_i\mid y_{-i}).$$

ELPD stands for expected log predictive density. This finite-data sum estimates performance for the declared prediction task using training sets of size $n-1$; it is not a guarantee about every future population. The integrated prediction averages over the training posterior. Substituting its mean parameter or scoring with the full-data posterior answers a different question.

A binomial count and a sequence of individual Bernoulli outcomes have different sample spaces and combinatorial constants. They can give the same parameter posterior but different reported scores. Similarly, the sum of marginal scores for several correlated future outcomes is not their joint log score. Choose the scoring unit before comparing models and retain it across candidates.

Changing continuous measurement units illustrates why absolute scores need context. Convert every waiting time from minutes to seconds. A correctly transformed predictive density is divided by sixty, so each natural-log score decreases by $\log(60)$. Both models' scores shift by the same amount and their difference is unchanged. A comparison that changes only one model's outcome units has no valid interpretation. Keeping normalising constants matters even when they did not matter for fitting a posterior kernel.

The logarithmic score rewards a complete predictive distribution, but the operational target may emphasise a particular event. A better average score across ordinary visits need not improve prediction of days with a staffing crisis. Evaluate the daily event using replications of whole days, preserving shared shocks and centre effects. Also inspect predictions for rare outcomes and relevant subgroups. Choose these checks because of the intended use, and disclose additional checks developed after seeing failures. Predictive ranking does not replace the utility calculation in chapter 12.

---

Source: `course/chapters/10_model_checking.md:85–106`

## Worked example 2: exact LOO you can inspect

Use the lab's four observations $y=(1,2,0,3)$, a prior $\mu\sim N(0,4)$, and conditionally independent observations $y_i\mid\mu\sim N(\mu,1)$. Here the second normal argument denotes variance: the prior SD is two and the observation SD is one. Excluding a row leaves three observations. Adding prior and likelihood precisions gives

$$v_{-i}=\frac{1}{1/4+3}=\frac4{13},\qquad
m_{-i}=\frac{\sum_{j\ne i}y_j}{1/4+3}.$$

The held-out outcome has variance $1+v_{-i}=17/13$, incorporating observation noise and uncertainty about the mean. Its pointwise log score is

$$\ell_i=-\frac12\log\{2\pi(17/13)\}
-\frac{(y_i-m_{-i})^2}{2(17/13)}.$$

| Excluded outcome | Sum of remaining outcomes | Training posterior mean | Held-out log score |
|---:|---:|---:|---:|
| 1 | 5 | 1.538462 | −1.163930 |
| 2 | 4 | 1.230769 | −1.279315 |
| 0 | 6 | 1.846154 | −2.356238 |
| 3 | 3 | 0.923077 | −2.702392 |

Adding the unrounded scores gives **−7.501875**. Excluding three makes the remaining data pull the mean down, explaining its poor held-out score. For a numerical check, integrate the product of the normal held-out likelihood and its normal training posterior; the resulting predictive density equals the density used in the table. Lab 10 evaluates the same values with `scipy.stats.norm.logpdf`.

“Exact LOO” means each training posterior is recomputed after removing the observation. This example also has exact analytic integration. In a more complex model, a separate MCMC refit still has simulation error, so report that error where it could affect the comparison. Exact refitting repairs an approximation problem; it cannot repair a poorly chosen validation target.

---

Source: `course/chapters/10_model_checking.md:108–127`

## How importance sampling avoids most refits

Assume proper full and leave-one-out posteriors and likelihood factorisation $p(y\mid\theta)=\prod_i p(y_i\mid\theta)$, with compatible support when a row is removed. Bayes's rule gives

$$p(\theta\mid y)=
\frac{p(y_i\mid\theta)p(\theta\mid y_{-i})}{p(y_i\mid y_{-i})},\qquad
\frac{p(\theta\mid y_{-i})}{p(\theta\mid y)}
=\frac{p(y_i\mid y_{-i})}{p(y_i\mid\theta)}.$$

Thus full-posterior draws can be reweighted with raw ratios $r_i^{(s)}=1/p(y_i\mid\theta^{(s)})$. The weighted prediction is $\sum_s r_i^{(s)}p(y_i\mid\theta^{(s)})/\sum_s r_i^{(s)}$. With raw ratios, this reduces to $S/\sum_s r_i^{(s)}$, a harmonic-mean identity. A few enormous ratios can dominate its denominator: draws rarely visited by the full posterior may matter greatly when the influential observation is removed.

Pareto-smoothed importance sampling, PSIS, fits a tail model to the largest ratios and smooths them. It reduces instability and estimates a Pareto shape diagnostic $\hat k$; it cannot create information about posterior regions never explored. A large diagnostic signals unreliable reweighting and often influence. It does not establish that the observation is erroneous. The [PSIS paper](https://arxiv.org/abs/1507.02646) develops the tail approximation and its diagnostics.

Lab 10 stores pointwise log likelihood and calls `az.loo(..., pointwise=True)`. In the pinned [ArviZ 0.22 API](https://python.arviz.org/en/v0.22.0/api/generated/arviz.loo.html), inspect `pareto_k`, `loo_i`, and `good_k`. The reported threshold is

$$k_{\mathrm{good}}=\min\{1-1/\log_{10}(S),\ 0.7\},$$

where $S$ is the nominal posterior sample count. It is 0.5 for 100 draws and reaches the 0.7 cap for sufficiently large samples. Reliable underlying sampling remains necessary; a large nominal count does not remove autocorrelation or missed modes.

When a point exceeds the threshold, locate it, inspect its data and residual behaviour, and refit that holdout exactly if feasible. Replace its approximate contribution with the refitted score and identify the replacement in the report. Many problematic points may favour a suitable K-fold procedure or model revision. Do not quietly omit them, and do not interpret acceptable Pareto diagnostics as proof of predictive adequacy.

---

Source: `course/chapters/10_model_checking.md:129–139`

## Worked example 3: paired comparison uncertainty

Suppose two models' log-score differences on the same five units are $d=(0.4,1.0,-0.2,0.8,0)$. The total improvement is two log-score units and the average is 0.4. Squared deviations from that average sum to 1.04, so the sample variance is $1.04/4=0.26$. Under an independence approximation,

$$\operatorname{SE}(\Delta_{\mathrm{elpd}})
\approx\sqrt{n\operatorname{Var}_{\mathrm{sample}}(d_i)}
=\sqrt{5(0.26)}=1.140175.$$

Use paired differences because difficult observations may have poor scores under both models. Adding independent standard errors of the two totals discards that pairing. The reported SE describes uncertainty from the available evaluation units; it is distinct from Monte Carlo error and PSIS approximation error. More posterior draws may reduce computational error while leaving uncertainty from five observations essentially unchanged.

Here the advantage is modest relative to its approximate SE. With so few units, a normal interval or a significance declaration would overstate what this summary establishes. Inspect which observations drive the difference. Dependence, strong influence, and selecting the best of many attempted models further weaken a simple interpretation. These qualifications accompany the formula in practical [LOO model evaluation](https://arxiv.org/abs/1507.04544).

---

Source: `course/chapters/10_model_checking.md:141–147`

## Match holdouts to deployment

Row-level LOO can be appropriate for another visit in a known centre when the other visits really will be available. For an unseen-centre target, hold out the whole centre and integrate over a new centre effect. Do not estimate the held-out centre effect using its outcomes before scoring it. Repeated visits by the same patient can similarly require patient-level holdouts when predicting for new patients.

For forecasting, train on the past and test later periods at the actual forecast horizon. Randomly splitting days lets later information inform earlier predictions. A smoothed estimate of yesterday using tomorrow's observation can be useful retrospectively but does not demonstrate forecasting skill. [The time-series bridge](../advanced/05_time_series.md) develops this distinction.

Fit scaling, imputation, feature selection, and tuning within each training fold whenever they learn from the dataset. A hospital's average outcome computed before splitting is especially direct leakage. If candidate selection uses validation outcomes, an additional outer evaluation or genuinely untouched set is needed to evaluate the whole selection procedure. With few centres, acknowledge the limited independent evidence; hundreds of patient rows do not create hundreds of independent new-centre trials.

---

Source: `course/chapters/10_model_checking.md:149–165`

## Model averaging has more than one meaning

Bayesian model averaging uses posterior model probabilities, obtained from prior model probabilities and marginal likelihoods

$$p(y\mid M)=\int p(y\mid\theta,M)p(\theta\mid M)\,d\theta.$$

A Bayes factor is a ratio of these marginal likelihoods. It depends on the entire prior, including parameter regions distant from the fitted posterior; improper priors generally leave arbitrary normalising constants. Its posterior model odds concern the specified model set. LOO does not compute these odds.

Predictive stacking chooses nonnegative weights summing to one to maximise a held-out mixture score:

$$\max_w\sum_i\log\left\{\sum_m w_m p_m(y_i\mid y_{-i})\right\}.$$

The weights describe a predictive combination, not probabilities that individual models are true. Pseudo-BMA instead weights models using their total estimated predictive scores; unlike stacking, it does not optimise the mixture's pointwise predictions. Averaging compatible predictive distributions also differs from averaging coefficients with different meanings across models. See the [stacking paper](https://arxiv.org/html/1704.02030v3) and [model-evidence bridge](../advanced/02_model_evidence.md). No weighting method repairs failures shared by all candidates.

For a numerical illustration, suppose two models assign probabilities $(0.9,0.1)$ and $(0.1,0.9)$ to the observed outcomes on two held-out units. Each total log score is $\log(0.9)+\log(0.1)=-2.407946$. An equal predictive mixture assigns probability 0.5 on each unit and scores $2\log(0.5)=-1.386294$, which is better. Indeed the product $(0.1+0.8w)(0.9-0.8w)$ is maximised at $w=0.5$. The components' complementary mistakes explain the gain. Averaging their log scores would retain the inferior value; averaging predictions before taking logs is a different operation.

With two identical predictive models, every weight gives exactly the same predictions, so the data cannot determine a unique stacking weight. Even with distinct models, fitted weights can be uncertain. Evaluate a learned combination as part of the full training procedure, and do not present its score on the weight-fitting data as untouched evidence of future performance.

---

Source: `course/chapters/10_model_checking.md:167–171`

## Lab

Run [Lab 10](../../notebooks/10_model_checking.ipynb), or its [Python source](../../labs/10_model_checking.py). Reproduce the four analytic LOO contributions before interpreting PSIS output. Report the predictive target, same-unit score difference, paired SE with its independence limitation, and the number and identities of problematic Pareto diagnostics. The lab's waiting-time rows have centre structure, so its pointwise SE is explicitly an approximation.

Present the discrepancy plot with its units and replication rule. Write separate conclusions about relative predictive performance and the better model's remaining failure. Then design an unseen-centre validation procedure without claiming the existing row-level output already evaluates it.

---

Source: `course/chapters/10_model_checking.md:173–177`

## Retrieval and summary

Without the text, explain why a good sampler can accompany a poor centre check, why an exact refit may disagree with unstable PSIS, and which information must be unavailable when forecasting. Describe one failure that a check of the mean would miss.

Model criticism asks whether consequential features are reproduced. Predictive comparison asks which candidate predicts better for a specified unit and deployment. Their uncertainty includes data limitations as well as computational approximations. State the target first, retain pointwise evidence, investigate warnings, and make revisions traceable.

---

Source: `course/chapters/10_model_checking.md:179–187`

## Exercises

**10.1 — Concept.** Can a model have good R-hat and poor posterior predictive checks? Give a concrete reason.

**10.2 — Calculation.** Pointwise log-score improvements are 1, 2, −1, and 2. Calculate their total and the approximate paired SE using sample variance. Interpret the strength of the comparison cautiously.

**10.3 — Design.** You want to predict outcomes in a new hospital but have repeated patient visits in ten existing hospitals. Propose a validation split, describe a leakage risk, and explain why ordinary row-level LOO answers a different question.

[Solutions](../solutions.md).

---

Source: `course/chapters/10_model_checking.md:189–191`

## Further reading

The primary papers linked above cover LOO, PSIS, and stacking. Vehtari's [cross-validation FAQ](https://users.aalto.fi/~ave/modelselection/CV-FAQ.html) expands on predictive targets, dependence, and comparison uncertainty; [Bayesian Workflow](https://arxiv.org/abs/2011.01808) places model criticism within iterative analysis.

---

Source: `course/chapters/11_robustness.md:1–3`

# 11 · Test assumptions and computational calibration

**Objectives:** assess prior and likelihood sensitivity; recognise missing-data assumptions; distinguish calibration from model fit; design a simulation check; derive observation-process and robustness contributions; interpret sensitivity and calibration limits. **Prerequisite:** chapter 10 and the normal and beta updates. [Appendix 2](../appendices/02_calculus.md) reviews differentiation and integration; [Appendix 4](../appendices/04_numerics.md) reviews numerical error.

---

Source: `course/chapters/11_robustness.md:5–11`

## Which conclusions survive reasonable changes?

An analysis recommends changing a service because the estimated benefit exceeds a break-even point. A colleague uses another defensible prior and recommends keeping the existing design. Neither calculation contains a programming error. What should the report say? The disagreement identifies a consequential assumption, and the analysis should show how that assumption affects the decision.

Sensitivity analysis varies plausible analysis choices and records changes in a named target: a location, a tail probability, a future count, or an action. Robustness means limited sensitivity over the particular changes considered. It is always relative to that target and set of changes. An estimate can be robust to extreme observations while a tail-risk prediction remains highly sensitive to the likelihood.

Start with a small, reasoned set of alternatives. Compare observable prior predictions, fit each model, and record the target, uncertainty, computation checks, and decision. Include alternatives motivated by subject knowledge, not just settings that reproduce a preferred result. Document changes made after seeing outcomes. A sensitivity table is evidence about the consequences of assumptions; it is not permission to select the most convenient row.

---

Source: `course/chapters/11_robustness.md:13–23`

## Influence is a property of an analysis

Influence asks how much changing or removing a particular observation or group changes the result. An unusual observation need not be influential if the model already expects substantial variation there. Conversely, an ordinary-looking observation can strongly affect a poorly identified contrast. Measure influence on the actual estimand, not only on coefficients or residuals.

Deletion refits are diagnostic counterfactuals. They do not justify discarding a record without a reason about its validity or target population. Compare changes with posterior uncertainty and numerical error: a shift smaller than simulation noise does not establish scientific sensitivity. If observations arrive in clusters, examine deletion of a whole cluster as well as individual rows. Removing a group can expose dependence on an exchangeability assumption that row deletion barely changes.

Prior sensitivity and observation influence can interact. A single datum may dominate under a very broad prior but have less effect under substantive regularisation. That does not by itself establish which prior is appropriate. Explain what prior information is being asserted and which observable predictions it produces.

Separate sensitivity to a scientifically meaningful alternative from sensitivity to an arbitrary computational setting. Increasing grid resolution should stabilise the same posterior; changing the observation model intentionally produces another posterior. If a numerical method has not stabilised, first resolve that problem before attributing differences to substantive assumptions. Conversely, running one model more accurately cannot settle disagreement between two plausible observation mechanisms.

The spread of a sensitivity table is not automatically a probability distribution over answers. Its rows need not be equally plausible, and the union of their credible intervals has no standard posterior coverage interpretation. If model averaging is justified, state the model weights and their basis. Otherwise report scenario-specific intervals alongside the assumptions defining each scenario, without hiding the disagreement in one unexplained wider interval.

---

Source: `course/chapters/11_robustness.md:25–42`

## Why a Student-t likelihood changes influence

Write the residual as $r=y-\mu$. For a normal location model with known observation SD $\sigma$, the log likelihood contributes $-r^2/(2\sigma^2)$ plus constants. Differentiating with respect to the location gives

$$\frac{\partial\log p_N(y\mid\mu)}{\partial\mu}=\frac{r}{\sigma^2}.$$

Its magnitude grows without bound with the residual. An extreme observation pulls strongly on the location. For a Student-t location model with degrees of freedom $\nu>0$ and scale $s>0$, the corresponding term and derivative are

$$\log p_t(y\mid\mu)=C-\frac{\nu+1}{2}
\log\left(1+\frac{r^2}{\nu s^2}\right),\qquad
\frac{\partial\log p_t(y\mid\mu)}{\partial\mu}
=\frac{(\nu+1)r}{\nu s^2+r^2}.$$

Here $C$ is constant in the location when scale and degrees of freedom are fixed. The derivative is bounded and tends towards zero for extremely large residuals. It describes one observation's contribution to the posterior location equation, not a universal guarantee about the fitted estimate. In regression the coefficient derivative also contains the predictor value, so heavy-tailed outcome noise alone does not solve every high-leverage predictor problem.

A Student-t **scale is not its SD**. For $\nu>2$, variance is $s^2\nu/(\nu-2)$; for $1<\nu\le2$, the mean exists but the variance is infinite; for $\nu\le1$, even the mean is undefined. The symmetric location remains defined. With four degrees of freedom and scale one, SD is $\sqrt2$. To match a normal SD of one, use t scale $1/\sqrt2$. Holding scale fixed therefore changes both tail shape and variance, which must be acknowledged when interpreting a likelihood comparison.

An equivalent construction gives each observation a latent precision multiplier: draw $\lambda_i\sim\operatorname{Gamma}(\nu/2,\nu/2)$ using shape and rate, then draw $Y_i\mid\lambda_i,\mu\sim N(\mu,s^2/\lambda_i)$. Integrating out the multiplier gives the t likelihood. Conditional on a residual, its expected multiplier is $(\nu+1)/(\nu+r^2/s^2)$. Large residuals favour smaller multipliers, allowing more local variance. This construction explains how the likelihood accommodates an unusual outcome without requiring the common location to move as much. It is still a modelling assumption about variation, not a posterior verdict that a record should be deleted.

---

Source: `course/chapters/11_robustness.md:44–64`

## Worked example 1: an extreme measurement

Lab 11 uses measurements $(0.1,-0.4,0.2,0.6,-0.2,0,8)$ and prior $\mu\sim N(0,4)$, where the prior variance is four. Under known normal observation SD one, the sum is 8.3 and posterior precision is $7+1/4=7.25$. Hence

$$E[\mu\mid y]=\frac{8.3}{7.25}=1.144828,\qquad
\operatorname{SD}(\mu\mid y)=\sqrt{1/7.25}=0.371391.$$

Without the artificial eight, the sum is 0.3 and the mean becomes $0.3/6.25=0.048$. This large change exposes the normal model's sensitivity. Under a t likelihood with four degrees of freedom and scale one, numerical integration of the normal prior times the seven t densities gives a posterior location mean of **0.136818**. Without the eight, it is **0.046157**.

The derivative calculation explains the difference. At location zero, a residual of eight contributes eight to the normal location score, but only $5(8)/(4+64)=0.588235$ to the t score. A residual of one contributes one to both. The t likelihood pays attention to the central observations while allowing an isolated larger residual.

| Prior SD | Data used for diagnostic comparison | Normal posterior location mean | Student-t posterior location mean |
|---:|---|---:|---:|
| 2 | All seven | 1.144828 | 0.136818 |
| 2 | Six central observations | 0.048000 | 0.046157 |
| 4 | All seven | 1.175221 | 0.141196 |
| 4 | Six central observations | 0.049485 | 0.047513 |

These values can be checked by independently normalising the one-dimensional posterior densities and integrating location times density. The lab uses a fine grid; extending the integration bounds checks that grid truncation is immaterial here. Likelihood choice has a much larger effect than doubling the prior SD. This is a conclusion about these data and settings, not a general ranking of priors and likelihoods.

Investigate the eight before choosing a final model. It could be a transcription error, a member of a separate population, or a legitimate rare measurement. For the synthetic lab it is deliberately inserted. A robust central-location analysis does not estimate the mean of an unspecified contamination process, nor does it guarantee accurate probabilities of extreme waits. Fitting scale or degrees of freedom adds uncertainty and can alter the comparison; the table deliberately fixes both likelihood scales.

---

Source: `course/chapters/11_robustness.md:66–82`

## Describe how a value becomes observable

Let $R_i=1$ indicate that an outcome is observed, $\theta$ govern outcomes, and $\psi$ govern observation. A selection model can express

$$p(y,R\mid\theta,\psi)=p(y\mid\theta)p(R\mid y,\psi).$$

The observed-data likelihood integrates over missing values:

$$p(y_{\mathrm{obs}},R\mid\theta,\psi)
=\int p(y_{\mathrm{obs}},y_{\mathrm{mis}}\mid\theta)
 p(R\mid y_{\mathrm{obs}},y_{\mathrm{mis}},\psi)\,dy_{\mathrm{mis}}.$$

Missing completely at random, MCAR, means observation does not depend on observed or missing values. Missing at random, MAR, permits dependence on observed information but not on the missing values after conditioning on that information. Missing not at random, MNAR, retains that additional dependence. These are assumptions about the data-generating process; observed records alone generally cannot distinguish MAR from MNAR.

Under MAR, distinct outcome and missingness parameters, and an appropriately factorised prior, the missingness contribution can be ignored for the usual likelihood-based posterior inference about outcome parameters. This is an ignorability result with conditions, not a blanket instruction to discard incomplete rows. Complete cases can have a different covariate distribution from the target population. Population averages may still require modelling and standardisation over that target.

For missing predictors, a joint model supplies a distribution for their unknown values and integrates over them. Filling each blank with one mean and treating it as measured removes uncertainty and can distort associations. The [Stan missing-data guidance](https://mc-stan.org/docs/stan-users-guide/missing-data.html) illustrates latent-value modelling; [the observation-process bridge](../advanced/03_observation_process.md) adds measurement error and selection mechanisms.

---

Source: `course/chapters/11_robustness.md:84–108`

## Worked example 2: selection and an unidentified mean

First consider the lab's known demonstration mechanism. Generate a standard normal population but retain only values below 0.7. The fraction retained is $\Phi(0.7)=0.758036$. Since the derivative of the standard normal density is $\phi'(z)=-z\phi(z)$, integrating gives

$$E[Y\mid Y<0.7]=
\frac{\int_{-\infty}^{0.7}z\phi(z)\,dz}{\Phi(0.7)}
=-\frac{\phi(0.7)}{\Phi(0.7)}=-0.411925.$$

Thus even a huge observed sample concentrates near a negative mean, although the generating population mean is zero. The bias arises from the observation mechanism, not inadequate posterior computation. The calculation is a reference for the simulation, whose finite-sample mean fluctuates around it.

If a register records everyone but reports only “above 0.7” for a high value, that censored observation contributes $1-\Phi(0.7)=0.241964$ under this specified standard normal model. If high values are absent altogether and the dataset is sampled conditional on inclusion, an observed $y<0.7$ contributes the truncated density $\phi(y)/\Phi(0.7)$. The first is an event probability; the second is a conditional density with a selection normaliser. They represent different information. Treating a censoring threshold as an exact value is incorrect.

Now consider a survey with 100 eligible people, 80 responses, and an observed mean wait of ten minutes. The missing people's mean is unknown. Define a sensitivity parameter $\delta$ as their mean minus the respondents' mean. Holding those quantities fixed for this illustration, the population mean is

$$0.8(10)+0.2(10+\delta)=10+0.2\delta.$$

| Assumed extra wait among nonrespondents | Missing-group mean | Population mean |
|---:|---:|---:|
| 0 minutes | 10 minutes | 10 minutes |
| 5 minutes | 15 minutes | 11 minutes |
| 15 minutes | 25 minutes | 13 minutes |

If a policy trigger is a population mean above twelve minutes, the conclusion changes when $\delta>10$. The observed survey cannot select the correct row. Follow-up sampling or external evidence can inform plausible values; otherwise present the range and its decision implications. This table isolates structural sensitivity and is not a posterior interval. A fuller analysis also propagates uncertainty about respondent means, response fractions, and the sensitivity parameter.

The known truncation mechanism in the normal demonstration permits a specified selection likelihood. Real survey nonresponse rarely supplies such complete knowledge. Do not infer that fitting a parametric selection model automatically identifies its unobserved component. A narrow posterior can reflect a strong assumption about that component.

---

Source: `course/chapters/11_robustness.md:110–123`

## What simulation-based calibration checks

Parameter recovery fixes plausible generating parameters, simulates data, fits the model, and asks whether the results make sense. Repeated recovery at selected settings can diagnose weak identification or implementation defects. It does not imply that a Bayesian interval has its advertised coverage at every fixed parameter value.

Simulation-based calibration, SBC, instead averages over the model's prior predictive distribution:

1. Draw a generating parameter $\theta^\star$ from a proper prior.
2. Generate data from the stated likelihood at $\theta^\star$.
3. Fit that same model to those data, without revealing $\theta^\star$ to the fitting algorithm.
4. Obtain $S$ posterior draws and count how many are below $\theta^\star$.

Conditional on the simulated dataset, the generating value itself has the model's posterior distribution. With correct inference, continuous parameters, and independent posterior draws, it is exchangeable with those draws. Each of the $S+1$ possible ranks is therefore equally likely. This is a consequence of the joint model and conditioning, developed in the [original SBC paper](https://arxiv.org/abs/1804.06788).

The generator must match the intended prior, likelihood, constraints, and observation mechanism. A missingness model should simulate missingness too. Improper priors cannot supply the required prior draws. Ties for discrete quantities need randomised treatment; otherwise simple continuous-rank uniformity is the wrong reference. Correlated MCMC draws also invalidate the simple independent-rank calculation. Diagnose each fit and use an appropriate dependence-aware procedure or sufficiently independent draws; ordinary posterior sample count is not enough. The [Stan SBC guide](https://mc-stan.org/docs/stan-users-guide/simulation-based-calibration.html) discusses these requirements.

---

Source: `course/chapters/11_robustness.md:125–138`

## Worked example 3: ranks and their variability

Lab 11 draws $\theta^\star\sim\operatorname{Beta}(2,2)$ and $Y\mid\theta^\star\sim\operatorname{Binomial}(20,\theta^\star)$. The correct fitted posterior is Beta($2+Y,22-Y$). For illustration, if the generating value is 0.60 and four independent posterior draws are 0.42, 0.71, 0.55, and 0.63, two draws are smaller, so the rank is two. One rank is uninformative; the check repeats across independently generated datasets.

The lab uses 500 replications and 200 independent posterior draws per replication. Correct ranks range from zero through 200 and have mean 100. A discrete uniform rank has variance $S(S+2)/12$, so the mean rank across 500 replications has SE

$$\sqrt{\frac{200(202)}{12(500)}}=2.595.$$

A mean near 99 is therefore unsurprising. A mean near 33, as in the deliberately biased implementation, is far beyond ordinary variability under this reference. The biased update adds eight unjustified successes, moving posterior draws upwards; the generating value then has a small rank more often.

In ten histogram bins, expected counts are roughly 50, with marginal count SD about $\sqrt{500(0.1)(0.9)}=6.7$. There are 201 possible integer ranks, so equal-width bins need not contain exactly equal numbers of ranks: their precise expected counts differ slightly. The lab's horizontal line at 50 is a visual reference, not an exact simultaneous acceptance band. Inspect the [rank histograms](../../artifacts/figures/11_sbc.svg) against their simulation variability.


<!-- VISUAL01:13 BEGIN -->

---

Source: `course/chapters/11_robustness.md:140–159`

### Visual investigation: ideal calibration still has finite variation

An ideal SBC replication draws a parameter from the prior, data from the sampling model, then nine independent draws from the exact posterior. For a continuous parameter without ties, rank the original parameter among those nine. Predict whether repeating the experiment one hundred times should put exactly ten ranks in each bin.

![Exact Binomial(100,0.1) masses show variation in one ideal SBC rank-bin count around ten; a finite count need not equal its expectation.](../../artifacts/figures/visual01_13_calibration.svg)

**Read the figure.** The horizontal axis counts how many of the one hundred replications land in one particular rank bin. The vertical axis is its probability mass under ideal calibration. This is an exact reference distribution, not an observed SBC histogram. Ten is an expectation, not a required result.

| Quantity for one rank bin | Ideal reference |
|---|---:|
| Rank probability, for ranks 0 through 9 | 0.1 |
| Expected count among 100 independent replications | 10 |
| Count SD | 3 |
| 2.5% and 97.5% bin-count quantiles | 5 and 16 |

**Mathematical connection.** Exchangeability under the prior predictive construction makes the ten ranks uniform. Across independent replications a particular bin count is Binomial(100,0.1), with variance $100(0.1)(0.9)=9$. The ten bin counts are jointly constrained to total one hundred; they are not ten independent binomials. The displayed 0–25 count range omits a small positive tail.

**Original unscored exploration — predict, observe, explain.** Predict whether a count of sixteen alone disproves calibration; observe that it lies at the reported upper marginal quantile. Explain why this is not a simultaneous acceptance band for all ten bins. Transfer to correlated posterior draws: identify the exchangeability/independence assumptions that need attention before using this simple reference. Rank shape may reveal a problem, but does not identify its unique computational or modelling cause.

<!-- VISUAL01:13 END -->

---

Source: `course/chapters/11_robustness.md:161–167`

## Interpret failure without overdiagnosing it

Excess extreme ranks can suggest posterior distributions that are too narrow; central ranks can suggest excessive spread; a sloping histogram can suggest bias. These patterns are clues, not unique diagnoses. Dependence, inaccurate fitting, generator mistakes, indexing errors, and inappropriate tie handling can produce misleading patterns. Reproduce the failure on an exact small case and change one component at a time. Record failed fits rather than silently excluding difficult simulated datasets.

Uniform ranks are necessary for the ideal calculation but are not proof of a correct implementation. An algorithm that ignores data and always draws from the prior can pass parameter-rank checks averaged over that same prior. Checking only marginal parameters can also miss dependence errors. Use analytically solved cases, posterior contraction checks, and additional quantities that depend on the data. The [test-quantity SBC paper](https://arxiv.org/abs/2211.02383) explains why the chosen checks affect sensitivity to defects.

SBC assesses computational consistency under the simulated model. Even a perfectly implemented normal model can fail to reproduce real outliers. A plausible posterior predictive plot can likewise coexist with computational bias in a direction that plot does not inspect. Scientific adequacy, identification, and computational calibration remain distinct questions.

---

Source: `course/chapters/11_robustness.md:169–173`

## Lab

Run [Lab 11](../../notebooks/11_robustness.ipynb), or its [Python source](../../labs/11_robustness.py). Compare the normal location with its analytic value and the selected-sample mean with the truncation calculation. In a separate copy, remove the artificial outlier and double the prior SD to reconstruct the sensitivity table. State the t scale convention in the report.

Explain the direction of the biased SBC ranks before interpreting their histogram. If increasing replications, compare random bin variability rather than demanding perfectly level bars. Submit a sensitivity table and a paragraph separating computational consistency from scientific validation. Do not conclude that the observed sample alone identifies why records are missing.

---

Source: `course/chapters/11_robustness.md:175–179`

## Retrieval and summary

From memory, distinguish an outlier from an influential observation; explain why matching t scale to normal SD changes variance; and say what extra assumption each row of the survey table makes. Then describe a faulty algorithm that a simple SBC histogram might miss.

Robustness is a claim about specified perturbations and targets. Observation processes belong in the model or in an explicit sensitivity analysis. Calibration simulations test the inference procedure under stated generating assumptions. A credible report names what changed, checks numerical error, and explains which uncertainties the posterior does not represent.

---

Source: `course/chapters/11_robustness.md:181–189`

## Exercises

**11.1 — Concept.** A correct SBC histogram is approximately uniform, but predictions fail to reproduce observed outliers. Explain why these findings do not contradict one another.

**11.2 — Calculation.** A Student-t likelihood has $\nu=4$ and scale 2. Calculate its variance and SD. Is the likelihood's location necessarily the same estimand as the sample mean in a contaminated dataset?

**11.3 — Design.** Survey nonresponse may be more common among people with especially long waits, even after adjusting for observed variables. Explain the identification problem and propose a sensitivity analysis without claiming the observed data determine the missingness mechanism.

[Solutions](../solutions.md).

---

Source: `course/chapters/11_robustness.md:191–193`

## Further reading

The SBC and observation-process sources linked above supply technical continuation. [Bayesian Workflow](https://arxiv.org/abs/2011.01808) connects sensitivity, checking, and iteration; the [observation-process bridge](../advanced/03_observation_process.md) develops explicit missingness and measurement models.

---

Source: `course/chapters/12_decisions.md:1–3`

# 12 · Finish an analysis that supports a decision

**Objectives:** define a population estimand; calculate expected utility and information value; communicate model checks and sensitivity; complete a reproducible capstone; derive population expected utility; distinguish parameter uncertainty from realised risk. **Prerequisite:** chapters 1–11, especially predictive expectation, group models, and sensitivity. [Appendix 1](../appendices/01_probability.md) reviews conditional expectation and total variance.

---

Source: `course/chapters/12_decisions.md:5–18`

## Start with the choice, population, and horizon

A fictional service has randomised onboarding design A or B within eight centres. It must choose a design for 10,000 future visits, equally distributed across those existing centres. An extra completion is worth five utility units and rolling out B costs 1,000 units. These are stipulated teaching quantities, not estimates of real financial value. The practical question is whether expected improvements justify the cost for this population and horizon.

An inference about completion rates does not by itself answer that question. We also need available actions, their consequences, and a rule for valuing those consequences. Keeping A is the reference action. The primary analysis allows only keeping A everywhere or adopting B everywhere; choosing a separate design for every centre would be a different decision problem with potentially different implementation costs.

Let $\theta_{jA}$ and $\theta_{jB}$ denote completion probabilities in centre $j$. For target weights $w_j\ge0$ summing to one, define

$$\Delta_w=\sum_{j=1}^8w_j(\theta_{jB}-\theta_{jA}).$$

The capstone fixes $w_j=1/8$, so $\Delta=\Delta_w$ is an equal-centre absolute probability contrast. These weights describe future visits, not precision weights for estimating effects. Training sample sizes affect posterior uncertainty but do not determine who matters in the future population.


<!-- VISUAL01:14 BEGIN -->

---

Source: `course/chapters/12_decisions.md:20–39`

### Visual investigation: an action threshold comes from the loss table

Consider an original reserve decision linked to the illustrative eight-trial forecast in chapter 3. Reserve capacity costs four units regardless of the outcome and perfectly prevents an eighteen-unit disruption loss when $K\ge7$. No other costs or benefits are included. Predict whether the most probable event alone determines the preferred action.

![Expected loss of no reserve increases as eighteen times event probability; fixed reserve cost four crosses it at probability two ninths.](../../artifacts/figures/visual01_14_loss.svg)

**Read the figure.** Horizontal position is event probability $q=P(K\ge7)$, shown from zero to one half; the same straight loss functions extend to one. Vertical height is expected loss in stipulated cost units. Compare heights at the same q. The dotted crossing is a tie, not a discontinuity in either probability or loss.

| Action | Loss if K ≥ 7 | Loss otherwise | Expected loss |
|---|---:|---:|---|
| Reserve | 4 | 4 | 4 |
| No reserve | 18 | 0 | 18q |

**Mathematical connection.** Equality occurs at $q=4/18=2/9$. Above that threshold reserve has smaller expected loss; below it no reserve does; at equality both minimise expected loss. Under Beta(3,2) shared-parameter prediction for eight trials, q = 0.236364 and no-reserve loss = 4.254545. The plug-in Binomial gives q = 0.106376 and loss = 1.914762. The two probability treatments therefore change this toy decision while leaving its loss table fixed.

**Original unscored exploration — predict, observe, explain.** Hold the full predictive probability fixed and raise reserve cost from four to five. Predict the action, then observe that five exceeds 4.254545. Explain why the posterior need not change when the preferred action does. Transfer to imperfect prevention: identify which cell of the loss table would change before recalculating. These fictional losses are teaching assumptions, not an operational recommendation or a claim that reserving eliminates real disruption.

[Open the guided decision experiment](../../explorer.html#visual-decision) to predict, change one setting, and explain the result.

<!-- VISUAL01:14 END -->

---

Source: `course/chapters/12_decisions.md:41–46`

## Worked example 1: the capstone from counts to action

The [training data](../../data/experiment.csv) contain sixteen centre-arm binomial counts. Use independent Beta(1,1) priors, giving

$$\theta_{ja}\mid y\sim\operatorname{Beta}(a_{ja},b_{ja}),\qquad
 a_{ja}=1+y_{ja},\quad b_{ja}=1+n_{ja}-y_{ja}.$$

---

Source: `course/chapters/12_decisions.md:56–59`

For each cell, write $m_{ja}=a_{ja}/(a_{ja}+b_{ja})$ and $v_{ja}=a_{ja}b_{ja}/[(a_{ja}+b_{ja})^2(a_{ja}+b_{ja}+1)]$. Independence under this particular model gives

$$E[\Delta\mid y]=\frac18\sum_j(m_{jB}-m_{jA}),\qquad
\operatorname{Var}(\Delta\mid y)=\frac1{64}\sum_j(v_{jB}+v_{jA}).$$

---

Source: `course/chapters/12_decisions.md:77–83`

In risk-neutral units, the expected incremental value of adopting B conditional on the rates is

$$U_B(\Delta)=10000(5)\Delta-1000=50000\Delta-1000,\qquad U_A=0.$$

Averaging gives the action rule

$$E[U_B\mid y]>0\quad\Longleftrightarrow\quad E[\Delta\mid y]>0.02.$$

---

Source: `course/chapters/12_decisions.md:93–93`

This no-pooling model is transparent and preserves centre differences. It sacrifices information sharing and supplies no learned population distribution for unseen centres. A common-rate pooled model is a useful comparison, while a hierarchical logistic extension adds exchangeability assumptions. Complexity should improve the answer or expose consequential uncertainty. [Chapter 9](09_hierarchical.md) develops that tradeoff.

---

Source: `course/chapters/12_decisions.md:95–109`

## Expected value and realised outcomes are different distributions

Each value of $50000\Delta-1000$ is conditional expected incremental value, given completion probabilities. Its posterior distribution represents uncertainty about those expectations. It is not the distribution of the actual number of extra completions or realised rollout value. The capstone's risk-neutral action remains valid because expectation averages over both parameter uncertainty and future outcome variation.

For example, with exactly 1,250 future visits per centre, a model of realised completions under B could generate

$$K_{jB}\mid\theta_{jB}\sim\operatorname{Binomial}(1250,\theta_{jB}),\qquad K_B=\sum_jK_{jB},$$

conditionally independently across centres. Then

$$\operatorname{Var}(K_B\mid y)=
E\left[\sum_j1250\theta_{jB}(1-\theta_{jB})\mid y\right]
+\operatorname{Var}\left(\sum_j1250\theta_{jB}\mid y\right).$$

The first term is future outcome noise; the second is uncertainty about the expected total. Even if every probability were known, the first term would remain. For decisions with nonlinear utility, both terms can matter, so simulate consequences under each action before applying utility. The [Stan decision-analysis guide](https://mc-stan.org/docs/stan-users-guide/decision-analysis.html) presents this outcome-first calculation.

---

Source: `course/chapters/12_decisions.md:119–121`

A posterior interval for the expected incremental value is obtained by transforming the interval for the contrast with the increasing affine function above. That transformation preserves its posterior probability content, but adding a label such as “prediction interval” would change its meaning incorrectly. A prediction interval for future completions requires the extra binomial simulation or equivalent beta-binomial integration. Specify which distribution every reported interval summarises.

There is an additional counterfactual issue. The same future visits cannot all receive both A and B. Independent simulated totals under the two actions describe independent hypothetical cohorts, not an identified joint distribution of paired potential outcomes for the same people. Risk-neutral expected differences need the marginal expectations. A distribution for realised paired differences needs additional dependence assumptions. Do not imply that randomisation alone supplies them.

---

Source: `course/chapters/12_decisions.md:123–125`

## Population weights can change the answer

To see why weights are substantive, consider a separate two-centre example with posterior mean improvements 0.10 and −0.02. Equal weights give $0.5(0.10)+0.5(-0.02)=0.04$ and expected net value 1,000 under the capstone's horizon and cost. If future visits are instead 20% in the first centre and 80% in the second, the contrast is $0.2(0.10)+0.8(-0.02)=0.004$ and expected net value is −800. The preferred action changes because the target population changed, although the fitted centre effects did not.

---

Source: `course/chapters/12_decisions.md:135–135`

Population shares and distributional priorities are also different inputs. A service may value benefits to an underserved group more highly than its visit share, or impose a minimum benefit constraint for every centre. Make those choices explicit in the utility or constraints. An overall positive average can coexist with an unfavourable effect in a particular group.

---

Source: `course/chapters/12_decisions.md:137–147`

## Utility includes risk attitudes

Expected utility compares actions by averaging a declared valuation of consequences. Linear value is risk-neutral in those units. A concave valuation represents aversion to variability: a large loss can outweigh a similarly likely gain even when expected net value is positive. Utility should reflect the decision maker's priorities; posterior probabilities cannot determine those priorities.

For a simple illustration, suppose a net consequence $V$ is +3,000 with probability 0.6 and −3,000 with probability 0.4, while keeping A yields zero. Linear utility prefers the gamble because $E[V]=600$. Under $u(V)=-\exp(-V/3000)$,

$$E[u(V)]=-0.6e^{-1}-0.4e^1\approx-1.3080<u(0)=-1.$$

This risk-averse valuation prefers zero. Its certainty equivalent, $-3000\log\{0.6e^{-1}+0.4e^1\}\approx-805.59$, is the sure net value with the same utility. This is a separate two-consequence illustration, not a fitted capstone risk model. Applying a nonlinear utility directly to the capstone's conditional expected values would omit future outcome risk unless that omission were an explicit approximation.

A probability such as $P(\Delta>0\mid y)$ concerns improvement, while $P(\Delta>0.02\mid y)$ concerns positive conditional expected net value. Neither universally determines the preferred action. A stated probability-of-loss constraint is possible, but define the loss event and its threshold rather than adding an unexplained “conservative” cutoff.

---

Source: `course/chapters/12_decisions.md:149–161`

## Opportunity loss and perfect information

For each parameter state, an oracle knowing that state would choose the action with the largest conditional expected utility. Relative to that oracle, the opportunity losses for the capstone are

$$L_A=\max(0,U_B),\qquad L_B=\max(0,-U_B).$$

Opportunity loss measures a forgone opportunity, not necessarily a negative realised outcome. Their difference satisfies $L_A-L_B=U_B$ for every draw. Averaging is a useful numerical check. Minimising expected opportunity loss gives the same action as maximising expected utility because the oracle term is common to all actions.

The expected value of perfect information about these uncertain rates is

$$\operatorname{EVPI}=E[\max(0,U_B)\mid y]-\max(0,E[U_B\mid y]).$$

It equals the expected opportunity loss of the optimal current action and is nonnegative. Perfect information lets the decision depend on the state before action is taken. It does not mean foreseeing and avoiding every unlucky future completion outcome. A calculated EVPI remains conditional on the represented uncertainty and fixed decision; it does not price learning about omitted model failures.

---

Source: `course/chapters/12_decisions.md:163–180`

## Worked example 2: calculate the value of a particular study

Consider a separate decision with the same horizon and cost but a simplified current posterior: $\Delta=0.08$ with probability 0.6, or $\Delta=-0.04$ with probability 0.4. These states give conditional net values +3,000 and −3,000. Current expected net value is 600, so choose B. Keeping A loses the positive-state opportunity, $0.6(3000)=1800$; choosing B loses $0.4(3000)=1200$. Their difference is 600, and EVPI is $1800-600=1200$.

A proposed study reports either “+” or “−”. Its assumed sampling model is $P(+\mid\text{positive state})=0.8$ and $P(+\mid\text{negative state})=0.2$. Enumerate possible future data before collecting them:

| Study result | Predictive probability | Updated positive-state probability | Expected net value of B | Subsequent action |
|---|---:|---:|---:|---|
| + | $0.6(0.8)+0.4(0.2)=0.56$ | $0.48/0.56=6/7$ | 2,142.857 | B |
| − | $0.6(0.2)+0.4(0.8)=0.44$ | $0.12/0.44=3/11$ | −1,363.636 | A |

The predictive probabilities sum to one. Averaging the updated positive-state probabilities gives $0.56(6/7)+0.44(3/11)=0.6$, recovering the current posterior probability. Information does not create a systematic expected effect increase. Its value comes from allowing different actions after different results.

With the study, expected optimised value is $0.56(2142.857)+0.44(0)=1200$. The **expected value of sample information**, EVSI, is therefore $1200-600=600$ units. As a check, residual expected opportunity loss after the study is $0.08(3000)+0.12(3000)=600$: wrong positive results cause the first loss and wrong negative results the second. EVPI minus that residual loss is again EVSI.

If the study costs 100 units without delaying rollout, its net expected gain is 500. If it costs 700, it is not worthwhile solely for this decision, even though that cost is below EVPI. Perfect information is an upper bound, not the study's expected benefit. These calculations assume the stated sampling model is correct and that the study does not itself change the decision horizon or consequences.

Information can change beliefs while having zero value for this action set. Suppose a weaker study has positive-result probabilities 0.55 and 0.45 in the two states. A positive result gives positive-state probability $0.33/0.51=0.647059$; a negative result gives $0.27/0.49=0.551020$. Both still favour B. Averaging the subsequent optimised values therefore gives the same 600 units as acting now, and EVSI is zero. This study might be useful for another question, but neither result changes this decision. Information value depends on the available actions and their consequences as well as statistical precision.

---

Source: `course/chapters/12_decisions.md:182–191`

## General EVSI and its limits

For proposed future data $Z$, let $\bar U(a\mid y)$ be the current expected utility of action $a$. Then

$$\operatorname{EVSI}=E_{Z\mid y}\left[\max_a\bar U(a\mid y,Z)\right]
-\max_a\bar U(a\mid y).$$

For each possible or simulated dataset, update, optimise the subsequent action, and only then average over datasets. Maximising after averaging would force the same action regardless of the study result and discard the information's purpose. In larger problems this can require nested simulation; separate numerical error in the inner updates and outer averaging. Optimising noisy estimates can itself introduce bias.

Under the same model, actions, horizon, and utility, cost-free information that can be ignored satisfies $0\le\operatorname{EVSI}\le\operatorname{EVPI}$. Collection costs and delays are assessed afterwards in compatible value units. With nonlinear utility, model costs as consequences and recompute utility; arbitrary subtraction of monetary costs from utility scores is invalid. If learning also serves other populations or future decisions, calculate their value explicitly rather than carrying over this bound unchanged.

---

Source: `course/chapters/12_decisions.md:193–197`

## Freeze, check, and examine sensitivity

Before inspecting holdout outcomes, record the estimand, priors, exclusions, and planned comparisons. Fit only the training counts. Inspect prior predictions at the cell level as well as overall: independent uniform cell priors can produce a moderate overall average while allowing extreme individual centres. Posterior checks of centre ranges can be easy for a flexible no-pooling model, so moderate tail fractions are limited evidence of adequacy.

Evaluate the frozen models on the sixteen held-out counts using their beta-binomial predictions. Keep the same marginal cell scoring units; a sum of marginal scores is not generally a joint predictive score for a pooled or hierarchical model. Sixteen discrete counts give limited information about coverage. If the holdout prompts revision, report that it became development data and seek new validation where possible.

---

Source: `course/chapters/12_decisions.md:216–222`

## Communicate and reproduce the decision

Lead a memo with the action, population, horizon, and conditions. Report the absolute improvement in percentage points, a model-based interval, expected consequence, and an assumption capable of reversing the action. Label the estimated probability as positive conditional expected net value, rather than guaranteed realised profitability. Numerical precision should serve the decision; a several-unit Monte Carlo error does not justify reporting utility to six decimal places.

For this synthetic experiment, randomisation supports a treatment interpretation within the simulated population under consistent treatment, no interference, and appropriate outcome observation. Generalising to real users or unseen centres requires additional evidence. The [causal bridge](../advanced/04_causal.md) explains why prediction alone cannot establish intervention effects.

Keep a reproducibility record containing data provenance and checksums, training/holdout roles, model equations, prior revisions, target weights, units, utility and cost assumptions, software versions, seeds, commands, and generated outputs. Separate analytic quantities from simulation estimates and record their error. The exact capstone draws require moment and Monte Carlo checks; R-hat and NUTS divergences are inapplicable. An MCMC extension must supply its own diagnostics. Reproducibility lets another analyst audit the recommendation; it does not establish the truth of its assumptions.

---

Source: `course/chapters/12_decisions.md:224–228`

## Lab

**Selected-core project order: attempt → save plan → consult reference → revise.** Start from the capstone brief and save your target, model, priors, split and decision rule before opening Lab 12, its executed notebook or the reference report; all are worked references. Then reproduce and critique the supplied analysis, record assistance and explain your revisions. **Extended study:** general EVSI computation and expanded opportunity-loss derivations add to the core workload.

Use the [capstone brief](../capstone.md), [Lab 12](../../notebooks/12_capstone.ipynb), and [Python source](../../labs/12_capstone.py). Reproduce the analytic moments, compare them with the saved simulation within MCSE, and verify the opportunity-loss identity. Change cost and population weights separately so their effects remain interpretable. The [decision plot](../../artifacts/figures/12_decision.svg) marks both zero improvement and break-even improvement. Consult the [reference report](../capstone_solution.md) after your attempt.

---

Source: `course/chapters/12_decisions.md:230–234`

## Retrieval and summary

Explain why a probable improvement need not justify an action; why future outcome variation remains with known parameters; and why an experiment can cost less than EVPI but still be unattractive. Reconstruct the two-result study tree without the table.

A decision is conditional on a population, action set, model, utility, and horizon. Weight effects for that population, propagate the uncertainties relevant to the utility, and distinguish perfect information from a particular study. Finish with a recommendation whose assumptions and calculations another reader can inspect.

---

Source: `course/chapters/12_decisions.md:236–244`

## Exercises

**12.1 — Concept.** Why can B have a high probability of improving completion but still be a poor decision? State which missing quantities determine the choice.

**12.2 — Calculation.** Suppose $\Delta$ is 0.06 with probability 0.7 and −0.02 with probability 0.3. For 10,000 future visits, five utility units per extra completion and rollout cost 1,000 units, use U_B=50,000 Delta−1,000 and U_A=0 to calculate expected net utility, both expected opportunity losses, the optimal action, and EVPI.

**12.3 — Communication.** Write a five-sentence memo using your own completed capstone analysis of data/experiment.csv, including its holdout_trials and holdout_successes columns (10,000 future visits, equally weighted over eight existing centres; five utility units per extra completion, rollout cost 1,000). Attach or identify your result artifact so the memo can be checked against it. Include the target population, absolute improvement, uncertainty, decision, and one limitation. Avoid treating a model-based probability as an unconditional guarantee.

[Solutions](../solutions.md).

---

Source: `course/chapters/12_decisions.md:246–248`

## Further reading

[Think Bayes, decision analysis](https://allendowney.github.io/ThinkBayes2/chap09.html) offers further discrete calculations. [Bayesian Modeling and Computation, workflow chapter](https://bayesiancomputationbook.com/markdown/chp_09.html) connects decisions to a complete analysis. The [reference and continuation map](../reference.md) identifies further study.

---

Source: `course/advanced/01_approximation.md:1–5`

# A01 · Approximate a posterior without hiding the error

**Prerequisites:** [Monte Carlo](../chapters/05_monte_carlo.md), [HMC](../chapters/06_hmc.md), and [regression](../chapters/07_regression.md); derivatives, multivariate Normals, and stable integration in [Appendix 2](../appendices/02_calculus.md), [Appendix 3](../appendices/03_linear_algebra.md), and [Appendix 4](../appendices/04_numerics.md).

**Objectives:** A01.O1 derive Laplace and ELBO identities; A01.O2 quantify approximation error against an exact target; A01.O3 diagnose underdispersion, local modes, and optimisation limits.

---

Source: `course/advanced/01_approximation.md:7–13`

## Which uncertainty can a fast fit preserve?

Suppose two calibration offsets have a strongly correlated posterior. An optimisation routine quickly returns accurate estimates of both offsets. That is encouraging if the only requested output is their posterior means. It is insufficient if the operational question concerns the probability that their sum exceeds a tolerance. That probability depends on the spread and joint structure the routine may have discarded.

This bridge studies two ways of replacing a difficult posterior with a tractable distribution: local curvature, giving a Laplace approximation, and optimisation within a chosen family, giving a variational approximation. The estimand is always specified separately from the approximation. We will examine means, covariance, and a tail probability of a linear combination. A small error in one does not guarantee a small error in another.

Write the model as a proper joint density $p(y,\theta)=p(y\mid\theta)p(\theta)$, with finite, positive evidence $p(y)$. The target is $p(\theta\mid y)$. An approximation $q(\theta)$ is an additional computational choice, not a new observation. Increasing the number of draws from $q$ makes its summaries more precise while leaving any discrepancy between $q$ and the posterior intact. This distinction parallels Monte Carlo error in the core chapters, but here even infinitely many independent draws may converge to the wrong answer.

---

Source: `course/advanced/01_approximation.md:15–36`

## A quadratic picture near the mode

Let $\ell(\theta)=\log p(y,\theta)$ and let $\hat\theta$ be an interior local maximum. Assume twice continuous differentiability near that point, zero gradient, and a positive-definite negative Hessian

$$H=-\nabla^2\ell(\hat\theta).$$

A second-order Taylor expansion gives

$$\ell(\theta)\approx\ell(\hat\theta)
-\frac12(\theta-\hat\theta)^T H(\theta-\hat\theta),\qquad
q_L(\theta)=N(\hat\theta,H^{-1}).$$

The linear term vanishes at the mode. After exponentiation, the remaining quadratic has the shape of a Normal density. In numerical work solve linear systems involving the Hessian; constructing an inverse explicitly is rarely the best implementation. A negative or zero eigenvalue is a reason to investigate the stationary point, parameter redundancy, or boundary behaviour, not a reason to take absolute values until a covariance appears.

The approximation can be exact for a Gaussian posterior. More generally, it needs posterior mass to concentrate in a region where the quadratic is useful. A narrow curved ridge may look locally elliptical but bend elsewhere. A distant second mode can contain important mass without changing the Hessian at the first. A boundary mode does not satisfy the interior expansion. Heavy tails can carry substantial probability far beyond the neighbourhood checked by the curvature.

Integrating the approximate joint density also yields

$$\log p(y)\approx\ell(\hat\theta)+\frac d2\log(2\pi)
-\frac12\log|H|.$$

This evidence approximation requires the constants in the joint density. Constants discarded during posterior optimisation cannot be recovered from the Hessian. Its accuracy depends on the same global shape issues as the posterior approximation; a tidy determinant is not an independent evidence check.

---

Source: `course/advanced/01_approximation.md:38–46`

## Coordinates are part of the calculation

A positive rate can be represented by $\lambda$ or by $\eta=\log\lambda$. Densities transform with a Jacobian:

$$p_\eta(\eta\mid y)=p_\lambda(e^\eta\mid y)e^\eta.$$

Modes are density summaries and therefore depend on coordinates. A Gaussian fit in log-rate space becomes a lognormal approximation after transformation; it will not equal a Gaussian fit to the rate itself. Neither should be selected just because it gives a more convenient answer. Examine support, skewness, numerical stability, and the estimand that matters.

The exact posterior probability of an event is invariant under a correctly performed transformation. Disagreement between transformed approximations measures their limitations, not two different exact posteriors. When comparing them, compute the same rate-scale event in both. Comparing the mode in one coordinate with the mean in another confounds the summary choice with the approximation choice.

---

Source: `course/advanced/01_approximation.md:48–69`

## The direction of the variational objective

Choose a normalised family $q_\phi(\theta)$, indexed by optimisation parameters $\phi$. Assume its support and integrability make the following expectations finite. Starting from Bayes' rule,

$$\begin{aligned}
\operatorname{KL}(q_\phi\Vert p(\cdot\mid y))
&=E_q[\log q_\phi(\theta)-\log p(\theta\mid y)]\\
&=E_q[\log q_\phi(\theta)-\log p(y,\theta)]+\log p(y).
\end{aligned}$$

Define the evidence lower bound, or ELBO, by

$$\mathcal L(\phi)=E_q[\log p(y,\theta)]-E_q[\log q_\phi(\theta)].$$

Then

$$\log p(y)=\mathcal L(\phi)+
\operatorname{KL}(q_\phi\Vert p(\cdot\mid y))\ge\mathcal L(\phi).$$

The direction is **from the approximation to the posterior**, with expectation under the approximation. Maximising the ELBO minimises that divergence for a fixed model. It does not minimise the reverse divergence. Putting approximation mass where the posterior density is tiny is costly; omitting a region where the approximation puts almost no mass can be less costly. This helps explain why a restricted family may miss modes or have insufficient spread. It is a mechanism, not a theorem that every variational marginal must be too narrow. See the ELBO and mean-field discussion in [Blei, Kucukelbir, and McAuliffe](https://arxiv.org/html/1601.00670v9).

Three gaps deserve separate names. Optimisation error is failure to find the best member of the selected family. Approximation error remains when the best member differs from the target. Model error concerns the target itself as a description of the world. An improving objective addresses only the first gap, and even there a stochastic objective estimate can be noisy. Also, two models can have differently loose bounds: a larger ELBO across models need not imply larger evidence.

---

Source: `course/advanced/01_approximation.md:71–107`

## Worked analysis: two correlated calibration offsets

For a deliberately exact benchmark, suppose earlier Gaussian calibration data and priors have produced the following posterior for two offsets, measured in the same units:

$$\theta\mid y\sim N\left[
\begin{pmatrix}1\\-0.5\end{pmatrix},
\Sigma=\begin{pmatrix}1&0.8\\0.8&1\end{pmatrix}\right].$$

This is the fully specified target for the experiment; no fitting to an unspecified dataset is required. We want the sum $S=\theta_1+\theta_2$, the difference $D=\theta_1-\theta_2$, and $P(S>2.5\mid y)$. The precision is

$$Q=\Sigma^{-1}=\frac1{0.36}
\begin{pmatrix}1&-0.8\\-0.8&1\end{pmatrix}.$$

The log density is already quadratic, so its mode is the mean and its negative Hessian is exactly $Q$. Laplace recovers the entire target. This is a valuable implementation reference because failure here is numerical or algebraic, rather than a subtle non-Gaussian effect.

Now restrict the variational family to independent Normals,

$$q(\theta)=N(a_1,v_1)N(a_2,v_2).$$

Here $\operatorname{tr}(M)=\sum_j M_{jj}$ is the matrix trace, the sum of diagonal entries. In particular $\operatorname{tr}(QV_q)=\sum_j Q_{jj}v_j$ for diagonal $V_q$. For a Gaussian target the divergence, apart from constants, is

$$\frac12\left[
\operatorname{tr}(Q V_q)+(a-m)^TQ(a-m)-\log|V_q|
\right],\qquad V_q=\operatorname{diag}(v_1,v_2).$$

Differentiating the quadratic in $a$ sets $a=m$. Differentiating with respect to each positive variance gives $Q_{jj}-1/v_j=0$, hence $v_j=1/Q_{jj}=0.36$. The optimal independent approximation has the right means and the wrong marginal variances. A reciprocal precision diagonal describes conditional spread here, whereas the exact marginal variances are one.

| Quantity | Exact posterior and Laplace | Optimal independent Normal |
|---|---:|---:|
| Mean of the sum | 0.5 | 0.5 |
| Variance of the sum | 3.6 | 0.72 |
| Variance of the difference | 0.4 | 0.72 |
| Probability the sum exceeds 2.5 | 0.145920 | 0.009211 |

The exact sum variance includes two covariance terms: $1+1+2(0.8)=3.6$. Its tail is $1-\Phi(2/\sqrt{3.6})$. The independent approximation uses $0.36+0.36=0.72$. A tolerance exceedance of roughly fifteen percent is represented as less than one percent. Meanwhile the difference is **overdispersed**, because removing positive covariance removes cancellation. “Variational uncertainty is too small” is therefore incomplete unless the quantity and direction are specified.

An ellipse plot would show what a table of marginal means hides. The exact ellipse stretches along the sum direction and contracts along the difference direction. The independent approximation cannot rotate. A richer family with unrestricted covariance contains the exact target in this example, although optimisation of that family still requires checking.

---

Source: `course/advanced/01_approximation.md:109–124`

## See dependence before projecting it

![Two 90 percent joint ellipses reverse orientation when correlation changes sign; bars compare exact and mean-field contrast variances.](../../artifacts/figures/continuation_covariance.svg)

Each ellipse encloses 90% probability under its own bivariate Normal distribution: its squared Mahalanobis radius is $\chi^2_{2,0.9}=4.60517$. It is not a pair of marginal 90% intervals. Both coordinates keep means $(1,-0.5)$ and exact marginal variances one. With positive correlation the ellipse extends along the sum direction; with negative correlation it extends along the difference direction. Projecting onto a direction $a$ gives variance $a^T\Sigma a$.

For a general correlation $\rho$, the exact sum and difference variances are $2+2\rho$ and $2-2\rho$. The optimal independent reverse-KL Gaussian instead has variance $1-\rho^2$ in each coordinate. Thus both of its contrast variances equal $2(1-\rho^2)$: it is not obtained merely by deleting the off-diagonal covariance while keeping unit marginal variances. At $\rho=0$ the two distributions agree.

| Correlation | Exact sum variance | Exact difference variance | Either mean-field variance | Exact probability sum > 2.5 |
|---:|---:|---:|---:|---:|
| 0.8 | 3.6 | 0.4 | 0.72 | 0.145920273 |
| −0.8 | 0.4 | 3.6 | 0.72 | 0.000782701 |

The sum mean stays 0.5 and the difference mean stays 1.5. The mean-field sum tail is 0.009211063 for either sign. Sign reversal can therefore turn an underestimated sum tail into an overestimated one without changing the approximation's sum variance. The figure's numerical table remains usable without the graphic.

[Open the guided covariance experiment](../../explorer.html#continuation-covariance). **Predict:** which contrast becomes more uncertain if correlation changes from 0.8 to −0.8? **Change:** reverse only that sign, then try zero; retain threshold 2.5. **Explain:** use the two covariance terms to explain both variances and explain why the mean-field result stays unchanged under sign reversal. **Transfer:** for $2\theta_1-\theta_2$, derive the variance before using a simulation. This is an original unscored exploration; it saves no responses.

---

Source: `course/advanced/01_approximation.md:126–140`

## Worked stress test: positive, skewed uncertainty

Take a rate posterior $\lambda\mid y\sim\operatorname{Gamma}(3,2)$, using shape and rate. Its exact mean is 1.5 and variance is 0.75. The log density is $C+2\log\lambda-2\lambda$, giving rate-scale mode one and negative second derivative two at that mode. Thus direct Laplace gives $N(1,0.5)$.

That approximation assigns probability 0.078650 to a negative rate. For the operational event $\lambda>3$, the exact probability is

$$e^{-6}\left(1+6+\frac{6^2}{2}\right)=0.061969,$$

whereas the Gaussian tail is 0.002339. This is substantial approximation error even though the mode and curvature were calculated exactly. Truncating the Gaussian at zero would create yet another approximation requiring renormalisation; it does not automatically fix the right tail.

In log coordinates the transformed log density is $C+3\eta-2e^\eta$. Its mode is $\log(1.5)$ and curvature is three. A Gaussian approximation with that mean and variance $1/3$ implies a rate mean $1.5e^{1/6}=1.772041$. Respecting support improves one property while leaving other discrepancies. The lab can compare both approximations against gamma probabilities or independently normalised quadrature, with the same event thresholds throughout.

![Exact sum and mean-field densities, and gamma target versus rate-scale Laplace](../../artifacts/figures/13_approximation.svg)

The left panel compares sum uncertainty at correlation 0.8; the right panel shows the positive gamma target and the Gaussian mass outside its support. For the changed-correlation investigation use `result = compute(rho=-0.8)` and `render(result)`: the sum variance becomes 0.4, the difference variance 3.6, and the sum tail above 2.5 is about 0.000782701129. The mean-field sum variance is 0.72 for either sign.

---

Source: `course/advanced/01_approximation.md:142–150`

## A local success can miss another explanation

Consider a separate one-dimensional target that is an equal mixture of Normal densities centred at minus four and plus four, both with variance one. Its exact mean is zero and its variance is seventeen: one unit of within-component variance plus sixteen units from the separated component means. A local Gaussian near either peak can describe that neighbourhood extremely well while completely misrepresenting the overall mean, spread, and probability of a positive parameter.

Multiple optimisation starts can reveal the two peaks, but finding both is only the beginning. Their relative posterior masses depend on integrated density, not merely on peak heights. A narrow tall peak can carry less probability than a broad lower peak. Combining local approximations requires mass estimates and care about overlap, which is beyond the single-mode Laplace calculation developed here. The appropriate report may simply be that the proposed approximation does not resolve the target reliably.

A variational Normal family faces a related tradeoff. It can centre between the peaks and place substantial probability in the low-density gap, or concentrate near one peak and miss the other. Reverse KL can prefer concentration. Symmetric starts can reach equally good local solutions with opposite means. A stable objective trace then describes a stable optimisation outcome; it does not supply evidence that one explanation has negligible posterior mass.

One tempting repair is to reweight draws by the target density divided by the approximation density. Importance sampling can improve an approximation only when proposal support and tail behaviour allow useful weights. A proposal that almost never visits the other peak cannot recover it reliably from a modest draw count. Extreme weights or a handful of dominating draws are evidence of this difficulty. Report numerical uncertainty in any corrected estimate and investigate the proposal rather than interpreting a normalised weight vector as proof that all relevant regions were explored.

---

Source: `course/advanced/01_approximation.md:152–158`

## Lab: establish accuracy for the requested output

Lab 13, `labs/13_approximation.py`, uses seed 1313 for optional simulation. Begin with the exact correlated target above, compute Laplace curvature and optimal independent variances, and report both linear-combination variances and the sum tail. Then reproduce the gamma stress test. The experiment requires no general-purpose variational optimiser: an analytic optimum isolates family error from optimisation error.

Compare any simulated summaries with their exact values using Monte Carlo standard errors. For numerical quadrature, expand bounds and refine spacing separately. Agreement of two implementations of the same mistaken formula is weaker evidence than agreement with an independently evaluated integral. Record approximation discrepancies as findings, rather than making the intentionally inaccurate method fail an unrelated convergence threshold.

For a later realistic fit, use several starts, inspect objective traces, and compare a small tractable subproblem with quadrature or a carefully diagnosed sampler. Posterior predictive checks still assess the model's observable implications. A fast approximation that gives a plausible predictive mean can distort a rare-event decision. MCMC R-hat and effective sample size do not certify a deterministic Laplace fit or an optimised variational family.

---

Source: `course/advanced/01_approximation.md:160–164`

## Retrieval and interpretation

Without looking back, explain which expectation defines the KL direction, why the ELBO is a lower bound, and why the difference variance increased in the independent approximation. Then name a check that could expose a missed second mode. These are discussion prompts; assessed problems are separate.

The central reporting habit is to name the approximation, the coordinate system, the target summary, and the available accuracy evidence. Exactness for one Gaussian benchmark verifies a mechanism, not universal reliability. This bridge prepares you to read more advanced approximation methods while keeping their computational success distinct from posterior accuracy.

---

Source: `course/advanced/01_approximation.md:166–168`

## Exercises

The public question bank contains [adv.approximation.1](../exercises/questions.md#adv.approximation.1), [adv.approximation.2](../exercises/questions.md#adv.approximation.2), and [adv.approximation.3](../exercises/questions.md#adv.approximation.3): [advanced practice questions](../exercises/questions.md). Attempt those separately; their hints and reference answers are not part of this reading.

---

Source: `course/advanced/01_approximation.md:170–173`

## Further reading

- Blei, Kucukelbir, and McAuliffe, [Variational Inference: A Review for Statisticians](https://arxiv.org/html/1601.00670v9), for variational families, the ELBO, and optimisation.
- Vehtari, [BDA3 chapter notes](https://avehtari.github.io/BDA_course_Aalto/BDA3_notes.html), sections on normal approximation and transformations, for limitations of curvature summaries.

---

Source: `course/advanced/02_model_evidence.md:1–5`

# A02 · Model evidence, prior sensitivity, and averaged predictions

**Prerequisites:** [continuous conjugate models](../chapters/04_continuous.md), [predictive comparison](../chapters/10_model_checking.md), and [decisions](../chapters/12_decisions.md); integration and log arithmetic in [Appendix 2](../appendices/02_calculus.md) and [Appendix 4](../appendices/04_numerics.md).

**Objectives:** A02.O1 calculate analytic evidence and posterior model weights; A02.O2 assess prior sensitivity and averaged predictions; A02.O3 distinguish hypothesis comparison from predictive weighting.

---

Source: `course/advanced/02_model_evidence.md:7–13`

## What does it mean to compare models?

A laboratory measures an instrument's offset from a reference standard. One scientific hypothesis says the offset is exactly zero. Another says there is a persistent but uncertain offset. A separate operational question asks how well tomorrow's reading can be predicted. These questions are related, but they need not rank modelling choices in the same way.

The evidence, also called marginal likelihood, measures how much probability or density a model assigned to the observed dataset **before conditioning on it**. Cross-validation assesses predictions for held-out observations after learning from a training set. Both involve integration over parameters; they integrate with different distributions and answer different questions. This bridge derives evidence in a setting where the calculation is exact, then uses the same models to construct a predictive mixture.

The estimands will be posterior probability of an explicitly defined model, the mean of a future measurement, and its predictive variance. A model probability is conditional on the candidate set, the within-model priors, and the model prior probabilities. It is not an unconditional probability that the whole scientific account is true. All candidates may omit an important feature such as drift, outliers, or changing measurement precision.

---

Source: `course/advanced/02_model_evidence.md:15–31`

## Evidence averages over a prior

For candidate $M_k$ with parameters $\theta_k$, define

$$m_k(y)=p(y\mid M_k)=\int p(y\mid\theta_k,M_k)
p(\theta_k\mid M_k)\,d\theta_k.$$

With prior model probabilities $\pi_k$, Bayes' rule gives

$$w_k=p(M_k\mid y)=\frac{\pi_k m_k(y)}{\sum_j\pi_jm_j(y)},\qquad
\frac{w_1}{w_0}=\frac{\pi_1}{\pi_0}\frac{m_1(y)}{m_0(y)}.$$

The evidence ratio is the Bayes factor. It updates prior model odds, not prior parameter odds inside one model. In continuous models the evidence is a density with units determined by the observed data. Its numerical magnitude alone is not an absolute quality score. Ratios are meaningful when models describe the same recorded event using the same observation convention.

A likelihood evaluated at its maximum is not evidence. Maximisation picks the best parameter value after seeing the data; integration averages across values the prior allowed before seeing them. A flexible model can fit well yet allocate little prior predictive density near the observed dataset. This is sometimes called an automatic complexity penalty, but “complexity” here is inseparable from the actual prior and data scale. Parameter counting alone cannot reproduce the integral.

Compute log evidences and normalise model weights with log-sum-exp. Retain all model-dependent normalising constants. A dropped likelihood factor is harmless for a posterior kernel only when it is constant in the unknowns being compared; a factor that differs between models cannot be discarded from their evidence ratio.

---

Source: `course/advanced/02_model_evidence.md:33–57`

## An exact Normal comparison

Let $y_1,\ldots,y_n$ be conditionally independent readings in calibration units with known measurement variance $\sigma^2$. Compare

$$M_0:\ \mu=0,\quad y_i\sim N(0,\sigma^2),$$

$$M_1:\ \mu\sim N(0,\tau^2),\quad y_i\mid\mu\sim N(\mu,\sigma^2).$$

The exact-zero hypothesis has positive prior probability because it is a separate model. An ordinary continuous prior on the offset assigns probability zero to a single point, before and after observing continuous data. It cannot answer the same point-hypothesis question by counting posterior draws equal to zero.

Write $s^2=\sigma^2/n$ and $R=\sum_i(y_i-\bar y)^2$. Completing the sum of squares gives

$$\sum_i(y_i-\mu)^2=R+n(\bar y-\mu)^2.$$

Under either model, the part describing residual differences around the mean is the same. Under $M_1$, integrating the uncertain mean yields $\bar y\sim N(0,s^2+\tau^2)$; under $M_0$, $\bar y\sim N(0,s^2)$. Consequently

$$\log B_{10}=-\frac12\log\left(1+\frac{\tau^2}{s^2}\right)
+\frac{\bar y^2}{2}\left(\frac1{s^2}-\frac1{s^2+\tau^2}\right).$$

To calculate the full evidence rather than its ratio, retain the common residual factor:

$$m_1(y)=(2\pi\sigma^2)^{-n/2}e^{-R/(2\sigma^2)}
\sqrt{2\pi s^2}\;N(\bar y;0,s^2+\tau^2).$$

Here $N(z;a,b)$ denotes a Normal density evaluated at $z$, with mean $a$ and variance $b$. Multiplication by $\sqrt{2\pi s^2}$ restores the constant introduced when the mean-dependent exponential was expressed as a Normal density. This detail matters in an independent numerical integration check.

---

Source: `course/advanced/02_model_evidence.md:59–79`

## Worked analysis: three readings and three prior widths

Use the original illustrative readings $(1.1,1.5,1.9)$, measurement SD one, and equal prior probabilities for $M_0$ and $M_1$. Then $\bar y=1.5$, $s^2=1/3$, and $R=0.32$. Treat $\tau=0.5,2,10$ as three separate sensitivity analyses of the alternative's prior, not as three extra models silently receiving additional prior mass.

Within $M_1$, conjugate updating gives

$$v_1=\left(\frac1{\tau^2}+n\right)^{-1},\qquad
a_1=v_1\sum_i y_i,\qquad
\mu\mid y,M_1\sim N(a_1,v_1).$$

| Prior SD of offset | Log Bayes factor | Bayes factor | Posterior probability of $M_1$ | Offset mean within $M_1$ |
|---:|---:|---:|---:|---:|
| 0.5 | 1.166621 | 3.211123 | 0.762534 | 0.642857 |
| 2 | 1.832910 | 6.252053 | 0.862108 | 1.384615 |
| 10 | 0.510232 | 1.665678 | 0.624861 | 1.495017 |

For the middle row, posterior variance of the offset is $4/13=0.307692$. Its posterior mean is $18/13=1.384615$. The full log evidence under the zero-offset model is $-6.291816$, and under the alternative it is $-4.458906$. Their difference reproduces the table's log Bayes factor.

The broadest prior moves the alternative's posterior mean closer to the sample mean while reducing its posterior model weight. There is no contradiction. Conditional estimation of the offset asks where the alternative fits after updating. Evidence asks how successfully its whole prior predicted the observations. A prior that expected offsets spread across tens of calibration units allocated relatively little density to this modest observed deviation.

The prior scale should therefore come from plausible instrument behaviour, historical calibration, or an explicit sensitivity range. Choosing it solely to maximise the evidence using these same readings and then treating it as fixed conceals a data-dependent choice. A hyperprior on the scale is another coherent model, requiring its own prior predictive checks and integration; it is not equivalent to selecting the best row.

---

Source: `course/advanced/02_model_evidence.md:81–93`

## See the area that the peak cannot measure

![Identical likelihood curves accompany three prior-weighted integrands; their shaded areas change with prior width.](../../artifacts/figures/continuation_evidence.svg)

The dashed curve is the full likelihood for these same three readings, with all constants retained. Its maximum occurs at offset 1.5 and is about 0.054106. Multiplying it by each proper Normal prior produces the solid integrand. The shaded area under that product, over the entire real line, is the evidence. The displayed range captures its visible mass; the values below use the analytic whole-line integral, independently checked by quadrature.

| Prior SD | Likelihood maximum (same for all) | Integrated full-data evidence |
|---:|---:|---:|
| 0.5 | 0.054106 | 0.005945 |
| 2 | 0.054106 | 0.011575 |
| 10 | 0.054106 | 0.003084 |

The likelihood has units of inverse cubed reading units; the product also has inverse offset units, which integration removes. Heights of the two kinds of curve are not themselves dimensionally comparable. Their common axis is a numerical display in the stipulated calibration units, not a claim that a density equals a probability. Each evidence is a density for the same observed three-dimensional event, so their ratios are meaningful. The prior with SD two puts more useful weight around supported offsets than the narrow prior, while the broadest prior spreads much of its mass far away. Merely locating the maximum cannot detect either change. These are separate prior-sensitivity analyses of the same alternative, not three new alternatives receiving extra model probability.

---

Source: `course/advanced/02_model_evidence.md:95–119`

## Averaging future measurements

Assume tomorrow's reading has the same measurement variance and shares the persistent offset. Model averaging forms

$$p(y_*\mid y)=\sum_k w_k p(y_*\mid y,M_k).$$

Under the zero-offset model the future reading is $N(0,1)$. Under the alternative it is $N(a_1,1+v_1)$. The extra one is future measurement variation; the added $v_1$ is posterior uncertainty in the persistent offset. With $w=w_1$,

$$E[y_*\mid y]=w a_1,$$

$$\operatorname{Var}(y_*\mid y)=1+w v_1+w(1-w)a_1^2.$$

The final term is between-model uncertainty in the mean. It would disappear if we selected a model and treated that selection as certain. It would also be missed by averaging only within-model variances. A mixture generally is not Normal, even when each component is Normal; an interval or threshold probability should be computed from the mixture itself.

| Alternative prior SD | Averaged predictive mean | Averaged predictive variance |
|---:|---:|---:|
| 0.5 | 0.490200 | 1.183766 |
| 2 | 1.193688 | 1.493172 |
| 10 | 0.934177 | 1.731518 |

These are predictions for an individual future reading, not uncertainty solely about the expected reading. Subtract the future measurement variance one to obtain the variance of the mixture over the persistent offset. To simulate multiple future readings from a shared instrument, first draw one model and one offset for the whole future batch, then draw independent measurement errors. Choosing a fresh model independently for every reading describes a different process.

![Predictive mixture densities under three proper alternative prior widths](../../artifacts/figures/14_model_evidence.svg)

Compare the predictive shapes with the means and variances above. These are future-reading densities; the between-model term remains in the mixture. This plot does not replace a separate examination of prior-weighted evidence integrals.

---

Source: `course/advanced/02_model_evidence.md:121–127`

## How prior sensitivity can become decisive

For fixed data, as the alternative's prior width grows without bound, the logarithmic penalty in the Bayes factor keeps decreasing while its data-fit improvement approaches a finite limit. Eventually the Bayes factor favours the point null strongly. This limiting argument does not prove the offset is zero. It describes the consequences of allowing the alternative to disperse its prior predictions arbitrarily far from the observed scale.

An improper “flat” prior is worse for evidence: multiplying it by any positive constant leaves the conditional posterior unchanged but multiplies the evidence by that constant. A proper posterior does not rescue an undefined model comparison. Use proper, scientifically interpretable priors for this bridge's evidence calculation. Special constructions for improper-prior comparisons require additional choices and are outside its scope.

Measurement units provide another check. If offsets are converted from one calibration unit to a tenth of that unit, transform the measurement SD and the prior SD consistently. Both continuous-data evidences acquire the same change-of-variable factor, so the Bayes factor remains unchanged. Keeping a numerical prior SD fixed while changing units specifies a different prior and can change the comparison legitimately, but unintentionally.

---

Source: `course/advanced/02_model_evidence.md:129–139`

## Sequential evidence and the candidate set

Evidence also admits a predictive factorisation:

$$p(y_{1:n}\mid M)=\prod_{i=1}^n p(y_i\mid y_{1:i-1},M).$$

The first factor is a prior prediction, and later factors use earlier observations. This identity reconciles evidence as a prior average with its sequential learning interpretation. Under the exchangeable model above, the full product is unchanged by reordering the observations, although the individual factors change. Leave-one-out prediction uses almost the whole dataset to predict each omitted observation; it is not this same sequential product. Calling both quantities predictive does not make their training information identical.

The candidate list also affects posterior model probabilities. Suppose one alternative is duplicated under a new name. Giving every listed model an equal prior probability now increases the total prior probability assigned to that alternative's scientific story. Its combined posterior weight increases for a bookkeeping reason. If a broad hypothesis is split into several submodels, allocate its original prior mass across them deliberately. Model averaging is only as coherent as the model definitions and prior allocation supplied to it.

Finally, consider whether exact equality to zero is the scientific question. An instrument may be acceptable whenever its offset lies inside a tolerance interval. The posterior probability of that interval under a continuous model can address acceptability directly, without introducing a point-null model. If actions have different costs, integrate the relevant loss instead of applying a universal Bayes-factor threshold. Evidence comparison, practical equivalence, and decision analysis can all be useful, but each needs its own stated target.

---

Source: `course/advanced/02_model_evidence.md:141–152`

## Prediction uses a different comparison target

Leave-one-out prediction evaluates $p(y_i\mid y_{-i},M_k)$, where the posterior is fitted without the held-out reading. Summing its logarithm estimates predictive performance for the declared holdout task. It is neither the full-data evidence nor the training log likelihood. The distinction and computational diagnostics are developed in [Vehtari, Gelman, and Gabry](https://arxiv.org/abs/1507.04544).

Predictive stacking chooses weights on a simplex to optimise a held-out mixture score, for example

$$\max_{w_k\ge0,\ \sum_k w_k=1}
\sum_i\log\left[\sum_k w_k p(y_i\mid y_{-i},M_k)\right].$$

These weights describe a predictive combination. They are not posterior probabilities that models are true. They can exploit complementary predictions even when every candidate is an approximation to the data-generating process. They depend on the scoring rule, candidate predictions, and holdout design. [Yao and colleagues](https://arxiv.org/abs/1704.02030) develop this distinction and the stacking procedure.

If tomorrow means a new instrument rather than another reading from this instrument, the predictive distribution must also change. If it means a later time with possible drift, an exchangeable leave-one-out split can misrepresent deployment. An excellent score for the wrong holdout unit does not resolve the operational question. Likewise, a favourable Bayes factor within a narrow candidate set does not validate all the shared assumptions.

---

Source: `course/advanced/02_model_evidence.md:154–158`

## Lab and reporting practice

Lab 14, `labs/14_model_evidence.py`, uses the three readings and all three prior widths above; its default seed is 1414 if simulation is used. Evaluate the analytic full evidences and independently integrate the likelihood times the proper prior over the offset. Numerical integration should include an error estimate and a bounds or method check. Verify that posterior weights sum to one and reproduce the predictive moments using total variance or direct mixture integration.

Display evidence, model weights, conditional offset summaries, and predictive summaries in separate columns. Explain the known-noise assumption and equal prior model odds. Repeat with unequal model odds only as an explicitly labelled sensitivity analysis. Do not label a quadrature result with sampler diagnostics or interpret agreement of numerical methods as evidence that the scientific models are adequate.

---

Source: `course/advanced/02_model_evidence.md:160–164`

## Retrieval and interpretation

Explain why widening the alternative's prior can increase its conditional posterior mean while decreasing its model probability. Describe the three sources of variance in an averaged future reading. Finally, explain what additional specification is needed before a model weight can be interpreted as a scientific hypothesis probability.

This bridge supplies a small exact example of evidence calculation and model averaging. Its practical conclusion is to report the hypothesis set, proper priors, sensitivity, and prediction target alongside the numbers. The purpose of the comparison determines which number deserves attention.

---

Source: `course/advanced/02_model_evidence.md:166–168`

## Exercises

Attempt [adv.model_evidence.1](../exercises/questions.md#adv.model_evidence.1), [adv.model_evidence.2](../exercises/questions.md#adv.model_evidence.2), and [adv.model_evidence.3](../exercises/questions.md#adv.model_evidence.3) in the [public question bank](../exercises/questions.md). Their assessed datasets and answer keys are separate from this worked analysis.

---

Source: `course/advanced/02_model_evidence.md:170–174`

## Further reading

- Gelman and colleagues, [Bayesian Data Analysis, third edition](https://sites.stat.columbia.edu/gelman/book/), for posterior model probabilities and model criticism.
- Yao and colleagues, [Using stacking to average Bayesian predictive distributions](https://arxiv.org/abs/1704.02030), for predictive weighting and its interpretation.
- Vehtari, Gelman, and Gabry, [Practical Bayesian model evaluation using leave-one-out cross-validation and WAIC](https://arxiv.org/abs/1507.04544), for predictive scoring and approximation checks.

---

Source: `course/advanced/03_observation_process.md:1–5`

# A03 · Model what was observed, and why it was observed

**Prerequisites:** [continuous models](../chapters/04_continuous.md), [generalised regression](../chapters/08_glm.md), and [robustness and missingness](../chapters/11_robustness.md); conditioning and integration in [Appendix 1](../appendices/01_probability.md) and [Appendix 2](../appendices/02_calculus.md).

**Objectives:** A03.O1 construct integrated observation-process likelihoods; A03.O2 propagate measurement and missing-data uncertainty; A03.O3 identify unsupported selection assumptions and sensitivity parameters.

---

Source: `course/advanced/03_observation_process.md:7–13`

## A blank cell and a noisy reading are different evidence

A sensor survey reports four measurements and several absent records. Some instruments were unavailable; others may have failed when the physical quantity became unusually large. The surviving readings also contain measurement error. Replacing blanks with a sample mean and treating the recorded readings as exact would make a clean rectangular table, but it would not explain how the table arose.

Begin by distinguishing the quantity of scientific interest from its recorded representation. Let $X_i$ be a latent physical value, $Z_i$ a noisy reading, and $R_i$ an indicator that the reading is observed. The estimand might be the population mean of the physical value, the latent value of one particular item, or the average among respondents. Those are different targets even when they share a model.

This bridge develops one small measurement model and one missingness sensitivity analysis. The examples intentionally make some variances known so that uncertainty propagation is visible through exact calculations. Their transparency should not be mistaken for a claim that measurement precision or response mechanisms are usually known. Calibration data, repeat readings, administrative records, and design information can be essential components of an analysis.

---

Source: `course/advanced/03_observation_process.md:15–30`

## Write the observation process into the joint distribution

A possible factorisation, with parameters collected into $\theta$ and $\psi$, is

$$p(x,z,R\mid\theta,\psi)
=p(x\mid\theta)p(z\mid x,\theta)p(R\mid x,z,\psi).$$

The likelihood for recorded data sums or integrates over values that were not observed:

$$p(z_{\mathrm{obs}},R\mid\theta,\psi)
=\int p(x,z_{\mathrm{obs}},z_{\mathrm{mis}},R\mid\theta,\psi)
\,dx\,dz_{\mathrm{mis}}.$$

The factorisation is a proposed scientific story. It permits response to depend on latent values and noisy measurements, but a particular application may need a different dependence structure. For example, a device can fail because its unrecorded internal signal exceeded a threshold. Recording only successful measurements then changes both the distribution of observed values and the probability of observing them.

Integration expresses uncertainty about unobserved quantities. Sampling missing values inside a Bayesian program is a computational alternative to doing the integral analytically. Neither operation creates observations. If a missing outcome has a normalised conditional density that integrates to one and its missingness is ignorable, that row alone contributes no outcome information about the mean. Its eventual imputed value must not be counted as an independent extra measurement in a second fit.

---

Source: `course/advanced/03_observation_process.md:32–43`

## When can the missingness mechanism be ignored?

For a simpler outcome vector $y$, write $p(y,R\mid\theta,\psi)=p(y\mid\theta)p(R\mid y,\psi)$. Missing completely at random means response does not depend on the outcomes, conditional on any design information explicitly being held fixed. Missing at random means that, for the realised missingness pattern, response may depend on observed components but not additionally on missing components:

$$p(R\mid y_{\mathrm{obs}},y_{\mathrm{mis}},\psi)
=p(R\mid y_{\mathrm{obs}},\psi).$$

If the outcome and response parameters have distinct parameter spaces and independent priors, this permits the response factor to separate from inference about the outcome parameters. These conditions justify a specific ignorability calculation. The phrase “missing at random” does not mean that the observed sample is representative without adjustment or that complete-case regression is always valid. Conditioning on informative observed predictors may still be necessary.

If response depends on unobserved outcomes after accounting for observed information, the mechanism is missing not at random. A parametric selection model can be fitted, but fitting it does not establish that its extrapolation to unseen values is identified by the observed data. Different outcome distributions and selection functions can produce the same recorded distribution. A prior can select among those possibilities while the likelihood supplies little discrimination.

Observed patterns can contradict particular modelling restrictions. They generally cannot establish arbitrary missing-at-random assumptions because the relevant dependence involves unseen values. Design knowledge or follow-up sampling is often more informative than a new optimisation routine. The [Stan missing-data guide](https://mc-stan.org/docs/stan-users-guide/missing-data.html) illustrates integration through latent quantities and explains why missing predictors need their own distribution.

---

Source: `course/advanced/03_observation_process.md:45–82`

## Worked analysis: calibrated measurement uncertainty

Suppose respondent items have latent values and readings, in the same physical units,

$$X_i\mid\mu\sim N(\mu,4),\qquad
Z_i\mid X_i\sim N(X_i,9),\qquad
\mu\sim N(10,16).$$

Variances are the second arguments. Latent variation has SD two; independent, unbiased measurement error has SD three; the prior SD for the respondent population mean is four. Assume independence across items conditional on the mean, and suppose external calibration has established the two variance components. The four recorded values are $(8,10,11,13)$.

Writing $Z_i=X_i+E_i$ with independent $E_i\sim N(0,9)$ gives the convolution

$$Z_i\mid\mu\sim N(\mu,13).$$

This follows either by integrating the product of the two Normal densities or by adding independent Normal variables. The larger variance is measurement variation plus true item variation. It does not mean the physical items themselves became more variable.

The sum of readings is 42. Conjugate updating gives

$$V_\mu=\left(\frac1{16}+\frac4{13}\right)^{-1}=2.701299,$$

$$M_\mu=V_\mu\left(\frac{10}{16}+\frac{42}{13}\right)=10.415584.$$

The posterior SD of the mean is about 1.644 physical units. A naive analysis using variance four for the readings gives posterior mean 10.470588 and variance 0.941176. The means look similar because the sample mean is near the prior centre. The naive posterior variance is only about a third of the measurement-aware value. Comparing point estimates alone would miss the error.

Now estimate the latent value of the item whose reading was 13. Conditional on the population mean,

$$X_4\mid\mu,Z_4=13\sim
N\left(\frac9{13}\mu+\frac4{13}13,\frac{36}{13}\right).$$

Because the measurement is imprecise, the latent value is pulled towards the population mean. Integrating the posterior uncertainty in that mean gives

$$E[X_4\mid z]=11.210789,$$

$$\operatorname{Var}(X_4\mid z)
=\frac{36}{13}+\left(\frac9{13}\right)^2V_\mu
=4.063936.$$

The second term would disappear if the fitted population mean were treated as known. This calculation concerns an existing item's latent value. A new latent item has variance $4+V_\mu$; a new recorded reading has variance $13+V_\mu$. A reporting table should name which of these distributions supplies each interval.

---

Source: `course/advanced/03_observation_process.md:84–90`

## What if the calibration is unknown?

With only one reading per item and the model above, the marginal likelihood primarily identifies the sum of latent and measurement variances. Many pairs of variance components give exactly the same marginal reading distribution. Treating both as unknown with broad priors can therefore yield a long posterior ridge. A more powerful sampler explores the ridge; it does not remove the ambiguity.

Independent replicate measurements within items help because differences of two readings cancel the latent value. Their variance is twice the measurement variance under independent, equal-variance errors. A validation sample with a high-precision reference can identify bias and precision more directly. Correlated repeat errors or shared instrument drift weaken this simple argument and must be modelled if plausible.

Error in predictors needs equal care. If an outcome depends on a true exposure but only a noisy exposure is recorded, condition the outcome model on the latent exposure and supply a model for that exposure. Under a simple linear model with independent classical additive error, a naive population regression slope is attenuated by the ratio of true exposure variance to total recorded exposure variance. That familiar direction is not universal: differential errors, nonlinear links, and selection can behave differently. The [Stan measurement-error guide](https://mc-stan.org/docs/stan-users-guide/measurement-error.html) provides latent-variable constructions and rounding examples.

---

Source: `course/advanced/03_observation_process.md:92–119`

## Worked sensitivity analysis: who did not respond?

Now interpret the four calibration readings as a sample from respondents. Suppose a large administrative register establishes that respondents constitute a fixed fraction $\rho=0.4$ of the target population. We condition on that known fraction in this teaching example. It is not estimated from the four measurements.

Let the mean latent value among nonrespondents exceed the respondent mean by $\delta$ physical units. Specify a pattern-mixture model

$$X\mid R=1,\mu\sim N(\mu,4),\qquad
X\mid R=0,\mu,\delta\sim N(\mu+\delta,4).$$

The target is the **population mean**, not the realised mean of a finite set of already measured items. It is

$$\mu_{\mathrm{pop}}=\rho\mu+(1-\rho)(\mu+\delta)
=\mu+0.6\delta.$$

The respondent likelihood contains no $\delta$. Under an independent prior on that shift, its posterior equals its prior. Choosing several fixed shifts is therefore sensitivity analysis over unsupported extrapolations, not estimation of the shift from these data.

| Assumed nonrespondent shift | Posterior mean of population mean | Posterior variance conditional on shift |
|---:|---:|---:|
| -2 | 9.215584 | 2.701299 |
| 0 | 10.415584 | 2.701299 |
| 2 | 11.615584 | 2.701299 |

All rows fit the respondent readings equally well. The equality of their conditional variances does not imply that uncertainty about nonresponse is negligible; it reflects holding the shift fixed in each row. If instead $\delta$ has an independent prior variance $s_\delta^2$, population-mean variance gains $0.36s_\delta^2$. If the response fraction is uncertain, integrate its joint uncertainty too. A random prior over shifts is justified only when it represents actual beliefs or external evidence, not merely because it produces a single convenient interval.

The zero-shift row is a substantive equal-means assumption. More respondent measurements can estimate their mean precisely while leaving the shift unidentified. Targeted follow-up of nonrespondents, even a small sample with a documented collection process, can address the uncertainty that an enormous respondent sample cannot.


<!-- VISUAL01:15 BEGIN -->

---

Source: `course/advanced/03_observation_process.md:121–139`

### Visual investigation: unseen outcomes remain assumptions

Separate the information in respondents from an assumption about unobserved cases. In this new fixed-mean illustration, the response fraction is 0.6, respondents average twelve minutes, and nonrespondents have stipulated mean $12+\delta$. Predict which observed quantity changes when only delta changes.

![Respondent mean stays twelve while stipulated nonrespondent means vary; population means ten, twelve and fourteen follow from a sixty percent response fraction.](../../artifacts/figures/visual01_15_unseen.svg)

**Read the figure.** The horizontal axis is a sensitivity assumption in minutes, not an estimated regression coefficient. The vertical axis is a mean outcome in minutes. The dashed respondent line is unchanged. The dotted unseen mean changes one-for-one with delta; the solid population mean changes more slowly because unseen cases carry weight 0.4.

| Delta (minutes) | Respondent mean | Assumed nonrespondent mean | Population mean |
|---:|---:|---:|---:|
| −5 | 12 | 7 | 10 |
| 0 | 12 | 12 | 12 |
| 5 | 12 | 17 | 14 |

**Mathematical connection.** Total expectation gives $E[Y]=0.6(12)+0.4(12+\delta)=12+0.4\delta$. No respondent value is altered by selecting a scenario. These are stipulated component means; the lines have no posterior bands and the scenario range is not a credible interval. A distribution over delta would require additional assumptions or information.

**Original unscored exploration — predict, observe, explain.** Change only the response fraction to 0.8. Predict the sensitivity slope, then observe $E[Y]=12+0.2\delta$. Explain why more observed coverage reduces this mixture's sensitivity without identifying the unseen mean. Transfer to a calibrated noisy measurement: distinguish uncertainty about a recorded value from absence of a value. This small illustration is separate from the frozen measurement-error fit and its uncertainty calculations later in the reading.

<!-- VISUAL01:15 END -->

---

Source: `course/advanced/03_observation_process.md:141–154`

## Censoring, rounding, truncation, and selection

A censored record says that a value lies in a known region. For a Normal quantity, a record “at least $c$” contributes $1-\Phi((c-\mu)/\sigma)$, not a density at the threshold. A reading rounded to the nearest unit and recorded as $r$ contributes

$$\Phi\left(\frac{r+0.5-\mu}{\sigma}\right)
-\Phi\left(\frac{r-0.5-\mu}{\sigma}\right).$$

Those interval widths are part of the observation convention. Treating a rounded value as exact can be an adequate approximation when rounding is tiny relative to variation, but the approximation should be recognised.

Truncation means items outside an inclusion region do not appear in the recorded sample. Conditional on inclusion $Y>c$, an observed value contributes

$$p(y\mid Y>c,\theta)=\frac{p(y\mid\theta)}{P(Y>c\mid\theta)},\qquad y>c.$$

The denominator depends on parameters and cannot be dropped. If the number screened and number excluded are also known, their count likelihood can carry additional information. The conditional truncated likelihood alone intentionally omits that information. General selection replaces the hard threshold with an inclusion probability, again requiring normalisation and assumptions about unseen items.

---

Source: `course/advanced/03_observation_process.md:156–162`

## Missing predictors and the analysis target

Suppose an outcome is observed but its explanatory exposure is missing. Integrating an outcome likelihood over an unspecified exposure is not a complete model: the exposure needs a distribution, possibly conditional on other recorded covariates. The observed outcome can then inform the missing exposure through their joint model. This feedback is legitimate inference when the outcome is part of the available data, but it can be weak or highly dependent on the exposure prior.

Prediction validation adds an information constraint. If the eventual task predicts an unavailable outcome from available predictors, an imputation procedure cannot use that held-out outcome to reconstruct its missing predictor. Fit imputation distributions on the training information and integrate the missing predictor using only information available at prediction time. Otherwise an apparently successful missing-data method leaks the answer through preprocessing. Conversely, imputing missing predictors in an explanatory analysis where outcomes are observed answers a different conditioning question and may appropriately use them.

The practical check is to list, for each target, which quantities are observed, latent, or unavailable in deployment. A single completed spreadsheet often hides those distinctions; an explicit joint model makes them reviewable.

---

Source: `course/advanced/03_observation_process.md:164–170`

## Lab and interpretation

Lab 15, `labs/15_observation_process.py`, uses seed 1515 for any simulation. Reproduce the four-reading measurement example, compare naive and integrated population uncertainty, and calculate the latent fourth item's moments. Verify the convolution by a separate one-dimensional integral or independent simulation. Then evaluate all three fixed missingness shifts with the same respondent posterior and known response fraction.

The experiment should label the respondent mean, latent item value, population mean, and future reading distinctly. The missingness scenarios are intentionally indistinguishable by their respondent likelihood. Do not report an optimiser's preferred shift or a posterior concentration manufactured by a narrow prior as evidence that the data identify selection.

For retrieval, explain why a missing outcome can integrate out while a missing predictor still requires a distribution, why a latent item's uncertainty contains two terms, and how knowing the count of excluded items changes a truncation analysis. The reusable habit is to write down the recorded event before choosing its likelihood.

---

Source: `course/advanced/03_observation_process.md:172–196`

## Fitted workflow: standards, noisy predictors, and deployment

The exact calculations above isolate measurement uncertainty by fixing its variance.
Now fit an original synthetic bench-process experiment in which calibration offset,
instrument noise, slope, intercept and response noise are all uncertain. Quantities
are dimensionless deviations on a scale fixed before generation. The target is a
future response for one new item, using only that item's available reading and the
training experiment. No medical or personal data are involved.

Lab15 freezes 48 item IDs, 0–47, before generating values. IDs with remainder three
on division by four are held out. A reading is scheduled when the ID's remainder
on division by five is neither one nor four. Thus 36 training responses have 21
available and 15 missing readings; 12 held-out responses have eight available and
four missing readings. This scheduled recording design is independent of generated
values. It is not a fitted selection mechanism. The five exact standards
$(-2,-1,0,1,2)$ each have three independent instrument readings.

The lab publishes the actual training values, calibration readings and query
readings in its result. Seed 1515 uses separate `SeedSequence([seed,k])` streams:
1 for the $(5,3)$ calibration errors, 2 for 48 latent predictors, 3 for all 48
instrument errors **before masking**, and 4 for 48 response errors. Generation
uses $(a,\alpha,\beta,\tau,\sigma)=(.35,.7,1.3,.55,.65)$. These are provenance,
not fitted inputs. Hidden predictor truths and held-out outcomes are stored in a
separate evaluation payload; no fitting or prediction interface receives them.
There is no sample standardisation or outcome-based choice of masks or priors.

---

Source: `course/advanced/03_observation_process.md:198–258`

### The complete generative and observed-data models

With Normal second arguments denoting variances, specify

$$W^{cal}_{jk}\mid a,\tau\sim N(c_j+a,\tau^2),\qquad
X_i\sim N(\mu_x,s_x^2),$$
$$W_i\mid X_i,a,\tau\sim N(a+X_i,\tau^2),\qquad
Y_i\mid X_i,\alpha,\beta,\sigma\sim N(\alpha+\beta X_i,\sigma^2).$$

The baseline stipulates $\mu_x=0,s_x=1$ as exact process-distribution parameters.
They are not estimated from hidden synthetic values or held-out items. Instrument
gain is exactly one, standards are exact, instrument offset and precision are
shared between calibration and regression, and there is no drift. Errors and
latent predictors are independent across items conditional on parameters.

Use independent priors

$$a\sim N(0,.5^2),\quad \alpha\sim N(0,2^2),\quad \beta\sim N(0,1.5^2),$$
$$\log\tau\sim N(\log .45,.4^2),\qquad
\log\sigma\sim N(\log .60,.4^2).$$

These are teaching choices on this stipulated scale, not universal defaults.
In 20,000 prior replications, the 5%, median and 95% quantiles are:

| Prior implication | 5% | Median | 95% |
|---|---:|---:|---:|
| Instrument SD | 0.233 | 0.450 | 0.857 |
| Response-noise SD | 0.308 | 0.599 | 1.151 |
| Largest absolute residual among 15 standard readings | 0.568 | 1.194 | 2.270 |
| Range of 36 responses | 2.007 | 5.253 | 13.089 |
| SD of 36 responses | 0.487 | 1.237 | 3.046 |

The upper response ranges are substantial on a unit predictor scale. Prior
simulation makes that assumption visible; agreement with the eventual experiment
alone would not establish prior plausibility for a different process.

Integrating $X_i$ gives the **joint** likelihood for an available reading:

$$\begin{pmatrix}W_i\\Y_i\end{pmatrix}\sim N_2\left[
\begin{pmatrix}a+\mu_x\\\alpha+\beta\mu_x\end{pmatrix},
\begin{pmatrix}s_x^2+\tau^2&\beta s_x^2\\
\beta s_x^2&\beta^2s_x^2+\sigma^2\end{pmatrix}\right].$$

A missing-reading row contributes

$$Y_i\sim N(\alpha+\beta\mu_x,\beta^2s_x^2+\sigma^2).$$

Multiply all 15 calibration densities, all 21 paired training densities, and all
15 outcome-only training densities. The missing reading integrates out exactly;
it is not a measurement with an arbitrary huge variance. Fitting only $Y\mid W$
would omit the parameter-dependent marginal reading density. No held-out outcome
**or held-out reading** enters the training likelihood. The fixed design has no
parameter-dependent recording-probability factor.

Standard residuals identify the offset and instrument variance under these
restrictions; replicate contrasts isolate instrument noise. Paired covariance
informs slope, and remaining response dispersion informs $\sigma$. The stipulated
predictor mean and variance anchor the population and scale. These facts do not
identify a model with arbitrary unknown gain, uncertain standards, drift,
correlated errors and an unknown predictor distribution. Replicates with common
drift would not have the contrast variance assumed here.

---

Source: `course/advanced/03_observation_process.md:260–305`

### Fitting by integration, with measured numerical error

Let $q=(\beta,\log\tau,\log\sigma)$ and $t=(a,\alpha)^T$, with
$P=\operatorname{diag}(.25,4)$. Stack calibration residuals, paired
$(W-\mu_x,Y-\beta\mu_x)$ values and unpaired $Y-\beta\mu_x$ values into $z$.
The block covariance $D$ uses the densities above; $H$ selects the relevant
intercept. Conditional on $q$, Gaussian elimination gives

$$Q=P^{-1}+H^TD^{-1}H,\quad C=Q^{-1},\quad h=H^TD^{-1}z,\quad m=Ch,$$
$$\log p(z\mid q)=-\tfrac12\{n\log(2\pi)+\log|D|+\log|P|+\log|Q|
+z^TD^{-1}z-h^TCh\}.$$

The conditional intercept posterior is $N_2(m,C)$; its covariance must be retained.
Lab15 uses grouped sufficient statistics to evaluate this collapse, then tensor
Gauss–Legendre integration over $q$. Log mass equals integrated log likelihood
plus log prior **plus log quadrature volume**. The log-SD priors are already
densities in the integration coordinates; another Jacobian would change the prior.
Nodes are not equally weighted posterior draws.

The executed refinement compares orders $(97,73,73)$ and $(129,97,97)$ on
$\beta\in[-6,6]$ and six prior SDs either side of each log-SD mean. An expansion
to $[-9,9]$ and eight prior SDs uses $(193,129,129)$. The largest change among
checked means, SDs, predictive moments and log normalizer was $5.20\times10^{-6}$;
the largest interval-endpoint change was 0.00060. Expanded-domain changes were
below $3.23\times10^{-9}$ for those moments/log normalizer and 0.000018 for
interval endpoints. Estimated expanded posterior mass outside the original box
was $3.50\times10^{-11}$; original outer-5%-shell mass was $9.26\times10^{-10}$.

The lab fails if these checked changes exceed 0.001 for moments/log normalizer,
0.01 for endpoints or 0.002 for probabilities. Each refitted sensitivity also
passes the same checks. These are empirical numerical diagnostics, not universal
error bounds. Marginal parameter intervals integrate an interpolated density and
are checked under refinement; they do not use coarse node quantiles. Mixture-CDF
calculations omit less than $10^{-13}$ mass, bounding their probability error;
all moments and log scores use full mass. R-hat and effective sample size do not
apply to deterministic quadrature. Independent sequential Gaussian updating with
Simpson integration, dense conditioning and conjugate limits provide separate
checks in the author reference and tests.

| Parameter | Posterior mean | Posterior SD | Central 90% interval |
|---|---:|---:|---|
| Offset $a$ | 0.2583 | 0.0991 | [0.0998, 0.4247] |
| Response intercept $\alpha$ | 0.7464 | 0.2151 | [0.3944, 1.1007] |
| Slope $\beta$ | 1.2218 | 0.2199 | [0.8645, 1.5828] |
| Instrument SD $\tau$ | 0.4368 | 0.0901 | [0.3116, 0.6041] |
| Response-noise SD $\sigma$ | 0.8943 | 0.2028 | [0.5615, 1.2313] |

---

Source: `course/advanced/03_observation_process.md:307–357`

### Reconstruction and deployment condition on different information

For an already observed training item, its outcome can legitimately inform its
predictor. Conditional on parameters, with reading availability $R_i$,

$$v_i=(s_x^{-2}+R_i\tau^{-2}+\beta^2\sigma^{-2})^{-1},$$
$$m_i=v_i\{\mu_x/s_x^2+R_i(W_i-a)/\tau^2+\beta(Y_i-\alpha)/\sigma^2\}.$$

Lab15 omits unavailable terms by indexing and integrates both these moments over
the fitted joint parameter posterior. It preserves covariance between the two
intercepts. This reconstructs existing training items, not new population draws.

Deployment instead targets $p(Y_*\mid W_{*,obs},R_*,D_{train})$, with no future
outcome argument. At a node $q$, after intercept integration, write

$$M_w=m_a+\mu_x,\quad V_w=s_x^2+\tau^2+C_{aa},$$
$$M_y=m_\alpha+\beta\mu_x,\quad
V_y=\beta^2s_x^2+\sigma^2+C_{\alpha\alpha},\quad
K=\beta s_x^2+C_{a\alpha}.$$

For a supplied reading $w$, reweight each node by $N(w;M_w,V_w)$, then use

$$Y_*\mid w,q,D_{train}\sim
N\left(M_y+K(w-M_w)/V_w,\ V_y-K^2/V_w\right).$$

An available reading informs both the local predictor and parameter uncertainty.
This query-specific conditioning does not alter the saved training posterior.
Each held-out row is predicted separately; other held-out readings are not pooled.
For an absent reading, retain the training weights and use $N(M_y,V_y)$.
Predictor moments at a node with a reading are
$\mu_x+s_x^2(w-M_w)/V_w$ and $s_x^2-s_x^4/V_w$.

Report parameter uncertainty, predictor uncertainty, latent response
$\alpha+\beta X_*$ and future observed response separately. Mixture variance
adds within-node and between-node terms. Here within-node terms already include
integrated intercept uncertainty as well as latent variation; they are not a
pure measurement-noise component. Future response variance exceeds latent
response variance by the conditional posterior expectation of $\sigma^2$.
A missing-reading baseline query has predictor variance 1, latent-response mean
0.7464 and variance 1.5875, and observed-response variance 2.4284. Its central 90%
predictive interval is [−1.8155, 3.3025], calculated from the mixture CDF rather
than a Normal approximation to its moments.

Only after predictions are frozen does a separate scorer receive held-out
outcomes. Mean log predictive density per response unit was −1.2247 for eight
available-reading cases and −2.6360 for four missing-reading cases. Their 90%
interval coverages were respectively 8/8 and 2/4. These small, different subsets
do not establish predictive calibration, causal effects of recording, or model
superiority. Density scores also depend on the response's units. Mutating or
permuting held-out outcomes can change scores but cannot change fitting or
prediction; tests enforce this boundary.

---

Source: `course/advanced/03_observation_process.md:359–381`

### Criticise the instrument and response model

For 12,000 posterior replications, draw one joint parameter vector per experiment,
then new independent latent items and errors under the frozen training masks.
This tests population observations, not reconstructions of existing latent items.

| Discrepancy | Observed | Replicated 5%–95% | Replicated probability at least observed |
|---|---:|---|---:|
| Mean within-standard replicate variance | 0.139 | [0.058, 0.434] | 0.616 |
| Largest absolute standard-mean residual | 0.444 | [0.266, 0.934] | 0.693 |
| Absolute residual trend over standards | 0.056 | [0.005, 0.160] | 0.469 |
| Available-reading SD | 1.236 | [0.804, 1.373] | 0.185 |
| Reading/response covariance | 1.377 | [0.488, 2.160] | 0.342 |
| Response SD, available readings | 1.481 | [1.078, 2.025] | 0.518 |
| Response SD, missing readings | 1.759 | [1.007, 2.078] | 0.216 |
| Largest absolute response | 5.397 | [2.878, 5.553] | 0.066 |

Monte Carlo standard errors range from 0.0023 to 0.0046; the saved report also
contains Wilson intervals. The extreme response deserves attention even though
these particular checks reveal no severe calibration discrepancy. Posterior
predictive probabilities reuse training data and are not uniformly distributed
significance tests. Passing this list does not certify the assumptions or explain
away possible drift; zero simulated exceedances would not prove probability zero.

---

Source: `course/advanced/03_observation_process.md:383–415`

### Predeclared sensitivity, including the missing-predictor population

Each alternative refits the full observed likelihood. No held-out score selected
these scenarios. Compare prediction for an available reading of 1 and for no reading:

| Alternative | Mean slope | Mean instrument SD | 90% response interval, reading 1 | 90% response interval, missing |
|---|---:|---:|---|---|
| One calibration replicate per standard | 1.247 | 0.457 | [−0.282, 3.218] | [−1.728, 3.405] |
| Offset prior SD 1; log-instrument-SD prior SD .65 | 1.223 | 0.438 | [−0.257, 3.257] | [−1.810, 3.309] |
| Slope prior SD 3; log-response-SD prior SD .65 | 1.209 | 0.432 | [−0.335, 3.344] | [−1.859, 3.358] |
| Stipulated predictor SD .8 | 1.464 | 0.506 | [−0.304, 3.366] | [−1.679, 3.247] |
| Stipulated predictor SD 1.2 | 1.112 | 0.413 | [−0.235, 3.162] | [−1.989, 3.410] |

The result additionally reports all parameter intervals, predictive variances and
$P(Y_*>2)$ for every scenario. The slope changes materially with the stipulated
predictor SD: that anchor is substantive, even when available-reading prediction
looks fairly stable. Removing replicates changes the realised calibration sample
as well as its size; this one comparison is not a general precision theorem.

A separate **deployment-population** sensitivity leaves the training fit intact
and changes only the future missing-reading predictor mean:

| Future missing-reading predictor mean | Predictive response mean | Central 90% interval | $P(Y_*>2)$ |
|---|---:|---|---:|
| −.5 | 0.1355 | [−2.4497, 2.6886] | 0.1143 |
| 0 | 0.7464 | [−1.8155, 3.3025] | 0.2079 |
| .5 | 1.3573 | [−1.1938, 3.9291] | 0.3368 |

These future shifts are assumptions, not estimated future outcomes. Do not
transfer the earlier respondent-only likelihood invariance to missing **training
predictors**: their observed responses can constrain distributional shifts under
the imposed regression model. A training pattern-mixture extension would require
its own observed likelihood and identification discussion.

---

Source: `course/advanced/03_observation_process.md:417–437`

### New unscored practice: a different recording schedule

Consider exact standards $(-1.5,0,1.5)$ with two independent readings each. In a
new deployment batch, one item has instrument reading −0.4 and another has no
reading; neither response is available. Keep unit gain but allow uncertain offset
and instrument noise. Write the two prediction conditioning sets, identify the
node-weight change needed for the first item, and explain which additional
variance enters an observed response rather than a latent regression response.
Then stipulate predictor SD 1.3 and a future missing-reading mean shift of .25.
State which change requires refitting the training model and which only changes
the deployment distribution. Design an outcome-mutation check for leakage. This
is original optional practice, with no new assessment ID or worked answer.

The model construction follows the explicit measurement-error and missing-data
principles in the Stan guides linked above. [Bartlett and Keogh](https://arxiv.org/abs/1603.06284)
discuss Bayesian propagation of covariate-measurement uncertainty;
[Skarstein, Martino and Muff](https://arxiv.org/abs/2303.15240) connect missingness
and measurement error in joint models. [Le Morvan et al.](https://proceedings.mlr.press/v108/morvan20a.html)
study prediction with available features and missingness patterns. Our exact
Gaussian collapse, synthetic design and priors are original teaching choices,
not reproductions of those applications or evidence of local learning efficacy.

---

Source: `course/advanced/03_observation_process.md:439–441`

## Exercises

The [public question bank](../exercises/questions.md) contains [adv.observation_process.1](../exercises/questions.md#adv.observation_process.1), [adv.observation_process.2](../exercises/questions.md#adv.observation_process.2), and [adv.observation_process.3](../exercises/questions.md#adv.observation_process.3). Their assessed examples and protected feedback are maintained separately.

---

Source: `course/advanced/03_observation_process.md:443–447`

## Further reading

- Rubin, [Inference and missing data](https://doi.org/10.1093/biomet/63.3.581), the original treatment of missingness and ignorability conditions.
- Stan Development Team, [Missing data](https://mc-stan.org/docs/stan-users-guide/missing-data.html) and [Measurement error](https://mc-stan.org/docs/stan-users-guide/measurement-error.html), for explicit latent-variable models.
- Hernán and Robins, [Causal Inference: What If](https://miguelhernan.org/whatifbook), for selection, exchangeability, and the role of design information.

---

Source: `course/advanced/04_causal.md:1–5`

# A04 · Identify a causal target before fitting its posterior

**Prerequisites:** [generalised regression](../chapters/08_glm.md), [model checking](../chapters/10_model_checking.md), and [decision analysis](../chapters/12_decisions.md); conditional independence and total expectation in [Appendix 1](../appendices/01_probability.md).

**Objectives:** A04.O1 define causal estimands and identification assumptions; A04.O2 compute standardised identified contrasts; A04.O3 diagnose confounding, overlap, and unjustified adjustment.

---

Source: `course/advanced/04_causal.md:7–13`

## Would changing the action change the outcome?

A service offers optional training to staff handling difficult requests. Trained staff have a higher completion rate. Should everyone be offered training? The observed difference mixes any effect of training with differences between people who did and did not take it. Even a perfectly fitted Bayesian regression describes an observational distribution unless a causal argument connects that distribution to the proposed intervention.

There are three separate tasks. Define the intervention and population whose outcomes matter. Establish identification: express the causal target using quantities in an observable distribution under stated assumptions. Then estimate those quantities, perhaps with Bayesian models. Computation belongs to the third task. Its precision cannot substitute for the first two.

This bridge uses a binary intervention, a binary outcome, and a single pre-intervention covariate. It develops standardisation in a deliberately small synthetic setting where the causal mechanism is declared. More complicated longitudinal interventions, mediation, instruments, and interference need additional theory. The aim is to make the boundary between identification and posterior fitting visible, not to turn every regression into an intervention analysis.

---

Source: `course/advanced/04_causal.md:15–26`

## Define the intervention, outcome, population, and time

Let $A=1$ mean completing a specified training session before a service period, and $A=0$ mean no session. Let $Y=1$ indicate completion of a request within a stated deadline during that period. The potential outcome $Y(a)$ is the outcome that would occur under intervention $a$. Only one is observed for each unit.

For a target population with distribution $P_T$, the average treatment effect on the risk-difference scale is

$$\psi_T=E_T[Y(1)-Y(0)]
=E_T[Y(1)]-E_T[Y(0)].$$

This estimand is measured in probability units, or percentage points after multiplication by one hundred. It differs from an odds ratio, from the effect among those who were actually trained, and from the effect on a particular person. An average effect does not identify the joint distribution of the two potential outcomes or the fraction of people who personally benefit.

The intervention needs enough detail for potential outcomes to be meaningful. Different training durations or delivery formats may have different consequences. “Set training status to one” is ambiguous if observed status combines incompatible versions. Specify eligibility, assignment time, follow-up, and outcome measurement. For offers with incomplete uptake, the effect of offering training differs from the effect of completing it. A decision about offers should not silently inherit an estimate for completion.

---

Source: `course/advanced/04_causal.md:28–36`

## Assumptions that connect potential and observed outcomes

Let $Z$ denote pre-intervention request complexity. Identification by adjustment uses the following substantive conditions.

**Consistency:** the observed outcome equals the potential outcome under the intervention actually received, $Y=Y(A)$, with relevant intervention versions accounted for. **Conditional exchangeability:** within levels of measured baseline covariates, treatment assignment carries no further information about potential outcomes, $(Y(0),Y(1))\perp A\mid Z$. **Positivity:** both actions have positive probability in every covariate stratum with positive target weight. **No interference for this model:** one unit's outcome does not depend on other units' assignments.

These conditions are not outputs of the posterior sampler. Random assignment can justify exchangeability by design, subject to issues such as attrition and deviations from assignment. Observational adjustment requires a scientific argument that relevant common causes are measured and handled appropriately. Positivity can often be examined with data and design knowledge, although finite samples cannot perfectly distinguish rare exposure from structural impossibility.

If the target population differs from the source population, transport also requires that the relevant potential-outcome means are comparable after conditioning on the chosen covariates, and that those target covariates have support in the source. Supplying target weights is not enough to establish transportability. In the worked example the target and source are stipulated to share the same conditional response mechanism.

---

Source: `course/advanced/04_causal.md:38–51`

## Deriving the adjustment formula

Start with total expectation in the target population. Under transportability where needed, conditional exchangeability, consistency, and positivity,

$$\begin{aligned}
E_T[Y(a)]
&=\sum_z E_T[Y(a)\mid Z=z]P_T(Z=z)\\
&=\sum_z E[Y(a)\mid A=a,Z=z]P_T(Z=z)\\
&=\sum_z E[Y\mid A=a,Z=z]P_T(Z=z).
\end{aligned}$$

The final expression is the g-formula for this setting. For continuous covariates, replace the sum by an integral. Positivity ensures that each conditional observed mean requested by the formula is available in principle. A statistical model may still be needed to estimate it accurately from finite data.

The equation identifies marginal risks first, then takes their difference. In logistic regression one therefore predicts a probability under each intervention for every target covariate pattern and averages those probabilities. Averaging coefficients or applying the inverse logit after averaging linear predictors generally produces a different quantity. A treatment log-odds coefficient is not itself the average risk difference.

---

Source: `course/advanced/04_causal.md:53–91`

## Worked analysis: training and request complexity

Consider an original synthetic population with two equally common baseline strata: routine requests, $Z=0$, and complex requests, $Z=1$. Training probabilities are 0.2 and 0.8 respectively. For this example we **stipulate** that assignment is independent of potential outcomes within each stratum. The potential-outcome success probabilities are

$$\begin{array}{c|cc}
&P(Y(0)=1\mid Z)&P(Y(1)=1\mid Z)\\\hline
Z=0&0.10&0.30\\
Z=1&0.60&0.70
\end{array}$$

The names are merely labels in this synthetic example: complex requests are handled by a different workflow with a higher baseline completion probability. No empirical claim about real service complexity is implied. The target causal effect is

$$\psi_T=0.5(0.30-0.10)+0.5(0.70-0.60)=0.15.$$

To expose confounding, first use generating probabilities directly. Since the two strata are equally prevalent, total treatment prevalence is one half. Among trained units, eighty percent are in the high-baseline stratum; among untrained units, twenty percent are. Thus

$$P(Y=1\mid A=1)=0.2(0.30)+0.8(0.70)=0.62,$$

$$P(Y=1\mid A=0)=0.8(0.10)+0.2(0.60)=0.20.$$

The crude difference is 0.42, whereas the causal effect is 0.15. The crude comparison changes both treatment and the mixture of baseline strata. Standardisation holds the target covariate distribution fixed while changing treatment.

Now analyse the following fully specified illustrative dataset. Counts were chosen to make the population comparison transparent; they are not claimed to be a random sample generated by a particular seed.

| Baseline stratum | Training | Requests | Completions |
|---|---:|---:|---:|
| Routine | 0 | 80 | 8 |
| Routine | 1 | 20 | 6 |
| Complex | 0 | 20 | 12 |
| Complex | 1 | 80 | 56 |

Let $p_{az}=P(Y=1\mid A=a,Z=z)$. Assign independent $\operatorname{Beta}(1,1)$ priors to the four cell probabilities and independent binomial likelihoods conditional on the cell totals. This is a saturated outcome model. We condition on the assignment counts; no fitted propensity model is required for this particular posterior calculation because the identification assumptions have already been stipulated.

The four posteriors, in table order, are Beta(9,73), Beta(7,15), Beta(13,9), and Beta(57,25). Their means are respectively 0.109756, 0.318182, 0.590909, and 0.695122. Apply the identified target to every joint posterior draw:

$$\psi_T^{(s)}=0.5[p_{10}^{(s)}-p_{00}^{(s)}]
+0.5[p_{11}^{(s)}-p_{01}^{(s)}].$$

The posterior mean is 0.156319. Because the four posterior cells are independent in this model, its variance is one quarter of the sum of their beta variances, giving 0.005918 and SD about 0.07693. The posterior mean differs from the generating effect because of finite information and prior regularisation. An interval can be obtained by independent draws; a Normal interval is only an approximation to this bounded, generally non-Normal contrast.

---

Source: `course/advanced/04_causal.md:93–93`

For comparison, pooling all trained and untrained observations before a beta update gives a crude posterior mean difference $63/102-21/102=0.411765$. That is a valid estimate of a different observational contrast under its pooled model. Labelling it causal is the mistake. The adjusted analysis earns its interpretation from the declared assignment mechanism, not from being closer to the known synthetic answer.

---

Source: `course/advanced/04_causal.md:95–101`

## What an overlap failure changes

Suppose no complex requests are handled without training because policy prohibits it. The observed cell for $A=0,Z=1$ is empty for structural reasons. The target still asks what would happen to complex requests without training, but the observed distribution provides no such conditional outcome information.

With an independent Beta(1,1) prior, that cell's posterior remains its prior. The posterior distribution of the target is mathematically proper, yet its unsupported component is supplied by an assumption. A hierarchical regression may share information from other strata and reduce apparent uncertainty. That sharing can be useful extrapolation, but it does not restore nonparametric identification. A narrow interval from a rigid response surface may obscure the very uncertainty that matters.

One option is to change the estimand to a population with genuine overlap and explain the change. Another is to report sensitivity to extrapolation assumptions or seek data under a design that makes both actions possible. Restricting the target changes the question, so report who has been excluded. Very small but nonzero cell counts pose a related practical problem even when positivity holds in the population.

---

Source: `course/advanced/04_causal.md:103–111`

## Adjustment is a causal choice

A directed acyclic graph can summarise proposed causal relations. For the training example, a sufficient story has arrows $Z\to A$, $Z\to Y$, and $A\to Y$. Conditioning on the common cause blocks the noncausal path through baseline complexity. The graph encodes assumptions; it is not inferred solely from a regression coefficient.

Adding more covariates is not automatically safer. If $A\to C\leftarrow U\to Y$, the variable $C$ is a collider. Conditioning on it can associate treatment with an otherwise unrelated cause of the outcome, opening a noncausal path. For example, selecting only cases escalated either because of training-related reporting or because of hidden severity can create a misleading association within the selected subset.

If $A\to M\to Y$, the variable $M$ is a mediator. Adjusting for it can remove part of the total effect. A regression conditioned on the mediator does not automatically identify a direct causal effect either; mediator-outcome confounding and additional counterfactual assumptions must be addressed. The [back-door discussion in Pearl's overview](https://ftp.cs.ucla.edu/pub/stat_ser/r350.pdf) explains why adjustment sets depend on causal structure rather than predictive usefulness.

Temporal ordering helps distinguish baseline covariates from consequences of treatment, but it does not establish exchangeability alone. An excellent predictor measured before treatment can still fail to capture an unmeasured common cause. Conversely, a variable with modest predictive strength may be necessary for a defensible causal adjustment argument.

---

Source: `course/advanced/04_causal.md:113–119`

## Lab, checks, and communication

Lab 16, `labs/16_causal.py`, uses seed 1616. First enumerate the stipulated generator to verify the causal effect 0.15 and crude contrast 0.42. Then fit the exact four-cell beta model to the displayed table, draw joint probabilities, and compare simulated contrast moments with the analytic posterior mean and variance. Include the pooled observational contrast and the structural empty-cell scenario with a clearly labelled sensitivity analysis.

Simulation from the declared generator can test whether code recovers its known target over repeated datasets. It cannot establish that conditional exchangeability holds in an actual service. Posterior predictive checks assess the observed outcome model; they generally cannot distinguish causal stories that imply the same observed distribution. If using a logistic extension, preserve interactions needed for heterogeneous effects and standardise probabilities for each joint draw.

A useful report leads with the intervention, population, outcome horizon, effect scale, and assumptions. For this example: under the specified within-stratum assignment mechanism, the posterior mean improvement is about sixteen percentage points, with substantial uncertainty from the smaller cells. Applying that statement to a real service requires evidence supporting the same identification conditions. Good computation should make that condition easier to see.

---

Source: `course/advanced/04_causal.md:121–125`

## Retrieval and interpretation

Explain which step in the g-formula uses exchangeability, which uses consistency, and where positivity is needed. Describe why changing target weights changes the estimand. Then contrast an empty treatment cell, a poorly mixed sampler, and a misspecified outcome curve: each needs a different remedy.

The durable workflow is target, identification, estimation, and criticism. Bayesian inference provides coherent uncertainty conditional on the specified causal and statistical model. It does not make the causal assumptions consequences of the data.

---

Source: `course/advanced/04_causal.md:127–137`

## Sensitivity to selection within measured strata

The standardised posterior above conditions on exchangeability. Now hold the observed table and its likelihood fixed and ask how the answer changes if people selecting training differ in their potential outcomes even within $Z$. Keep the same intervention, follow-up and beneficial outcome $Y=1$. This is an original binary-outcome sensitivity model, not evidence that hidden selection exists or that a chosen magnitude is plausible.

Let $e_z=P(A=1\mid Z=z)$ denote the **source-population** propensity and $w_z=P_T(Z=z)$ the target weights. Here $e=(0.2,0.8)$ and $w=(0.5,0.5)$ are stipulated population quantities. Although the illustrative counts have these treatment fractions, we are not estimating propensities from those counts. Define $h(p,d)=\operatorname{expit}(\operatorname{logit}(p)+d)$ and specify two missing counterfactual risks:

$$q_{1z}=P(Y(1)=1\mid A=0,Z=z)=h(p_{1z},\delta_{1z}),$$

$$q_{0z}=P(Y(0)=1\mid A=1,Z=z)=h(p_{0z},\delta_{0z}).$$

Each $\delta$ is the missing-minus-observed log-odds difference for the **same potential outcome**, within a measured stratum. For example, $\delta_{0z}=1$ says that the odds of success without training among those who actually took training are $\exp(1)$ times those among controls. It does not say training multiplies anyone's success odds by that amount. A positive $\delta_0$ raises the untreated counterfactual risk among the treated, reducing the treatment contrast. A positive $\delta_1$ raises the treated counterfactual risk among the untreated, increasing the contrast. Selection of people with better potential success under either action into training corresponds to $\delta_0>0$ and $\delta_1<0$.

---

Source: `course/advanced/04_causal.md:139–161`

### Mix the missing and observed risks

By total expectation over source treatment status,

$$m_{1z}=E[Y(1)\mid Z=z]=e_zp_{1z}+(1-e_z)q_{1z},$$

$$m_{0z}=E[Y(0)\mid Z=z]=(1-e_z)p_{0z}+e_zq_{0z}.$$

If these source stratum means transport to the target population, the sensitivity estimand is

$$\psi_T(\delta_0,\delta_1)=\sum_z w_z\left[e_zp_{1z}+(1-e_z)h(p_{1z},\delta_{1z})-(1-e_z)p_{0z}-e_zh(p_{0z},\delta_{0z})\right].$$

This construction preserves observed $p_{az}$ and changes only missing risks. Both marginal risks remain in $[0,1]$, so the contrast is in $[-1,1]$. It is a risk difference; multiply by 100 for percentage points. Setting both shifts to zero gives $m_{az}=p_{az}$ and recovers the earlier standardisation formula for any interior $e_z$. That restriction equates the relevant potential-outcome means across treatment groups. By itself it need not make the joint pair of potential outcomes independent of treatment, which is more than this mean contrast requires.

For an interior risk, the derivatives make the sign convention checkable:

$$\frac{\partial\psi_T}{\partial\delta_{1z}}=w_z(1-e_z)q_{1z}(1-q_{1z})\geq0,\qquad
\frac{\partial\psi_T}{\partial\delta_{0z}}=-w_ze_zq_{0z}(1-q_{0z})\leq0.$$

Thus increasing $t$ along $\delta_0=t,\delta_1=-t$ can only lower each draw's contrast. These shifts summarise selection across treatment groups; they do not identify the prevalence or outcome effects of a particular unmeasured covariate.


<!-- VISUAL01:16 BEGIN -->

---

Source: `course/advanced/04_causal.md:163–182`

### Visual investigation: fixed observed risks allow different causal scenarios

To inspect the mixture formula without posterior sampling, fix one stratum at treatment fraction $e=0.4$ and observed risks $p_1=0.7$, $p_0=0.4$. Set the missing-outcome shifts to $\delta_0=t$ and $\delta_1=-t$. Predict whether increasing t can change the causal contrast while leaving these observed risks unchanged.

![A one-stratum bounded sensitivity curve decreases from risk difference 0.30 to minus 0.0543 as missing-counterfactual log-odds shifts increase in opposite directions.](../../artifacts/figures/visual01_16_causal.svg)

**Read the figure.** The horizontal coordinate is a stipulated log-odds shift. The vertical coordinate is a population risk difference in probability units. Points mark four assumptions along a continuous curve; they are neither posterior draws nor new observations. The zero line makes a sign change visible without declaring which assumptions are plausible.

| t | Risk difference |
|---:|---:|
| 0 | 0.300000 |
| 0.5 | 0.182131 |
| 1 | 0.059377 |
| 1.5 | −0.054265 |

**Mathematical connection.** Write $h(p,d)=\operatorname{logit}^{-1}(\operatorname{logit}(p)+d)$. The displayed contrast is $0.4(0.7)+0.6h(0.7,-t)-[0.6(0.4)+0.4h(0.4,t)]$. Increasing t lowers the missing treated risk and raises the missing untreated risk, so both changes lower the contrast. The bounded link keeps all component risks between zero and one.

**Original unscored exploration — predict, observe, explain.** Predict the derivative's sign before using the table, then explain why none of the observed-data likelihood terms changes. Transfer to uncertain observed risks: the nonlinear transformation must be applied draw by draw, not only to posterior means. These fixed-risk values are deliberately separate from Lab16's frozen posterior analysis. Their range is a sensitivity range, not a credible interval, and does not supply a probability model for unmeasured confounding.

<!-- VISUAL01:16 END -->

---

Source: `course/advanced/04_causal.md:184–194`

### A compatible full-data law and its observed likelihood

There is a complete joint distribution behind the mixtures. For each source stratum, draw $A$ with probability $e_z$. Conditional on $(A,Z)$, one possible coupling gives independent Bernoulli potential outcomes with means $(p_{0z},q_{1z})$ for controls and $(q_{0z},p_{1z})$ for treated people. Reveal only $Y=Y(A)$. This factorisation specifies a joint law; it does not claim that treatment temporally creates potential outcomes. Equivalently, first draw a baseline response type $U=(Y(0),Y(1))$ from its marginal distribution and then assign treatment conditional on $(U,Z)$ using Bayes' rule. The within-person association of potential outcomes is not learned here and is unnecessary for their mean difference.

For counts $s_{az}$ out of $n_{az}$, the observed-outcome likelihood conditional on cell totals remains

$$L(p;D)=\prod_{z,a}\binom{n_{az}}{s_{az}}p_{az}^{s_{az}}(1-p_{az})^{n_{az}-s_{az}}.$$

Including random treatment counts would add propensity factors proportional to $\prod_z e_z^{n_{1z}}(1-e_z)^{n_{0z}}$. Neither likelihood contains a shift. Independent Beta(1,1) priors therefore give exactly the same four beta posteriors in every scenario. The shifts are **unidentified assumptions specified by the analyst**, not parameters learned from these observed outcomes. Many such full-data laws share this observed likelihood but disagree about $\psi_T$. Predictive fit to this table cannot rank them. Choosing plausible shifts needs external subject knowledge, design information or validation data; our grid is illustrative, not calibrated to a real service.

This workflow follows the distinction between identification and estimation in [Hernán and Robins, Chapters 2–3 and Fine Point 14.2](https://miguelhernan.org/whatifbook). [VanderWeele and Arah's additive bias formulas](https://pmc.ncbi.nlm.nih.gov/articles/PMC3073860/) show how sensitivity calculations require assumptions about relationships involving unmeasured variables. [Li and colleagues' sensitivity-function method](https://pmc.ncbi.nlm.nih.gov/articles/PMC3202161/) provides a different approach based on propensity scores and corrected inverse-probability weighting. The particular bounded log-odds mixtures above are our declared model derived by total expectation; they are not those papers' formulas or a reproduction of their estimators.

---

Source: `course/advanced/04_causal.md:196–214`

## A numerical sensitivity surface

Lab16 keeps the original posterior calculation and applies each scenario to 80,000 shared independent draws of its four cell risks, using seed 1616. Here shifts are constant over $Z$. The entries below are **Monte Carlo posterior means of the risk difference**, conditional on the row and column assumptions. The largest mean MCSE in this grid is about 0.000272 risk units, or 0.0272 percentage points.

| $\delta_0$ for missing $Y(0)$ | $\delta_1=0$ | $\delta_1=-0.5$ | $\delta_1=-1$ |
|---|---:|---:|---:|
| 0 | 0.1563 | 0.1073 | 0.0658 |
| 0.5 | 0.1069 | 0.0579 | 0.0164 |
| 1 | 0.0626 | 0.0136 | -0.0279 |

The zero-shift entry agrees with the analytic standardisation mean above within simulation error. Apply the nonlinear transformation to each draw, not just to the four posterior means: in general $E[h(p,\delta)\mid D]\ne h(E[p\mid D],\delta)$.

| Fixed scenario $(\delta_0,\delta_1)$ | Mean | Central 90% interval | $P(\psi_T>0\mid D,\delta)$ | Probability MCSE |
|---|---:|---:|---:|---:|
| (0, 0) | 0.1563 | [0.0324, 0.2852] | 0.9833 | 0.00045 |
| (0.5, -0.5) | 0.0579 | [-0.0523, 0.1761] | 0.7934 | 0.00143 |
| (1, -1) | -0.0279 | [-0.1234, 0.0755] | 0.3118 | 0.00164 |

Along $(t,-t)$ the posterior mean tips between $t=0.5$ and $t=1$. At $(1,-1)$, missing $Y(0)$ odds are multiplied by about 2.718, while missing $Y(1)$ odds are multiplied by about 0.368. The posterior mean has changed sign, but substantial conditional uncertainty still allows benefit. An interval crossing zero, a mean crossing zero and a posterior probability crossing a chosen decision threshold are different criteria. None makes $t=1$ plausible by itself, and the explored grid is not a universal robustness guarantee.

---

Source: `course/advanced/04_causal.md:216–222`

### Conditional uncertainty and numerical error

For each fixed scenario, posterior SD and the 90% interval describe uncertainty in outcome risks propagated to the contrast. With $S$ independent draws, estimate mean MCSE by $s_\psi/\sqrt S$ and probability MCSE by $\sqrt{\hat\pi(1-\hat\pi)/S}$. The latter plug-in formula is unreliable if no draws, or all draws, exceed zero; a computed zero MCSE would not prove an exact tail probability. These iid calculations are not a substitute for effective sample size in an MCMC extension.

The grid's range describes different causal assumptions, not a posterior distribution over those assumptions. Do not combine rows into one credible interval unless an explicit external probability model for the shifts is supplied and justified. Likewise, this example conditions on stipulated propensities and target weights; uncertain estimated values would require additional propagation.

Shared draws preserve dependence between scenarios. For a change from zero to $(1,-1)$, form $D^{(s)}=\psi_T^{(s)}(1,-1)-\psi_T^{(s)}(0,0)$ and use $s_D/\sqrt S$. Adding the two mean variances as if the simulations were independent is incorrect for these paired draws. Lab16 records this paired MCSE as well as each conditional summary. Independent tests compare the moments with scalar beta-density quadrature and the sign probabilities with quadrature using a conditional beta CDF.

---

Source: `course/advanced/04_causal.md:224–236`

## Changing the population and losing overlap

Reweight the same source stratum potential-outcome means to $w=(0.8,0.2)$, retaining $e=(0.2,0.8)$ and the shifts. This target is assumed comparable within strata; changing weights alone cannot establish that assumption. The zero-shift mean becomes about 0.1880. Under $(1,-1)$ it becomes 0.0174, with central 90% interval [-0.0833, 0.1291] and benefit probability about 0.5900. The mean's sign differs from the equally weighted target. This is a change in the target population, not evidence that confounding disappeared. Do not replace source propensities by target weights: they play different roles in the mixtures.

For a separate **data-deletion experiment**, omit the high-stratum control observations while retaining the stipulated source population and its propensities. The base risk $p_{01}$ now has no likelihood information. Lab16 repeats $(1,-1)$ using three priors for that cell, marking each result as extrapolation:

| Prior = posterior for omitted $p_{01}$ | Scenario posterior mean | Central 90% interval |
|---|---:|---:|
| Beta(1,1) | 0.0326 | [-0.1638, 0.2969] |
| Beta(2,8) | 0.1768 | [0.0184, 0.3255] |
| Beta(8,2) | -0.0959 | [-0.1883, 0.0090] |

These are genuine posterior simulations conditional on priors and fixed shifts, not recovery of the deleted information. They complement the original zero-shift missing-cell example. Removing observations from a source with $e_1=0.8$ is different from a **structural policy** with $e_1=1$. Under that policy, $P(Y=1\mid A=0,Z=1)$ is not an observed conditional risk at all: a log-odds shift relative to it cannot solve the problem. Specify $E[Y(0)\mid Z=1]$ directly as a separate extrapolation assumption or restrict the target to supported strata. The lab transformation deliberately rejects propensity endpoints. Proper priors and finite shifts never restore nonparametric identification or positivity.

---

Source: `course/advanced/04_causal.md:238–245`

## Unscored changed-givens investigation

Use a different fictional training table: totals `[[45,35],[25,55]]`, successes `[[9,14],[13,39]]`, rows $Z=0,1$ and columns $A=0,1$. Assign independent Beta(2,3) priors. Stipulate source propensities $(0.35,0.65)$ and target weights $(0.6,0.4)$; the source assignment fractions need not equal the fixed illustrative sampling totals. Use seed 2616 and 60,000 posterior draws. This is optional unscored practice, with no supplied answer or new assessment ID.

1. Before computing, predict how $\delta_0=(0.4,0.8)$ and $\delta_1=(-0.6,-0.2)$ change the contrast relative to zero shifts. Derive the mixtures and explain each propensity factor. Use `cell_posterior` and `sensitivity_effect` in Lab16 to compare your prediction with posterior means, intervals and benefit probabilities.
2. Reuse the same cell draws under target weights $(0.3,0.7)$. Explain why a directional prediction for this population change needs information about stratum effects. Report the paired change and its MCSE.
3. Delete the $Z=1,A=0$ sample. Compare Beta(1,1) and Beta(3,7) priors for that cell only, retaining Beta(2,3) elsewhere. State which posterior stays equal to its prior. Distinguish this deletion from a source policy that prohibits controls in that stratum.
4. Write a short conclusion identifying what the observed likelihood learns, what each sensitivity assumption supplies, which result is conditional, and what outside evidence could change your assessment of plausible shifts. Do not describe a small MCSE as evidence for exchangeability.

---

Source: `course/advanced/04_causal.md:247–249`

## Exercises

Attempt [adv.causal.1](../exercises/questions.md#adv.causal.1), [adv.causal.2](../exercises/questions.md#adv.causal.2), and [adv.causal.3](../exercises/questions.md#adv.causal.3) in the [public question bank](../exercises/questions.md). Assessed datasets and protected reference analyses are separate from the teaching table above.

---

Source: `course/advanced/04_causal.md:251–254`

## Further reading

- Hernán and Robins, [Causal Inference: What If](https://miguelhernan.org/whatifbook), especially the initial treatment of counterfactuals, exchangeability, and standardisation.
- Pearl, [Causal inference in statistics: An overview](https://ftp.cs.ucla.edu/pub/stat_ser/r350.pdf), for graphical identification and adjustment.

---

Source: `course/advanced/05_time_series.md:1–5`

# A05 · Forecast dependent data using only the available past

**Prerequisites:** [continuous models](../chapters/04_continuous.md), [regression](../chapters/07_regression.md), and [predictive checking](../chapters/10_model_checking.md); total variance, Normal conditioning, and numerical integration in [Appendix 1](../appendices/01_probability.md), [Appendix 3](../appendices/03_linear_algebra.md), and [Appendix 4](../appendices/04_numerics.md).

**Objectives:** A05.O1 derive a dependent likelihood and multi-step forecast moments; A05.O2 propagate process and parameter uncertainty; A05.O3 design chronological validation without leakage.

---

Source: `course/advanced/05_time_series.md:7–13`

## The next reading is not another exchangeable row

A sensor records a deviation from its operating baseline every hour. A positive deviation now makes a positive deviation next hour more likely. Shuffling the readings leaves their histogram unchanged but destroys information needed for forecasting. An independent Normal likelihood can describe the marginal histogram reasonably while missing the temporal behaviour that matters operationally.

The estimand in this bridge is the predictive distribution of a future reading at a specified horizon, conditional on everything available at a stated forecast origin. We also distinguish that observed reading from an underlying physical state when sensors are noisy. The conditioning information must be part of the target: a reconstruction that uses later readings is not the same distribution as a forecast made in real time.

We begin with an autoregression whose parameters are known, so the forecast equations can be checked exactly. Then we integrate uncertainty about persistence and finally add a latent state. These are small models, but they expose mistakes that remain consequential in large forecasting systems: omitted dependence, fixed-parameter intervals, future information in preprocessing, and treating an uncertain state as observed truth.

---

Source: `course/advanced/05_time_series.md:15–36`

## A likelihood that preserves temporal order

For equally spaced measurements, a stationary first-order autoregression can be written

$$Y_t=\mu+\phi(Y_{t-1}-\mu)+\epsilon_t,
\qquad\epsilon_t\overset{\mathrm{iid}}{\sim}N(0,\sigma_\epsilon^2),
\qquad |\phi|<1.$$

The innovations are independent of the past. They are new shocks, not the marginal distribution of the readings themselves. Conditional on $y_0$ and parameters $\theta=(\mu,\phi,\sigma_\epsilon)$, the likelihood is

$$p(y_{1:T}\mid y_0,\theta)=
\prod_{t=1}^T N\{y_t;\mu+\phi(y_{t-1}-\mu),\sigma_\epsilon^2\}.$$

If the series is assumed to start in equilibrium, the full likelihood also includes

$$Y_0\mid\theta\sim N\left(\mu,\frac{\sigma_\epsilon^2}{1-\phi^2}\right).$$

Conditioning on the initial reading and modelling its stationary distribution are different analysis choices. Their distinction can matter for a short series, especially near a persistence boundary. Declare which likelihood is used. A long series reduces some initial-state effects but does not repair a false stationary model.

To obtain the stationary variance, subtract the mean and take variances using innovation independence: $V=\phi^2V+\sigma_\epsilon^2$. Therefore $V=\sigma_\epsilon^2/(1-\phi^2)$. Lag-$h$ correlation is $\phi^h$. A positive persistence gives long runs on the same side of the mean; negative persistence alternates signs. Neither is represented by treating the marginal variance as the innovation variance. The [Stan time-series guide](https://mc-stan.org/docs/stan-users-guide/time-series.html) develops autoregressive likelihoods and stationarity considerations.

Stationarity is a substantive assumption about a stable mean and covariance structure. A changing baseline, seasonal cycle, or intervention can violate it. A prior restricted to stationary parameters expresses that assumption; it does not demonstrate it. The limiting case $\phi=1$ with zero drift is a random walk with increasing forecast variance, not a stationary process with an inconvenient denominator.

---

Source: `course/advanced/05_time_series.md:38–54`

## Derive the conditional forecast

Repeated substitution from the last available reading gives

$$Y_{T+h}-\mu=\phi^h(y_T-\mu)
+\sum_{j=0}^{h-1}\phi^j\epsilon_{T+h-j}.$$

Conditional on parameters and the observed past, the forecast is Normal, with

$$m_h(\theta)=\mu+\phi^h(y_T-\mu),$$

$$v_h(\theta)=\sigma_\epsilon^2\sum_{j=0}^{h-1}\phi^{2j}
=\sigma_\epsilon^2\frac{1-\phi^{2h}}{1-\phi^2}.$$

Each innovation affects the horizon through a different power of persistence. For stationary parameters the conditional mean approaches the long-run mean and the variance approaches the stationary variance. It does not shrink to zero with a longer forecast horizon. The formula conditions on the last state being observed exactly; a noisy sensor requires another uncertainty term below.

Forecasts at different horizons are correlated because they share future innovations. To forecast an aggregate across future times, generate whole trajectories or use the joint covariance. Adding marginal variances as if future readings were independent generally gives the wrong uncertainty. Likewise, an interval at each horizon is a set of marginal intervals, not automatically a simultaneous band for an entire trajectory.

---

Source: `course/advanced/05_time_series.md:56–70`

## Worked forecast: a persistent sensor deviation

Suppose the baseline is known to be zero, persistence is 0.7, innovation SD is 0.4, and the current exact deviation is two sensor units. Then

| Hours ahead | Conditional mean | Conditional variance | Conditional SD |
|---:|---:|---:|---:|
| 1 | 1.400000 | 0.160000 | 0.400000 |
| 2 | 0.980000 | 0.238400 | 0.488262 |
| 3 | 0.686000 | 0.276816 | 0.526133 |

For the second horizon, substitute once to get $Y_{T+2}=0.7^2(2)+0.7\epsilon_{T+1}+\epsilon_{T+2}$. Its variance is $0.16(0.49+1)=0.2384$. The stationary variance is $0.16/(1-0.49)=0.313725$. A long-horizon forecast therefore remains uncertain even after the current excursion has faded from its mean.

The next-reading central Normal interval uses mean 1.4 and SD 0.4. A corresponding interval for the conditional expected reading would be a point when parameters and current state are fixed. The first describes an unobserved physical outcome; the second describes a known function of fixed inputs in this deliberately simple calculation. Later parameter uncertainty makes that function uncertain too.

This example also supplies a numerical reference for simulation. Draw many independent trajectories starting at two, with independent innovations at each step, and compare means and variances at the three horizons. Reusing one innovation for all future times would produce a different covariance structure and fail the variance calculation.

---

Source: `course/advanced/05_time_series.md:72–94`

## Integrate parameter uncertainty once per trajectory

For unknown parameters, the desired distribution is

$$p(y_{T+h}\mid y_{0:T})=\int
p(y_{T+h}\mid y_T,\theta)p(\theta\mid y_{0:T})\,d\theta.$$

Its moments obey

$$E[Y_{T+h}\mid y]=E_\theta[m_h(\theta)],$$

$$\operatorname{Var}(Y_{T+h}\mid y)
=E_\theta[v_h(\theta)]+\operatorname{Var}_\theta[m_h(\theta)].$$

The second term is uncertainty about the conditional forecast mean. In general it is nonzero, and evaluating the first term at a posterior mean is not equal to averaging it. Powers of persistence make even the predictive mean nonlinear in parameters. A plug-in forecast can therefore change both the mean and variance.

For a transparent illustration, suppose a deliberately stipulated posterior places equal mass at persistence 0.4 and 0.9, with baseline zero, innovation SD 0.4, and current value two. At horizon two the component means are 0.32 and 1.62, and component variances are 0.1856 and 0.2896. The integrated mean is 0.97 and variance is $0.2376+0.4225=0.6601$. Plugging in mean persistence 0.65 instead gives mean 0.845 and variance 0.2276. This two-point distribution is a teaching device, not a posterior fitted to an unstated dataset.

To simulate a forecast, draw one parameter vector from its joint posterior, keep it fixed along a whole future path, and recursively draw innovations. Drawing a fresh persistence at every future step changes the model to one with time-varying random coefficients. Breaking posterior dependence among persistence, baseline, and innovation scale also changes the predictive distribution.

![Chronological sensor series and held-out forecasts with uncertainty](../../artifacts/figures/17_time_series.svg)

The forecast starts at the training boundary. Its widening bands describe future readings under the fitted persistence uncertainty; later observations cannot inform an earlier forecast. Re-read the horizon and noise definition before comparing these bands with latent-state uncertainty.

---

Source: `course/advanced/05_time_series.md:96–115`

## An uncertain state is not a noisy parameter estimate

Suppose the sensor measures a latent deviation $X_t$ with independent measurement noise:

$$X_t=\phi X_{t-1}+\epsilon_t,\qquad
Y_t=X_t+\eta_t,\qquad\eta_t\sim N(0,r).$$

Given fixed parameters and past observations, let the current filtered state distribution be $X_T\mid y_{0:T}\sim N(m_T,P_T)$. Propagating one step gives state mean $a=\phi m_T$ and state variance $R=\phi^2P_T+\sigma_\epsilon^2$. The next observation has variance $R+r$. State uncertainty, process innovation, and new measurement noise are distinct terms.

If $m_T=2$, $P_T=0.25$, $\phi=0.7$, $\sigma_\epsilon^2=0.16$, and $r=0.09$, then $a=1.4$, $R=0.2825$, and observation forecast variance is 0.3725. Treating the filtered mean as an exact state would omit 0.1225. Treating a future latent-state interval as a reading interval would omit another 0.09.

After a new observation $y_{T+1}$ arrives, Normal conditioning gives

$$K=\frac{R}{R+r},\qquad
m_{T+1}=a+K(y_{T+1}-a),\qquad
P_{T+1}=(1-K)R.$$

This is the scalar Kalman update. It balances the predicted state with the new noisy reading. The gain is large when the reading is precise relative to state uncertainty. If parameters are themselves uncertain, the filtered distributions must also be integrated over those parameters; a fixed-parameter Kalman filter does not do that automatically.

Filtering conditions on observations through the current time. Smoothing also uses later observations to reconstruct earlier states. Smoothing is legitimate for retrospective reconstruction, but inserting smoothed historical states into a real-time forecast evaluation leaks future information. Labelling both outputs “estimated state” hides an essential difference in conditioning.

---

Source: `course/advanced/05_time_series.md:117–131`

## Name the information set on the timeline

![Filtering uses observations through its target time, smoothing uses later observations, and forecasting targets an unobserved future from a fixed origin.](../../artifacts/figures/continuation_timeline.svg)

Let $x_t$ be a latent state and $y_t$ its noisy observation. The open diamond names the state being inferred; the line and dots name the observations available. At time four, filtering asks for $p(x_4\mid y_{1:4})$. Smoothing that same historical state using a record ending at six asks for $p(x_4\mid y_{1:6})$. Forecasting from origin four asks for $p(x_6\mid y_{1:4})$, or for $p(y_6\mid y_{1:4})$ after adding future measurement noise. Equal target dates alone do not make distributions comparable: their information sets must also match.

| Task | Latent target | Last observation permitted | Can use observations 5 and 6? |
|---|---|---:|---|
| Filter at 4 | State at 4 | 4 | No |
| Smooth state 4 after time 6 | State at 4 | 6 | Yes |
| Forecast two steps from 4 | State at 6 | 4 | No |

Smoothing is legitimate retrospective inference. Using its future observations to evaluate a forecast made at four would leak information. Any fitted scales, transformations and tuning choices used by that forecast must obey the same origin. In a model with predictors, additionally state whether each future predictor was known at four, forecast from past information, or supplied as an explicitly hypothetical scenario. Observed future weather is not automatically available to a historical forecast.

The [multisite prediction case C03](../cases/03_air_quality.md) adds a second information boundary: which sites supply outcomes. Holding out a site and holding out future times ask different questions; neither can be inferred from the time axis alone. C03 already learns state and observation scales. Its historical omitted-site task uses contemporaneous information from other sites and permits retrospective state inference; it is not a future forecast. Read its declared prediction contract before interpreting a score. This timeline supplies a conceptual companion; it introduces no new case fit or evaluation result.

---

Source: `course/advanced/05_time_series.md:133–141`

## Chronological evaluation and forecast leakage

A forecast experiment needs a table of origins, horizons, and information sets. For sixty observations indexed zero through fifty-nine, fit using indices zero through thirty-nine and forecast indices forty through forty-four. An expanding rolling-origin evaluation can then use origins thirty-nine through fifty-four for horizons one and five. At each origin, refit or update using only observations already available there. Earlier test outcomes may become training data at later origins because deployment would also have observed them by then.

A random holdout usually answers an interpolation or missing-value reconstruction question: both earlier and later neighbours may be present in training. That can be useful, but it does not estimate the performance of forecasting beyond the observed past. The same issue appears in preprocessing. Centring by the full-series mean, estimating seasonal effects from future periods, selecting a model using the final test block, or using revised covariates unavailable at the origin can all leak information.

Use training-only transformations at each origin, and state whether future predictors are known, forecast, or supplied by a scenario. Do not treat future weather observations, future demand, or a final revised economic indicator as known inputs to a historical forecast unless the deployment task really permits them. Hyperparameter selection needs an inner chronological validation scheme or a separate development period.

Score the predictive distribution with a proper score such as log predictive density, alongside interpretable errors and interval coverage. Average over posterior predictive densities before taking the logarithm; averaging log densities over parameter draws is a different quantity. Overlapping multi-step forecast errors are dependent, so an independent-row standard error for average performance can be misleading. Report the origins and horizon-specific sample sizes instead of implying that many overlapping errors are many independent experiments.

---

Source: `course/advanced/05_time_series.md:143–147`

## Dependence affects information as well as forecasts

Positive serial correlation means neighbouring observations contain overlapping information about a long-run mean. Treating them as independent can make a mean estimate appear far more precise than it is. For a long stationary AR(1) series, away from boundary effects, the variance of the sample mean is approximately the marginal variance divided by the sample size, multiplied by $(1+\phi)/(1-\phi)$. This follows by adding the lag covariances in the variance of the sum. It is an approximation for a particular estimand, not a universal effective sample size for every model parameter.

Persistence near one also makes the distinction between a stable but slowly changing process and a nonstationary process difficult with a short record. A restrictive prior can noticeably shape long-horizon predictions even when one-step fitted values look similar. Compare the implied trajectories, equilibrium spread, and response to a shock under plausible priors. More exact computation cannot decide which historical stability assumptions are appropriate for the future deployment period.

---

Source: `course/advanced/05_time_series.md:149–155`

## Lab and limits of the model

Lab 17, `labs/17_time_series.py`, uses seed 1717 to generate sixty stationary AR(1) readings with baseline zero, persistence 0.7, and innovation SD 0.4. Generate the initial value from its stationary Normal distribution. For a small inference experiment, keep baseline and innovation SD known, assign persistence a uniform prior on $(-0.95,0.95)$, and integrate its **conditional** likelihood given the first observation on a refined grid. This is a declared conditional analysis even though the generator starts in equilibrium.

Compare parameter-integrated and plug-in forecasts at horizons one through five, then run the stated rolling origins for horizons one and five. Verify the known-parameter forecast table independently by recursion or simulation. Include the fixed-parameter state-uncertainty calculation as a separate check. A demonstration using full-series centring should be labelled leaked and compared with the valid procedure; it need not improve the score on every random dataset to be an invalid protocol.

Inspect residual autocorrelation, changing variation, and runs of forecast errors. A simple AR(1) can miss seasonality, abrupt shifts, nonlinear dynamics, or outliers. A longer lag model is not automatically a remedy for every failure, and a flexible model still needs a defensible forecast protocol. This bridge provides exact anchors for dependence and uncertainty, not a complete forecasting system.

---

Source: `course/advanced/05_time_series.md:157–159`

## Retrieval and interpretation

Explain why stationary variance exceeds innovation variance, why drawing new parameters at each simulated step changes the model, and why a smoothed state cannot be used as if it were known at a past forecast origin. A forecast statement is complete only when its horizon, available information, uncertainty components, and validation design are stated.

---

Source: `course/advanced/05_time_series.md:161–163`

## Exercises

The [public question bank](../exercises/questions.md) contains [adv.time_series.1](../exercises/questions.md#adv.time_series.1), [adv.time_series.2](../exercises/questions.md#adv.time_series.2), and [adv.time_series.3](../exercises/questions.md#adv.time_series.3). Their assessed series and protected solutions are separate from this chapter's lab specification.

---

Source: `course/advanced/05_time_series.md:165–173`

## Numerical precision for a simulated forecast variance

A trajectory simulation needs an error check for each reported feature. Suppose the exact forecast is a finite Normal mixture with component weights $w_j$, means $m_j$ and variances $v_j$. Let $m=\sum_j w_jm_j$ and $V=\sum_jw_j[v_j+(m_j-m)^2]$. Expanding $(Y-m)^4$ within a component, odd centred Normal moments vanish and the fourth moment is $3v_j^2$, giving

$$\mu_4=\sum_jw_j\{3v_j^2+6v_j(m_j-m)^2+(m_j-m)^4\}.$$

For N independent complete trajectories, each horizon provides N independent marginal outcomes. The sample mean has MCSE $\sqrt{V/N}$. The unbiased sample variance has exact variance $[\mu_4-(N-3)V^2/(N-1)]/N$ for N greater than one and a finite fourth moment. For large N this gives MCSE approximately $\sqrt{(\mu_4-V^2)/N}$. Dependence across horizons does not make the trajectories dependent, but it prevents treating all horizons as extra independent draws for one horizon's statistic. These errors describe simulation accuracy conditional on the specified mixture, not uncertainty in the model's calibration.

For an equal mixture of Normal(-1,1) and Normal(1,1), m=0, V=2 and $\mu_4=3+6+1=10$. With 100,000 trajectories, mean MCSE is about 0.004472 and large-N variance MCSE about 0.007746 in squared outcome units. A variance discrepancy must be compared with the second number, not with the error of the mean. Use this calculation as a reference for the two-point-parameter forecast exercise.

---

Source: `course/advanced/05_time_series.md:175–179`

## Further reading

- Stan Development Team, [Time-series models](https://mc-stan.org/docs/stan-users-guide/time-series.html), for autoregressive and latent dynamic model definitions.
- Martin, Kumar, and Lao, [Bayesian Modeling and Computation in Python, chapter 6](https://bayesiancomputationbook.com/markdown/chp_06.html), for Bayesian time-series modelling and checks.
- Särkkä and Svensson, [Bayesian Filtering and Smoothing, second edition](https://users.aalto.fi/~ssarkka/pub/bfs_book_2023_online.pdf), for filtering, smoothing, and state-space methods beyond this scalar introduction.

---

Source: `course/advanced/06_gaussian_processes.md:1–5`

# A06 · Gaussian processes as priors over nonlinear functions

**Prerequisites:** [regression](../chapters/07_regression.md) and [model checking](../chapters/10_model_checking.md); multivariate Normal conditioning and stable linear algebra in [Appendix 3](../appendices/03_linear_algebra.md) and [Appendix 4](../appendices/04_numerics.md).

**Objectives:** A06.O1 derive GP predictive conditioning; A06.O2 implement stable latent and noisy predictions; A06.O3 critique kernels, regularisation, and computational scaling.

---

Source: `course/advanced/06_gaussian_processes.md:7–13`

## What should a curve do between measurements?

A small calibration experiment measures a response at five input settings. A straight line misses the visible change in direction. A high-degree polynomial can pass near every reading but behave wildly beyond the measured range. We need a model of plausible functions, including uncertainty about unmeasured locations, rather than a curve chosen only for its visual fit.

A Gaussian process, or GP, defines a joint Normal distribution for function values at any finite collection of inputs. Its mean function states a baseline expectation; its covariance kernel states how deviations at different inputs relate. Once those functions and a Gaussian observation model are fixed, prediction follows from ordinary multivariate Normal conditioning. The calculation is exact conditional on those choices. Their appropriateness and uncertainty remain modelling questions.

The estimands here are a latent response $f(x_*)$, a future noisy measurement $Y_*$ at the same input, and joint predictions at several inputs. These are distinct distributions. A narrow interval for the latent mean curve is not an equally narrow interval for a new observation. The distinction extends the mean-versus-outcome distinction in linear regression.

---

Source: `course/advanced/06_gaussian_processes.md:15–36`

## From finite regression to a function prior

Suppose a basis regression has $f(x)=h(x)^T\beta$ with $\beta\sim N(b,V)$. For any finite collection of inputs, the function values are jointly Normal, with

$$m(x)=h(x)^Tb,\qquad
k(x,x')=h(x)^TVh(x').$$

This shows how covariance expresses shared uncertainty about a curve. Nearby inputs may produce similar basis vectors and therefore correlated responses. A GP specifies a mean and kernel directly, allowing function classes richer than a fixed small basis while preserving consistent finite-dimensional Gaussian distributions.

Write

$$f\sim\operatorname{GP}(m,k),\qquad
Y_i=f(x_i)+\epsilon_i,\qquad
\epsilon_i\overset{\mathrm{iid}}{\sim}N(0,\sigma_n^2).$$

For every finite set of inputs, the matrix $K$ with entries $K_{ij}=k(x_i,x_j)$ must be symmetric and positive semidefinite. This means $c^TKc\ge0$ for every vector $c$, because that expression is a variance. A function that merely decreases with distance is not automatically a valid kernel in every input space. Repeated inputs can make the latent covariance singular without making the underlying GP invalid.

A common one-dimensional choice is the squared-exponential kernel

$$k(x,x')=a^2\exp\left[-\frac{(x-x')^2}{2\ell^2}\right].$$

Amplitude $a$ has outcome units; length scale $\ell$ has input units. Short length scales permit faster variation, whereas long length scales strongly couple distant inputs. This kernel encodes very smooth functions. A Matérn kernel allows rougher behaviour, and additive or periodic kernels encode other structures. Kernel choice is a scientific prior about functions, not a cosmetic plotting option. [Rasmussen and Williams, chapter 4](https://gaussianprocess.org/gpml/chapters/RW4.pdf) develops covariance constructions and their properties.

---

Source: `course/advanced/06_gaussian_processes.md:38–55`

## Condition the joint Normal distribution

Let $X=(x_1,\ldots,x_n)$ denote training inputs and $X_*$ the requested prediction inputs. Define $K=K(X,X)$, $K_*=K(X,X_*)$, and $K_{**}=K(X_*,X_*)$. With independent measurement noise, let $C=K+\sigma_n^2I$. Then

$$\begin{pmatrix}Y\\f_*\end{pmatrix}
\sim N\left[
\begin{pmatrix}m_X\\m_*\end{pmatrix},
\begin{pmatrix}C&K_*\\K_*^T&K_{**}\end{pmatrix}\right].$$

Applying the conditional Normal result from Appendix 3 gives

$$E[f_*\mid y]=m_*+K_*^TC^{-1}(y-m_X),$$

$$\operatorname{Cov}(f_*\mid y)=K_{**}-K_*^TC^{-1}K_*.$$

Conditioning reduces latent uncertainty by an amount determined by covariance with the data and their measurement precision. For future independent measurements, add their noise variance to the diagonal of the conditional covariance. Off-diagonal entries remain important for differences, averages, and simultaneous trajectories. Drawing each prediction input independently from its marginal distribution would erase the function's joint structure.

The notation contains an inverse to state the mathematics, but a stable implementation uses Cholesky solves. Factor $C=LL^T$, solve $L u=y-m_X$ followed by $L^T\alpha=u$, and solve $L V=K_*$. Then the mean adjustment is $K_*^T\alpha$ and the latent covariance is $K_{**}-V^TV$. These steps avoid explicitly forming the inverse and reuse the factor for several predictions. The standard predictive calculation is given in [Rasmussen and Williams, chapter 2](https://gaussianprocess.org/gpml/chapters/RW2.pdf).

---

Source: `course/advanced/06_gaussian_processes.md:57–74`

## Worked reference: two symmetric calibration readings

Use zero prior mean, amplitude one, length scale one, and measurement variance 0.25. Observe two readings, both equal to one, at inputs minus one and plus one. Predict the latent response at zero. The matrices reduce to

$$C=\begin{pmatrix}1.25&e^{-2}\\e^{-2}&1.25\end{pmatrix},
\qquad k_*=(e^{-1/2},e^{-1/2})^T,\qquad k_{**}=1.$$

By symmetry, multiplying the vector $(1,1)^T$ by $C$ multiplies it by $1.25+e^{-2}$. Therefore the predictive mean and latent variance are

$$m_*=\frac{2e^{-1/2}}{1.25+e^{-2}}=0.875645,$$

$$v_*=1-\frac{2e^{-1}}{1.25+e^{-2}}=0.468895.$$

A future reading at zero has variance $v_*+0.25=0.718895$. Its mean remains 0.875645 because measurement errors have mean zero. The prediction does not have to pass through one: both observations are noisy, and the prior still contributes. Nor is the interpolated latent response certain merely because two symmetric observations agree.

This example provides an algebraic check independent of a general matrix implementation. A Cholesky predictor should reproduce it to floating-point tolerance. It also checks whether the code adds noise at the correct stage. If the latent variance is reported as 0.718895, the code or label has already mixed latent and observed targets.

For a further check, with a single input and one reading $y$, amplitude one and measurement variance $s^2$, the latent mean at that same input is $y/(1+s^2)$ and variance is $s^2/(1+s^2)$. Repeated observations at the same input reduce measurement uncertainty, but repeated input coordinates themselves do not create additional latent degrees of freedom.

---

Source: `course/advanced/06_gaussian_processes.md:76–84`

## Follow covariance into whole functions

![A covariance matrix generates correlated function draws, then conditioning produces distinct latent and future-reading intervals.](../../artifacts/figures/continuation_gp.svg)

The left panel evaluates the amplitude-one, length-one kernel on 41 inputs from −2 to 2. Diagonal entries are one; entries one input unit apart equal $e^{-1/2}=0.606531$, and entries two units apart equal $e^{-2}=0.135335$. A covariance square root $L$ satisfies $LL^T=K$. Draw one vector $z$ of independent standard Normals and compute the **whole** function vector $f=Lz$. The middle panel shows four such original prior draws (seed 6106); line segments join evaluated grid points and are not a simulation of every point on the continuum.

A separate vector is used for each curve, but the coordinates within a curve share the same matrix multiplication. Replacing this step by independent draws at every input would retain the marginal variance and erase the covariance. For example, two prior function values one unit apart have difference variance $2-2e^{-1/2}=0.786939$, whereas independent marginal draws would give two. This affects averages, extrema and crossings even when pointwise bands look identical. On the nearly singular dense grid the figure uses a symmetric eigenvalue square root, removing only negative roundoff eigenvalues; its reconstructed covariance is checked. A well-conditioned positive-definite matrix can instead use Cholesky.

The right panel conditions on the two readings in the preceding worked example: one at each of −1 and +1, both equal to one, with measurement variance 0.25. At zero, the mean is 0.875645, latent variance 0.468895 and future-reading variance 0.718895. The inner region is a collection of marginal 90% latent intervals; the outer region includes new independent measurement noise. Neither region promises 90% simultaneous coverage of an entire function. New noisy curve draws must add independent measurement noise to a shared latent draw, not replace that draw with independent latent marginals. [A13](13_gp_hyperparameters.md) adds unknown hyperparameters: each whole curve then shares one hyperparameter draw as well.

---

Source: `course/advanced/06_gaussian_processes.md:86–108`

## Worked nonlinear example: length scale changes the story

Now use five original illustrative observations in dimensionless calibration units:

$$x=(-2,-1,0,1,2),\qquad y=(0.2,-0.7,0.1,0.9,0.3).$$

Set zero mean, amplitude one, and measurement SD 0.15. Compare fixed length scales 0.4, one, and two. These are sensitivity scenarios, not posterior samples of a length scale. Predict at 0.5, between observations, and at three, outside the observed interval.

| Length scale | Mean at 0.5 | Latent variance at 0.5 | Mean at 3 | Latent variance at 3 |
|---:|---:|---:|---:|---:|
| 0.4 | 0.437258 | 0.606260 | 0.011261 | 0.998109 |
| 1 | 0.665268 | 0.025622 | -0.088120 | 0.536856 |
| 2 | 0.431308 | 0.012830 | -0.327190 | 0.139398 |

Add 0.0225 to each latent variance for a new noisy observation. With the shortest length scale, even the half-unit gap is substantial relative to assumed correlation distance, so uncertainty between data remains large. At input three, correlation with the training observations is nearly gone and predictions approach the zero-mean, unit-variance prior.

The longest length scale produces more confident interpolation and extrapolation under a stronger smoothness assumption. Its negative extrapolated mean is not a discovered physical law. It follows from the chosen covariance acting on this small data pattern. Further away, a stationary squared-exponential kernel eventually loses correlation with the training data and returns to its prior mean. A meaningful trend beyond the observed range may require a nonzero mean function or a different kernel.

An attractive curve does not identify the length scale reliably from five noisy points. Compare prior draws on the actual input range before fitting. Ask how often those draws change direction, how quickly they vary, and how large their responses become. Those observable consequences are more interpretable than calling one numerical length scale “weakly informative.” Input rescaling requires consistent transformation of the length-scale prior.

![Gaussian-process predictions at three fixed length scales](../../artifacts/figures/18_gaussian_processes.svg)

The panels hold each length scale fixed. Compare interpolation, extrapolation and the latent band with the noisy-reading band; agreement at observed inputs does not imply agreement between them. These outputs do not integrate hyperparameter uncertainty.

---

Source: `course/advanced/06_gaussian_processes.md:110–127`

## Kernel priors, regularisation, and fitted hyperparameters

Write kernel and noise settings as $\eta=(a,\ell,\sigma_n,\ldots)$. With these fixed, the predictive distribution above is analytic. With uncertainty about them,

$$p(f_*\mid y)=\int p(f_*\mid y,\eta)p(\eta\mid y)\,d\eta.$$

The resulting mixture is generally not Gaussian. Its covariance includes the average conditional covariance plus covariance of conditional means, just as in model averaging. Fitting a single best setting and conditioning on it omits the latter source of uncertainty.

Proper priors can be placed on positive scales through log coordinates, with centres and spreads chosen from the calibration units. For these dimensionless inputs, one possible sensitivity specification is $\log\ell\sim N(0,0.5^2)$, $\log a\sim N(0,0.5^2)$, with measurement SD either fixed by calibration or separately modelled. Those choices are illustrative beliefs about order-one variation, not universally appropriate defaults. Inspect their function draws before using them.

For Gaussian observations, integrating the latent training values gives the log marginal likelihood

$$\log p(y\mid\eta)=-\frac12(y-m_X)^TC^{-1}(y-m_X)
-\frac12\log|C|-\frac n2\log(2\pi).$$

The first term measures covariance-adjusted discrepancy and the determinant reflects the distribution's volume. Optimising this expression is often called empirical Bayes when used to choose hyperparameters. It is not integration over their posterior. Several combinations of short-scale variation, amplitude, and measurement noise can explain a small dataset similarly, so inspect sensitivity and possible multiple optima rather than trusting one optimiser run.

Regularisation is already present in the prior's coupling of function values. Strong smoothness can suppress noisy fluctuations but can also erase real abrupt changes. Very flexible short-scale priors can attribute noise to the latent function. The observation model and kernel therefore need joint criticism, including residual structure and held-out predictions designed for the intended interpolation or extrapolation task.

---

Source: `course/advanced/06_gaussian_processes.md:129–135`

## Numerical jitter is not measurement noise

A Cholesky factor can fail when matrices are singular or numerically almost singular. Adding a small diagonal quantity, often called jitter, can stabilise floating-point calculations. This is a numerical perturbation, measured in squared outcome units. It should be documented and small enough that the requested predictions are insensitive to reasonable reductions.

Measurement noise is a scientific distribution of discrepancies between a latent function and observed readings. It belongs in the likelihood and in new-reading variance. Numerical jitter does not automatically belong in future observation noise. Large jitter can materially change inference, effectively introducing an extra noise assumption even if the code calls it a numerical trick.

Repeated or nearly repeated inputs are a useful diagnostic. With strictly positive measurement variance, the observation covariance can remain positive definite even when the latent kernel matrix is singular. For effectively noiseless duplicated inputs, consider whether the records represent repetitions, exact constraints, or inconsistent data before silently adding large jitter. Tiny negative conditional variances from rounding should prompt a tolerance-aware check; substantial negatives indicate an error or severe conditioning problem, not something to hide by unconditional clipping.

---

Source: `course/advanced/06_gaussian_processes.md:137–143`

## Scalability changes the computation

A dense covariance matrix needs memory proportional to the square of the number of observations, and its Cholesky factorisation costs order $n^3$ operations. Storing one float64 matrix for ten thousand observations requires about eight hundred million bytes before other arrays and overhead. Repeating factorisations across hyperparameter proposals multiplies the work. Calling the model nonparametric does not make its computation free.

Inducing-variable methods, structured kernels, state-space representations for suitable kernels, and other approximations can reduce cost. Each exploits additional structure or changes the computational target. Their accuracy must be examined for the same predictive quantities that motivated the model. This bridge implements only the dense small-data calculation; it does not claim a scalable GP implementation. [Rasmussen and Williams, chapter 8](https://gaussianprocess.org/gpml/chapters/RW8.pdf) introduces computational approximations and their tradeoffs.

Non-Gaussian observation models, such as binary responses, also break the simple exact conditioning calculation for the posterior function. They typically need approximation or simulation. The kernel remains a prior, but a Gaussian prior does not force a Gaussian posterior under every likelihood. [Bridge A01](01_approximation.md) supplies the relevant distinction between optimisation and approximation accuracy.

---

Source: `course/advanced/06_gaussian_processes.md:145–149`

## Lab and interpretation

Lab 18, `labs/18_gaussian_processes.py`, uses seed 1818 for any function draws. Implement prediction with Cholesky solves, reproduce the two-point algebraic reference, then evaluate the five-point dataset at the three length scales and two test locations above. Plot latent and noisy intervals with separate labels. Include nearly repeated inputs with positive observation noise, and vary explicitly recorded tiny jitter values to check numerical sensitivity.

Verify symmetry, finite values, and nonnegative conditional variances within a justified rounding tolerance. Compare the small reference with direct analytic algebra. A successful factorisation certifies neither kernel suitability nor extrapolation accuracy. A complete interpretation names the kernel, scale settings, whether their uncertainty was integrated, and the part of input space supported by observations.

---

Source: `course/advanced/06_gaussian_processes.md:151–153`

## Retrieval and interpretation

Explain why a covariance kernel must be positive semidefinite, why a future reading has greater variance than its latent function value, and why a long length scale can produce confident but assumption-sensitive extrapolation. The GP is a coherent way to express uncertain nonlinear functions; its usefulness depends on a defensible prior and an honest prediction target.

---

Source: `course/advanced/06_gaussian_processes.md:155–157`

## Exercises

The [public question bank](../exercises/questions.md) contains [adv.gaussian_processes.1](../exercises/questions.md#adv.gaussian_processes.1), [adv.gaussian_processes.2](../exercises/questions.md#adv.gaussian_processes.2), and [adv.gaussian_processes.3](../exercises/questions.md#adv.gaussian_processes.3). Their assessed matrices, code tasks, and protected feedback remain separate from this reading.

---

Source: `course/advanced/06_gaussian_processes.md:159–161`

## Choose a next route

For the twenty-four-week extended route, choose the [penguin regression case C01](../cases/01_penguins.md) after its regression/checking prerequisites, or the [sensor forecasting case C02](../cases/02_sensor_forecasting.md) after A03/A05. Save an analysis plan before either worked reference. For computational GP depth, [A13](13_gp_hyperparameters.md) develops integrated hyperparameters and an empirical-Bayes comparison; it requires A06 and the numerical/linear-algebra appendices and adds an estimated 6–8 hours. The [advanced menu in the syllabus](../syllabus.md) gives other choices; chapter numbering is not a compulsory sequence.

---

Source: `course/advanced/06_gaussian_processes.md:163–166`

## Further reading

- Rasmussen and Williams, [Gaussian Processes for Machine Learning, chapter 2](https://gaussianprocess.org/gpml/chapters/RW2.pdf), for Gaussian regression and the Cholesky algorithm.
- The same authors, [chapter 4](https://gaussianprocess.org/gpml/chapters/RW4.pdf), for kernels and their assumptions, and [chapter 8](https://gaussianprocess.org/gpml/chapters/RW8.pdf), for computation on larger datasets.

---

Source: `course/advanced/07_prior_workflow.md:1–7`

# A07 · From judgments to a defensible prior

**Prerequisites:** [conditioning and Bayes' rule](../chapters/01_bayes.md), [Beta–Binomial updating](../chapters/02_beta_binomial.md), [shared predictive uncertainty](../chapters/03_prediction.md), and [Monte Carlo error](../chapters/05_monte_carlo.md). Read these as L01–L03 and L05. You need probabilities, expectations and the distinction between a parameter and a future observation; the integral notation below describes averaging and does not require deriving special functions.

**Objectives:** A07.O1 Document quantity, population, horizon and information provenance. A07.O2 Fit probability judgments and return predictive implications for feedback. A07.O3 Explain disagreement and consequential prior sensitivity.

**Study plan:** allow 4–6 hours for reading, Lab 21, discussion and the four associated assessments. This is an unpiloted planning estimate for an optional continuation, after the prerequisites. It adds no requirement to the original core route.

---

Source: `course/advanced/07_prior_workflow.md:9–17`

## Start with a question someone could misunderstand

A small workshop needs 16 usable labels from a job that will print 20. Its planner says the printer “usually works.” The technician remembers several troublesome setups. Before translating either statement into a distribution, decide what “works” describes. Is a label usable if it is legible, correctly aligned, or both? Are these beliefs about one fixed setup, the mix of jobs over a year, or the fraction that will work in the next small job? These are different quantities.

Our original teaching scenario fixes printer P, stock S, alignment, and a usability test requiring legibility and alignment. Let $\theta$ be the stable probability that a label passes that test under this setup. The target is the next job of 20 labels before any maintenance or stock change. Conditional on $\theta$, model the labels as independent Bernoulli trials. The future count is $K\mid\theta\sim\operatorname{Binomial}(20,\theta)$.

This stable-probability assumption needs discussion before fitting. A jam that affects neighboring labels, changing ink, or a different stock can break it. A distribution on one unknown $\theta$ does not automatically model those mechanisms. If the actual target is a mix of setups, define setup-specific probabilities and their population distribution, or restrict the target. A fitted Beta curve cannot repair a wrong quantity definition.

All roles, judgments, dates, costs and observation counts in this reading are **fictional teaching inputs**. No interview, professional expert review or operational recommendation is represented here.

---

Source: `course/advanced/07_prior_workflow.md:19–35`

## Uncertainty about probability is not label-to-label variation

Suppose $\theta$ were known to be 0.8. Individual labels would still succeed or fail, and $K$ would vary between otherwise identical jobs. That is conditional sampling variation. A prior distribution describes our uncertainty about the unknown $\theta$. It does not mean that the printer physically samples a new probability before every label.

If $\theta\sim\operatorname{Beta}(a,b)$, write $s=a+b$, $\mu=a/s$ and $v=ab/[s^2(s+1)]$. Then

$$E[K]=n\mu,\qquad
\operatorname{Var}(K)=E[n\theta(1-\theta)]+\operatorname{Var}(n\theta)
=\frac{nab}{s(s+1)}+n^2v.$$

The first term averages the variation that remains at a fixed $\theta$. The second propagates uncertainty about the conditional mean. For two distinct label indicators $Y_i,Y_j$, conditional independence implies

$$\operatorname{Cov}(Y_i,Y_j)=\operatorname{Var}(\theta)=v.$$

This predictive dependence comes from a shared unknown. It is not evidence of a physical jam. Simulating the correct predictive distribution means drawing one $\theta$ for a whole simulated job, followed by its 20 Bernoulli outcomes. Drawing a new independent $\theta_i$ for every label produces independent marginal Bernoulli outcomes with probability $\mu$ and a Binomial count. The marginal prediction for one label is the same, but the joint prediction changes.

A 10th percentile for $\theta$ also differs from a 10th percentile for $K/20$. The latter includes finite-job variation and lives on 21 possible values. Ask the provider to explain in words which quantity their percentile describes before using the answer.

---

Source: `course/advanced/07_prior_workflow.md:37–58`

## Make a provenance record before fitting

The record below is part of the analysis, not paperwork to add after selecting a convenient curve. The lab preserves its machine-readable version alongside the calculations.

| Field | Fictional record |
|---|---|
| Quantity and units | $\theta$, probability of a usable label; dimensionless |
| Population and conditions | Printer P, stock S, alignment fixed; legible and aligned counts as success |
| Horizon | Next 20-label job before any maintenance or stock change |
| Providers | A: production planner; B: maintenance technician; both are scripted roles |
| Elicitation date | 2026-09-01, a fictional scenario date, not an execution timestamp |
| Information already used | Shared fictional setup memo with no numeric trial data; role-specific memories may overlap |
| Information excluded | Outcomes of the future job and the separate archive illustration below |
| Candidate family | Beta on $(0,1)$; no exact mass at failure or perfection |
| Judgments | A0 and B0 below, retained separately with their identities |
| Returned implications | Fitted CDF points, quantiles, residuals, optimizer status, 20-label predictions and losses |
| Revision | B1 retains a link to B0 and an explicit reason; A0 remains unchanged |
| Decision sensitivity | All packets, three penalty values, and an explicitly hypothetical mixture-weight sweep |

Two people can repeat the same information in different words. Their agreement is not automatically independent evidence. Preserve the shared memo identifier and any common inspections so that later updating can avoid counting them twice.

Before showing a fitted curve, ask each role for judgments separately. Explain “10th percentile 0.65” as assigning probability 0.10 to $\theta\leq0.65$, not predicting that 10% of labels have success probability 0.65. Ask for reasons and alternative conditions, not spurious decimal precision. The first packet A0 assigns the 10th, 50th and 90th percentiles of $\theta$ to 0.65, 0.80 and 0.90.

---

Source: `course/advanced/07_prior_workflow.md:60–89`

## Derive the fit and identify what it can establish

The Beta density and normalizer are

$$f(t\mid a,b)=\frac{t^{a-1}(1-t)^{b-1}}{B(a,b)},\quad
B(a,b)=\frac{\Gamma(a)\Gamma(b)}{\Gamma(a+b)},\qquad a,b>0.$$

Its CDF is the accumulated area

$$I_x(a,b)=\int_0^x f(t\mid a,b)\,dt.$$

For a continuous strictly increasing CDF, a quantile judgment $Q(p_j)=x_j$ is equivalent to $I_{x_j}(a,b)=p_j$. A0 therefore proposes three equations:

$$I_{0.65}(a,b)=0.10,\qquad I_{0.80}(a,b)=0.50,\qquad I_{0.90}(a,b)=0.90.$$

Two parameters generally cannot satisfy three equations exactly. Choose and disclose a discrepancy criterion. This lab uses equal-weight squared **CDF** residuals:

$$r_j(a,b)=I_{x_j}(a,b)-p_j,\qquad
S(a,b)=\sum_j r_j(a,b)^2.$$

The residuals have probability units. Minimizing squared errors between fitted and elicited *quantile values* would be a different fitting rule and could give different parameters. Giving one point a larger weight would also be a substantive choice; a median is not automatically three times as reliable as a tail judgment.

Optimize $u=\log a$, $v=\log b$ instead of unconstrained shapes. Substituting $a=e^u$, $b=e^v$ gives

$$\widehat{u},\widehat{v}=\arg\min_{u,v}
\sum_j [I_{x_j}(e^u,e^v)-p_j]^2.$$

Exponentiation enforces positive shapes throughout optimization. It is a coordinate change for finding a minimum, so **no probability-density Jacobian belongs in this objective**. This is neither a posterior density on shapes nor an observation likelihood. The software estimates local changes numerically and searches from five declared starting pairs. Numerical bounds $-12\leq u,v\leq12$ prevent extreme arithmetic; they are guardrails, not elicited prior information. A boundary solution needs investigation.

The local interface `fit_beta_quantiles(values, probabilities) -> dict` returns shapes, fitted CDF values and quantiles, both kinds of residuals, the sum of squared CDF residuals, and the optimizer's message/status/evaluation count. It retains every starting fit. A successful termination means a numerical stopping rule was met; it does not establish a global minimum, a defensible family, an accurately represented belief, or truth about the printer. There is no sampling-based standard error for these fitted shapes in this exercise: the three judgments are not a random sample of observed proportions.

---

Source: `course/advanced/07_prior_workflow.md:91–109`

## Return the discrepancies to the provider

For A0 the fitted shapes are approximately $a=13.421901$, $b=3.633954$.

| Requested percentile | Elicited value | Fitted CDF at that value | CDF residual: fitted minus requested | Fitted quantile |
|---:|---:|---:|---:|---:|
| 0.10 | 0.65 | 0.092262 | −0.007738 | 0.655548 |
| 0.50 | 0.80 | 0.506860 | +0.006860 | 0.798315 |
| 0.90 | 0.90 | 0.892334 | −0.007666 | 0.902749 |

For example, the curve assigns about 9.23%, rather than 10%, below 0.65. The fitted 10th percentile is about 0.656. These are two descriptions of the same mismatch, in different units. Return both before deciding whether the approximation is useful.

The lab flags a maximum absolute CDF residual greater than 0.025, optimizer failure, or a boundary fit as requiring further feedback. This tolerance is a declared teaching screen, not a universal acceptability threshold. Smaller residuals still require substantive feedback. A returned `feedback_required=False` means only that this automatic screen found none of its specified problems.

Distinguish three situations:

1. **Unsupported or contradictory input.** Interior values paired with probabilities 0 or 1 cannot be matched exactly by a finite positive-shape Beta. Duplicate values with different CDF probabilities, decreasing probabilities, unsorted values, endpoints, NaNs, or two-dimensional stacks of provider packets are rejected. The helper requires at least two strictly increasing interior values and probabilities. It does not silently sort, clamp, average or reinterpret the judgments. Its deliberately narrow interface also rejects redundant equal-CDF entries; preserving these in a richer elicitation record is a separate task.
2. **Coherent judgments with poor family fit.** Values $(0.10,0.11,0.90)$ at probabilities $(0.1,0.5,0.9)$ can describe an increasing CDF. The lab retains this as a separate stress example, for which its best multistart Beta fit still misses a CDF probability by about 0.10. A convergence message does not remove that discrepancy. Discuss a more flexible family or the meaning of the judgments; do not call the input logically impossible just because a Beta fits badly.
3. **Disagreement between coherent packets.** Different providers may each give valid ordered judgments for the same target. Fit them separately and report the conflict. Treating their statements as extra independent Bernoulli observations silently changes both the information model and their meaning.

---

Source: `course/advanced/07_prior_workflow.md:111–128`

## A worked prediction for the job

Integrate the Binomial count mass over the fitted Beta:

$$\begin{aligned}
P(K=k)&=\int_0^1 {n\choose k}t^k(1-t)^{n-k}f(t\mid a,b)\,dt\\
&={n\choose k}\frac{B(a+k,b+n-k)}{B(a,b)},\qquad k=0,\ldots,n.
\end{aligned}$$

For A0 and $n=20$, the predicted mean is 15.7388 usable labels. The variance decomposition is $3.1676+3.7144=6.8820$ labels squared: the second term, uncertainty about the conditional mean, matters. Plugging in $E[\theta]$ would give variance about 3.3533 and discard shared uncertainty.

The predictive 10th/50th/90th count quantiles are 12, 16 and 19. Discrete quantiles are defined here as the smallest count whose cumulative probability reaches the requested probability. They do not imply exact 10% tail masses. Summing $P(K=k)$ from $k=0$ through 15 gives

$$P(K<16)=0.417959.$$

Notice the threshold: “at least 16” fails at 15, not at 16. The fitted median of $\theta$ near 0.8 does not imply that this job is nearly certain to supply 16 labels.

These are **prior predictive implications for feedback**. No actual job has been observed. A plausible predictive distribution is not an empirical goodness-of-fit result. If a provider finds the predicted shortfall surprising, revisit the quantity, their judgments and the conditional Binomial model. Do not simply narrow the prior until the prediction looks reassuring.

---

Source: `course/advanced/07_prior_workflow.md:130–142`

## Preserve disagreement and the revision trail

The technician's initial packet B0 assigns $(0.35,0.55,0.75)$ to the same three percentiles. In the scripted feedback conversation, B notices that memories of an unaligned setup influenced the answer. B offers B1, $(0.50,0.70,0.85)$, for the aligned setup. This is an illustrative clarification before future outcomes, not Bayesian updating with new data. Preserve B0, label B1 as a revision, and record the reason. In a real process the analyst could not claim this revision without obtaining and recording it.

| Packet | Status | Fitted $a$ | Fitted $b$ | Predictive mean of $K$ | $P(K<16)$ |
|---|---|---:|---:|---:|---:|
| A0 | Initial planner packet | 13.421901 | 3.633954 | 15.7388 | 0.417959 |
| B0 | Initial technician packet, retained | 5.360219 | 4.414264 | 10.9678 | 0.883668 |
| B1 | Scripted clarification of B0 | 7.615999 | 3.472578 | 13.7367 | 0.668551 |

B1 still disagrees materially with A0. Neither a small residual nor a more familiar job description resolves whose knowledge should govern. The result JSON retains the full fitted implications for all three packets. B0 does not disappear because it is inconvenient. Reasons to reopen the process might include ambiguity in the setup definition, overlapping evidence, a provider's experience being less relevant to this population, or an omitted failure mechanism. They require substantive investigation.

If a group chooses to discuss a common distribution, record what changed and whose beliefs it is intended to represent. Multiplying fitted densities usually makes a sharper distribution; without an information model it is not justified by two people agreeing. A linear mixture is another possible sensitivity construction, but its weights are assumptions, not measured credibility or posterior provider probabilities.

---

Source: `course/advanced/07_prior_workflow.md:144–175`

## Carry the disagreement into an action

Declare the loss before comparing priors. In fictional cost units, printing costs 2 plus a penalty of 25 if fewer than 16 labels are usable. Outsourcing costs 15 and is stipulated to guarantee enough labels. These are preferences and consequences, not facts learned by fitting a prior. If outsourcing can fail, its uncertainty belongs in a richer loss model.

$$L(\mathrm{print},K)=2+25\,1\{K<16\},\qquad
L(\mathrm{outsource},K)=15.$$

Expected-loss minimization selects print when

$$2+25P(K<16)<15\quad\Longleftrightarrow\quad P(K<16)<0.52.$$

At equality both actions tie. Do not optimize the mean number of labels as a substitute: the loss is driven by a threshold event.

| Packet | Expected print loss | Expected outsource loss | Lower-loss action under these assumptions |
|---|---:|---:|---|
| A0 | 12.448978 | 15 | Print |
| B0 | 24.091711 | 15 | Outsource |
| B1 | 18.713778 | 15 | Outsource |

This is consequential sensitivity: the declared plausible packets change the action. A reasonable report would explain the unresolved conflict and identify which information could clarify it. It would not select A0 because its answer is cheaper. An unchanged action across a few priors would be limited robustness over that declared set, not evidence that the priors are all true.

Preference uncertainty matters too. The lab repeats the calculation at penalties 15, 25 and 40 while holding each prior fixed. For B1, printing is preferred at 15 but outsourcing at 25; for A0 the switch occurs between 25 and 40. This separates uncertainty about the printer from uncertainty about how much a shortfall matters.

For a transparent pooling sensitivity, suppose a hypothetical prior is $w f_{A0}(\theta)+(1-w)f_{B1}(\theta)$. Integrals are linear, so its shortfall probability is

$$w(0.417959)+(1-w)(0.668551).$$

At $w=0.25,0.50,0.75$, this gives approximately 0.605903, 0.543255 and 0.480607. The action switches to print only above $w\approx0.592801$. An equal mixture therefore selects outsource. This calculation exposes how much an unelicited weight can matter; it does not recommend 50:50 pooling. To simulate this mixture correctly, draw the component and $\theta$ once per job, not once per label. Averaging fitted shape parameters is generally a different distribution.

![Three panels show the retained prior judgments, predictive usable-label counts and expected-loss sensitivity; numerical alternatives are given in the adjacent tables.](../../artifacts/figures/21_prior_workflow.svg)

The SVG supplies a title and description and distinguishes packets by line styles and markers as well as color. The displayed shortfall band includes counts 0–15. The lab result contains every plotted count probability and the numerical loss comparisons.

---

Source: `course/advanced/07_prior_workflow.md:177–188`

## Audit information reuse before a likelihood is added

Here is a separate exact illustration, **not** the origin of A0/B0/B1. Start with $\operatorname{Beta}(2,2)$. A fictional archive records 8 usable labels out of 10 under the same setup. Updating once gives $\operatorname{Beta}(10,4)$. If you now call that posterior “the prior” and put the same archive into the likelihood again, you get $\operatorname{Beta}(18,6)$.

The second calculation has counted the archive twice. It changes the mean from $5/7\approx0.7143$ to $3/4=0.75$ and reduces the variance from about 0.01361 to 0.00750. Changing a label from “posterior” to “prior” does not create new information.

There are two coherent bookkeeping routes: start at Beta(2,2) and use the archive likelihood once, or start at Beta(10,4), record that it already incorporates `fictional_archive_01`, and exclude that archive from subsequent likelihoods. If a distinct new inspection records 4 usable labels out of 5, the latter route gives Beta(14,5). Reusing the archive as well would incorrectly give Beta(22,7). Exchangeability across inspections remains an assumption to justify even when the records are distinct.

Judgment packets often have less explicit information content than this exact example. Their fitted concentration $a+b$ can be useful for describing spread and conjugate updating, but it is not a count of independent labels the provider has observed. Do not manufacture a fictitious trial sample from fitted shapes. When a provider has already seen the current observations, document the overlap and choose a model or analysis sequence that accounts for it. A sensitivity analysis may reveal the consequence, but cannot retroactively certify independence.


<!-- VISUAL01:17 BEGIN -->

---

Source: `course/advanced/07_prior_workflow.md:190–211`

### Visual investigation: information enters once even when a curve gets narrower

Use a separate provenance example, not a reconstruction of the elicitation scenarios above. Begin at Beta(2,3). An archive records five successes among eight items, and an independent current batch records four among six. Predict whether feeding the archive into the likelihood again after it already informed the prior adds information.

![Using an archive once yields Beta(11,8), whereas counting the same archive twice yields a narrower Beta(16,11) without new information.](../../artifacts/figures/visual01_17_information_reuse.svg)

**Read the figure.** Both axes concern the same probability parameter and its density. The dashed result is narrower, but its label marks an invalid reuse of the same evidence. Curve sharpness alone cannot establish a legitimate increase in information.

| Step / provenance | Beta parameters |
|---|---|
| Base prior, before archive | (2, 3) |
| Archive added once: 5 successes, 3 failures | (7, 6) |
| Independent current batch: 4 successes, 2 failures | (11, 8) |
| Incorrect extra use of the same archive | (16, 11) |

The legitimate posterior mean is 0.578947 with variance 0.0121884. Reusing the archive produces mean 0.592593 and variance 0.00862238. The narrower second density is a consequence of duplicated likelihood factors, not additional observations.

**Mathematical connection.** Correct updating is proportional to $p_0(p)L_{archive}(p)L_{current}(p)$. The erroneous path uses $L_{archive}(p)^2$, adding the same successes and failures twice. Conditional independence of genuinely distinct batches justifies multiplication; a second copy of a record is not an independent batch.

**Original unscored exploration — predict, observe, explain.** Replace the current batch with a genuinely independent second archive-sized batch that happens to have the same counts. Predict the algebra, then explain why identical counts can legitimately add information when their provenance differs. Transfer to expert elicitation: document which datasets the expert saw before deciding what can enter a subsequent likelihood. This conjugate example does not claim the book's elicited priors were formed from counts.

<!-- VISUAL01:17 END -->

---

Source: `course/advanced/07_prior_workflow.md:213–225`

## Complete the process, then communicate its limits

For this worked process, a defensible memo would contain the following sequence:

1. Define usability, setup, population and the next-job horizon; disclose conditional independence and stability.
2. Record A0/B0 separately with roles, information sources and date before numerical fitting.
3. Validate support and ordering; fit the declared family and discrepancy; retain all starts and numerical status.
4. Return the fitted quantiles, CDF mismatches and observable 20-label predictions; record the scripted B0→B1 clarification without erasing B0.
5. Audit information already used before introducing any new likelihood. No future job outcomes have been used here.
6. Evaluate the declared loss for all retained packets and the declared sensitivity scenarios. Report the action disagreement rather than claiming consensus.
7. State the next unresolved questions: which experience matches this setup, whether label outcomes really share one stable probability, and whether the shortfall cost and outsourcing guarantee are defensible.

The scientific conclusion is conditional: under this Binomial model and loss, the action depends on which retained packet is used. Numerical agreement between independent implementations establishes that the stated calculations were carried out correctly. It cannot establish genuine expert authority, adequacy of a fictional scenario, effectiveness of a short elicitation course, or optimality of the decision in a real workshop.

---

Source: `course/advanced/07_prior_workflow.md:227–233`

## Lab and further practice

Use [Lab 21](../../labs/21_prior_workflow.py); its percent-format cells are the authoritative notebook source. Run `.venv/bin/python -B labs/21_prior_workflow.py` from the repository root. Read the [finite result record](../../artifacts/results/21_prior_workflow.json), particularly `metrics.packets`, `metrics.coherent_poor_beta_fit`, `metrics.mixtures`, `metrics.information_reuse` and `checks`. The lab has no external data download or stochastic fit. Its seed field preserves the shared lab interface; it is not evidence of Monte Carlo sampling.

The independent checks integrate a density with a separately calculated gamma normalizer to verify CDF values and every predictive count probability. Expected loss is also checked by summing the state-specific losses over counts. The focused test suite adds exact polynomial-CDF and sequential-prediction references, invalid-input checks and optimizer-status checks. Integration tolerances measure numerical agreement, not trust in a judgment provider.

Before changing code, predict what happens to each variance term as the job grows. Then alter one coherent packet, retain its predecessor and explain which predictive claim changes. Construct an invalid packet separately and explain why it must be clarified before fitting. Finally, state a loss range under which the action is or is not stable. These explorations are distinct from the four optional assessed tasks in the [question bank](../exercises/questions.md): `adv.prior_workflow.1`–`.4`, covering uncertainty versus variation, conflicting fits, action sensitivity and information reuse. Their assessed situations and givens are separate from this worked example.

---

Source: `course/advanced/07_prior_workflow.md:235–239`

## Sources and scope

Garthwaite, Kadane and O'Hagan describe elicitation as an iterative preparation, judgment, fitting and feedback process and distinguish faithful representation from objective truth. Those ideas motivate the record and feedback loop here. See their author-hosted [Statistical Methods for Eliciting Probability Distributions](https://www.stat.cmu.edu/tr/tr808/tr808.pdf), especially sections 1.1–1.3.

The official [SHELF manual, `fitdist`](https://oakleyj.r-universe.dev/SHELF/SHELF.pdf) describes fitting cumulative probability judgments by least squares and returning discrepancies. This lab implements its own small SciPy example; it does not depend on R or reproduce a manual exercise. The printer story, judgments, revision, loss model and all practice prompts here are original teaching constructions. These sources support methods and process, not a claim that this module has validated learning outcomes or qualifies a reader as a professional elicitor.

---

Source: `course/advanced/08_categorical_conjugacy.md:1–5`

# A08 · Categorical updating and prediction

**Prerequisites:** the [beta-binomial model](../chapters/02_beta_binomial.md), [posterior prediction](../chapters/03_prediction.md), [rates and continuous measurements](../chapters/04_continuous.md), and probability notation in [Appendix 1](../appendices/01_probability.md). The gamma-function step is developed here. This optional continuation takes an estimated 4–6 hours including the lab and practice; the estimate has not been piloted.

**Objectives:** A08.O1 Derive Dirichlet updating and predictive counts. A08.O2 Distinguish shared uncertain probabilities, batch heterogeneity and types of zero.

---

Source: `course/advanced/08_categorical_conjugacy.md:7–13`

## A repair can have more than two outcomes

A fictional service records one status for each job seven days after completion: **resolved**, **revisit**, or **replacement**. A replacement takes precedence if both a revisit and replacement occur; otherwise a revisit takes precedence over resolved. Every completed job has exactly one recorded status. These coding rules matter: three overlapping binary indicators would require a different likelihood.

Eight comparable jobs give counts $(5,3,0)$ in that order. A planner needs the distribution of replacement demand among the next three jobs. Zero observed replacements is a statement about a small sample. It does not establish that replacement is impossible.

Let $\theta=(\theta_R,\theta_V,\theta_P)$ be the probabilities under unchanged service conditions. The estimand is this common probability vector; the prediction target is a vector of future job counts. We assume jobs are conditionally independent given $\theta$, measured at the same seven-day horizon, and comparable in case mix and working conditions. These assumptions can fail if, for example, a new supplier changes the jobs. All data, prior choices and operational details here are original fictional teaching givens, not service evidence.

---

Source: `course/advanced/08_categorical_conjugacy.md:15–30`

## The simplex and the categorical likelihood

For $K$ exclusive, exhaustive categories, the simplex is

$$\Delta_{K-1}=\{\theta: \theta_j\geq0,\ \sum_{j=1}^K\theta_j=1\}.$$

It has $K-1$ free coordinates: for three categories, choose the first two and set $\theta_3=1-\theta_1-\theta_2$. Positive probabilities live inside a triangle, not throughout a three-dimensional cube. Increasing one probability leaves less mass for the others. A category label is a name, not an ordered numerical response; assigning codes 1, 2, 3 does not make their average meaningful.

If $X_i=j$, the categorical likelihood contribution is $\theta_j$. For counts $y_j=\sum_i1\{X_i=j\}$ and $n=\sum_j y_j$,

$$p(y\mid\theta)=\frac{n!}{\prod_j y_j!}\prod_j\theta_j^{y_j}.$$

The coefficient counts distinct ordered sequences with those counts. It is constant in $\theta$, so it drops out of a posterior kernel. It must return when computing the probability of an unordered count vector. Conditional independence does not assert that the unknown probabilities themselves are independent.


<!-- VISUAL01:18 BEGIN -->

---

Source: `course/advanced/08_categorical_conjugacy.md:32–50`

### Visual investigation: three probabilities share one constrained space

Before count prediction, inspect the space in which a three-category probability vector lives. A new Dirichlet(4,3,2) illustration has mean $(4/9,3/9,2/9)$. Predict what must happen to the other coordinates if the first probability increases by 0.1.

![A triangle encodes probability triples summing to one; the Dirichlet(4,3,2) mean and an arrow transferring 0.1 from category two to one stay on the simplex.](../../artifacts/figures/visual01_18_simplex.svg)

**Read the figure.** The triangle uses barycentric coordinates: each corner assigns probability one to its named category, an edge assigns zero to the opposite category, and interior positions assign positive probabilities to all three. These are unitless probability coordinates, not future counts or ordinary independent horizontal/vertical parameters. The arrow transfers 0.1 from category two to category one, keeping the third fixed.

| Probability triple | Sum | Interpretation |
|---|---:|---|
| (4/9, 3/9, 2/9) | 1 | Dirichlet mean |
| (4/9 + 0.1, 3/9 − 0.1, 2/9) | 1 | Valid movement along the simplex |
| (0.5, 0.4, 0.3) | 1.2 | Invalid probability vector |

**Mathematical connection.** With total concentration nine, $\operatorname{Cov}(p_1,p_2)=-4(3)/(9^2(10))=-12/810$. Negative covariance here follows from the Dirichlet joint model and the sum constraint; separately sampled marginal betas generally fail to produce a valid joint vector. For six future trials, category one's count variance is 2.222222 under Dirichlet-multinomial prediction versus 1.481481 under the plug-in multinomial. The count vector has a fixed integer total six; that is a different space from the probability simplex.

**Original unscored exploration — predict, observe, explain.** Predict whether increasing the first probability requires each other probability to fall. Observe that only their sum must fall by 0.1; the arrow shows one possible allocation. Explain why the marginals alone do not determine the joint simulation. Transfer to merging categories two and three: identify the resulting beta parameters before calculating a future count. Categories are assumed exhaustive and mutually exclusive.

<!-- VISUAL01:18 END -->

---

Source: `course/advanced/08_categorical_conjugacy.md:52–74`

## Why the Dirichlet density has gamma functions

For $a>0$, define

$$\Gamma(a)=\int_0^\infty t^{a-1}e^{-t}\,dt.$$

Integration by parts gives $\Gamma(a+1)=a\Gamma(a)$, and $\Gamma(1)=1$, so $\Gamma(m)=(m-1)!$ for positive integers $m$. Gamma functions extend the factorial calculation to positive noninteger shapes.

Take $K$ independent gamma variables $G_j$ with shape $\alpha_j>0$ and rate one. Put $S=\sum_jG_j$ and $\theta_j=G_j/S$. In coordinates $(S,\theta_1,\ldots,\theta_{K-1})$, with the last probability determined by the others, the absolute Jacobian is $S^{K-1}$. Write $A=\sum_j\alpha_j$. The joint density becomes

$$\frac{e^{-S}S^{A-K}}{\prod_j\Gamma(\alpha_j)}
\prod_j\theta_j^{\alpha_j-1}\,S^{K-1}
=\frac{e^{-S}S^{A-1}}{\prod_j\Gamma(\alpha_j)}
\prod_j\theta_j^{\alpha_j-1}.$$

Integrating out $S$ contributes $\Gamma(A)$. Thus, with respect to ordinary volume in the first $K-1$ simplex coordinates,

$$p(\theta\mid\alpha)=\frac{1}{B(\alpha)}\prod_j\theta_j^{\alpha_j-1},\qquad
B(\alpha)=\frac{\prod_j\Gamma(\alpha_j)}{\Gamma(A)}.$$

This also derives the simplex integral $\int_{\Delta_{K-1}}\prod_j\theta_j^{\alpha_j-1}d\theta=B(\alpha)$. For $K=2$, it is the usual beta normalizer. The density and positive-shape domain agree with [SciPy's Dirichlet definition](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.dirichlet.html).

Write $\alpha=Aq$, where $q$ sums to one. The vector $q$ is the prior mean and $A$ controls concentration around it. At fixed $q$, increasing $A$ reduces variance. A shape below one permits density that grows near a boundary; it does not create a point mass at zero. $\operatorname{Dirichlet}(1,1,1)$ is uniform in the two free coordinates of a triangle. Its individual marginals are Beta$(1,2)$, so three uniform marginal priors do not describe it.

---

Source: `course/advanced/08_categorical_conjugacy.md:76–109`

## Updating and the full covariance

Multiplying likelihood and prior adds exponents:

$$p(\theta\mid y)\propto\prod_j\theta_j^{\alpha_j+y_j-1},\qquad
\theta\mid y\sim\operatorname{Dirichlet}(a),\quad a=\alpha+y.$$

Below, $T=\sum_j a_j=A+n$. The posterior mean is a weighted average:

$$E[\theta_j\mid y]=\frac{a_j}{T}
=\frac{A}{A+n}\frac{\alpha_j}{A}+\frac{n}{A+n}\frac{y_j}{n},\quad n>0.$$

The prior shapes act algebraically like added counts, but they need not represent previous observations. Treating an elicited prior and the same historical data as independent sources would count information twice. For $n=0$, the posterior is the prior.

To derive moments, rather than memorize them, multiply the density by a monomial. For nonnegative integer $r_j$,

$$E\!\left[\prod_j\theta_j^{r_j}\mid y\right]=\frac{B(a+r)}{B(a)}.$$

The gamma recurrence then gives

$$E[\theta_j]=\frac{a_j}{T},\quad
E[\theta_j^2]=\frac{a_j(a_j+1)}{T(T+1)},\quad
E[\theta_i\theta_j]=\frac{a_i a_j}{T(T+1)}\quad(i\ne j).$$

Subtract products of means:

$$\operatorname{Var}(\theta_j)=\frac{a_j(T-a_j)}{T^2(T+1)},\qquad
\operatorname{Cov}(\theta_i,\theta_j)=-\frac{a_i a_j}{T^2(T+1)}.$$

Equivalently, with $q=a/T$,

$$\operatorname{Cov}(\theta)=\frac{\operatorname{diag}(q)-qq^T}{T+1}.$$

The off-diagonal covariances are negative. This reflects competing shares of a fixed total, not a causal effect of resolving a job on another outcome. Each row sums to zero; the full matrix is singular because the sum of the probabilities has zero variance. Independent beta draws erase this constraint, even when each beta is the correct marginal.

---

Source: `course/advanced/08_categorical_conjugacy.md:111–124`

## Work the repair example

Use the stipulated prior $\operatorname{Dirichlet}(2,1,1)$, with mean $(1/2,1/4,1/4)$ and concentration four. Observing $(5,3,0)$ gives

$$a=(7,4,1),\quad T=12,\quad E[\theta\mid y]=(7/12,1/3,1/12).$$

The prior normalizer is $B(2,1,1)=1/6$, and the posterior normalizer is $B(7,4,1)=1/9240$. The complete posterior covariance is

$$\operatorname{Cov}(\theta\mid y)=\frac1{1872}
\begin{pmatrix}35&-28&-7\\-28&32&-4\\-7&-4&11\end{pmatrix}.$$

The replacement probability has marginal Beta$(1,11)$ distribution. Its mean $1/12$ is a probability, not a prediction that exactly one of the next twelve jobs will require replacement. Its CDF is $1-(1-p)^{11}$, so the equal-tail 95% credible interval is approximately $(0.002299,0.284914)$. This broad interval reflects how little eight jobs establish about a rare category under this prior. It describes uncertainty in the common probability; a prediction interval for a replacement count must also include future sampling variation.

Sequential updating must agree with the batch calculation. For example, first observing $(2,1,0)$ gives $(4,2,1)$; adding $(3,2,0)$ gives $(7,4,1)$. Under the stated common-vector likelihood, any ordering of the eight jobs produces the same posterior. Order invariance is a consequence of the model, not evidence that real temporal changes are absent.

---

Source: `course/advanced/08_categorical_conjugacy.md:126–179`

## Integrate a future count vector

Let $Z$ be the category counts in $m$ future jobs, with $\sum_j z_j=m$. Conditional on $\theta$, use a multinomial. Integrating over the posterior,

$$\begin{aligned}
p(z\mid y)&=\frac{m!}{\prod_j z_j!}\int\prod_j\theta_j^{z_j}
\frac{\prod_j\theta_j^{a_j-1}}{B(a)}\,d\theta\\
&=\frac{m!}{\prod_j z_j!}\frac{B(a+z)}{B(a)}\\
&=\frac{\Gamma(m+1)\Gamma(T)}{\Gamma(T+m)}
\prod_j\frac{\Gamma(a_j+z_j)}{\Gamma(a_j)\Gamma(z_j+1)}.
\end{aligned}$$

This is the Dirichlet–multinomial count law. [Stan's distribution reference](https://mc-stan.org/docs/functions-reference/multivariate_discrete_distributions.html) supplies a separate formula check. With $m=1$, it reduces to the posterior mean probabilities. For larger $m$, substituting the posterior mean in a multinomial generally changes the distribution.

For three future jobs there are $\binom{m+K-1}{K-1}=\binom52=10$ vectors. The coefficient follows by placing two separators among three job-count marks. The following complete table is also a text alternative to the figure. The lab checks it by a separate enumeration of all $3^3=27$ ordered paths using exact fractions.

| Resolved | Revisit | Replacement | Predictive probability |
|---:|---:|---:|---:|
| 0 | 0 | 3 | $1/364$ |
| 0 | 1 | 2 | $1/91$ |
| 0 | 2 | 1 | $5/182$ |
| 0 | 3 | 0 | $5/91$ |
| 1 | 0 | 2 | $1/52$ |
| 1 | 1 | 1 | $1/13$ |
| 1 | 2 | 0 | $5/26$ |
| 2 | 0 | 1 | $1/13$ |
| 2 | 1 | 0 | $4/13$ |
| 3 | 0 | 0 | $3/13$ |

For example, the ordered path resolved–revisit–replacement has probability
$\frac7{12}\frac4{13}\frac1{14}=1/78$. All six orders give the same product, so the count vector $(1,1,1)$ has mass $6/78=1/13$. A repeated category increments its own numerator: three resolved jobs have probability $\frac7{12}\frac8{13}\frac9{14}=3/13$. This is a predictive updating identity, not a physical claim that each repair changes the underlying service probabilities.

The expected count and full covariance follow from total expectation and total covariance. Given $\theta$,
$E[Z\mid\theta]=m\theta$ and $\operatorname{Cov}(Z\mid\theta)=m(\operatorname{diag}(\theta)-\theta\theta^T)$. Therefore

$$E[Z\mid y]=mq,$$

$$\begin{aligned}
\operatorname{Cov}(Z\mid y)
&=E[\operatorname{Cov}(Z\mid\theta)\mid y]+\operatorname{Cov}(m\theta\mid y)\\
&=\frac{mT}{T+1}(\operatorname{diag}(q)-qq^T)
+\frac{m^2}{T+1}(\operatorname{diag}(q)-qq^T)\\
&=m\frac{T+m}{T+1}(\operatorname{diag}(q)-qq^T).
\end{aligned}$$

Thus $\operatorname{Var}(Z_j)=mq_j(1-q_j)(T+m)/(T+1)$ and
$\operatorname{Cov}(Z_i,Z_j)=-mq_iq_j(T+m)/(T+1)$ for $i\ne j$.
The variance inflation relative to a fixed-$q$ multinomial is $(T+m)/(T+1)$, here $15/13$. Direct weighted summation over the ten rows yields

$$E[Z]=(7/4,1,1/4),\qquad
\operatorname{Cov}(Z)=\frac1{208}
\begin{pmatrix}175&-140&-35\\-140&160&-20\\-35&-20&55\end{pmatrix}.$$

These are count units and squared count units. The expected replacement count is $1/4$, while its variance is $55/208$. As $T$ grows at fixed $q$, shared uncertainty shrinks and the predictive covariance approaches the multinomial covariance. For $m=1$ there is no inflation.

---

Source: `course/advanced/08_categorical_conjugacy.md:181–201`

## Merge categories without changing the question's meaning

The gamma construction also proves aggregation. Independent unit-rate gamma variables add their shapes. Consequently, for any nonempty proper subset $S$,

$$\theta_S=\sum_{j\in S}\theta_j\sim
\operatorname{Beta}\left(\sum_{j\in S}a_j,\ T-\sum_{j\in S}a_j\right).$$

More generally, merging disjoint groups that partition all categories gives another Dirichlet with summed shapes. Aggregate the observed counts by the same rule; updating before or after merging agrees. One cannot invent a finer split by dividing a shape arbitrarily without adding a new prior assumption about the finer categories.

For replacement versus everything else, the posterior is Beta$(1,11)$. The future replacement count $W=Z_P$ is beta-binomial:

$$p(W=k\mid y)=\binom3k\frac{B(1+k,11+3-k)}{B(1,11)}.$$

Summing the rows in the table gives masses $(11/14,33/182,11/364,1/364)$ for $k=0,1,2,3$. In particular,

$$P(W\geq1\mid y)=1-\frac{11\cdot12\cdot13}{12\cdot13\cdot14}
=\frac3{14}\approx0.214286.$$

Under this model, the probability of needing at least one replacement in the next three jobs is about 21%. This calculation can inform a stock discussion, but selecting inventory also requires costs, lead times and the consequences of a shortage. It is neither a guarantee nor a measured service failure rate.

The plug-in binomial fixes $\theta_P=1/12$ and gives $1-(11/12)^3=397/1728\approx0.229745$. It has a smaller variance yet a larger probability of at least one replacement in this example. Shared uncertainty increases both the mass at zero and the mass at two or three. “More uncertainty means every bad-event probability rises” is false. Here convexity of $(1-p)^3$ implies $E[(1-p)^3]\geq(1-E[p])^3$, explaining the direction of the no-replacement comparison.

---

Source: `course/advanced/08_categorical_conjugacy.md:203–207`

## Relabelling is not changing the prior

If categories are reordered as replacement, resolved, revisit, reorder **all** arrays: the prior becomes $(1,2,1)$, the data $(0,5,3)$, and the posterior $(1,7,4)$. The original future vector $(2,0,1)$ is now $(1,2,0)$ and retains probability $1/13$. Means and covariance rows and columns permute in the same way. Changing only the names while leaving shapes attached to old array positions changes the model.

The prior need not be symmetric for relabelling invariance. Symmetry means equal prior treatment of different named categories. Relabelling means the same model represented in a different order. Lab 22 checks all six permutations, including their full covariance matrices.

---

Source: `course/advanced/08_categorical_conjugacy.md:209–215`

## A sampling zero and a structural zero need different models

A **sampling zero** means a possible category was not observed in this sample. The repair example is such a case: a positive prior shape remains positive after adding zero. Increasing the sample of nonreplacement jobs will lower predicted replacement risk, without making it exactly zero after a finite sample.

A **structural zero** means the event is impossible within the stated population and coding system. For example, a service restricted to a component that is never replaceable may have only resolved and revisit as admissible statuses. Then construct a two-category model on that support and set the excluded category to zero by definition. Do not pass a zero shape to an ordinary Dirichlet density, whose positive-shape assumption was used in its derivation. Removing a category after seeing its count is zero is not independent evidence of impossibility. If structural status is itself uncertain, a model allowing a point mass on the boundary requires an explicit additional assumption.

Neither distinction excuses unrecorded outcomes. Missing status is not automatically a resolved job or a sampling zero. The denominator and follow-up rules need an audit before fitting. A redesign of coding, eligibility or observation horizon changes the population and may require a new prior or likelihood.

---

Source: `course/advanced/08_categorical_conjugacy.md:217–232`

## Shared uncertainty versus actual batch heterogeneity

The calculation above draws one uncertain $\theta$ and uses it for all future jobs. Conditional on $\theta$, jobs are independent. After integrating it out, two jobs' replacement indicators have covariance $\operatorname{Var}(\theta_P)>0$: evidence that replacement is common would affect both predictions. Conversely, indicators for different categories on different jobs have covariance $\operatorname{Cov}(\theta_i,\theta_j)<0$. Within a single job the indicators are mutually exclusive, with covariance $-q_iq_j$. These are three different covariance questions.

A different scientific model says each batch $b$ has its own probability vector:

$$\theta_b\mid\mu,\kappa\overset{\mathrm{ind}}\sim\operatorname{Dirichlet}(\kappa\mu),\qquad
Y_b\mid\theta_b\sim\operatorname{Multinomial}(n_b,\theta_b).$$

Here $\kappa$ describes variation across batches conditional on hyperparameters; it is not the posterior sample size for a single shared vector. Integrating a batch vector produces the same mathematical count family, for a different reason. [PyMC's batch construction](https://www.pymc.io/projects/examples/en/latest/mixture_models/dirichlet_mixture_of_multinomials.html) explicitly assigns each batch its own vector. Lab 22 does not fit this hierarchy or estimate heterogeneity.

For two groups of three jobs sharing our posterior vector, the covariance between their count vectors is $9\operatorname{Cov}(\theta\mid y)$; the replacement-to-replacement entry is $11/208$. If instead the two groups independently draw vectors from Dirichlet$(7,4,1)$ with those shapes held fixed, each group has the same ten-state marginal, but cross-group covariance is zero. If hyperparameters are learned and shared, integrating their uncertainty can also induce cross-batch dependence. Zero covariance is conditional on the fixed-hyperparameter comparison, not a universal claim about hierarchical models.

To simulate the shared-vector prediction, draw $\theta$ **once per simulated future collection**, then draw all its jobs or batches using that vector. To simulate independent physical batch variation with fixed hyperparameters, draw one vector per batch. Drawing a fresh independent vector for every individual job removes within-collection sharing and yields a multinomial with the mean probabilities. All three recipes have the same one-job marginal; their joint predictions differ.

Repeated batches with scientifically meaningful labels, enough replication and checks of changing case mix are needed to investigate heterogeneity. A single pooled count vector and an overdispersed predictive distribution cannot establish it. Preserve batch labels before pooling; a convenient conjugate calculation cannot recover labels that were discarded.

---

Source: `course/advanced/08_categorical_conjugacy.md:234–238`

## Diagnose independent beta fits

Each Dirichlet coordinate has a valid beta marginal, Beta$(a_j,T-a_j)$. Correct marginal means sum to one, but **independent draws from those marginals almost surely do not**. For the worked posterior, independence would give variance $78/1872=1/24$ to the sum of the three probabilities; the joint Dirichlet gives exactly zero. Renormalizing independent beta draws changes their marginals and does not generally reconstruct the intended Dirichlet.

Using unrelated Beta$(1,1)$ priors for each category-versus-rest analysis is a further error if presented as one categorical prior. With the eight jobs, their three posterior means would sum to $(6+4+1)/10=1.1$. A compatible Dirichlet prior supplies both coherent marginals and their dependence. Separate binary analyses can answer separate questions, but their outputs cannot automatically be combined into a probability vector for exclusive categories.

---

Source: `course/advanced/08_categorical_conjugacy.md:240–248`

## Run, check and interpret

Run [Lab 22](../../labs/22_categorical_conjugacy.py) with `.venv/bin/python -B labs/22_categorical_conjugacy.py`. Its percent cells are the authoritative notebook source. It saves the [numerical result](../../artifacts/results/22_categorical_conjugacy.json) and the figure below; no external dataset or random fit is required. The result includes every count vector, exact fractions, probability and count covariance matrices, aggregation and relabelling checks, and limitations.

![All ten future count probabilities and the replacement marginal under shared uncertainty and a fixed posterior mean. The complete numerical alternative appears in the tables and formulas above.](../../artifacts/figures/22_categorical_conjugacy.svg)

The log-gamma implementation is compared with SciPy and with exact ordered-path enumeration. Independent tests also integrate a simplex kernel, check posterior moments and mixed moments, enumerate sequential updates and check cross-batch dependence. Numerical agreement checks the implementation under the model; it does not validate exchangeability or the stipulated prior.

Before changing code, predict what merging resolved and revisit will do to the replacement marginal. Then change the future horizon, verify normalization and moments, and explain the change in variance inflation. Finally write the two batch simulation recipes and identify which evidence would justify one scientifically. These are worked-example explorations. The three separate optional assessed tasks in the [advanced question bank](../exercises/questions.md) address derivation, changed-category prediction and diagnosis of independent-beta misuse, using different givens.

---

Source: `course/advanced/09_multivariate_hierarchy.md:1–5`

# A09 · Learning correlated depot effects

**Prerequisites:** [continuous models](../chapters/04_continuous.md), [Hamiltonian Monte Carlo](../chapters/06_hmc.md), [regression](../chapters/07_regression.md), [hierarchical models](../chapters/09_hierarchical.md), [linear algebra](../appendices/03_linear_algebra.md), and [numerical computation](../appendices/04_numerics.md). This optional continuation takes an estimated 8–12 hours including the lab and an executed repair memo. That estimate has not been piloted.

**Objectives:** A09.O1 Construct and interpret covariance through scales and correlation. A09.O2 Make existing- and new-group predictions with shared draws and within/between contrasts. A09.O3 Diagnose and re-evaluate equivalent parameterizations.

---

Source: `course/advanced/09_multivariate_hierarchy.md:7–13`

## The question: does a depot's baseline tell us about its workload response?

A fictional service company records visit duration at twelve depots. Some depots have few recorded visits, and some operate over a narrow range of workloads. A dispatcher wants to predict several visits at an existing depot and at a depot without duration records. She also asks whether depots with longer baseline service times tend to be more sensitive to workload.

An intercept-only hierarchy cannot answer that last question: it requires a different workload slope at each depot and an estimated relationship between intercepts and slopes. A table of separately fitted slopes is also inadequate when the smallest depot has only two observations. The model must express both the pooling assumption and uncertainty about the distribution that supplies the pooling.

Everything in this example is original synthetic teaching data. Depot selection, design, coefficients and priors are stipulated, not elicited business evidence. The numerical exercise can expose implementation and computational mistakes. It cannot establish that these depots represent a real population or that workload causes longer visits.

---

Source: `course/advanced/09_multivariate_hierarchy.md:15–37`

## Separate within-depot and between-depot workload

Let $x_{ij}$ be workload in jobs for visit $i$ at depot $j$, and let $\bar x_j$ be that depot's design mean. Define

$$w_{ij}=\frac{x_{ij}-\bar x_j}{10},\qquad q_j=\frac{\bar x_j-50}{10},\qquad
y_{ij}=\log\!\left(\frac{\text{duration}_{ij}}{1\text{ minute}}\right).$$

The denominator makes the logarithm dimensionless. A one-unit within-depot contrast means ten additional jobs relative to that depot's mean. A one-unit between-depot contrast means ten additional jobs in a depot's average workload. The lab constructs the workload design before generating outcomes; no service-time information enters either centering operation.

Our sampling model is

$$y_{ij}\mid b_j,\theta\sim N\!\left(\alpha+b_{0j}+(\beta_W+b_{1j})w_{ij}+\beta_Bq_j,\;\sigma^2\right),$$

$$b_j=\begin{pmatrix}b_{0j}\\b_{1j}\end{pmatrix}\mid\Sigma\sim N_2(0,\Sigma),
\qquad j=1,\ldots,J.$$

The distribution notation uses **variance** as the second normal parameter. The PyMC implementation takes **standard deviation**. Conditional on the group effects and population parameters, visit errors are independent. This assumption excludes remaining serial dependence, shared visit shocks and residual variance differences between depots.

At a fixed depot, changing $w$ to $w+1$ changes expected log duration by $\beta_W+b_{1j}$. It multiplies the conditional median duration by $\exp(\beta_W+b_{1j})$. In contrast, comparing population-average predictions at the same within-depot deviation but with $q$ increased by one changes expected log duration by $\beta_B$. Two particular depots also differ in their realized intercept and slope effects. These are distinct comparisons, even though both are expressed in ten-job units.

For example, a depot with $\bar x=40$ has $q=-1$; a visit at workload 50 has $w=1$. A depot with $\bar x=60$ has $q=1$; a visit at workload 50 has $w=-1$. They share the same raw workload but occupy different positions relative to their own operation. Replacing both terms by one coefficient of $(x-50)/10=w+q$ imposes equality of the population within and between coefficients. That is an additional model restriction, not harmless centering.

We condition on known design means. For prediction at a new depot, the dispatcher supplies a planned or externally known mean workload. If that mean is uncertain, inferred from a short future sequence, or changed by a policy intervention, it needs a model too. Do not quietly replace a training mean with a future sample mean and claim the same predictive target.

---

Source: `course/advanced/09_multivariate_hierarchy.md:39–63`

## Build a covariance that means something

Write

$$\Sigma=D\Omega D,\qquad D=\operatorname{diag}(\tau_0,\tau_1),\qquad
\Omega=\begin{pmatrix}1&\rho\\\rho&1\end{pmatrix}.$$

Thus

$$\Sigma=\begin{pmatrix}\tau_0^2&\rho\tau_0\tau_1\\\rho\tau_0\tau_1&\tau_1^2\end{pmatrix},
\qquad |\Sigma|=\tau_0^2\tau_1^2(1-\rho^2).$$

Positive scales and $-1<\rho<1$ give a positive-definite covariance. The scales answer separate questions: how much baseline log duration varies, and how much the log-duration response per ten jobs varies. Correlation describes how these deviations co-vary. It is not the correlation between all observed durations and workloads.

A lower triangular factor that preserves this decomposition is

$$L=\begin{pmatrix}\tau_0&0\\\rho\tau_1&\tau_1\sqrt{1-\rho^2}\end{pmatrix},\qquad LL^T=\Sigma.$$

If $z_0,z_1$ are independent standard normals, $b_0=\tau_0z_0$ and $b_1=\tau_1(\rho z_0+\sqrt{1-\rho^2}z_1)$. Both effects share $z_0$, which creates their covariance. Multiplying the slope by $\tau_0$ instead of $\tau_1$, or putting $L$ on the wrong side of a row vector, creates a different model. The lab's independent tests check the reconstructed covariance and every recorded noncentered effect vector.

Conditioning a bivariate normal also gives a direct interpretation:

$$b_1\mid b_0,\tau,\rho\sim N\!\left(\rho\frac{\tau_1}{\tau_0}b_0,\;\tau_1^2(1-\rho^2)\right).$$

As a worked illustration, fix $\tau_0=0.4$, $\tau_1=0.2$, $\rho=0.5$ and a known intercept deviation $b_0=0.3$. The conditional slope deviation has mean $0.075$ and standard deviation $\sqrt{0.03}\approx0.173$. With population slope $0.18$, its conditional mean total slope is $0.255$. This is not a plug-in recipe for the fitted model: a real depot intercept and all three covariance parameters remain uncertain and must be integrated over.

---

Source: `course/advanced/09_multivariate_hierarchy.md:65–91`

## Put priors on implications, not just matrix entries

The lab uses independent population priors

$$\alpha\sim N(2.8,0.6^2),\quad\beta_W\sim N(0.18,0.3^2),\quad
\beta_B\sim N(0.25,0.4^2),$$

$$\tau_0\sim\operatorname{HalfNormal}(0.65),\quad
\tau_1\sim\operatorname{HalfNormal}(0.45),\quad
\sigma\sim\operatorname{HalfNormal}(0.5),\quad\Omega\sim\operatorname{LKJ}(2).$$

Here HalfNormal arguments are scales. The scale priors are proper and allow values near zero. They neither guarantee strong identification nor prevent narrow posterior geometry. At typical workload, $\exp(2.8)\approx16.4$ minutes is the prior median from the population intercept alone; random depot effects, regression uncertainty and visit noise make full predictions much broader.

The LKJ density is proportional to $|\Omega|^{\eta-1}$ on positive-definite correlation matrices. Its shape and domain are specified in the [Stan correlation-distribution reference](https://mc-stan.org/docs/functions-reference/correlation_matrix_distributions.html). For **two** effects, the normalizing integral is especially transparent:

$$\int_{-1}^{1}(1-r^2)^{\eta-1}dr=B(1/2,\eta),\qquad
p(\rho)=\frac{(1-\rho^2)^{\eta-1}}{B(1/2,\eta)}.$$

Set $u=(\rho+1)/2$. Since $d\rho/du=2$, the transformed density is proportional to $u^{\eta-1}(1-u)^{\eta-1}$, with the beta normalizer. Therefore the lab implements the exact bivariate LKJ law using $u\sim\operatorname{Beta}(\eta,\eta)$ and $\rho=2u-1$. It does not fix correlation or estimate it from fitted group means. This beta identity with shapes $(\eta,\eta)$ must not be transferred unchanged to larger correlation matrices.

At $\eta=1$ the bivariate correlation is uniform. At $\eta=2$, $p(\rho)=3(1-\rho^2)/4$, so $E[\rho]=0$, $E[\rho^2]=1/5$, and

$$P(|\rho|>0.8)=2\int_{0.8}^1\frac34(1-r^2)dr=0.056.$$

The corresponding probability under $\eta=1$ is $0.20$. These are substantial differences about extreme association, not universally good or bad defaults. The scales-and-correlation construction also allows domain judgments for each scale separately; see the [Stan multivariate hierarchical regression discussion](https://mc-stan.org/docs/stan-users-guide/regression.html#multivariate-priors-for-hierarchical-models).

The lab makes 5,000 prior draws and predicts three visits at a new depot with $q=0.5$ and $w=-1,0,1$. Under the base prior, the simulated medians are about 15.5, 19.1 and 22.1 minutes; the respective 90% intervals are about 2.3–108.7, 3.6–99.6 and 3.4–146.4 minutes. These wide intervals merit discussion before any data are fitted. About 7.6% of these simulated visits fall outside a **teaching review range** of 2–120 minutes. That range is not a physical impossibility or a likelihood truncation.

---

Source: `course/advanced/09_multivariate_hierarchy.md:93–93`

Doubling both effect-scale priors increases that share to about 19.3%, and the upper 90% bound at $w=1$ rises to about 401 minutes. Changing only $\eta$ to one yields about 7.5% outside the range, but increases extreme-correlation prior mass markedly. Similar marginal duration summaries can hide very different beliefs about joint responses. These simulation values have Monte Carlo variation; the exact correlation-tail calculations above do not. Neither alternative is used to quietly repair a sampler: both change the statistical target.

---

Source: `course/advanced/09_multivariate_hierarchy.md:95–111`

## How the data supply different amounts of information

The weak regime has depot visit counts

$$2,3,4,5,6,8,10,12,15,18,22,28,$$

for a total of 133. Its within-depot workloads have a narrow range and its generating residual standard deviation is 0.65. The strong regime uses

$$40,45,50,55,60,65,70,75,80,90,100,120,$$

for a total of 850, a wider workload range, and residual standard deviation 0.28. Both panels share the same twelve generated depot effects and design means; they have different visit realizations. The generating effect scales are 0.30 and 0.18, with correlation 0.55. Those values are a simulation record, not answers that a finite-data posterior must recover exactly.

The relevant information for a depot slope is not merely its observation count. At fixed noise scale it also depends on $\sum_i w_{ij}^2$. A hundred visits at nearly the same workload can leave the slope weakly identified. Likewise, hundreds of visits at twelve depots do not become hundreds of independent depot pairs for estimating correlation. The strong regime estimates each depot effect more accurately, while the population covariance is still informed by only twelve such effects.

The twelve realized synthetic slope deviations average about $0.132$, even though their generating distribution has mean zero. Their average total slope is therefore about $0.22+0.132=0.352$, rather than $0.22$. This is ordinary finite-group variation: zero population expectation is not a sample sum-to-zero constraint. Precise visits reveal the realized depot slopes; they do not remove uncertainty about how representative those twelve slopes are of the population. Requiring a posterior to reproduce the generating population coefficient exactly would be an invalid acceptance test.

The planned predictions use $w=-1,0,1$. The two outer workload values extend beyond the weak panel's narrow observed support, especially at the depot with only two visits. Their intervals therefore depend on the assumed linear workload response outside that depot's observations. They are useful for exposing uncertainty, but are not evidence that extrapolation is reliable. The new depot's specified $q=0.5$ lies within the design's between-depot range; that does not supply missing within-depot information.

---

Source: `course/advanced/09_multivariate_hierarchy.md:113–136`

## Derive the fixed-hyperparameter update

For one depot, write $r=y-\mu$, where $\mu_i=\alpha+\beta_Ww_i+\beta_Bq$, and let $X$ have rows $(1,w_i)$. At fixed $\Sigma$ and $\sigma$, the log posterior kernel in $b$ is

$$-\frac12b^T\Sigma^{-1}b-\frac{1}{2\sigma^2}(r-Xb)^T(r-Xb).$$

Expanding the square and collecting terms gives precision and linear term

$$Q=\Sigma^{-1}+\frac{X^TX}{\sigma^2},\qquad h=\frac{X^Tr}{\sigma^2}.$$

Complete the square, $b^TQb-2b^Th=(b-m)^TQ(b-m)-m^TQm$, where $Qm=h$. Hence

$$b\mid y,\theta\sim N_2(m,V),\qquad V=Q^{-1},\qquad m=Q^{-1}h.$$

Use linear solves rather than computing a matrix inverse to multiply a vector. If $X^TX$ is small, prior precision dominates and the effect shrinks toward zero. If it is large in one direction only, pooling remains strong in the other direction. Correlation couples the directions, so shrinking each univariate regression independently misses part of the update.

For a numerical reference, take $\Sigma=\left(\begin{smallmatrix}0.49&-0.07\\-0.07&0.0625\end{smallmatrix}\right)$, $\sigma=0.6$, $w=(-1,0.5,1.5)$, $y=(0.3,-0.2,0.8)$ and $\mu=(0.1,0.2,0.3)$. The update is approximately

$$m=(0.066672,0.021050)^T,\qquad
V=\begin{pmatrix}0.102967&-0.019680\\-0.019680&0.038520\end{pmatrix}.$$

An independent route starts with $\operatorname{Cov}(y)=X\Sigma X^T+\sigma^2I$ and $\operatorname{Cov}(b,y)=\Sigma X^T$, then conditions the joint Gaussian. The tests also integrate the original likelihood times prior directly over both effect coordinates. An implementation that swaps an effect scale, drops the likelihood normalizer, or uses $\sigma$ where $\sigma^2$ is required will fail appropriate checks.

This conditional Gaussian is useful for validating the **actual hierarchy**, but it is not its full posterior. When covariance and residual scale are learned, the posterior for each depot is a mixture of these conditional distributions. Freezing those hyperparameters at estimates understates uncertainty.

---

Source: `course/advanced/09_multivariate_hierarchy.md:138–152`

## Two coordinates, one target

In centered coordinates we sample $b_j\sim N_2(0,\Sigma)$. In noncentered coordinates we sample $z_j\sim N_2(0,I)$ and set $b_j=Lz_j$. The data likelihood is evaluated at exactly the same $b_j$ in both models. A row-oriented array implements this as `b = z @ L.T`.

For $J$ depots, the absolute determinant of the transformation from all $z_j$ to all $b_j$ is $|L|^J$. With hyperparameters held fixed,

$$\log p_z(z\mid\Sigma)=\log p_b(Lz\mid\Sigma)+J\log|L|,$$

$$\log|L|=\log\tau_0+\log\tau_1+\tfrac12\log(1-\rho^2).$$

This is an equality of probability measures expressed in different coordinates, not an equality of raw density heights. In the joint transformation $(z,\tau,\rho)\mapsto(b,\tau,\rho)$, cross-derivatives of $b$ with respect to the hyperparameters do not add another factor: the Jacobian is block triangular. The determinant is still the product of the effect blocks. In code that directly declares standard-normal $z$, the induced $b$ distribution is already correct; adding a second $J\log|L|$ term would be a mistake.

There are further Jacobians in the sampler's unconstrained coordinates. Positive scales represented as $s=\exp(v)$ contribute $\log s$. A beta variable $u=\operatorname{logistic}(a)$ contributes $\log u+\log(1-u)$. Our independent density test compares the compiled PyMC joint density with normalized SciPy prior and likelihood densities, including these transformations. It then compares the two models after adding $J\log|L|$. Merely checking two handwritten functions against one another would not establish what the fitted code actually samples.

Why change coordinates? When data barely inform a depot, its effect and a small population scale can form a narrow joint region in centered coordinates. Expressing the weakly informed effect as a standard-normal $z$ can reduce that dependence. With highly informative depot observations, $b$ may be well constrained, while $z=L^{-1}b$ must move jointly with $L$; centering can then work better. This dependence on data information is described in [Stan's reparameterization discussion](https://mc-stan.org/docs/stan-users-guide/efficiency-tuning.html#hierarchical-models-and-the-non-centered-parameterization). The lab tests both regimes rather than declaring one coordinate system universally superior.

---

Source: `course/advanced/09_multivariate_hierarchy.md:154–174`

## Predictions share a depot, not just a label

For an existing depot, a posterior draw already contains its effect vector. For each posterior draw, use that same vector in **all** planned visits to that depot, and then draw independent visit errors. Replacing the learned effect with a fresh draw from the population discards that depot's records and answers a new-depot question instead.

For a new depot at each posterior draw:

1. Take the population coefficients, $\Sigma$ and $\sigma$ from that draw.
2. Draw one $b_{\mathrm{new}}\sim N_2(0,\Sigma)$ for that depot.
3. Reuse it for every planned visit there; draw one independent visit error per visit.
4. For a second new depot, draw a second effect vector. Reuse the same population draw for both.

At fixed population parameters, put $a(w)=(1,w)^T$. For two distinct visits to one new depot,

$$\operatorname{Cov}(y_a,y_b\mid\theta)=a(w_a)^T\Sigma a(w_b)
=\tau_0^2+(w_a+w_b)\rho\tau_0\tau_1+w_aw_b\tau_1^2.$$

The variance of a single visit additionally includes $\sigma^2$. For two different new depots, the conditional covariance of their log durations is zero under this model. After integrating uncertain population coefficients, predictions at different depots can still be dependent. Apply the law of total covariance: average the conditional covariance and add the covariance of the conditional means.

For example, with $\tau=(0.5,0.3)$, $\rho=0.6$, $\sigma=0.2$ and visits at $w=0,1$, the shared-depot covariance is $0.25+0.09=0.34$. Redrawing a depot effect at every visit removes that term conditional on the population parameters. Single-visit histograms might look correct, while uncertainty for a depot's average, total workload response, or probability that **all** visits exceed a threshold is wrong. The lab tests this failure explicitly.

At fixed lognormal parameters, the median is $\exp(m)$ and the mean is $\exp(m+v/2)$. For parameter mixtures, obtain predictive quantiles from propagated predictive draws or the averaged CDF. A physical-scale mixture mean requires checking that the integral of $\exp(m+v/2)$ is finite; a finite simulated average does not establish this. This lab reports physical-scale quantiles and event probabilities.

---

Source: `course/advanced/09_multivariate_hierarchy.md:176–187`

## Units and zero-sum restrictions can change the model

For a linear predictor $a+bx$, changing to $x'=(x-c)/s$ and $y'=Ay+d$ yields

$$\begin{pmatrix}a'\\b'\end{pmatrix}
=A\begin{pmatrix}1&c\\0&s\end{pmatrix}\begin{pmatrix}a\\b\end{pmatrix}
+\begin{pmatrix}d\\0\end{pmatrix},\qquad
\Sigma'=T\Sigma T^T,\quad T=A\begin{pmatrix}1&c\\0&s\end{pmatrix}.$$

Residual scale changes to $|A|\sigma$. For $n$ observed responses the transformed density has log Jacobian $n\log|A|$. Scaling without shifting leaves correlation unchanged for positive units, but moving the intercept's reference point mixes slope into intercept and can change their correlation. Retaining independent priors with the same numerical parameters after such changes generally defines a new target. For the lab's logarithmic response, changing minutes to seconds adds $\log60$ to the intercept; it does not multiply log-response coefficients by 60.

Likewise, forcing $\sum_jb_j=0$ is not automatically equivalent to independent zero-mean normal effects. For scalar independent effects of variance $\tau^2$, subtracting their sample average makes each variance $\tau^2(1-1/J)$ and introduces covariance $-\tau^2/J$ between different effects. If the population intercept absorbs that average, its induced prior also changes and depends on $\tau$. Equivalent constrained coordinates are possible only with the full induced joint prior. Adding a zero-sum restriction while leaving other priors unchanged is a model intervention and must be labeled as such.

---

Source: `course/advanced/09_multivariate_hierarchy.md:189–205`

## Execute a diagnosis, intervention and re-evaluation

[Lab 23](../../labs/23_multivariate_hierarchy.py) supplies a complete recorded experiment. The matching [result](../../artifacts/results/23_multivariate_hierarchy.json) contains every initial and repaired fit, predictive summaries and a diagnosis ledger. It is a worked computational reference for self-study, not an assessed answer key. The script and helper files are authoritative; the generated notebook explains when it is replaying evidence.

The declared initial comparison uses four chains, each with 1,000 warmup and 1,000 retained draws, in each of four fits: weak centered, weak noncentered, strong centered and strong noncentered. All use the same priors and likelihood within their regime, target acceptance 0.90 and maximum tree depth 12. Separate deterministic seeds are assigned before seeing any diagnostic. Chain execution and BLAS each use one core. The recording keeps both warmup and retained arrays, dimensions, source snapshots, versions, UTC times, logs, wall time and process peak memory.

A failed initial numerical screen triggers the declared repair: the same target and coordinates, target acceptance 0.99, 2,000 warmup and 2,000 retained draws per chain. The original remains in the ledger. Increasing target acceptance asks adaptation for a smaller integration step; it can cost more work and does not guarantee that the problem disappears. More draws help precision only when exploration is adequate. Changing a prior to eliminate a narrow region is instead a scientific model revision requiring renewed prior and posterior criticism.

The numerical screens are rank-normalized $\widehat R<1.01$, bulk and tail ESS above 400, no divergences or maximum-depth hits, and energy BFMI above 0.3 in every chain. These are diagnostic conventions, not mathematical sufficiency conditions. Energy BFMI compares successive energy changes with the energy distribution's variance; low values suggest poor energy exploration. The actual record retains energy quantiles, per-chain values and raw energy draws, not just a minimum or a green flag.

Mean MCSE is checked for population coefficients, each effect scale, correlation, residual scale, an existing-depot expected log duration, a new-depot expected log duration, and its conditional log-response variance. The prospective precision limits are 0.02 in each reported estimand's units, except 0.03 for correlation. A posterior standard deviation is uncertainty under the model; MCSE is uncertainty from finite simulation. A tiny MCSE does not mean correlation is precisely learned.

For an estimand with means $\hat m_C,\hat m_N$ from independently seeded coordinate runs, compare

$$|\hat m_C-\hat m_N|\quad\text{with}\quad5\sqrt{\operatorname{MCSE}_C^2+\operatorname{MCSE}_N^2}.$$

The five-MCSE rule is a declared diagnostic tolerance for this set of comparisons, not a calibrated omnibus hypothesis test. Report the values, not just “agreement.” Chains trapped in the same region can agree. MCSE from poorly explored chains can itself be misleading. An observed divergence is neither a required teaching outcome nor something to erase by selecting another seed.

---

Source: `course/advanced/09_multivariate_hierarchy.md:207–224`

Full re-evaluation also includes support and units, independent density/conditional checks, prior prediction, posterior prediction by depot, and remaining weak identification. The lab reports replicated mean, standard deviation and maximum log duration, groupwise predictive means and in-sample 90% coverage. Coverage from the same visits used to fit the model is descriptive, not held-out calibration. A posterior predictive tail probability is a model-criticism summary, not the probability that the model is true.

<!-- A09_EXECUTION_SUMMARY -->

The current complete recording `20260927T005939Z_f269cd58` produced the following results. C denotes centered and NC noncentered coordinates. ESS values are the minimum over all monitored parameters, including depot effects and noncentered auxiliaries. The JSON retains every individual estimand and chain diagnostic, not just these rounded summaries.

| Fit | Divergences | Max R-hat | Min bulk / tail ESS | Min BFMI | Correlation mean MCSE | Wall seconds |
|---|---:|---:|---:|---:|---:|---:|
| Weak C, initial | 698 | 1.583 | 7 / 4 | 0.113 | 0.0157 | 61.8 |
| Weak NC, initial | 2 | 1.005 | 1081 / 1326 | 0.850 | 0.0071 | 13.4 |
| Strong C, initial | 0 | 1.008 | 545 / 703 | 0.881 | 0.0050 | 64.7 |
| Strong NC, initial | 0 | 1.005 | 1072 / 1573 | 0.733 | 0.0054 | 59.2 |
| Weak C, repair | 14 | 1.020 | 278 / 186 | 0.104 | 0.0073 | 596.2 |
| Weak NC, repair | 0 | 1.003 | 1861 / 2546 | 0.765 | 0.0057 | 58.8 |

The weak centered initial run is unusable under the declared screens. Reparameterization improved exploration substantially, but the initial noncentered run still had two divergences. Its numerical repair passed the declared screens. The centered numerical repair took about **9.9 minutes** and still failed: fourteen divergences, poor energy exploration, R-hat above 1.01 and insufficient ESS remained. Its mean-MCSE limits passed, illustrating why apparently adequate estimand precision cannot replace exploration diagnostics. No fit hit maximum tree depth. The two strong-regime fits both passed; here NC had the higher minimum ESS. These observations support an information-dependent investigation, not a rule that centering must win with strong data.

All ten final estimand-mean comparisons met the five-combined-MCSE tolerance in each regime. For correlation, the strong-coordinate mean difference was 0.0040, against tolerance 0.0366; the weak-coordinate difference was 0.0201, against tolerance 0.0463. **Weak-coordinate agreement does not certify the centered fit:** its failed energy, divergence and convergence screens remain disqualifying. The worked weak predictions therefore use the repaired NC fit; the strong predictions use the passing NC initial fit. Every alternative remains visible in the ledger and figure.

---

Source: `course/advanced/09_multivariate_hierarchy.md:226–232`

The repaired weak fit's correlation median was about -0.025, with a 90% interval **[-0.739, 0.701]**. Its small mean MCSE, about 0.0057, does not turn that broad scientific uncertainty into a well-learned correlation. The strong NC interval was **[0.011, 0.757]**, with median 0.455: more information, still only twelve groups. A generating correlation of 0.55 is neither a required posterior mean nor a threshold for accepting computation.

For a new depot at $q=0.5$, $w=0$, the weak fit predicted a median duration of about 21.8 minutes and a 90% interval of 6.3–70.3 minutes. At existing depot zero, the corresponding prediction was 8.3 minutes with interval 2.5–28.5 minutes. The strong-fit intervals were about 10.1–37.7 minutes for the new depot and 8.6–21.4 for depot zero. Different mean workloads and conditioning information prevent treating these differences as a controlled effect of being a new depot.

The selected fits' observed mean, standard deviation and maximum log durations all lay within their corresponding central 90% replicated-statistic intervals. For the maximum, posterior predictive upper-tail probabilities were about 0.858 in the weak regime and 0.590 in the strong regime. These checks did not identify an extreme discrepancy for those particular summaries; they do not test every possible mismatch or establish predictive calibration. Groupwise in-sample coverage ranged from 50% to 100% in the weak panel and about 84% to 96% in the strong panel. The weak depot-zero value is just one of two visits inside its nominal 90% band: such tiny denominators cannot establish coverage accuracy. The JSON also reports each depot's design information, effect intervals, replicated mean and residual summaries.

The complete recorder took **855.5 seconds (14.3 minutes)** on the recorded machine, with one chain core and one thread in each installed BLAS library. Process CPU time was 851.1 seconds, peak resident memory about 409.3 MiB, and retained compressed fit arrays 23.2 MiB. Wall time includes setup inside the recorder, sampling, diagnostics and serialization; it excludes interpreter startup, earlier import work and subsequent notebook/predictive verification. Earlier attempts are preserved separately: one oversubscription interruption has an observed elapsed lower bound of 589 seconds; another incomplete recording retains two completed fits totaling 228.3 seconds, with its unfinished work unmeasured. The earlier complete recording `20260926T205711Z_ff11e2f7` took 3109.0 seconds (51.8 minutes), including a 2080.2-second (34.7-minute) failed centered repair, with 2947.2 CPU seconds and 385.7 MiB peak memory. That superseded recording remains historical evidence. All these earlier costs are additional to the current recorder's 14.3 minutes; timings depend on the execution environment and cache state.

---

Source: `course/advanced/09_multivariate_hierarchy.md:234–240`

Notebook execution explicitly replayed and verified the current `20260927T005939Z_f269cd58` recording; it was not a second NUTS run. Future changed-source recordings must refresh this summary and retain earlier evidence. This package has local mathematical/computational checks, not independent human approval or a claim that NUTS screens prove the model true.

<!-- A09_EXECUTION_SUMMARY_END -->

![Depot correlation intervals, chain energy diagnostics, and predictions at existing and new depots](../../artifacts/figures/23_multivariate_hierarchy.svg)

The upper figure panels show all fits, including the initial failures and their repairs. The lower panels distinguish visit predictions for depot zero from a new depot with $q=0.5$. These depots have different mean workloads and different conditioning information; the width and location differences are not an isolated causal effect of “being new.” The figure's labels and the JSON table provide a text alternative, and color is supplemented by points, line styles and captions.

---

Source: `course/advanced/09_multivariate_hierarchy.md:242–262`

## A small conjugate check with a carefully limited claim

A separate normal–inverse-Wishart fixture offers an independent exact calculation. It models independent **bivariate observations**, not scalar visits with correlated depot coefficients. Declare

$$y_i\mid\mu,\Sigma\sim N_2(\mu,\Sigma),\quad
\mu\mid\Sigma\sim N_2(m_0,\Sigma/\kappa_0),$$

$$p(\Sigma)\propto|\Sigma|^{-(\nu_0+d+1)/2}
\exp\!\left[-\tfrac12\operatorname{tr}(\Psi_0\Sigma^{-1})\right].$$

The exponent fixes the inverse-Wishart convention; alternative parameter names can hide different degrees of freedom. For a derivation of these conjugate families see [Murphy's Gaussian conjugacy note](https://www.cs.ubc.ca/~murphyk/Papers/bayesGauss.pdf).

With observations $(1,0),(0,1),(1,1)$, $m_0=0$, $\kappa_0=1$, $\nu_0=4$, and $\Psi_0=I$, the raw sums give $\kappa_n=4$, $\nu_n=7$, $m_n=(1/2,1/2)$, and

$$\Psi_n=I+\sum_i y_i y_i^T-4m_nm_n^T=2I.$$

Integrating both unknowns yields a bivariate Student predictive with degrees of freedom $\nu_n-d+1=6$ and scale matrix

$$\frac{\kappa_n+1}{\kappa_n(\nu_n-d+1)}\Psi_n=\frac5{12}I.$$

The t scale matrix is **not** its covariance; with six degrees of freedom the covariance is $(6/4)(5I/12)=5I/8$. Tests independently derive the update using exact rational raw moments, compare predictive density to a ratio of integrated evidences, and simulate an inverse-Wishart/normal mixture. None of these checks validates the posterior under separate half-normal scales and an LKJ correlation prior. That requires the actual-model density, conditional-Gaussian, coordinate and predictive checks already described.

---

Source: `course/advanced/09_multivariate_hierarchy.md:264–274`

## Write the repair memo

Use this sequence for your own investigation before consulting assessed solutions:

1. State the prediction target, response and predictor units, design support, priors and exchangeability assumptions. Distinguish within from between effects.
2. Predict which regime and coordinates may be difficult, then inspect all actual runs. Record uncertainty about that prediction.
3. Identify whether your intervention changes coordinates, numerical settings, data, likelihood or prior. Show a density/Jacobian argument when claiming equivalence.
4. Repeat numerical diagnostics, estimand precision and agreement checks. Retain failures and costs; do not turn a failed initial run into a disappearing draft.
5. Repeat predictive criticism and explain what remains scientifically uncertain even if numerical screens improve. For new depots, demonstrate effect reuse across visits.

A satisfactory memo can conclude that one coordinate system is unusable for a particular regime, or that an attempted repair did not resolve a problem. It must then restrict numerical claims accordingly. “All screens pass, therefore this is the true depot model” is never an adequate conclusion. The lesson's three optional assessments are `adv.multivariate_hierarchy.1`–`.3`; the final item is the executed repair memo, with no extra COMP01 item.

---

Source: `course/advanced/10_outcome_regression.md:1–5`

# A10 — Regressions for named and ordered outcomes

A fictional inspection team classifies reusable shipping containers as **ready**, **service**, or **retire**. Can load and age predict the next inspection label? Before fitting anything, sketch how you expect each category's probability to change as load increases. Must the service probability increase monotonically? Would giving the labels an order justify using the same predictor effect at both category boundaries?

A08 learned one common vector of categorical probabilities. Here that vector depends on measured predictors. This optional chapter follows L06, L08, L10, and A08: likelihoods, generalized regression, model checking, and categorical outcomes. Allow 6–8 hours for chapter, lab, investigation, and optional assessments; the estimate awaits learner pilots and adds work beyond the selected core. The observation unit is one independent inspection. The main target is the change in retirement probability between loads 25 and 75 at age five, with secondary targets covering the whole category vector and predictive frequencies.

---

Source: `course/advanced/10_outcome_regression.md:7–19`

## Start with the generative question

Code ready, service, and retire as 0, 1, and 2. Codes identify categories; treating them as measured numeric values would introduce assumptions about spacing that the labels do not supply. We generate ninety training inspections and thirty independent evaluation inspections. Load is uniform from 25 to 75 and age uniform from one to nine. Fixed transformations are

$$
x_L=(L-50)/25,\qquad x_A=(A-5)/4.
$$

Thus a one-unit change in scaled load is twenty-five load units, and a one-unit age change is four years. The transformations are declared before looking at either dataset. They make slopes interpretable over a specified range without using evaluation outcomes to choose preprocessing.

The original synthetic generator uses an ordered logistic model with linear predictor $\eta=0.9x_L+0.6x_A$ and thresholds −0.5 and 0.8. That is a teaching mechanism, not evidence that container inspection is governed by proportional odds. We fit two alternatives under proper priors. Evaluation data are not supplied to fitting functions, and no model is redesigned after evaluation scores are read.

Conditionally independent labels are a simplifying assumption. Repeated inspections of the same container, inspector disagreement, or batch effects would require additional structure. Likewise, load need not be causally assigned. The present target is predictive association under the declared data-generating and observation assumptions, not the effect of an intervention on load.

---

Source: `course/advanced/10_outcome_regression.md:21–34`

## Nominal regression: predict a simplex

A nominal model treats the labels as distinct without imposing an ordering. Define logits

$$
z_0=0,\quad z_1=\alpha_1+\beta_{L1}x_L+\beta_{A1}x_A,
\quad z_2=\alpha_2+\beta_{L2}x_L+\beta_{A2}x_A.
$$

Probabilities are $p_k=\exp(z_k)/\sum_j\exp(z_j)$, and the observed category is a categorical draw from that vector. Independent intercept priors are $N(0,1.5^2)$; independent slope priors are $N(0,1)$. Normal notation uses variance, while software accepts standard deviation. Each nonbaseline coefficient describes a log probability ratio against ready, conditional on the other predictor.

Adding a constant to every logit changes none of the probabilities: numerator and denominator gain the same multiplicative factor. If every category had an unrestricted intercept, this shift would be unidentified by the likelihood. Setting the ready logit to zero chooses coordinates. It does not mean that ready is impossible or that its probability stays fixed; its probability changes through the denominator.

A baseline change also needs a prior transformation. Subtracting an old nonbaseline logit from every logit creates differences of coefficients. Those differences are correlated under the original independent priors. If you instead assign fresh independent priors after relabeling the baseline, you have changed the prior probability model, not merely rewritten the same fit. This matters especially with limited data or rare categories.

---

Source: `course/advanced/10_outcome_regression.md:36–42`

## Worked step 1: normalize before interpreting

Take logits $(0,\log2,\log3)$. Exponentials are $(1,2,3)$, so probabilities are $(1/6,2/6,3/6)$. The retire-versus-ready probability ratio is three; retirement probability itself is one half. Interpreting a logit as a category probability would confuse the ratio scale with the response scale.

Now add 1,000 to every logit. The mathematical probabilities are unchanged, but directly exponentiating can overflow. Stable softmax subtracts the largest logit or uses log-sum-exp before exponentiating. The lab checks invariance and normalization, including extreme logits. Stability should preserve a valid model, not silently clip arbitrary invalid probabilities into range.

For independent observations the likelihood is $\prod_i p_{i,y_i}$. The vectorized log likelihood is the sum of selected log probabilities. The lab checks a direct product against that sum for an actual fitted draw. This is a small implementation check: it verifies category indexing and multiplication, not prior adequacy or the scientific fit.

---

Source: `course/advanced/10_outcome_regression.md:44–57`

## Ordered regression: two boundaries, one slope vector

An ordinal alternative uses

$$
P(Y\le k\mid x)=\operatorname{logit}^{-1}(c_k-x^\top\beta),
\qquad k=0,1,
$$

with $c_0<c_1$. We parameterize the cutpoints as $m-d/2$ and $m+d/2$, where $m\sim N(0,1.5^2)$, $\log d\sim N(\log1.3,0.4^2)$, and both slopes independently follow $N(0,1)$. The exponential of log gap is positive, guaranteeing ordered cutpoints without sorting independently drawn thresholds.

There is no additional intercept in $x^\top\beta$. If an intercept and both cutpoints could shift together, the cumulative probabilities would remain unchanged and the likelihood would not identify their common location. The midpoint provides the location; the predictor contains slopes only. Proper priors complete the model but should not disguise a redundant parameterization.

The cumulative log odds are $c_k-x^\top\beta$. Increasing scaled load by one multiplies the odds of being at or below **either** boundary by $e^{-\beta_L}$. This shared multiplier is the proportional-odds restriction. It does not assert constant probability differences, equal spacing of categories, or equal category-specific odds ratios. Ordered labels make cumulative splits meaningful; they do not demonstrate that one slope vector describes both splits.

---

Source: `course/advanced/10_outcome_regression.md:59–69`

## Worked step 2: difference cumulative probabilities

At centered predictors under the generating thresholds, cumulative probabilities are $\operatorname{logit}^{-1}(-0.5)=0.377541$ and $\operatorname{logit}^{-1}(0.8)=0.689974$. Therefore ready, service, and retire probabilities are approximately $(0.377541,0.312434,0.310026)$. The middle probability is the difference between cumulative probabilities, and the final probability is one minus the upper cumulative probability.

As the linear predictor increases, both cumulative curves decrease. Yet the gap between them can first grow and then shrink. A hump-shaped middle-category probability is therefore possible under an ordinary proportional-odds model. Seeing a service hump is not by itself a diagnostic failure. What matters is whether the two cumulative splits can share a linear predictor on the log-odds scale.

![Two cumulative logistic curves whose gap is service probability, beside prior category probabilities at centered predictors.](../../artifacts/figures/25_outcome_regression_01.svg)

The left panel depicts that construction. The right panel summarizes 4,000 prior parameter draws. At the center, nominal mean probabilities are (0.2925, 0.3515, 0.3560), while ordinal means are (0.3777, 0.2436, 0.3787). For nominal retirement probability, the central 90% prior interval is approximately [0.0231, 0.8549]; for ordinal service probability it is [0.0575, 0.4745]. These are distributions of probabilities before outcomes, not intervals containing a future category label.

Prior draws also inspect all four corners of the declared predictor domain. Across corners, nominal mean retirement probability ranges from 0.3560 to 0.3675 and ordinal mean service probability from 0.2049 to 0.2070. Individual draws are much more extreme than these averages: corner retirement upper 95th percentiles exceed 0.93 for both models. Averaging can conceal implausibly decisive prior curves. If this were a real application, review whole curves and plausible covariate ranges before observing outcomes; do not retune priors to manufacture a desired evaluation score.

---

Source: `course/advanced/10_outcome_regression.md:71–79`

## Actual fitting and numerical evidence

Lab 25 fits both models with four NUTS chains, one CPU core, 1,000 warmup iterations and 1,500 retained draws per chain, target acceptance 0.95, and jittered adaptive diagonal initialization. It repeats both fits for the changed-givens dataset and fits two intercept-only benchmarks. Named random streams separate data generation, priors, fitting, and posterior replication.

All six fits have zero divergences. The largest reported rank R-hat is 1.00201; the smallest bulk or tail effective sample size across reported parameters and targets is 2,829.45. Those pass the frozen thresholds R-hat below 1.01 and ESS at least 400. These diagnostics address sampling behavior. They do not prove a proportional-odds assumption, guarantee accuracy of every unreported tail, or transform synthetic data into empirical evidence.

For an independent reference, remove covariates and use category counts (3,2,3), retaining each model's actual priors. Nominal integration runs over two nonbaseline logits; ordinal integration runs over midpoint and log gap. Two-dimensional Gauss–Legendre rules use orders 31 and 61 over eight prior standard deviations per coordinate. The finer nominal mean vector is (0.357569, 0.269178, 0.373253); the ordinal vector is (0.361114, 0.277771, 0.361114). Symmetric outer counts and the ordinal location prior imply equal outer-category posterior means, providing another useful structural check.

The largest order-31/61 discrepancy is 0.001264 for nominal probabilities and 0.003119 for ordinal probabilities. The corresponding maximum sampler-versus-finer-rule discrepancies are about 0.004042 and 0.001337. Each category passes the declared allowance of five target-specific MCMC MCSE plus the measured quadrature refinement discrepancy. The rule comparison is a practical error estimate, not a rigorous bound on quadrature error or truncated tails. In particular, the coarse ordinal rule is visibly less accurate than the printed decimal precision might suggest. This tractable fixture checks a subproblem; it does not certify an exact reference posterior for the full regression.

---

Source: `course/advanced/10_outcome_regression.md:81–98`

## Read the response-scale results

![Fitted category-probability curves for nominal and ordinal regressions, with uncertainty bands and observed load-band proportions for original and changed datasets.](../../artifacts/figures/25_outcome_regression_02.svg)

Each curve fixes age at five; bands are pointwise 90% posterior intervals for category probabilities. Black crosses are raw category proportions in load thirds, averaging over the ages actually observed there. They are useful orientation, not age-matched validation points. The top row shows original data and the bottom row the changed generator. Category names, line styles, and the following tables provide alternatives to color-only interpretation.

For the original data, fitted mean probabilities at load fifty and age five are:

| Model | Ready | Service | Retire |
|---|---:|---:|---:|
| Nominal | 0.423653 | 0.212503 | 0.363844 |
| Ordinal | 0.413995 | 0.236910 | 0.349095 |

The retirement contrast compares load seventy-five with twenty-five at age five, using the **same posterior draw** at both endpoints. Nominal mean contrast is 0.432971, with 90% interval [0.182003, 0.657307] and MCSE 0.001437. Ordinal mean contrast is 0.373940, interval [0.144510, 0.587793], MCSE 0.001526. Subtracting independently drawn endpoint probabilities would lose their posterior dependence and give the wrong contrast uncertainty.

A future inspection is categorical even when its probability vector is uncertain. A posterior interval for retirement probability does not predict a continuous fraction of an individual inspection. To simulate a future label, draw parameters, compute its vector, then draw a category. To simulate several inspections, retain their shared parameter draw before conditionally generating outcomes. Replicated frequencies then include both parameter uncertainty and sampling variation.

The independent thirty-inspection evaluation gives average log predictive scores −1.017618 for nominal and −1.000541 for ordinal; larger is better. The paired nominal-minus-ordinal difference is −0.017077 with an iid-row standard error of 0.027634. That modest difference does not establish a general winner. Scores use the log of the posterior-averaged category probability, not the average log likelihood across parameter draws. The latter evaluates a different quantity.

---

Source: `course/advanced/10_outcome_regression.md:100–104`

## Criticize the cumulative splits

Posterior replication evaluates $P(Y\le0)$ and $P(Y\le1)$ within three predetermined load bands, retaining each observation's age. In the middle band of the original sample, observed cumulative proportions are (0.5333, 0.7000). Nominal replicated means are (0.4295, 0.6348), and ordinal means are (0.4177, 0.6475). Both underpredict those observed proportions, but the observed values lie inside their broad central 90% replicated ranges.

At high load, the observed pair is (0.2222, 0.4444), compared with ordinal replicated means (0.3002, 0.5174). This suggests a useful direction for criticism without providing decisive rejection in a small dataset. Band summaries can miss local departures and interactions. A larger scientific analysis could examine both cumulative logits against each predictor, category-specific residual patterns, and sensitivity to plausible alternatives. Do not interpret a posterior predictive tail area as a conventional uniformly distributed test p-value.

---

Source: `course/advanced/10_outcome_regression.md:106–120`

## Changed givens: a nominal mechanism and an honest negative comparison

Save a prediction before running the second scenario. It uses separately generated training and evaluation inspections with logits

$$
(0,\ 1+1.8x_L+0.2x_A,\ -0.3+4x_L+0.6x_A).
$$

Retirement grows more sharply relative to ready than service does. The induced cumulative logits generally have different, nonlinear slopes, challenging the proportional-odds restriction. Explain that restriction explicitly; “service rises then falls” is insufficient because the ordinal model can also produce such a hump.

Both models are actually refitted under the same frozen priors and computation settings. At centered predictors, the nominal mean category vector is (0.173324, 0.692778, 0.133898) and the ordinal vector (0.161152, 0.689686, 0.149162). Their mean retirement contrasts are 0.347313 and 0.393997. All observed cumulative proportions by load band still lie within the displayed broad replicated ranges. These particular data do not expose the known generating restriction sharply.

The outer score is −1.051651 for nominal and −1.010023 for ordinal. The paired difference is −0.041628 with standard error 0.028157: the more flexible nominal model loses on this realized evaluation sample, even though the changed generator is nominal. This is a result to explain, not to erase by selecting another seed. Prior shrinkage, estimation uncertainty, and small-sample score variation all matter. A correctly specified family does not guarantee that its fitted predictive distribution wins every finite comparison.

Conclude your investigation by separating three statements: the changed mechanism violates a restriction; the chosen posterior predictive check has limited power to reveal it; and the realized outer comparison does not favor the flexible fit. None logically cancels the others. Save your explanation before consulting the worked reference.

---

Source: `course/advanced/10_outcome_regression.md:122–126`

## Limits and optional practice

These models require clear, stable category definitions. Misclassification, unobserved grouping, changing inspection practice, and extrapolation beyond the declared predictor domain are outside the fitted example. Predictive associations also need not be causal effects. A well-mixing sampler and normalized probability vector are necessary computational achievements, not complete scientific validation.

The [worked lab](../../labs/25_outcome_regression.py) contains complete fitted references and the changed scenario. For methodological background, see the identification and ordered-logistic sections of the [Stan regression guide](https://mc-stan.org/docs/stan-users-guide/regression.html). Attempt the three optional [outcome-regression questions](../exercises/continuation_questions.md#adv-outcome-regression-1), save your work, then consult the protected [solutions and rubrics](../exercises/continuation_solutions.md#adv-outcome-regression-1). These optional items leave the original core grading and mastery requirements unchanged.

---

Source: `course/advanced/11_study_design.md:1–5`

# A11 — Study design: evaluate the whole rule

A fictional laboratory tests protective seals. A seal either holds under a specified test or fails. The laboratory wants to approve a batch only when its underlying success probability exceeds 0.7. Before any tests are observed, should it commit to eight tests, twenty tests, or a rule that sometimes stops after eight? Predict which option has the greatest approval probability, which uses the fewest tests, and which has the lowest total loss. There is no reason those answers must name the same design.

This optional module builds on beta updating, predictive distributions, simulation, and decision analysis in L02, L03, L05, and L12. Allow 5–7 hours including the lab, investigation, and optional questions; this is an unpiloted planning estimate. It adds work beyond the selected twelve-week route. The goal is to evaluate a complete candidate policy, not to discover a universally optimal sample size. One observation is one completed test of a different seal. We assume immediate, correctly classified results and conditionally independent outcomes with a common reliability throughout a study.

---

Source: `course/advanced/11_study_design.md:7–19`

## Two priors, two jobs

Let the unknown reliability be $p$. Conditional on it, each result is Bernoulli: $Y_i\mid p\sim\mathrm{Bernoulli}(p)$. The **design prior**, $p\sim\mathrm{Beta}(8,2)$, expresses uncertainty when anticipating possible studies. Its mean is 0.8. We use it to assign probabilities to future datasets and to average consequences across possible truths. It is optimistic about reliability; that optimism should be visible rather than hidden inside a simulation function.

The **analysis prior** is separately fixed at $\mathrm{Beta}(1,1)$. After $s$ successes in $n$ trials, the stipulated analysis reports $p\mid s,n\sim\mathrm{Beta}(1+s,1+n-s)$. Its tail probability

$$
q(s,n)=P(p>0.7\mid s,n)
$$

controls the decision. Different priors here do not mean that the same analyst must simultaneously hold contradictory beliefs. We are evaluating an analysis procedure under a particular prospective distribution. For example, a laboratory may be required to use a standard analysis while a sponsor has additional planning information. The design calculation asks how that stipulated procedure behaves if the planning assumptions are credible.

Do not insert both priors into one posterior. Nor should you use the analysis posterior to average planning losses merely because it is already available. The observation rule and the distribution used to evaluate it have different roles. Recording both prevents an apparently technical choice from silently changing the scientific question.

---

Source: `course/advanced/11_study_design.md:21–27`

## Freeze the entire policy

We compare fixed sample sizes 8, 14, and 20 with one sequential policy. Fixed designs approve when $q\ge0.95$ at their only look and otherwise reject. The sequential policy looks after 8 and 20 tests. At eight, it approves if $q\ge0.95$, rejects for futility if $q\le0.10$, and otherwise continues. At twenty, it approves if $q\ge0.95$ and otherwise rejects. Twenty is a hard cap.

A test costs 0.25 loss units. Approving when $p\le0.7$ costs 190; rejecting when $p>0.7$ costs 10. Correct terminal decisions have no additional loss. These numbers are fictional judgments, not monetary estimates. They make false approval much more consequential than false rejection while allowing testing itself to matter. The probability threshold is a stipulated rule; it has not been derived as the optimal action for these costs and the design prior.

No extra looks, delayed outcomes, replacement of failed seals, or changing thresholds after a disappointing result are allowed. Such changes define another policy. Optional stopping is not a license to omit the stopping mechanism from a prospective comparison. A Bayesian posterior may remain coherent under a stated sampling rule while the probability of ever crossing a decision boundary changes substantially.

---

Source: `course/advanced/11_study_design.md:29–54`

## Worked step 1: from an observed count to a decision

Suppose all eight initial seals hold. The analysis posterior is Beta(9,1), so

$$
q(8,8)=1-0.7^9=0.959646393.
$$

That exceeds 0.95 and leads to approval. A probability statement about reliability is being converted into an action by a declared threshold. It is not the probability that the next seal holds, which under this analysis posterior is $9/10$.

Before seeing any results, the design probability of eight successes is

$$
P(S_8=8)=\frac{B(16,2)}{B(8,2)}=\frac{9}{34}
=0.2647058824.
$$

The first calculation used the analysis prior to interpret a dataset. The second used the design prior to weight how often that dataset might arise. Confusing them would change assurance. Enumerating the other eight possible counts shows that at the first look, counts 0–4 stop for futility, counts 5–7 continue, and count 8 approves.

For a fixed $n$, all possible counts follow the beta-binomial predictive law,

$$
P(S_n=s)=\binom ns\frac{B(8+s,2+n-s)}{B(8,2)}.
$$

Multiply each count probability by its approval indicator and sum. That is **assurance**: the prospective probability that the analysis will declare success. It averages over uncertainty about the truth as well as sampling variability. It is not power at $p=0.8$, even though 0.8 is the design-prior mean; averaging a nonlinear decision probability generally differs from evaluating it at the average truth.

---

Source: `course/advanced/11_study_design.md:56–70`

## Worked step 2: continuing paths and their loss

For a continuing first-stage count $s$, the design distribution updates to Beta(8+s,10−s). The number of additional successes among twelve new tests is therefore beta-binomial with those updated shapes. The joint probability of a two-stage path is its first-stage mass multiplied by that conditional second-stage mass. Reusing Beta(8,2) at the second stage would incorrectly erase information shared by all observations within a study.

At a terminal count $(n,s)$, let

$$
u(s,n)=P(p\le0.7\mid s,n,\text{design prior}).
$$

Conditional expected terminal loss is $190u$ for approval and $10(1-u)$ for rejection. Add $0.25n$, then average using terminal-state masses. This integrates the uncertain truth on the appropriate side of the reliability boundary. The stopping event gives no extra information about $p$ once an exchangeable sequence's sufficient counts are known, under this fully specified rule. Its effect still matters when calculating which terminal counts can occur and with what probability.

An independent calculation advances a probability distribution over states $(n,s)$ one trial at a time. Under the design prior, a success transition has probability $(8+s)/(10+n)$. It only checks decisions at declared looks. This method shares the mathematical model with count enumeration but uses a different computational route; agreement can expose missed paths or mistaken conditional weights.

A smaller exact anchor makes the structure inspectable. Use uniform design and analysis priors, reliability threshold 0.5, looks 2 and 4, success threshold 0.8, and futility threshold 0.2. Two successes at the first look approve, zero reject, and one continues. Each initial count has probability $1/3$. Conditional on continuation, the updated design prior is Beta(2,2); two further successes occur with probability $3/10$, the only successful continuation. Thus assurance is $1/3+(1/3)(3/10)=13/30$, and expected size is $2(2/3)+4(1/3)=8/3$. A fixed four-test design approves counts 3 or 4, each with probability $1/5$, giving $2/5$. Lab 26 independently enumerates all sixteen ordered paths using rational arithmetic.

---

Source: `course/advanced/11_study_design.md:72–84`

## Try the exact policy before scaling up

[Open the guided stopping experiment](../../explorer.html#continuation-study-design). This deliberately small version uses uniform design and analysis priors, unlike the main reliability study's Beta(8,2) design prior. It implements the exact two-look anchor above, with no Monte Carlo noise. **Predict:** will allowing the first look change assurance even if the terminal success criterion stays fixed? **Change:** keep looks 2 and 4 and thresholds 0.8/0.2, then raise only the success threshold to 0.9. **Explain:** the default first-look posterior probabilities are 0.125, 0.5 and 0.875. Raising the success threshold removes early approval while retaining early futility; enumerate the surviving successful path. **Transfer:** compare assurance to approval probability at fixed truth 0.5. Why does substituting the design-prior mean for its distribution change the calculation?

| Policy (uniform priors, reliability boundary 0.5) | Assurance | Expected size | Approval probability at fixed truth 0.5 |
|---|---:|---:|---:|
| Default sequential, success threshold 0.8 | 13/30 = 0.433333 | 8/3 | 0.375 |
| Fixed four tests, success threshold 0.8 | 2/5 = 0.4 | 4 | 0.3125 |
| Sequential, success threshold 0.9 | 1/5 = 0.2 | 10/3 = 3.333333 | 0.0625 |

For the default rule, first-look counts zero, one and two each have design mass 1/3. Only count one continues, and its conditional chance of two further successes is 3/10, giving assurance 1/3 + (1/3)(3/10) = 13/30. This explains the default table without requiring JavaScript.

In the last row, only four successes approve: the two-success first stage now continues. The design probability of all four successes is 1/5; its fixed-truth probability at 0.5 is 1/16. These exact values, the earlier path derivation and the table form a complete offline and print alternative. The explorer also exposes terminal-state masses, including rejected states. Reset restores every default independently of the other explorers. This original unscored investigation saves no responses; the approval threshold is a posterior decision rule, not a guaranteed repeated-sampling error level.

---

Source: `course/advanced/11_study_design.md:86–103`

## What the executed comparison says

![Exact assurance and expected loss for four policies, with independent simulation estimates and two-MCSE bars.](../../artifacts/figures/26_study_design_01.svg)

The figure compares exact calculations with 100,000 prospective studies per policy. The following table is its numerical equivalent; loss includes test costs and terminal errors.

| Policy | Exact assurance | Expected tests | Expected loss |
|---|---:|---:|---:|
| Fixed 8 | 0.264706 | 8 | 8.413355 |
| Fixed 14 | 0.332016 | 14 | 8.899708 |
| Fixed 20 | 0.364027 | 20 | 9.830133 |
| Looks 8, 20 | 0.411226 | 15.493213 | 9.078560 |

More fixed tests improve assurance here, but increase expected total loss. The sequential rule has greater assurance than fixed twenty and uses fewer tests on average, yet fixed eight has the lowest expected loss among these four candidates. Calling the sequential policy “best” without naming the target would hide that tradeoff. None of these comparisons certifies global optimality among all possible stopping rules.

For the sequential rule, simulation gives assurance 0.413100 with MCSE 0.001557, expected size 15.499520 with MCSE 0.018372, and loss 8.997080 with MCSE 0.048482. The simulated loss is lower than its exact reference by about 0.08148, which is 1.68 MCSE. That difference is Monte Carlo noise in estimating an expectation, not evidence that simulation creates a better policy. All recorded simulation comparisons fall within five MCSE of the exact results. Count enumeration and recursion agree within the predeclared $10^{-12}$ tolerance and terminal masses normalize to one within that tolerance.

One reliability is drawn per simulated study, then retained for all its trials. Drawing a new reliability before every seal would produce a different dependence structure and the wrong distribution of counts. MCSE for a probability is approximately $\sqrt{\hat a(1-\hat a)/M}$; for size and loss, use sample standard deviation divided by $\sqrt M$. If no approvals occur, a zero estimated MCSE does not prove a zero population probability: report a finite-simulation upper bound. Fixed sample size has genuinely zero simulation variance and is returned as its exact integer.

---

Source: `course/advanced/11_study_design.md:105–122`

## Assurance and fixed-truth behavior answer different questions

![Sequential terminal states at sample sizes eight and twenty, plus approval probabilities at six fixed reliabilities.](../../artifacts/figures/26_study_design_02.svg)

The terminal-state panel uses distinct markers for approve/reject. Marker area has a small visibility baseline plus 1,000 times probability mass; it increases with mass but is not directly proportional to it. Minimum-size marks can represent zero-mass, unreachable terminal counts. Use the numerical masses, not ratios of marker areas, for quantitative comparisons. The aggregate masses are 0.264706 for early approval, 0.110860 for early rejection, 0.146520 for approval at twenty, and 0.477914 for rejection at twenty. Only the two declared looks can end a study. These four numbers also explain the expected size: all studies pay for eight tests, while the remaining probability 0.624434 pays for twelve more.

For a fixed truth, the recursion replaces its predictive success probability by that constant $p$. The analysis rule remains unchanged. The plotted lines connect six evaluated truths as visual guides; they are not exact interpolation formulas. The sequential operating characteristics are:

| Fixed reliability | Approval probability | Expected tests |
|---|---:|---:|
| 0 | 0 | 8 |
| 0.5 | 0.004032 | 12.312500 |
| 0.7 | 0.078557 | 16.978972 |
| 0.8 | 0.280182 | 17.311355 |
| 0.9 | 0.724653 | 14.774101 |
| 1 | 1 | 8 |

At the boundary $p=0.7$, approval counts as an error under the declared loss. Its probability is about 7.86%, despite requiring a posterior tail of at least 95% at every approval. The two percentages condition on different objects. A posterior statement conditions on observed data and a prior; an operating characteristic conditions on a fixed truth and averages over data. Extra looks would require recalculation of the event “approve at any allowed look.” They cannot inherit a 5% guarantee from the posterior threshold.

---

Source: `course/advanced/11_study_design.md:124–130`

## Changed givens: less optimistic planning

Before opening the worked lab output, replace only the design prior with Beta(3,2). Write down which quantities can change and which must stay fixed. Then recompute all four policies and explain the result. The analysis posterior, thresholds, action for a particular count, and fixed-truth operating curves must remain unchanged. Assurance, expected size under the design distribution, and design-averaged loss may change because datasets and truths receive new weights.

The executed reference obtains assurances 0.090909, 0.107843, 0.114907, and 0.141728 for fixed 8, fixed 14, fixed 20, and sequential respectively. Their expected losses are 6.119819, 6.838740, 7.892057, and 7.400578. Sequential expected size falls to 13.818182 because early futility becomes more common: its probability rises to 0.424242. Lower assurance and lower average loss can coexist when lower reliability makes rejection appropriate. Do not interpret loss reductions across different design priors as an improvement to the same policy under the same population.

This exercise tests an explanation, not just replacement of two beta parameters. Save your initial claim, run the changed calculation, and identify any mistaken assumption. A useful extension is to change a cost while leaving the rule frozen, distinguish reevaluation from redesign, and resist retroactively calling a revised rule validated by the original calculation.

---

Source: `course/advanced/11_study_design.md:132–138`

## Limits and next steps

This prospective model assumes a stable common reliability and conditionally independent outcomes given that reliability; integrating over its uncertainty gives exchangeable, predictively dependent seal outcomes. Immediate outcomes exclude decisions made with pending tests. A fixed test definition excludes changes in stress level during the study. If those assumptions are implausible, adding more Monte Carlo replications only estimates the wrong prospective model more precisely. Costs also deserve sensitivity analysis: a decision recommendation is conditional on their meaning and relative magnitude.

The [worked lab](../../labs/26_study_design.py) exposes `Policy`, count enumeration, recursion, and simulation separately. Its output is a reference containing answers; use it after saving a prediction. The method extends the decision-analysis logic in L12 from one expectation to an entire observation-and-action process. Primary background is the [Stan decision-analysis guide](https://mc-stan.org/docs/stan-users-guide/decision-analysis.html) and the finite predictive calculations discussed by [Wilson and colleagues](https://pmc.ncbi.nlm.nih.gov/articles/PMC9325402/); the seal scenario, costs, and results here are original teaching choices.

Complete the three optional [study-design questions](../exercises/continuation_questions.md#adv-study-design-1) after your investigation. They distinguish the two priors, require a new small stopping calculation, and challenge a false error-rate claim. Save an attempt before consulting the separately protected [worked solutions](../exercises/continuation_solutions.md#adv-study-design-1). Their optional marks do not alter core grading or mastery requirements.

---

Source: `course/advanced/12_survival.md:1–5`

# A12 — Survival regression when observation ends first

A fictional factory installs ninety conveyor belts at different workloads. Some fail during follow-up; others are still running when their scheduled observation ends. What fraction of comparable belts would survive twelve weeks at a specified workload? Before calculating, predict what would happen if every last observed time were treated as a failure. Also predict what information a belt observed running for eleven weeks contributes, even though its lifetime is unknown.

This optional module follows continuous models, generalized regression, predictive checking, and observation models in L04, L08, L10, and A03. Numerical integration is also needed. Allow 6–8 hours including the lab and investigation, an unpiloted planning estimate beyond the selected core. The observation unit is one belt, followed from installation. Time is measured in weeks; workload $x$ is a dimensionless, predetermined scale. The target is a probability for a population under stated conditions, not a promise about any individual belt.

---

Source: `course/advanced/12_survival.md:7–27`

## Generate a lifetime, then generate its observation

Let $T_i>0$ be latent failure time and $C_i>0$ the administrative follow-up limit. We observe

$$
t_i=\min(T_i,C_i),\qquad \delta_i=1(T_i\le C_i).
$$

An event indicator of one means the failure time was observed. Zero means only that the belt survived beyond its last observation. Censoring is not a category of failure, an imputed lifetime, or a missing record to discard. The observation process is part of the model.

For the teaching data, workload is uniform on $[-1,1]$, the Weibull shape is 1.4, and its scale is $\lambda(x)=12\exp(-0.35x)$ weeks. Follow-up is independently uniform from six to eighteen weeks, conditional on workload. These choices generate reproducible synthetic data; they are not engineering evidence about belts. The generator's negative workload coefficient makes greater workload shorten lifetimes, but a small realized sample need not recover that coefficient precisely.

The fitted model leaves scale and shape unknown:

$$
\log\lambda_i=a+b x_i,\qquad k=\exp(r),
$$

with independent priors $a\sim N(\log12,0.6^2)$, $b\sim N(0,0.5^2)$, and $r\sim N(0,0.4^2)$. The second Normal argument denotes variance; software receives standard deviations 0.6, 0.5, and 0.4. The log scale is the logarithm of the numerical time measured in weeks. Changing time units therefore changes its intercept and prior location. Shape and workload slope remain dimensionless.

A positive $b$ lengthens lifetime in this parameterization. Increasing workload by one multiplies every conditional lifetime quantile by $e^b$. This is an accelerated-time interpretation. At a common shape, the corresponding hazard ratio is $e^{-kb}$, so it is not simply $e^b$. State the parameterization before interpreting a sign or exponentiated coefficient.

---

Source: `course/advanced/12_survival.md:29–49`

## Density, survival, hazard, and interval probability

For a Weibull lifetime,

$$
S(t\mid\lambda,k)=\exp[-(t/\lambda)^k],\quad
f(t\mid\lambda,k)=\frac{k}{\lambda}(t/\lambda)^{k-1}S(t),
$$

and $h(t)=f(t)/S(t)$. Survival is dimensionless. Density and hazard have units of inverse weeks. A density value is not the probability of failure at exactly that time; under a continuous model that point probability is zero. A small interval probability is approximately density times interval width, while a hazard describes the instantaneous event rate among survivors.

For fixed model parameters, failure between weeks eight and twelve conditional on survival to eight has probability

$$
1-\frac{S(12)}{S(8)}
=1-\exp\{-[(12/\lambda)^k-(8/\lambda)^k]\}.
$$

This integrates hazard over an interval and transforms the integrated rate. Multiplying the hazard at week eight by four weeks is only an approximation, and can be poor if the hazard changes markedly. The model permits decreasing hazards for $k<1$, constant hazard for $k=1$, and increasing hazards for $k>1$; it does not permit arbitrary peaks or multiple failure phases.

Administrative censoring contributes $S(t_i)$, because the recorded event is “still functioning through $t_i$.” Observed failure contributes $f(t_i)$. Conditional independence of censoring and lifetime, given recorded workload, lets us omit factors involving only the censoring distribution when learning lifetime parameters. That assumption is substantive: withdrawal after an unrecorded vibration warning would not be administrative censoring of this kind.

---

Source: `course/advanced/12_survival.md:51–70`

## Worked step 1: count failures, retain all exposure

Start with the exponential special case $k=1$, where the failure rate is $\theta=1/\lambda$ per week. Suppose failures occur at two and five weeks and a third belt is still running at four weeks. The likelihood is

$$
(\theta e^{-2\theta})(\theta e^{-5\theta})e^{-4\theta}
=\theta^2 e^{-11\theta}.
$$

There are two events but eleven belt-weeks of exposure. Discarding the censored record loses four informative weeks. Calling it a failure changes the power of $\theta$ from two to three and asserts an event that was never observed.

With a Gamma prior of shape two and rate ten weeks, multiplication gives Gamma(shape four, rate twenty-one weeks). Its posterior mean rate is $4/21=0.1904761905$ per week. The rate parameter of the Gamma distribution has units of weeks so that its product with the random failure rate is dimensionless. This convention differs from software's Gamma scale argument, which is the reciprocal of that rate.

Lab 27 independently integrates the unnormalized prior-times-likelihood density and its first moment. Their ratio agrees with $4/21$ to the recorded floating-point precision. Setting Weibull shape to one reproduces the exponential event-count/exposure log likelihood exactly in the fixture. These calculations test both the event power and the inclusion of censored exposure; a plausible survival curve alone would not reveal either mistake.

For the full synthetic dataset, the observed event count is 57 and total exposure is 754.938708 belt-weeks. Ignoring workload and assuming exponential lifetimes would give Gamma(59, 764.938708) for the rate. This is an anchor with stronger assumptions, not the fitted Weibull regression posterior. The full analysis uses the individual covariates and learns shape.

![First twenty-four belts shown as observed timelines, with circles for failures and vertical ticks for administrative censoring.](../../artifacts/figures/27_survival_01.svg)

Every line begins at installation and stops at the earlier of failure or the follow-up limit. Circles and vertical ticks carry different likelihood contributions even when their positions are similar. Across all ninety records, 57 lines end in failure and 33 in censoring; observed exposure sums to 754.938708 weeks. The lab result contains every time, indicator, workload, and scheduled censor limit, providing a numerical equivalent to the displayed subset.

---

Source: `course/advanced/12_survival.md:72–91`

## Worked step 2: construct and integrate the regression posterior

Taking logs of the density/survival product gives

$$
\ell(a,b,r)=\sum_i\delta_i\{\log k-k\log\lambda_i+(k-1)\log t_i\}
-\sum_i(t_i/\lambda_i)^k.
$$

Only observed events multiply the density terms inside braces; every belt contributes cumulative hazard in the final sum. The code checks positive finite times, binary indicators, aligned covariates, and consistency with a supplied administrative schedule. A censored time must equal its follow-up limit; no observed time may exceed that limit.

There are only three unknown parameters, so this lab uses deterministic integration rather than Monte Carlo sampling. First, numerical optimization finds a convenient posterior location and a positive-definite local curvature matrix. Its inverse supplies a coordinate scale. Tensor Gauss–Legendre nodes then span a box in those standardized coordinates, and each node receives the actual prior-times-likelihood weight multiplied by the integration weight and transformation determinant.

The Gaussian curvature defines coordinates; it does not replace the posterior by a Gaussian. Dropping the determinant would corrupt the normalizer. Dropping prior normalization constants would also corrupt it, even when normalized posterior means happened to remain unchanged. The retained normalizer refers to continuous event-time densities expressed in weeks, not to the probability of observing an exact dataset.

Orders 31, 51, and 71 use standardized bounds ±7. A separate order-71 calculation expands the box to ±9. This sequence runs for the proper analysis, shorter-follow-up investigation, and deliberate censor-as-failure comparison. The predeclared thresholds are $10^{-4}$ for target survival/conditional-probability means, $10^{-3}$ for parameter means, and $10^{-3}$ for log normalizers. All comparisons pass. Across those scenarios, the largest parameter-mean change is about $5.42\times10^{-6}$, and the largest log-normalizer change is $3.62\times10^{-6}$.

The original and shortened-follow-up mode searches report precision loss, with gradient norms about $6.88\times10^{-6}$ and $2.34\times10^{-6}$. Those messages remain in the records. A failed optimizer termination is not relabeled successful. Here the mode is only a coordinate choice; positive curvature and subsequent independent order/bound checks establish the reported integration stability. They do not establish that optimization found a unique global mode or prove a rigorous bound on every omitted posterior tail.

Independent references add different checks. Separate SciPy Weibull log-density/log-survival calculations agree with the hand-written fixture likelihood. Adaptive integration of the event density over positive time gives one within $1.34\times10^{-15}$. A tiny no-covariate posterior is integrated adaptively in two dimensions and compared with a separate tensor rule over the same bounded rectangle: its mean $S(12)$ is 0.2590747527, with absolute discrepancy $1.10\times10^{-10}$. That bounded fixture is not an exact reference for the ninety-belt regression.

---

Source: `course/advanced/12_survival.md:93–109`

## What survives to twelve weeks?

![Workload-specific survival curves with posterior probability intervals, a deliberately incorrect censor-as-failure fit, and a shorter-follow-up sensitivity fit.](../../artifacts/figures/27_survival_02.svg)

Solid curves use the proper observation model; shaded bands are pointwise 90% posterior intervals for a survival probability. Dashed curves deliberately treat every censored time as a failure. Dotted curves use shorter follow-up with the same latent lifetimes. The numerical equivalents at week twelve are:

| Analysis | Workload −0.5: mean S(12) | Workload +0.5: mean S(12) |
|---|---:|---:|
| Proper censoring | 0.409569 | 0.374833 |
| Censoring called failure | 0.224386 | 0.198027 |
| Shorter follow-up | 0.465652 | 0.507003 |

Under the proper fit, the low-workload 90% posterior interval is approximately [0.3080, 0.5152], and the high-workload interval [0.2737, 0.4812]. The mean high-minus-low contrast is −0.034736, with interval [−0.1690, 0.0994]. There is considerable uncertainty about the workload difference. The fitted mean slope is −0.076521, much nearer zero than the generating value −0.35. A synthetic truth does not entitle us to replace the realized inference with the expected story.

At workload zero, the posterior mean of the parameter-specific conditional failure probability during weeks eight–twelve is 0.312586, with interval about [0.2436, 0.3859]. Averaging $1-S(12)/S(8)$ over parameter draws answers that parameter-uncertainty question. The posterior predictive probability for a newly observed survivor involves $1-E[S(12)]/E[S(8)]$, because surviving to eight also changes the parameter weights. The two summaries need not coincide. Always name which conditioning operation was performed.

These intervals quantify uncertainty about probabilities. A future belt either survives or fails; it does not have an outcome inside the probability interval. For a specified belt drawn under the model, posterior predictive survival probability is the posterior mean of $S$. For many future belts, shared parameter uncertainty also induces dependence after parameters are integrated out.

---

Source: `course/advanced/12_survival.md:111–117`

## Reproduce observation, not just lifetimes

Posterior prediction draws a shared parameter vector, simulates ninety latent lifetimes at the recorded workloads, and then applies each belt's actual censoring schedule. Comparing uncensored simulated lifetimes directly with observed minimum times would compare different quantities. The lab uses 4,000 such replicated datasets and reports event fractions and observed mean times by workload half.

For low workload, the observed event fraction is 0.6383 and the replicated mean is 0.6057; its 90% replicated range is [0.4681, 0.7447]. For high workload, these are 0.6279 and 0.6273, with range [0.4651, 0.7907]. The observed mean times, 8.0885 and 8.7158 weeks, lie within the corresponding replicated ranges [7.1047, 9.7524] and [6.6966, 9.4492]. MCSEs for replicated mean event fractions are about 0.00141 and 0.00146. The broad ranges describe dataset variation, not MCSE. Passing these coarse checks does not validate every feature of the Weibull model.

Weeks-to-days conversion provides another diagnostic. Multiply all times and scales by seven and shift the prior mean of $a$ by $\log7$. Survival predictions remain unchanged. Each event density acquires a factor $1/7$, so the log likelihood shifts by minus the event count times $\log7$. The fixture checks that shift within $2.67\times10^{-15}$, and checks the transformed log-scale prior within $4.45\times10^{-16}$. Comparing raw density values across units without the Jacobian would produce a false discrepancy.

---

Source: `course/advanced/12_survival.md:119–127`

## Changed givens and limits

Save a prediction, then reduce administrative follow-up to Uniform(3,9) weeks using a separate stream while retaining the original latent lifetimes and workloads. Explain what is lost about twelve-week survival before inspecting the reference. The shorter schedule yields 26 observed events and 469.202003 belt-weeks. All follow-up now ends before the target time, making twelve-week inference more dependent on the assumed lifetime family and priors.

The fitted mean workload slope becomes +0.111167. The high-minus-low survival contrast is +0.041351 with a broad interval [−0.1263, 0.2086]. This sign change does not show that lower follow-up improves belts or reverses a causal effect. The likelihood contains less event-time information from this realized sample. Both displayed S(12) intervals widen here, but there is no universal theorem that every posterior interval must widen after every loss of observations. Their centers and shapes may change too. Weighted quadrature interval endpoints are approximate; the numerical convergence criteria above explicitly certify means and normalizers, not equally precise endpoint locations.

Finally, suppose a belt is removed after an unrecorded vibration alarm. Removal may predict imminent failure even conditional on recorded workload. The administrative-censoring factorization no longer applies. Record the alarm process if possible, consider a joint observation model or sensitivity analysis, and limit conclusions. More integration nodes cannot recover an unmeasured withdrawal mechanism. Competing risks, left truncation, recurring repairs, and operational replacement optimization are outside this bounded lesson.

The [worked lab](../../labs/27_survival.py) includes complete reference calculations. The [Stan survival guide](https://mc-stan.org/docs/stan-users-guide/survival.html) supplies methodological background; the equations are independently checked here. Attempt the three optional [survival questions](../exercises/continuation_questions.md#adv-survival-1), save your reasoning, then consult the protected [worked solutions](../exercises/continuation_solutions.md#adv-survival-1). Optional marks do not change core grading.

---

Source: `course/advanced/13_gp_hyperparameters.md:1–5`

# A13 — Learn the smoothness, then predict the curve

A calibration instrument has been measured at twelve input settings. Between those settings, several smooth curves could explain the observations. Outside them, the curves disagree much more. Should we choose the smoothness that fits best, or carry uncertainty about smoothness into prediction? Before calculating, sketch two plausible curves through a noisy collection of points. Mark where their disagreement reflects measurement noise and where it reflects uncertainty about the latent calibration function.

This optional module follows [A06](06_gaussian_processes.md), with Gaussian conditioning and numerical integration from the appendices. Allow six to eight hours for the chapter, Lab 28, investigation and questions. It belongs to the computational depth route alongside [predictive combinations](14_predictive_combination.md), [fitted variational inference](15_variational_fit.md) and [splines](16_splines.md); those are alternative extensions, not compulsory intervening prerequisites. The breadth modules on [outcomes](10_outcome_regression.md), [design](11_study_design.md) and [survival](12_survival.md) ask the same foundational questions about observation units, targets and assumptions in different settings. None changes the selected twelve-week core or its grading.

---

Source: `course/advanced/13_gp_hyperparameters.md:7–34`

## A curve and a measurement are different targets

Our observation unit is one calibration measurement at a known input. Inputs are dimensionless standardized settings; outcomes have calibration units. The synthetic observations use twelve equally spaced inputs from −2 to 2 and the mechanism

$$
y_i=0.6\sin(1.8x_i)+0.2x_i+\epsilon_i,\qquad
\epsilon_i\sim N(0,0.18^2).
$$

This mechanism creates a reproducible teaching dataset. It is not empirical evidence about an instrument, and the generating curve need not be a draw from the fitted prior. Knowing the generator lets us explain the exercise; the fitting functions receive only the observations.

We fit a zero-mean Gaussian process with covariance

$$
k_\ell(x,x')=\exp\{- (x-x')^2/(2\ell^2)\},
\qquad y_i\mid f,\sigma\sim N(f(x_i),\sigma^2).
$$

The amplitude is fixed at one calibration unit and the prior mean at zero. We learn the length scale and observation-noise standard deviation, with independent priors

$$
\log\ell\sim N(\log0.8,0.6^2),\qquad
\log\sigma\sim N(\log0.2,0.5^2).
$$

Normal notation here uses variance as the second argument; software `scale` arguments use standard deviation. Log-scale priors guarantee positivity without imposing hard scientific cutoffs. Length controls how rapidly function values can vary together. Noise describes repeat-to-repeat variation at an unchanged input. Sparse observations can leave these explanations partially confounded: a rapidly varying curve with little noise may explain similar data to a smoother curve with more noise.

Our point targets are latent values and future noisy measurements at inputs 0, 1 and 3. Input 3 lies beyond the measured range. We also ask for the average latent curve across a specified grid and the probability that any grid value exceeds 0.8. A pointwise interval cannot answer either curve question by itself.

---

Source: `course/advanced/13_gp_hyperparameters.md:36–56`

## Worked example 1: condition two measurements by hand

Take inputs −1 and 1 and observations 0.2 and −0.1. Fix length at 0.8 and noise SD at 0.2. The training covariance has diagonal $d=1.04$ and off-diagonal $r=\exp(-2/0.8^2)$. Its inverse is

$$
C^{-1}=\frac{1}{d^2-r^2}
\begin{pmatrix}d&-r\\-r&d\end{pmatrix}.
$$

At the midpoint, both cross covariances equal $h=\exp[-0.5/0.8^2]$. Consequently the conditional mean is $h(0.2-0.1)/(d+r)$ and the latent variance is $1-2h^2/(d+r)$. The mean is about 0.042 and the latent variance about 0.613. Add 0.04 to that variance for a new noisy measurement. Check that both predictions share a mean; observation noise changes predictive spread, not the conditional expectation.

This calculation makes two useful distinctions. First, a GP prediction conditions on all measurements jointly rather than drawing a line independently through each neighborhood. Second, the training covariance includes measurement noise, whereas the latent query covariance does not. Adding noise everywhere would confuse uncertainty about the curve with uncertainty about an additional reading.

For twelve measurements the same formulas use matrix factorization instead of explicit inversion. With $C=K_\ell+\sigma^2I$ and cross covariance $K_*$,

$$
m_*=K_*^TC^{-1}y,\qquad
V_*=K_{**}-K_*^TC^{-1}K_*.
$$

Cholesky solves are numerically preferable to forming $C^{-1}$. A tiny diagonal jitter of $10^{-10}$ is used in variance units. Jitter is an arithmetic stabilization choice, not an extra learned noise component. The lab repeats relevant calculations at zero and $10^{-8}$ jitter and records the differences.

---

Source: `course/advanced/13_gp_hyperparameters.md:58–74`

## Three ways to handle unknown hyperparameters

The fixed analysis uses length 0.8 and noise 0.2. It provides a useful reference to the earlier GP lesson, but it deliberately treats two uncertain quantities as known. The empirical-Bayes analysis chooses the largest attained marginal likelihood,

$$
p(y\mid\ell,\sigma)=N(y;0,K_\ell+\sigma^2I),
$$

after integrating the latent training function analytically. This is not maximizing the joint density over twelve latent function values. The determinant in the marginal likelihood accounts for the volume of functions compatible with a hyperparameter setting, connecting the calculation to A02's distinction between a high peak and an integrated probability.

The empirical-Bayes optimizer starts from nine declared length/noise pairs. Every termination message, gradient norm and boundary hit is retained. Multiple starts reduce dependence on one initialization; they do not certify a global optimum. The attained setting is approximately length 0.905 and noise SD 0.131. The integrated posterior means are approximately 0.917 and 0.167. A posterior mean of hyperparameters is descriptive; substituting those means into one GP does not reproduce the integrated predictive distribution.

The full analysis multiplies the marginal likelihood by the two proper log-scale prior densities and integrates. Because integration coordinates are log length and log noise, those are the densities supplied to quadrature. Applying an additional exponential Jacobian would change the intended prior. Conversely, integrating in positive length/noise coordinates would require the corresponding lognormal densities.

![Posterior density in log length and log noise, with fixed and empirical-Bayes settings marked.](../../artifacts/figures/28_gp_hyperparameters_01.svg)

The plotted surface represents posterior density per unit log length and log noise, obtained by dividing node probabilities by quadrature integration weights. The axes label positive length and noise on logarithmic scales. It is not a density per unit of positive length or noise; changing coordinates changes a density height. Read its broad support and dependence as well as the labeled color scale. The posterior leaves several smoothness/noise explanations plausible. Fixed amplitude and mean remain assumptions even after both displayed quantities have been integrated.

---

Source: `course/advanced/13_gp_hyperparameters.md:76–99`

## Worked example 2: build a mixture prediction

Suppose, for illustration, two posterior hyperparameter components have weights 0.3 and 0.7. At a query their conditional predictions are $N(-1,0.5^2)$ and $N(1,1)$. The mixture mean is $0.3(-1)+0.7(1)=0.4$. Its variance is

$$
0.3\{0.25+(-1-0.4)^2\}
+0.7\{1+(1-0.4)^2\}=1.615.
$$

The variance contains within-component uncertainty and disagreement between component means. Keeping only the weighted conditional variances gives 0.775 and discards that disagreement. The same identity works for vectors: integrated covariance is the mean conditional covariance plus the covariance of conditional means.

A mixture percentile is not a weighted percentile. To find its 90th percentile solve

$$
0.3\Phi((q+1)/0.5)+0.7\Phi(q-1)=0.9.
$$

A bracketed root finder supplies a value whose substituted CDF can be checked directly. The optional assessment asks you to perform that calculation with your own bracket. In the fitted lab, every hyperparameter node contributes one Normal CDF and its normalized posterior weight. Endpoints for the 90% intervals are roots at probabilities 0.05 and 0.95, not averages of node endpoints. The result record includes the CDF residual.

At input zero the integrated latent mean is about −0.076, with a 90% interval approximately [−0.257, 0.110]. The fixed analysis gives approximately [−0.305, 0.134]. Integration is narrower here because the data shift probability toward different hyperparameters than the chosen fixed reference. The law of total variance compares integration with the *posterior average* conditional variance, not with an arbitrary fixed model's variance. It therefore does not prove that every integrated interval must be wider than every plug-in interval.

![Fixed, empirical-Bayes and integrated predictions, and jointly sampled latent curves.](../../artifacts/figures/28_gp_hyperparameters_02.svg)

The left panel separates latent intervals from the integrated noisy band. Extrapolation toward input 3 exposes differences that can be hard to see among the measured points. With the declared stationary, zero-mean prior, sufficiently distant predictions return toward zero and prior variability. That is a modeling consequence, not evidence that an actual calibration curve must return to zero.

---

Source: `course/advanced/13_gp_hyperparameters.md:101–107`

## One random curve needs shared random quantities

For each replicated curve, draw one hyperparameter pair from its posterior. Conditional on that pair, draw one multivariate Normal function vector on the entire prediction grid. Do not redraw length separately at each query and do not replace the vector draw by independent marginal Normals. Both shortcuts destroy dependencies relevant to averages, slopes and threshold events.

On 31 equally spaced points from −2 to 2, trapezoidal weights are $1/30$ internally and $1/60$ at the endpoints. They sum to one because the integral is divided by the domain length. For each conditional Gaussian component, the average has mean $a^Tm$ and variance $a^TVa$. These one-dimensional Normals form another exactly specified finite quadrature mixture. Its fitted mean is approximately 0.0263 and its 90% interval approximately [−0.0565, 0.1096]. The lab compares simulated mean and variance against those analytic mixture moments, reporting target-specific Monte Carlo standard errors.

The threshold event is more difficult, so 5,000 joint draws estimate its probability. The result is 0.5642, with Monte Carlo error about 0.0070. The finer grid gives 0.5690, a paired increase of 0.0048. A paired refinement uses the same curves evaluated on 61 points, then subsamples every other point for the coarse grid. This isolates the effect of looking at more locations from the error caused by drawing another independent simulation sample. The larger grid can discover an exceedance between coarse points. Neither event is the exact continuum maximum; a continuous-path claim would require further work.

---

Source: `course/advanced/13_gp_hyperparameters.md:109–115`

## Numerical evidence has several layers

The first quadrature order, 41 per dimension over six prior SDs, was insufficient: some extrapolation interval endpoints changed by roughly 0.004 on refinement to 81, beyond the declared 0.001 criterion. That failure remains recorded. The final analysis uses finer integration and an additional 161-point rule at the expanded eight-SD bound. CDF tolerance remains $10^{-4}$, endpoint tolerance $10^{-3}$ and log-normalizer tolerance $10^{-3}$. A failed coarse rule is useful evidence about resolution, not grounds to relax the tolerances.

Independently, the two-measurement fixture uses its explicit determinant and inverse inside adaptive two-dimensional integration. Agreement with the grid implementation checks more than re-evaluating the same vectorized formula. It is still a small fixture, not proof that every larger GP calculation is correct. Normalization, root residuals, jitter sensitivity, integration refinement and joint-functional simulation each address different possible mistakes.

None of these checks establishes that the squared-exponential covariance is scientifically appropriate. Abrupt calibration changes, nonstationarity, input error, outliers or correlated observation noise could make the fitted model misleading despite impeccable arithmetic. A useful criticism would compare replicated local differences and repeated-measurement discrepancies with observations. Extending the mean or amplitude model would create additional uncertainty rather than being silently covered by the current intervals.

---

Source: `course/advanced/13_gp_hyperparameters.md:117–119`

## Check what remains shared in a future measurement

Suppose two future measurements are planned at the same input. They share the latent function value and the hyperparameters but have independent observation errors under this model. Their posterior covariance is therefore the integrated latent variance, while each marginal variance additionally includes the posterior mean noise variance. Their difference removes the latent value, leaving conditional variance twice the noise variance. This is why replication is informative about noise in a way that two measurements at different inputs are not: the latter difference also includes function variation. If repeat errors were correlated, that cancellation argument would need a revised observation model. Describe this dependence before simulating repeated readings, rather than independently drawing two entire latent curves. The distinction also helps interpret calibration averages: averaging repeated noisy readings reduces independent noise, but does not erase uncertainty about their shared latent mean. A posterior interval for that mean and a predictive interval for the next reading answer different questions even at the same input.

---

Source: `course/advanced/13_gp_hyperparameters.md:121–127`

## Investigation: a repeated input

Before opening the changed-givens output in [Lab 28](../../labs/28_gp_hyperparameters.py), predict what an extra independently noisy reading at the sixth existing input can tell us. Save your reasoning. The lab retains the original observations and adds one new reading from a separate stream. It then integrates the same model with the same priors and verifies refinement again.

Compare posterior noise and length means, latent predictions, and noisy predictions. Explain why replication directly informs repeatability without introducing a new input separation. It can help distinguish noise from local function variation, but one replicate cannot settle every covariance choice. Its realized discrepancy might shift noise upward or downward. Report the observed direction and explain it; do not retrofit an expectation that all intervals must expand.

Finish with the three [optional questions](../exercises/continuation_questions.md#adv-gp-hyperparameters-1). Attempt and save your work before consulting the protected worked feedback. A useful continuation project combines this chapter's uncertainty propagation with A16's learned smoothing comparison. Count that analysis once in your workload, and identify any optional activity it replaces. The methodological background is [GPML chapter 5](https://gaussianprocess.org/gpml/chapters/RW5.pdf) and the [Stan GP guide](https://mc-stan.org/docs/stan-users-guide/gaussian-processes.html); the synthetic analysis and numerical evidence here are local work.

---

Source: `course/advanced/14_predictive_combination.md:1–5`

# A14 — Learn weights for predictions

Two regression models disagree about a future parcel-handling job. One is linear; the other allows curvature. Could a mixture predict better than either? Before fitting, describe what evidence would convince you. A combination that scores well on observations used to choose its weights has learned those observations. It still needs a separate predictive evaluation.

This optional module builds on regression, predictive checking and A02's discussion of model comparison. Allow five to seven hours including Lab 29 and the assessment. It extends the earlier conceptual explanation of stacking into an actual fitted workflow. It does not replace Bayesian model averaging or declare one combination method universally preferable. Within the seven-module continuation, A10 and A12 supply different outcome models that could later become candidates; A13 and A16 show how a single candidate can already integrate substantial parameter uncertainty. A15 asks whether approximating that uncertainty changes consequential predictions.

---

Source: `course/advanced/14_predictive_combination.md:7–29`

## Specify the unit and distribution being predicted

One row is one independent fictional job. A known scalar input describes its operating setting, and the outcome is a continuous handling response. We generate 100 development rows and later 100 independent outer rows using

$$
x\sim U(-2,2),\qquad
y=1+0.6x+0.35x^2+0.4\sin(2x)+\epsilon,
\quad\epsilon\sim N(0,0.5^2).
$$

The generator deliberately contains structure omitted by both candidates. A linear mean misses curvature and the oscillation; a quadratic mean still misses the oscillation. Neither label is a claim of truth. Our score evaluates a predictive *density for a future response*, not just an estimated mean. A candidate can have a plausible mean and poor variance, producing a poor log score.

The models share a conjugate prior convention. With $X$ their respective design matrices,

$$
y\mid\beta,\sigma^2\sim N(X\beta,\sigma^2I),\qquad
\beta\mid\sigma^2\sim N(0,\sigma^2V_0),\qquad
\sigma^2\sim IG(3,1).
$$

Here the inverse-gamma density is proportional to $(\sigma^2)^{-4}\exp(-1/\sigma^2)$. Thus the second parameter is the scale in the inverse-gamma convention, not a gamma rate applied directly to variance. Set $V_0=\operatorname{diag}(4,1,\ldots,1)$: the intercept has a larger prior variance multiplier than each nonconstant coefficient.

The linear design is $(1,u)$ and quadratic design $(1,u,u^2)$. Within each training set, $u=(x-\bar x_{train})/s_{train}$, using the population-SD divisor. That transformation is learned from inputs, so it belongs inside the fitting boundary. The outer values cannot influence it. This convention also defines the prior: changing coefficient coordinates while assigning fresh independent priors generally changes the prior over functions.

---

Source: `course/advanced/14_predictive_combination.md:31–57`

## Worked example 1: a predictive Student distribution

For a training matrix $X$ and outcomes $y$, conjugacy gives

$$
V_n=(V_0^{-1}+X^TX)^{-1},\quad m_n=V_nX^Ty,
\quad a_n=3+n/2,
$$

$$
b_n=1+\tfrac12(y^Ty-m_n^TV_n^{-1}m_n).
$$

At design row $h$, integrating coefficients and residual variance yields

$$
y_*\mid y\sim t_{2a_n}\left(h^Tm_n,
\sqrt{\frac{b_n}{a_n}(1+h^TV_nh)}\right).
$$

The second displayed argument is the Student distribution's scale, not its standard deviation. For degrees of freedom greater than two, its variance additionally multiplies squared scale by $\nu/(\nu-2)$. The leading one inside parentheses represents new observation noise. Dropping it would score a latent-mean distribution against noisy outcomes and make predictions excessively concentrated.

As a small independently checkable fixture, use inputs −1, 0, 1 and responses 0.2, 0.8, 1.4 under the linear model. Compute the training center, SD, design and posterior, then evaluate the predictive density at input 0.4 and outcome 0.9. Lab 29 verifies that answer in a different way: integrate coefficients and variance jointly for the combined training and new response vector, evaluate the multivariate Student density, and divide by the training marginal density. Its log ratio agrees with the coefficient-space predictive calculation within $10^{-9}$.

For that fixture, the training center is 0 and population SD is 0.816497. The posterior coefficient mean is (0.738462, 0.367423), with shape 4.5 and rate 1.163846. At input 0.4 the predictive mean is 0.918462, Student scale is 0.594752 and degrees of freedom are 9; the log density at outcome 0.9 is −0.427584. These intermediate values let you locate a disagreement in scaling, fitting or prediction before testing the joint-density ratio.

This identity tests the conjugate distribution and scale convention. It does not establish that the chosen polynomial mean or inverse-gamma prior is scientifically adequate. Posterior predictive checks for residual pattern and spread still matter. Nor does it imply that a mixture of Student distributions is itself Student; the final stack remains a mixture density.

---

Source: `course/advanced/14_predictive_combination.md:59–69`

## Why a held-out density matrix is necessary

A fixed, outcome-independent permutation assigns development IDs to five folds. For each fold and candidate, fit the input transformation using the other four folds, fit the posterior there, and evaluate a predictive log density at each held-out row's observed response. Put that result in the row's original position. The completed matrix has 100 rows and two columns. Every cell concerns the same observational unit and conditioning target as the other cell in its row.

Saving fold membership and transformations makes the information boundary inspectable. A low density should mean that a candidate predicted that observation poorly, not that rows were misaligned or one column used a different outcome transformation. Comparing a density in seconds with another in minutes without the relevant Jacobian would also invalidate the objective. Here all candidates score the same response in the same units.

No group effects occur in this synthetic example. In an application with sites or subjects, a held-out subject's outcomes cannot help estimate its effect. Decide whether the target is another observation from a known group or an observation from a new group. That decision controls fold construction, effect integration and scoring units. Merely moving a scaler inside the fold does not repair leakage through an estimated group effect.

![Development folds, weight fitting and outer evaluation, with the learned objective curve.](../../artifacts/figures/29_predictive_combination_01.svg)

The flow diagram shows two distinct uses of held-out information. Fold-held-out outcomes train the combination weights. They are not subsequently untouched evidence about those weights. The outer sample evaluates the entire frozen procedure. In the implementation, outer data are generated only after weight estimation, development refitting and a digest of the resulting rules have been constructed.

---

Source: `course/advanced/14_predictive_combination.md:71–90`

## Worked example 2: optimize densities before logs

Let $p_{i1}$ and $p_{i2}$ be the two held-out predictive densities for row $i$. The stacking rule chooses $0\le w\le1$ to maximize

$$
L(w)=\sum_i\log\{wp_{i1}+(1-w)p_{i2}\}.
$$

For a simple two-row illustration, take columns $(0.8,0.2)$ and $(0.2,0.8)$. At weight one half, each mixture probability is 0.5, giving total log score $2\log0.5\approx-1.386$. Either endpoint gives $\log0.8+\log0.2\approx-1.833$. The mixture benefits because each component compensates for the other's weak row. This does not make one half optimal for arbitrary data; the third row in the optional assessment changes the calculation.

Averaging log densities would instead optimize $w\sum\log p_{i1}+(1-w)\sum\log p_{i2}$, a linear function of the weight. It usually selects an endpoint and represents a different operation. Average the densities for each observation, then take its logarithm. The lab uses stable log-sum-exp arithmetic to avoid underflow when densities are very small.

For positive component densities, the derivative and second derivative are

$$
L'(w)=\sum_i\frac{p_{i1}-p_{i2}}{wp_{i1}+(1-w)p_{i2}},\qquad
L''(w)=-\sum_i\frac{(p_{i1}-p_{i2})^2}{\{wp_{i1}+(1-w)p_{i2}\}^2}.
$$

Concavity supplies a strong numerical check. At an interior optimum the first derivative should be near zero; at zero it should be nonpositive and at one nonnegative. The lab compares bounded optimization with both endpoints and an independently evaluated grid of 10,001 weights. Its result passes the declared objective and derivative checks. A numerical optimizer alone would be weaker evidence, especially if it reported a point just inside a superior endpoint.

---

Source: `course/advanced/14_predictive_combination.md:92–104`

## What the fitted combination actually did

The learned weight on the linear model is approximately 0.05096; the remainder is on the quadratic model. This means the linear predictive density made a small useful contribution to the development objective. It is not a 5.1% posterior probability that the linear model is true. Stacking optimizes a predictive mixture within the supplied candidates, and its weights depend on those candidates, the scoring rule, and the development observations.

On the independent outer sample, mean log scores are approximately −1.08983 for linear, −0.87877 for quadratic, −0.95547 for the fixed half-and-half mixture, and −0.88451 for the fitted stack. Larger is better. The stack beats linear by 0.20532 units per row, with paired SE 0.04215, and the fixed mixture by 0.07096, with SE 0.01806. It loses to quadratic by 0.00574, with SE 0.00210.

![Mixture predictive densities and paired outer score differences.](../../artifacts/figures/29_predictive_combination_02.svg)

The right panel reports differences using the same outer rows for both predictions. If $d_i$ is stack log score minus comparator log score, the estimated standard error is $s_d/\sqrt{100}$. Treating component scores as independent would discard this pairing. Two-SE bars are a familiar approximate uncertainty display, not an exact finite-sample confidence guarantee or evidence from repeated independent model-development exercises.

Empirical coverage of nominal 90% predictive intervals is 0.85 for linear and 0.90 for quadratic, the fixed mixture and the stack. Intervals for mixtures are computed by inverting the mixture Student CDF. Equal coverage does not mean equal predictive quality: interval width, density shape, and the locations of misses also matter. With only 100 outer rows, even coverage estimated at exactly 0.90 has appreciable sampling uncertainty.

The negative comparison with quadratic is a central finding. The learned mixture nearly selected that component, but the small addition that helped on development data hurt on this particular outer sample. This is compatible with correct optimization. It also illustrates why a development objective cannot stand in for evaluation. After seeing the outer result, replacing the stack with quadratic might be a reasonable future decision, but that revised selection would need fresh evaluation before being presented as independently validated.

---

Source: `course/advanced/14_predictive_combination.md:106–108`

## Density scores depend on a declared outcome scale

A predictive density has reciprocal outcome units. If response units change by a positive factor c, the transformed density divides by c and every log score shifts by minus log c. When all candidates use the same transformation, their paired log-score differences stay unchanged because the common shift cancels. Comparing one candidate in the original units with another in transformed units without a Jacobian would instead create an artificial advantage. This provides a useful independent check of a scoring pipeline: transform the outcome and every candidate consistently, then verify that relative scores agree. Coverage alone would not reveal every such error, because interval endpoints might be transformed correctly while density normalization is not. Before extending the lab to models of a logged response, write the predictive density on the actual scoring scale and identify its Jacobian explicitly. This is part of defining comparable predictions, not an optional numerical decoration after weight fitting.

---

Source: `course/advanced/14_predictive_combination.md:110–116`

## Investigation: duplicate a model

Save a prediction before running the changed-givens section of [Lab 29](../../labs/29_predictive_combination.py). Duplicate the entire linear column of held-out predictions and optimize three simplex weights. Should the duplicate copies receive equal weight? Should their total weight change? What should happen to predictions if one copy gains exactly the weight lost by the other?

Because the duplicate columns are identical, the objective depends only on their combined weight. The lab runs two declared initializations. One solution splits the roughly 0.05096 total into about 0.01699 and 0.03397; another into about 0.03822 and 0.01274. Both give effectively the same density mixture, with maximum checked predictive discrepancy around $2.3\times10^{-8}$. Different individual weights are expected nonidentifiability, not automatically an optimizer failure.

This example warns against interpreting small differences in model weights as stable scientific rankings. Correlated or nearly duplicate candidates can produce similar instability without being exactly identical. Examine predictive differences, not just a sorted list of weights. A richer candidate library may help prediction, but choosing that library after inspecting outer errors uses the outer sample for development.

---

Source: `course/advanced/14_predictive_combination.md:118–124`

## A defensible workflow beyond this example

Start by stating what a future observation means, what covariates will be available then, and what the candidate predictive densities condition on. Freeze the transformation, prior, fold and scoring rules. Trace a particular row through those rules before trusting the full matrix. An outer design that differs from deployment cannot be repaired by precise weight optimization. For dependent time series, random row folds may expose future information; for grouped observations, the group rather than the row may be the appropriate held-out unit.

Keep three claims separate in your report. The conjugate reference supports the density calculation. The grid and derivative checks support optimization of the specified development objective. The outer comparison estimates performance of the frozen procedure on the stated population. None proves that the population will remain unchanged or that candidate models contain every scientifically plausible mechanism.

Attempt the three [optional questions](../exercises/continuation_questions.md#adv-predictive-combination-1), save your calculations and diagnosis, then consult feedback. A useful independent investigation substitutes survival or nominal-response candidates only after defining comparable predictive units; that is additional project work, not something already completed by this lab. The [loo stacking vignette](https://mc-stan.org/loo/articles/loo2-weights.html) and [stacking paper](https://arxiv.org/html/1704.02030v3) provide methodological background. Their examples are separate from this original synthetic analysis and do not validate its local results.

---

Source: `course/advanced/15_variational_fit.md:1–7`

# A15 — Fit a variational posterior, then ask what it misses

A sensor has an unknown offset and a positive gain. You have twelve calibration readings and need to predict its response beyond the calibration range. A Gaussian approximation is quick to evaluate and convenient to store. Does a well-optimized Gaussian preserve the uncertainty that matters for this prediction? Before looking at a contour plot, explain how a larger gain could be compensated by a smaller offset over a short input range.

This optional chapter follows [A01](01_approximation.md), Gaussian regression and the optimization and integration appendices. Allow six to eight hours for the worked lab, investigation and questions. A01 derives an optimal approximation for a Gaussian target; this chapter actually runs an optimizer for a nonlinear target. Optimization already appears elsewhere in the course, including proposal fitting and prior elicitation. The new step is optimizing a variational distribution and separating its numerical convergence from its posterior accuracy.

Within the continuation, A13 and A16 integrate low-dimensional hyperparameters, while A10 uses sampling and A12 deterministic posterior integration. Those methods offer useful comparisons rather than a ranking of universally best algorithms. The common question is whether computational evidence supports the particular mean, covariance or tail being reported. None of these optional modules changes the core assessments.

---

Source: `course/advanced/15_variational_fit.md:9–28`

## The scientific model comes first

The observation unit is a calibration reading at a known input. The fitted response model is

$$
y_i=a+\exp(b)x_i+\epsilon_i,\qquad
\epsilon_i\sim N(0,0.3^2),
$$

with independent priors $a\sim N(0,1)$ and $b\sim N(0,0.7^2)$. Offset $a$ has response units, while $b$ is log gain under the stated input/output convention. The gain is positive because it is exponentiated. The noise SD 0.3 is treated as known. The synthetic generator uses offset 0.25, log gain −0.4 and twelve equally spaced inputs from 0.2 to 1.2. This is an original teaching mechanism, not a validated description of a real sensor.

The response is nonlinear in $b$, so a Gaussian prior does not yield a Gaussian posterior in $(a,b)$. Conditional on a particular $b$, however, inference for $a$ is Gaussian. This partial conjugacy gives us a strong independent numerical reference while leaving a genuinely nonconjugate joint target for variational fitting.

We care about posterior gain, offset/log-gain covariance, and

$$
P\{a+1.5\exp(b)>1.3\mid y\}.
$$

The event concerns the latent mean response at input 1.5. A future noisy reading above 1.3 is a different event and would integrate an additional observation-noise tail. State which event informs your decision before choosing an approximation: a visually plausible posterior may still distort its probability.

---

Source: `course/advanced/15_variational_fit.md:30–44`

## Choose a family, not just an algorithm

We fit two families in the original offset/log-gain coordinates. The diagonal family is $q(a,b)=N(a;m_a,s_a^2)N(b;m_b,s_b^2)$. The full family is a bivariate Gaussian with a free positive-definite covariance. Its lower-triangular factor has positive diagonal entries, represented by exponentials of unconstrained log scales. For a full factor, the second diagonal entry is a conditional scale parameter; the marginal SD of $b$ also depends on the off-diagonal entry.

Coordinate choice matters. A Gaussian in $(a,b)$ induces a non-Gaussian distribution for positive gain. A Gaussian directly in $(a,\exp b)$ would be a different family and could assign probability to negative gain unless constrained. Calling both “Gaussian VI” would conceal an important modeling approximation.

Maximizing the evidence lower bound,

$$
\operatorname{ELBO}(q)=E_q[\log p(y,a,b)]-E_q[\log q(a,b)],
$$

is equivalent to minimizing $KL(q\Vert p(a,b\mid y))$. The marginal likelihood is constant with respect to the variational parameters. The direction of KL matters: this objective penalizes placing approximation mass where the target density is small and can concentrate the approximation. It is not designed to match every marginal variance or every decision-tail probability.

A full covariance expands the family and cannot have a worse globally optimal ELBO than the diagonal subfamily. That mathematical ordering does not imply a smaller error for every particular target. The lab supplies a concrete counterexample for the decision tail, even when the full family's contour looks more convincing.

---

Source: `course/advanced/15_variational_fit.md:46–60`

## Worked example 1: optimize a target whose answer is known

Before using the nonlinear model, fit a Gaussian target with mean $(1,-0.5)$ and covariance

$$
\Sigma=\begin{pmatrix}1&0.8\\0.8&1\end{pmatrix}.
$$

Its precision is $\Sigma^{-1}=(1/0.36)\begin{pmatrix}1&-0.8\\-0.8&1\end{pmatrix}$. The reverse-KL diagonal optimum has the correct mean and variances equal to reciprocal precision diagonals, both 0.36. They are not the target marginal variances of one. The full Gaussian optimum recovers the target covariance itself.

Actually run the optimizer for both families. Then compare its fitted means and covariance entries with these analytic answers to tolerance $10^{-6}$. This checks parameterization, entropy, gradients and optimization together. Merely assigning the known answer would test neither the optimizer nor the chain of transformations it uses.

For the target's sum, variance is 3.6; the mean-field approximation gives 0.72. For the difference, target variance is 0.4, and mean-field still gives 0.72. The same approximate covariance understates one contrast and overstates another. “VI underestimates uncertainty” is an incomplete description unless you state the target and family. Changing the sign of correlation reverses which contrast is compressed, connecting this anchor to A01's changed-correlation investigation.

The Gaussian test passes in Lab 30. Its success is a bounded implementation check. It cannot prove that a Gaussian family approximates the nonlinear sensor posterior, just as a correct linear algebra routine cannot prove that an assumed scientific likelihood is appropriate.

---

Source: `course/advanced/15_variational_fit.md:62–83`

## Worked example 2: evaluate the nonlinear ELBO

Let a joint Gaussian approximation have means $m_a,m_b$, variances $v_a,v_b$ and covariance $c$. Its exponential moments are

$$
E[e^b]=e^{m_b+v_b/2},\quad E[e^{2b}]=e^{2m_b+2v_b},
\quad E[ae^b]=(m_a+c)e^{m_b+v_b/2}.
$$

Expand the squared residual before taking expectations:

$$
E[(y-a-xe^b)^2]
=y^2-2ym_a-2yxE[e^b]+m_a^2+v_a
+2xE[ae^b]+x^2E[e^{2b}].
$$

The covariance contribution in $E[ae^b]$ is essential for the full family. Omitting it would optimize an incorrect objective while still allowing the code to produce smooth traces. Add the Gaussian prior expectations and analytic Gaussian entropy to obtain the ELBO. These identities make objective evaluation deterministic; they do not tell us the maximizing variational parameters.

Lab 30 uses BFGS from means $(0,0)$, $(0.7,-0.7)$ and $(-0.7,0.7)$, with initial SDs 0.5 and zero correlation. The declared maximum is 2,000 iterations and gradient tolerance $10^{-8}$. Complex-step derivatives avoid subtractive cancellation in the optimization gradient. Independently, centered finite differences at fixed parameter points check those derivatives. Gauss–Hermite rules of orders 21 and 41 integrate the direct log joint at several fixed Gaussian distributions and check the closed-form objective to $10^{-7}$.

Every start retains initial and final objective, callback trajectory, gradient norm, iteration count, status and message. Some runs report precision loss even with small independently evaluated gradients. Those messages remain visible. Selecting the largest attained ELBO is a declared selection rule; deleting unfavorable starts or renaming precision loss as success would destroy useful diagnostic evidence.

---

Source: `course/advanced/15_variational_fit.md:85–109`

## Build an independent posterior reference

Conditional on log gain $b$, define $r_i=y_i-e^b x_i$. The offset posterior has

$$
v_a(b)=\left(1+n/0.09\right)^{-1},\qquad
m_a(b)=v_a(b)\sum_i r_i/0.09.
$$

Integrating offset analytically leaves a one-dimensional log-gain density proportional to

$$
\exp\left[-\frac12\left\{\frac{\sum r_i^2}{0.09}
-\frac{(\sum r_i/0.09)^2}{1+n/0.09}+\frac{b^2}{0.49}\right\}\right].
$$

Terms constant in $b$ cancel when normalizing posterior moments. The reference record's normalizer therefore concerns this proportional kernel; it should not be interpreted as the model's marginal likelihood. Direct two-dimensional integration includes the normalized joint density separately.

Adaptive quadrature integrates the kernel, moments and conditional Normal tail on [−5,5], then repeats on [−7,7]. The tail integral conditions on $b$, using the Gaussian probability that offset exceeds $1.3-1.5e^b$. This avoids approximating a discontinuous two-dimensional indicator on a coarse grid. Separate two-dimensional Gauss–Legendre rules of orders 121 and 181 cross-check means and covariances. These routes share the scientific model but differ in numerical reduction and implementation.

The expanded reference yields offset mean about 0.25451, gain mean 0.78593, covariance between offset and log gain −0.05270, and decision-tail probability 0.72942. Bound expansion changes the original tail by much less than $10^{-5}$. Reported adaptive error estimates and tensor discrepancies are numerical evidence, not mathematical guarantees about every omitted tail or every future dataset.

![Nonlinear posterior contours and actually optimized Gaussian contours.](../../artifacts/figures/30_variational_fit_01.svg)

The contour levels are 10%, 50% and 90% of each distribution's peak density as approximated on the finite plotting grid: each displayed density is divided by its sampled grid maximum. They are not 10%, 50% and 90% enclosed-probability regions. The diagonal ellipse cannot follow the negative dependence; the full ellipse can tilt, but the nonlinear target has curvature and shape that an ellipse cannot reproduce. A good visual inspection names both successes and remaining differences.

---

Source: `course/advanced/15_variational_fit.md:111–121`

## Read the targets, not just the trace

The diagonal approximation gives gain mean about 0.76609 and gain variance 0.01195, versus reference variance 0.05615. The full approximation gives mean 0.78839 and variance 0.04427. Its gain uncertainty is closer to the reference, though still compressed. Offset/log-gain covariance is zero by construction in the diagonal family and approximately −0.03769 in the full family, compared with −0.05270 in the reference.

Yet the diagonal decision tail is approximately 0.72906, exceptionally close to reference 0.72942, while the full approximation gives 0.74801. This is target-specific cancellation, not evidence that removing covariance is generally advantageous. The full approximation has the more flexible family and a better fitted objective, but the chosen event slices through the posterior in a way not summarized by either fact.

![Optimization trajectories and target-tail discrepancies for original and narrowed calibration inputs.](../../artifacts/figures/30_variational_fit_02.svg)

The optimization panel includes all starts, and the target panel compares probabilities with the independent reference. Keep three error sources separate. Optimizer error concerns reaching a good point within the chosen family. Family error is what remains when that family is optimized accurately. Scientific model error concerns the assumed response, prior, noise and observation mechanism. More iterations may address the first; a richer family may address the second; neither alone addresses the third.

R-hat is a diagnostic for comparing simulation chains, not a certificate for deterministic VI convergence. Likewise, drawing a million values from a fitted Gaussian can make its Monte Carlo error tiny while leaving its discrepancy from the target unchanged. In this lab the objective is deterministic, so noisy ELBO estimates do not explain persistent target differences.

---

Source: `course/advanced/15_variational_fit.md:123–125`

## A prediction can hide a covariance error

For a future latent response at input x, the Gaussian approximation implies mean $m_a+xE[e^b]$ and variance $v_a+x^2\operatorname{Var}(e^b)+2x\operatorname{Cov}(a,e^b)$. The last covariance equals $cE[e^b]$. Near the observed calibration range, negative dependence can make the total response much more precise than either offset or gain alone suggests. Extrapolation changes the balance because the gain-variance term grows quadratically with input while the covariance term grows linearly. Checking only the posterior mean curve can therefore conceal both missing dependence and underestimated gain uncertainty. Compute these terms separately at an interior input and at 1.5, and explain their signs before looking at a total interval. This algebra does not make the response distribution Gaussian: exponentiated log gain is lognormal and correlated with offset. Moment agreement is a useful diagnostic but cannot substitute for the tail calculation used in the decision. Two distributions can share a mean and variance while assigning different probabilities to that event.

---

Source: `course/advanced/15_variational_fit.md:127–135`

## Investigation: shorten the calibration range

Predict what happens when all twelve inputs lie between 0.2 and 0.5. Save an explanation before viewing the changed analysis in [Lab 30](../../labs/30_variational_fit.py). The lab generates fresh readings from a separate random stream with the same offset, gain and noise mechanism, then repeats both fits and the independent reference. Narrowing the input range makes it harder to distinguish an offset shift from a gain change, while the event at input 1.5 becomes a longer extrapolation.

The actual changed reference tail is approximately 0.92573. The fitted diagonal and full Gaussian tails are about 0.99590 and 0.99883. Both substantially overstate that probability, and full covariance does not solve the problem. Reference gain mean is about 1.47288 in this realized sample, not the generating gain $e^{-0.4}$. Sampling variation and weak identification can move a posterior substantially; an analysis must report its observed result rather than force the fitted mean toward the simulation truth.

Compare the changed covariance, gain distribution and event probabilities with the original analysis. Explain why changing both design support and realized noise prevents attributing every numerical difference solely to range restriction. A paired investigation retaining a common noise vector could isolate that contrast more directly, but would be an additional experiment with its own declared design.

Finish the [optional questions](../exercises/continuation_questions.md#adv-variational-fit-1) before consulting worked feedback. For a continuation project, choose a consequential target before fitting and explain which independent reference would challenge your approximation. Count this work once if it also serves as your optional project. The [VI review](https://arxiv.org/html/1601.00670v9) explains the objective and family distinctions; [CmdStan's VI configuration guide](https://mc-stan.org/docs/cmdstan-guide/variational_config.html) motivates transparent optimization records. The present deterministic SciPy implementation is not an execution of CmdStan ADVI.

---

Source: `course/advanced/16_splines.md:1–5`

# A16 — Learn smooth additive effects

A coating process responds to both temperature and humidity. A straight line may miss a broad rise and fall, but a highly flexible curve can follow noise. How can we fit smooth effects while admitting uncertainty about how much curvature the observations support? Before looking at a spline basis, sketch a plausible temperature response and explain what observations near the boundary would tell you that observations near the center would not.

This optional chapter extends the basis-expansion idea from regression into a fitted additive model with learned regularization. Regression, predictive evaluation and the linear algebra and integration appendices are prerequisites; A06 is helpful but not required. Allow six to eight hours including Lab 31, the changed-support investigation and questions. With A13, A14 and A15 it forms the computational depth menu, estimated at 23–31 additional hours. Combined with the breadth modules, the seven-module route adds 40–54 planning hours. These are unpiloted estimates, not a claim that everything fits into the old core schedule.

---

Source: `course/advanced/16_splines.md:7–24`

## State the observation model and its limits

One observation is an independently prepared coating under known temperature and humidity. The two predictors are scaled to predetermined physical ranges [0,1]. These are fixed units, not minima and maxima estimated from all available rows. The original synthetic mechanism is

$$
y=0.2+0.7\sin(2\pi x)+0.6\cos(\pi z)+\epsilon,
\qquad\epsilon\sim N(0,0.2^2),
$$

with independent uniform inputs. There are 80 training observations and 40 independent outer observations. The fitted model assumes

$$
y_i=\alpha+f_x(x_i)+f_z(z_i)+\epsilon_i.
$$

Noise SD 0.2 is known in this bounded example. Additivity means that changing temperature has the same mean-response effect at every humidity. An interaction, such as temperature becoming harmful only at high humidity, lies outside this model. Smooth marginal effects cannot automatically represent that mechanism.

Our targets include centered component effects, total mean responses, future noisy outcomes, and predictive performance against a matched linear model. The component curves describe the model under its identifiability convention; they are not causal effects of interventions. A scientific application would require assumptions about how temperature and humidity were assigned and which other process conditions were controlled.

---

Source: `course/advanced/16_splines.md:26–36`

## Worked example 1: a basis is a collection of fixed functions

Write a smooth effect as $f(u)=\sum_j c_jB_j(u)$. At a particular input suppose three nonzero basis values are $(0.2,0.5,0.3)$ and the associated coefficients are $(1,-0.4,0.8)$. Then the prediction is $0.2-0.2+0.24=0.24$. The functions may vary nonlinearly with the predictor, but for fixed inputs the prediction is a dot product and is linear in the coefficients.

This distinction explains why Gaussian regression algebra remains useful. Building a nonlinear design matrix does not make the conditional coefficient posterior non-Gaussian when the likelihood and priors are Gaussian. The difficult question becomes which coefficient combinations should be shrunk, and how much. Ordinary independent small-variance priors on all raw coefficients would impose a particular curve prior, but would not transparently separate slope from curvature.

The lab uses cubic B-splines with four fixed interior knots at 0.2, 0.4, 0.6 and 0.8. Boundary knots at zero and one repeat four times, producing eight raw basis functions. Their values are nonnegative and sum to one within the domain, including endpoint evaluation. Local support means that only a few contribute at most interior inputs. Knots divide the polynomial pieces; they do not mean the fitted curve must have a sharp corner there.

![Eight cubic basis functions, posterior-mean weighted components, and their summed temperature effect.](../../artifacts/figures/31_splines_01.svg)

The figure follows the calculation from basis to weighted sum. Each middle-panel line is one raw basis function multiplied by its posterior-mean coefficient after the fitted centered effect has been mapped back to raw coordinates. The final line is their sum. Individual raw coefficients are coordinate-dependent quantities; the curve is the more useful scientific object. The plot therefore does not invite interpreting each coefficient as a separate physical mechanism.

---

Source: `course/advanced/16_splines.md:38–51`

## Worked example 2: penalize curvature, protect the nullspace

The derivative penalty is

$$
c^TRc=\int_0^1\{f''(u)\}^2du,\qquad
R_{jk}=\int_0^1 B_j''(u)B_k''(u)du.
$$

For $f(u)=a+bu$, the second derivative vanishes and the penalty is zero regardless of $a$ and $b$. For $f(u)=u^2$, the second derivative is two, so the penalty is exactly four. Lab 31 reconstructs these polynomials in the basis and verifies their penalties independently. It also checks that the raw penalty has exactly two numerically zero eigenvalues.

Each cubic basis has a piecewise linear second derivative. Products of those derivatives are piecewise quadratic, so three-point Gauss–Legendre integration on every knot interval is sufficient to integrate them exactly up to floating-point arithmetic. This is an actual integrated derivative penalty. An arbitrary second-difference penalty on coefficients may also encourage smoothness, but should not automatically be described as this exact continuous penalty, especially with different knot spacing.

A prior proportional only to $\exp[-c^TRc/(2\tau^2)]$ is improper. Moving arbitrarily far along either affine null direction leaves the penalty unchanged; integrating the supposed density along that direction diverges. A likelihood can sometimes make a posterior proper despite an improper prior, but that does not turn the prior into a probability distribution or make every comparison valid. Here we explicitly complete the model with proper priors.

---

Source: `course/advanced/16_splines.md:53–70`

## Identify the additive effects before fitting

An intercept and two unrestricted smooths are redundant: adding a constant to one smooth and subtracting it from the intercept leaves every fitted mean unchanged. We impose empirical training constraints

$$
\sum_{i\in train}f_x(x_i)=0,\qquad
\sum_{i\in train}f_z(z_i)=0.
$$

For each term, the mean row of its training basis defines a one-row constraint. An orthonormal nullspace matrix maps seven free coordinates into eight raw coefficients satisfying that constraint. Diagonalizing the restricted penalty then isolates one remaining zero-penalty affine direction and six positive-penalty directions. The training-derived transformation is stored and reused for future inputs. Recomputing centering using query rows would change the meaning of the fitted model at prediction time.

The intercept has prior $N(0,1)$. Each term's normalized affine coordinate also has prior $N(0,1)$. Each positive-penalty direction is divided by the square root of its penalty eigenvalue, making the penalty the squared norm of its new coordinates. Conditional on a smoothing SD $\tau_j$, those six coordinates receive independent $N(0,\tau_j^2)$ priors. Finally,

$$
\log\tau_x,\log\tau_z\ \stackrel{ind}{\sim}\ N(\log5,0.7^2).
$$

A larger smoothing SD permits more curvature; smaller values shrink it. Some software calls the inverse variance a smoothing parameter, reversing the verbal direction. Always state the parameterization. The normalized affine coordinate is not a slope in original physical units, so its unit-SD prior should be understood through its mapped curve. The lab draws 2,000 prior coefficient sets and reports mean-response intervals at fixed queries to make that induced scale inspectable.

---

Source: `course/advanced/16_splines.md:72–85`

## Integrate coefficients and smoothing uncertainty

Conditional on the two smoothing scales, the model is a proper Gaussian regression with known noise variance. If coefficient prior covariance is $D$, its posterior covariance and mean are

$$
V=(D^{-1}+X^TX/0.04)^{-1},\qquad
m=VX^Ty/0.04.
$$

Integrating coefficients gives a Gaussian marginal likelihood with observation covariance $0.04I+XDX^T$. The implementation works in prior-whitened coefficient space, which is smaller and remains stable when some prior variances approach zero. An independent tiny fixture evaluates the observation-space multivariate Normal density and conditioning formulas directly to check the coefficient-space calculation.

Numerical integration over log smoothing scales combines this marginal likelihood with their proper priors. Each quadrature node supplies a coefficient posterior and therefore a Normal distribution for any linear function of coefficients. The full predictive distribution is a mixture. Means and total covariance average conditional uncertainty and between-node differences; interval endpoints invert mixture CDFs. Adding 0.04 produces future-observation variance within every component. Averaging component endpoints would repeat the mixture-quantile mistake discussed in A13.

The initial rules used orders 31, 61 and 91 over six prior SDs, followed by an eight-SD expansion. In the changed-support analysis, the coarsest CDF comparison missed the $10^{-4}$ criterion by a small amount. That failed execution remains recorded. A further 121-point rule checks the expanded domain without relaxing mean, CDF, endpoint or normalizer criteria. This is numerical refinement after a documented failure, not tuning the model to improve its evaluation score.

---

Source: `course/advanced/16_splines.md:87–95`

## What the fitted curves and predictions show

Posterior mean smoothing SDs are approximately 9.14 for temperature and 2.76 for humidity. The greater permitted temperature curvature accords with a full oscillation across the domain, while the humidity mechanism makes a smoother half-wave. That interpretation is specific to the chosen derivative penalty and coordinate scaling; comparing these numbers to an unrelated basis parameterization would be misleading.

At humidity 0.5, predicted noisy-response means at temperatures 0.25, 0.5 and 0.9 are about 0.840, 0.114 and −0.244. Their 90% predictive intervals are approximately [0.494,1.186], [−0.231,0.458] and [−0.587,0.100]. These include residual variation, so they are wider than uncertainty intervals for the latent mean. The figures show component uncertainty rather than treating the plotted posterior mean as the whole result.

![Centered effects, posterior smoothing mass, and additive-versus-linear outer score differences.](../../artifacts/figures/31_splines_02.svg)

The posterior hyperparameter panel displays quadrature mass over log-scale nodes. The colors locate mass in this particular numerical grid; without dividing by integration weights they are not posterior density heights and should not be compared across quadrature resolutions. The effect panels compare the original fit with a changed training-support analysis. Their vertical zero points depend on each analysis's training-centering convention. A shifted component curve is not necessarily evidence of a changed physical effect; compare total response predictions as well as centered components.

---

Source: `course/advanced/16_splines.md:97–103`

## Compare a genuinely matched linear baseline

The baseline retains exactly the intercept and the two unpenalized affine directions, with the same proper priors as the additive model. It therefore matches the limiting model as both curvature SDs approach zero. A separately chosen raw slope prior might produce a different linear model and confound the comparison of functional flexibility with a change in prior scale. The lab verifies the small-$\tau$ limit numerically at $10^{-6}$.

Both fits are completed using training data before outer data are generated. Knots, physical units, centering, priors, noise assumptions and model definitions are not selected from evaluation outcomes. Prediction receives only query inputs; a separate scoring step receives outcomes. Tests also check that perturbing outer outcomes cannot alter a fitted transformation or its predictions.

On the 40 outer observations, additive minus linear mean log score is approximately 0.953, with paired row SE 0.309. Mean scores are about 0.046 and −0.907 respectively; positive log density is possible for a continuous outcome whose density exceeds one in its units. The additive model's nominal 90% predictive coverage is 0.925, or 37 of 40 rows. That small sample provides limited precision. The favorable comparison supports this frozen analysis on this synthetic population; it does not establish that additive splines outperform linear regression in general.

---

Source: `course/advanced/16_splines.md:105–111`

## Boundaries are modeling choices

Clamping the knots defines basis evaluation at the endpoints; it does not mean the fitted curve is flat there. Boundary behavior is influenced by fewer nearby observations, proper nullspace priors and the curvature penalty. The implementation rejects inputs outside [0,1] instead of silently extending the terminal polynomial piece. A library's ability to extrapolate does not supply scientific justification for that extrapolation.

If an application needs predictions outside the physical range, choose and explain a boundary model: for example, a separately justified linear continuation, a saturating mean, or a mechanistic model. Then propagate its uncertainty and assess it where data are available. Such a model is additional work. It is not already supported by the present fitted intervals.

Even inside [0,1], weak data support can make predictions strongly prior-dependent. Predictor correlation can also make the division between two additive effects uncertain despite a well-estimated total mean. Sum-to-zero constraints remove exact algebraic ambiguity; they do not create information about every combination of temperature and humidity.

---

Source: `course/advanced/16_splines.md:113–119`

## Investigation: remove the warmest training settings

Before viewing the changed analysis in [Lab 31](../../labs/31_splines.py), predict the consequences of dropping all training rows with temperature above 0.7 while retaining the same physical domain and knots. Save the prediction and name a query where loss of support should be especially consequential. The lab refits both smoothing scales and propagates their uncertainty using the retained rows.

At temperature 0.9 and humidity 0.5, the changed noisy interval is roughly [−0.939,0.874], compared with [−0.587,0.100] originally. Its mean shifts to about −0.047. This is extrapolation relative to observed training support, even though the query remains inside the permitted physical basis domain. Distinguish those two meanings of extrapolation. The changed smoothing means also increase, but one realized dataset does not establish a universal rule that removing observations increases smoothing SDs or widens every interval.

Explain why the component centering changes when rows disappear and why a total-response comparison is needed alongside the effect plot. Diagnose what an unmodeled temperature–humidity interaction would look like in residual checks. Finally attempt the three [optional questions](../exercises/continuation_questions.md#adv-splines-1), save your work and then consult feedback. For a continuation project, combine these ideas with A14's evaluation boundaries or A13's joint curve functionals, naming any displaced optional activity and counting shared analysis once. Background on basis construction appears in [Bayesian Modeling and Computation](https://bayesiancomputationbook.com/markdown/chp_05.html), while [smooth identifiability](https://www.stat.ethz.ch/R-manual/R-devel/library/mgcv/html/identifiability.html) explains why additive constraints need explicit treatment.

---

Source: `course/exercises/questions.md:8–12`

### extra.0.1 — Reverse a quality-control table

Objectives: L00.O4, L00.O2 · Difficulty: introductory · Type: numerical · Optional practice.

A shipment contains 30% refurbished and 70% new devices. Conditional defect probabilities are 0.12 and 0.02 respectively. Treat these probabilities as known and the groups as exhaustive. Construct the four-cell table of joint probabilities for group and defect status. Find the marginal defect probability and the probability a defective device is refurbished. Explain which population supplies each denominator.

---

Source: `course/exercises/questions.md:16–20`

### extra.0.2 — Variance in a mixed arrival process

Objectives: L00.O4 · Difficulty: intermediate · Type: derivation · Optional practice.

A monitoring period uses mode A with probability 1/4 and mode B with probability 3/4. Given mode A, the event count $Y$ is Poisson(2); given B it is Poisson(6). You may use that a Poisson($\lambda$) count has mean and variance $\lambda$. Derive the law of total variance for this model by explaining why the cross term vanishes. Evaluate $E(Y)$, the within-mode and between-mode variance contributions, and $\operatorname{Var}(Y)$. Is Poisson with the marginal mean an equivalent model?

---

Source: `course/exercises/questions.md:24–37`

### extra.0.3 — Repair the batch axis

Objectives: L00.O5, L00.O3 · Difficulty: intermediate · Type: coding · Optional practice.

The intended experiment is 4,000 independent batches, each containing 30 independent Bernoulli(0.4) trials. Diagnose this code and replace it with runnable NumPy logic:

```python
rng = np.random.default_rng(7003)
x = rng.binomial(1, .4, size=(4000, 30))
batch_count = x.sum(axis=0)
estimated_parameter = batch_count.mean()
```

Return the batch-count vector, its sample mean and sample variance, and a separate estimate of the fixed success probability. State the theoretical count moments, a five-standard-error tolerance for the count mean, and why a count variance is not posterior uncertainty in the probability. Do not demand exact equality from one random seed.

---

Source: `course/exercises/questions.md:41–45`

### extra.0.4 — Two seeds, one estimand

Objectives: L00.O5, L00.O1 · Difficulty: introductory · Type: conceptual · Optional practice.

Two independent simulations each use 10,000 Bernoulli trials with fixed success probability 0.08. Their estimated probabilities are 0.076 and 0.084. Explain in 100–150 words whether this disagreement establishes a bug, estimate the standard error of each estimate and of their difference, and distinguish adding simulated trials from collecting new scientific data. Assume the two random streams are independent; the estimates are supplied hypothetical results.

---

Source: `course/exercises/questions.md:51–55`

### extra.1.1 — Two-stage evidence for three mechanisms

Objectives: L01.O4, L01.O2 · Difficulty: intermediate · Type: numerical · Optional practice.

Mutually exclusive, exhaustive mechanisms H1, H2, H3 have priors (0.5, 0.3, 0.2). Their probabilities of event A are (0.2, 0.6, 0.8). Their probabilities of B given A are (0.9, 0.5, 0.25). Calculate the posterior table after A and after A and B. Calculate $P(A)$ and $P(B\mid A)$ and verify the final posterior by a single joint update. Do not assume A and B are conditionally independent.

---

Source: `course/exercises/questions.md:59–63`

### extra.1.2 — Odds and support

Objectives: L01.O4 · Difficulty: intermediate · Type: derivation · Optional practice.

Let H and its complement have prior probabilities $\pi$ and $1-\pi$, and likelihoods $\ell_1=P(E\mid H)$ and $\ell_0=P(E\mid H^c)$. Derive posterior odds and log odds when all quantities needed are positive. Then analyse $\pi=0$, $\ell_0=0$ with $\pi\ell_1>0$, and zero total evidence. Can finite positive likelihood evidence revive a hypothesis given exactly zero prior mass?

---

Source: `course/exercises/questions.md:67–71`

### extra.1.3 — Correlated reports

Objectives: L01.O5, L01.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

A fault has prior probability 0.2. The first report A is positive with probability 0.75 under a fault and 0.25 without a fault. Given that A was positive, report B is positive with probability 0.8 under a fault and 0.4 without a fault. Calculate the posterior after two positive reports. An analyst instead treats the reports as independent copies with likelihoods 0.75 and 0.25; calculate that shortcut's posterior. Also calculate the posterior if B is literally a copy of A. Identify what evidence each calculation uses.

---

Source: `course/exercises/questions.md:75–79`

### extra.1.4 — Communicate a changed screening population

Objectives: L01.O5, L01.O1 · Difficulty: introductory · Type: communication · Optional practice.

A detector has sensitivity 0.9 and false-positive probability 0.03. In the general population prevalence is 0.005; in a referred population it is 0.10. Assuming the detector's conditional performance transfers unchanged, calculate positive predictive probability in both populations. Write an 80–120-word message explaining why the original positive predictive probability should not be quoted to referred users and name an assumption to check. These are hypothetical screening probabilities, not guidance about a real medical test.

---

Source: `course/exercises/questions.md:85–89`

### extra.2.1 — Normalisation and beta moments

Objectives: L02.O4, L02.O2 · Difficulty: intermediate · Type: derivation · Optional practice.

For $a,b>0$, let $p(\theta)=C\theta^{a-1}(1-\theta)^{b-1}$ on $0<\theta<1$. Using $B(a,b)=\int_0^1 t^{a-1}(1-t)^{b-1}dt=\Gamma(a)\Gamma(b)/\Gamma(a+b)$ and $\Gamma(x+1)=x\Gamma(x)$, derive C, $E(\theta)$, $E(\theta^2)$ and $\operatorname{Var}(\theta)$. Explain why a density unbounded at an endpoint can still be proper. Evaluate mean and variance for $a=2,b=5$.

---

Source: `course/exercises/questions.md:93–97`

### extra.2.2 — Skewness and odds summaries

Objectives: L02.O4, L02.O1 · Difficulty: intermediate · Type: numerical · Optional practice.

A posterior is Beta(1,4). Find its mean, median and central 90% equal-tail interval, using its analytic CDF or a checked numerical routine. Transform the interval to odds $r=\theta/(1-\theta)$. Compare odds at the posterior mean with posterior mean odds; the latter can be obtained by integrating $r p(\theta)$. Which probability estimate minimises squared loss and which absolute loss? Explain whether transforming a highest-density interval generally preserves its highest-density property.

---

Source: `course/exercises/questions.md:101–105`

### extra.2.3 — Unequal cells need unequal masses

Objectives: L02.O5, L02.O3 · Difficulty: intermediate · Type: coding · Optional practice.

Approximate Beta(2,3) using cells with edges `[0, .1, .3, .6, .8, 1]` and their midpoints. The faulty code is `w = beta.pdf(mid, 2, 3); w /= w.sum()`. Repair it, preferably using log weights, and report normalised cell masses, approximate mean and $P(\theta>0.6)$. Compare with exact references and explain why the cutoff is convenient here. Refine every original cell into 100 equal subcells and show improved accuracy. Supply runnable code; do not reinterpret density heights as probabilities.

---

Source: `course/exercises/questions.md:109–113`

### extra.2.4 — All failures, all successes

Objectives: L02.O5 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Compare independent analyses of five trials with either zero or five successes under priors Beta(1,1) and Beta(2,8). Give a four-row table of posterior distributions and next-trial success probabilities. Diagnose the claim “all successes prove the rate is one, and a uniform prior means no prior assumptions.” Explain support and why these proper priors do not assign a point mass at an endpoint.

---

Source: `course/exercises/questions.md:119–123`

### extra.3.1 — Integrate a shared future probability

Objectives: L03.O4, L03.O2 · Difficulty: intermediate · Type: derivation · Optional practice.

Given data, $\theta\sim\operatorname{Beta}(a,b)$ with positive shapes. Conditional on one shared $\theta$, let $X_1,\ldots,X_m$ be independent Bernoulli trials and $K=\sum X_j$. Derive the marginal mass of K and explain why it sums to one. Derive $\operatorname{Cov}(X_i,X_j)$ for $i\ne j$ and $\operatorname{Var}(K)$, separating within-parameter and between-parameter variation. Evaluate the moments for a=2, b=3, m=4.

---

Source: `course/exercises/questions.md:127–131`

### extra.3.2 — Two superficially similar simulators

Objectives: L03.O4, L03.O1 · Difficulty: intermediate · Type: coding · Optional practice.

Simulate 100,000 four-trial batches under two models: A draws one Beta(2,3) probability per batch; B draws a fresh independent Beta(2,3) probability per trial. Use seed 7302. Write runnable code, identify each array axis and compare the count mean and variance in each model with analytic targets. Use mean tolerance 0.03 and variance tolerance 0.04, and explain these as generous simulation checks rather than guarantees. Why is B inappropriate for uncertainty about a single common probability?

---

Source: `course/exercises/questions.md:135–139`

### extra.3.3 — Elicit an observable extreme

Objectives: L03.O5 · Difficulty: intermediate · Type: numerical · Optional practice.

Before observing data, an engineer says that an eight-component batch, sharing one unknown reliability, should contain either zero or eight successes with probability below 0.05. Compare the prior predictive extreme probability under Beta(1,1) and Beta(10,10). Both priors have mean reliability 1/2. Calculate the probabilities exactly or with a beta-binomial routine; say which is consistent with the stated constraint and what the constraint does not establish.

---

Source: `course/exercises/questions.md:143–153`

### extra.3.4 — Explain a three-action choice

Objectives: L03.O5, L03.O3 · Difficulty: intermediate · Type: communication · Optional practice.

A machine is healthy, worn or critical with posterior probabilities (0.5, 0.3, 0.2). Losses in cost units are given below and already include all relevant consequences. Calculate expected loss for each action, choose a risk-neutral action and write an 80–120-word explanation. Find the largest uniform replacement loss at which replacement is weakly preferred, holding the other rows fixed.

| Action | Healthy | Worn | Critical |
|---|---:|---:|---:|
| Continue | 0 | 6 | 30 |
| Inspect and respond | 3 | 4 | 8 |
| Replace now | 5 | 5 | 5 |

---

Source: `course/exercises/questions.md:159–163`

### extra.4.1 — Predict counts over a new exposure

Objectives: L04.O4, L04.O2 · Difficulty: intermediate · Type: derivation · Optional practice.

Given data, an event rate per hour has posterior $\lambda\sim\operatorname{Gamma}(a,b)$ in shape-rate form, with $a,b>0$. A future count over t hours is conditionally Poisson($t\lambda$). Integrate out the rate to derive $P(K=k)$, identifying a negative-binomial convention explicitly. Derive its mean and variance and evaluate them for a=3, b=2 hours, t=4 hours. Explain the extra variance and the units of b and t.

---

Source: `course/exercises/questions.md:167–171`

### extra.4.2 — Change rate coordinates without changing predictions

Objectives: L04.O4, L04.O1 · Difficulty: intermediate · Type: numerical · Optional practice.

An hourly rate $\lambda$ has Gamma(4,2) shape-rate posterior. Define the rate per minute $r=\lambda/60$ and $z=\log(\lambda/(1\text{ event/hour}))$, with the reference unit implicit in numerical formulas. Give both transformed densities, including Jacobians. Compute the mean and variance of the count in 30 minutes using either rate coordinate, and numerically check $P(\lambda<3)=P(r<0.05)=P(z<\log3)$. State how you would check normalisation of the log-rate density.

---

Source: `course/exercises/questions.md:175–179`

### extra.4.3 — Uncertain scale changes the mean posterior

Objectives: L04.O5, L04.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Measurements are (2,4,4,6) in metres. Assume independent Normal($\mu,\sigma^2$) observations and the improper joint prior $p(\mu,\sigma^2)\propto1/\sigma^2$ with respect to $d\mu\,d\sigma^2$. Compare the integrated posterior for $\mu$ with a plug-in analysis that uses a flat prior on $\mu$ and treats the sample variance as a known observation variance. Give centres, scales, posterior variances and central 90% intervals. State when the integrated posterior is proper and when its mean and variance exist. Explain why “the standard errors match” would not justify identical intervals.

---

Source: `course/exercises/questions.md:183–187`

### extra.4.4 — Check square completion by quadrature

Objectives: L04.O5 · Difficulty: intermediate · Type: coding · Optional practice.

Let $\mu\sim\operatorname{Normal}(1,2)$, where 2 is the variance, and observations be 2 and 5 with known independent observation variance 2. Derive the posterior and the predictive distribution for one new measurement. Independently normalise a dense grid of the original prior-times-likelihood and check posterior mean and variance within 0.001 and posterior 5%/95% quantiles within 0.003. Provide runnable code and explain grid truncation/refinement. Why would evaluating only the derived posterior density be a weaker check?

---

Source: `course/exercises/questions.md:193–197`

### extra.5.1 — Precision for a rare posterior event

Objectives: L05.O4, L05.O2 · Difficulty: intermediate · Type: numerical · Optional practice.

In 50,000 independent posterior draws, exactly 100 satisfy a policy event. Estimate its probability and Monte Carlo standard error. Based on that pilot estimate, how many independent draws in total would target MCSE 0.0001? State the finite-variance/independence assumptions and explain why observing zero event hits would not prove zero event probability or provide a reliable zero-MCSE estimate. Separate precision of this computation from adequacy of the model.

---

Source: `course/exercises/questions.md:201–205`

### extra.5.2 — Self-normalised importance weights

Objectives: L05.O4 · Difficulty: intermediate · Type: derivation · Optional practice.

A proposal q covers the support of an unnormalised target $\tilde p$. Derive the self-normalised importance estimate for $E_p[h(X)]$ using draws from q. For raw weights (1,2,1,6) and corresponding h-values (0,1,2,4), calculate the estimate and weight ESS $(\sum w)^2/\sum w^2$. Explain finite-sample bias, conditions for consistency, and why a respectable weight ESS would not reveal a completely missed target tail.

---

Source: `course/exercises/questions.md:209–213`

### extra.5.3 — A jump-chain counterexample you can enumerate

Objectives: L05.O5, L05.O3 · Difficulty: advanced · Type: coding · Optional practice.

The target on states {0,1} is $\pi=(0.9,0.1)$. A Metropolis proposal always proposes the other state. Construct the exact transition matrix and verify stationarity. Starting at 0 with seed 7503, simulate 200,000 transitions, storing both every resulting state and only accepted moves. Compare each sample's fraction of ones with its theoretical target; use absolute tolerance 0.01 for the full chain. Provide runnable reference logic and explain why keeping repeated states is essential. No burn-in deletion is required for this long illustrative run, but discuss its initialisation limitation.

---

Source: `course/exercises/questions.md:217–221`

### extra.5.4 — Choose precision for the estimand

Objectives: L05.O5, L05.O1 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Two hypothetical sampler reports for the same target give means 0.60 and 0.60, posterior SD 0.10 in each, and mean ESS 4,000 and 400. For event $\theta>0.8$, they report probabilities 0.025 and 0.060 with indicator MCSE 0.003 and 0.020. A decision uses whether that probability exceeds 0.04. Write a diagnostic memo: calculate mean MCSEs, assess what mean agreement establishes, and propose checks and a stopping criterion for the event probability. No traces or acceptance rates are supplied; do not invent them.

---

Source: `course/exercises/questions.md:227–231`

### extra.6.1 — One Hamiltonian step

Objectives: L06.O4 · Difficulty: intermediate · Type: derivation · Optional practice.

Work in dimensionless coordinates with target $q\sim N(0,1)$, momentum mass 1, kinetic energy $p^2/2$, initial q=1 and p=0.5, and step size $\epsilon=0.4$. Derive and calculate one leapfrog step, including both half-momentum updates. Compute initial/final Hamiltonians, their difference and the Metropolis correction probability. Explain why the correction is needed even though the exact Hamiltonian flow conserves energy.

---

Source: `course/exercises/questions.md:235–239`

### extra.6.2 — A missing Jacobian on a log coordinate

Objectives: L06.O4, L06.O2 · Difficulty: intermediate · Type: diagnosis · Optional practice.

A positive rate has Gamma(3,2) density proportional to $\lambda^2 e^{-2\lambda}$. For $z=\log\lambda$, two proposed unnormalised log densities are A: $2z-2e^z$ and B: $3z-2e^z$. Select the correct one, derive its gradient, and identify the rate distribution obtained if A were used as the density with respect to dz. Explain when adding a manual Jacobian to a library's automatically transformed positive random variable would count it twice.

---

Source: `course/exercises/questions.md:243–247`

### extra.6.3 — Validate a new fit against an exact target

Objectives: L06.O5, L06.O3 · Difficulty: advanced · Type: coding · Optional practice.

Use prior Beta(3,5) and observe four successes in ten independent trials with one shared probability. Write a runnable four-chain PyMC fit with at least 1,000 warmup and 1,000 retained draws per chain, sequential cores and fixed seed 7603. Derive exact posterior mean and central 90% interval, and exact mean/variance of a future 12-trial count. Report this fit's own R-hat, bulk/tail ESS, divergences and mean MCSE when run; specify checks for numerical agreement and replicate the future count. Explain why exact-reference agreement does not establish scientific adequacy. A design-only submission must label unexecuted outputs explicitly.

---

Source: `course/exercises/questions.md:251–255`

### extra.6.4 — Two kinds of model review

Objectives: L06.O5, L06.O1 · Difficulty: intermediate · Type: communication · Optional practice.

A hypothetical waiting-time fit reports four chains, maximum R-hat 1.002, minimum bulk ESS 1,800, minimum tail ESS 1,200 and zero divergences. Mean MCSE is small relative to the decision's required precision. However, its normal posterior predictive distribution puts 18% probability below zero, and every observed wait is positive. Write a 120–180-word review with separate computational and modelling conclusions, one targeted predictive check and two concrete possible revisions. Do not claim access to traces, data or a fresh run beyond this packet.

---

Source: `course/exercises/questions.md:261–269`

### extra.7.1 — A two-coefficient Gaussian update

Objectives: L07.O4, L07.O2 · Difficulty: advanced · Type: derivation · Optional practice.

Let $y\mid\beta\sim N(X\beta,I_3)$ and $\beta\sim N(0,I_2)$, with

$$X=\begin{pmatrix}1&0\\1&1\\1&2\end{pmatrix},\qquad y=\begin{pmatrix}1\\2\\2\end{pmatrix}.$$

Derive the general Gaussian precision update from square completion and calculate this posterior's precision, covariance and mean. Give all matrix dimensions. Check the mean by solving the precision system and explain why off-diagonal covariance matters for prediction. Use linear solves in numerical code rather than a matrix inverse as the default algorithm.

---

Source: `course/exercises/questions.md:273–277`

### extra.7.2 — Where a regression line is precise

Objectives: L07.O4, L07.O1 · Difficulty: intermediate · Type: numerical · Optional practice.

The joint posterior mean of intercept and slope is (2,1), with covariance $V=\begin{pmatrix}1&-0.4\\-0.4&0.25\end{pmatrix}$. Observation SD is fixed at 0.6. At x=0 and x=2 calculate the posterior mean response, variance of that mean and variance of a new individual response. Compare with the erroneous calculation that discards coefficient covariance. Explain why individual and mean intervals answer different questions. Assume a Gaussian coefficient posterior and normal independent observation noise.

---

Source: `course/exercises/questions.md:281–285`

### extra.7.3 — A scaled prior is a joint prior

Objectives: L07.O5 · Difficulty: intermediate · Type: coding · Optional practice.

A regression uses $z=(x-10)/2$, with independent priors $\alpha_z\sim N(5,4)$ and $\beta_z\sim N(0,1)$; second arguments are variances. Derive the joint prior of original-scale coefficients in $\alpha+\beta x$. Give its mean/covariance and write NumPy code verifying prediction equality for x=(6,10,14) on the same 10,000 prior draws, seed 7703. Explain why retaining independent original-scale priors with the transformed marginal variances would change the model.

---

Source: `course/exercises/questions.md:289–293`

### extra.7.4 — Curvature, collinearity and extrapolation

Objectives: L07.O5, L07.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

A linear model is trained with x between 0 and 2. Average residuals in low, middle and high x bins are respectively +2, −4 and +2 response units. A second predictor has sample correlation 0.998 with x; the two slope posteriors are broad and strongly negatively correlated, though within-range predictions are stable. The client requests prediction at x=5. Write a diagnosis and evaluation plan addressing all three facts. State what additional information you need; the bin means and correlation alone do not justify selecting a final model or claiming a causal effect.

---

Source: `course/exercises/questions.md:299–303`

### extra.8.1 — Standardise on the probability scale

Objectives: L08.O4, L08.O1 · Difficulty: intermediate · Type: derivation · Optional practice.

For binary response y, treatment indicator a and stratum indicator z, let $p(a,z)=\operatorname{logit}^{-1}(-2+0.8a+2z)$. Derive the Bernoulli likelihood for independent observations $(y_i,a_i,z_i)$ conditional on the coefficients. A target population has weights 0.75 in z=0 and 0.25 in z=1. Calculate standardised risks under a=0 and a=1 and their difference. Compare with applying the inverse logit to the average linear predictor. Explain what extra assumptions a causal interpretation would require; coefficients here are supplied fixed values.

---

Source: `course/exercises/questions.md:307–311`

### extra.8.2 — Exposure and extra-Poisson variation

Objectives: L08.O4, L08.O2 · Difficulty: intermediate · Type: numerical · Optional practice.

A log rate is $\log\lambda=\log2+x\log1.5$, in events per hour. Two records both have x=1 but exposures 2 and 5 hours. Counts follow a negative-binomial model with mean $\mu=t\lambda$ and dispersion $\phi=4$, defined by $\operatorname{Var}(Y\mid\mu,\phi)=\mu+\mu^2/\phi$. Calculate rate, both means and variances and the corresponding Poisson variances. Write the log-mean with its offset. Explain why exposure should not be treated as another freely estimated slope in this specified model.

---

Source: `course/exercises/questions.md:315–319`

### extra.8.3 — A separated likelihood tail

Objectives: L08.O5 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Four binary observations have x=(-2,−1,1,2) and y=(0,0,1,1). Fit $P(y_i=1)=\operatorname{logit}^{-1}(\beta x_i)$ with intercept fixed at zero. Show what happens to the likelihood as $\beta\to+\infty$ and diagnose a proposal to use a flat prior on $\beta$ “because four perfectly classified observations identify the slope.” Compare proper Normal(0,$2.5^2$) and Normal(0,$25^2$) priors qualitatively. Propose a prior predictive and posterior sensitivity check; no sampled numeric output is required.

---

Source: `course/exercises/questions.md:323–327`

### extra.8.4 — Association under treatment selection

Objectives: L08.O5, L08.O3 · Difficulty: intermediate · Type: conceptual · Optional practice.

A service gives extra support to users judged especially likely to struggle. Some of that judgement is recorded as a difficulty score, but staff also see unrecorded circumstances. A logistic regression adjusting for the score estimates a negative support coefficient with a narrow posterior. State a defensible conclusion about association and explain why this does not establish that support harms completion. Define a useful causal target and describe a design or additional assumptions that could identify it. Address overlap and the difference between offering and receiving support.

---

Source: `course/exercises/questions.md:333–337`

### extra.9.1 — Shrinkage includes uncertainty

Objectives: L09.O4, L09.O2 · Difficulty: intermediate · Type: derivation · Optional practice.

A group mean has prior $\alpha\sim N(\mu,\tau^2)$ and n observations conditionally independent $N(\alpha,\sigma^2)$, with all hyperparameters fixed. Derive the conditional posterior mean and variance and its shrinkage weight. Evaluate for $\mu=10$, $\tau^2=4$, $\sigma^2=9$, n=3 and sample mean 13. Describe limits as n tends to infinity and as $\tau^2$ tends to zero, and what fixing hyperparameters leaves out.

---

Source: `course/exercises/questions.md:341–345`

### extra.9.2 — Two observations in an unseen group

Objectives: L09.O4, L09.O3 · Difficulty: intermediate · Type: numerical · Optional practice.

Given training data, $\mu\sim N(10,1)$; fixed between-group variance is $\tau^2=4$ and individual variance $\sigma^2=9$. A new group intercept is $\alpha_g=\mu+u_g$, with independent $u_g\sim N(0,4)$, independent of $\mu$. New outcomes are $Y_{gj}=\alpha_g+\epsilon_{gj}$ with independent $\epsilon_{gj}\sim N(0,9)$. Calculate each outcome's mean/variance, covariance of two outcomes in the same new group, covariance in two distinct new groups, and variance of their average in both cases. Explain how a joint simulation must share latent draws.

---

Source: `course/exercises/questions.md:349–353`

### extra.9.3 — Many rows, few groups

Objectives: L09.O5, L09.O1 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Three centres each contribute 500 measurements with known observation SD 1 metre. Their sample means are 9.8, 10.1 and 10.4 metres. Model centre means as independent $N(\mu,\tau^2)$ given hyperparameters, with $\mu\sim N(10,2^2)$ and either $\tau\sim\operatorname{HalfNormal}(0.2)$ or $\operatorname{HalfNormal}(2)$, in metres. An analyst says the 1,500 rows make the scale prior irrelevant. Diagnose that claim and design a prior/posterior sensitivity report for the mean in a fourth, unseen centre. State the exchangeability assumption and avoid claiming either prior is proven by these summaries.

---

Source: `course/exercises/questions.md:357–361`

### extra.9.4 — Equivalent hierarchies, different coordinates

Objectives: L09.O5 · Difficulty: advanced · Type: coding · Optional practice.

At fixed $\mu=2$, $\tau=0.5$, $\sigma=1$, consider J=3 latent group means and one observation per group y=(1,2,4). The centred model uses $\alpha_j\sim N(\mu,\tau^2)$; the noncentred model uses $z_j\sim N(0,1)$ and $\alpha_j=\mu+\tau z_j$. Derive their equality as distributions, including the Jacobian, and write a NumPy/SciPy check of joint log-density equality at z=(−1,0,2). Verify simulated prior moments using seed 7904 and 100,000 draws with 0.01 tolerance for mean and variance. Explain why equivalence does not imply identical sampler efficiency when scales become unknown.

---

Source: `course/exercises/questions.md:367–371`

### extra.10.1 — Four exact leave-one-out scores

Objectives: L10.O4 · Difficulty: intermediate · Type: numerical · Optional practice.

Four independent Bernoulli observations sharing one probability are y=(1,1,1,0), with prior Beta(1,1). Calculate the leave-one-out posterior for each held-out row, its held-out predictive mass and its natural log score. Sum the four log scores. Contrast with evaluating these same rows under the full-data posterior predictive distribution. State the predictive unit and why this tiny example does not establish broad model adequacy.

---

Source: `course/exercises/questions.md:375–379`

### extra.10.2 — Why leave-one-out weights become unstable

Objectives: L10.O4, L10.O2 · Difficulty: advanced · Type: derivation · Optional practice.

Assume $p(y\mid\theta)=\prod_j p(y_j\mid\theta)$, proper full and leave-one-out posteriors, and positive held-out likelihood on the relevant leave-one-out support. Derive the ratio $p(\theta\mid y_{-i})/p(\theta\mid y)$ and a self-normalised importance estimate of a leave-one-out expectation using full-posterior draws. Derive an identity for $p(y_i\mid y_{-i})$ involving $E_{\theta\mid y}[1/p(y_i\mid\theta)]$. Explain how an influential observation creates unstable weights and propose a diagnostic and a remedy.

---

Source: `course/exercises/questions.md:383–387`

### extra.10.3 — Validation for a new clinic next month

Objectives: L10.O5, L10.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

You have six months of visits at ten clinics, repeated visits by some patients, and a model intended for next month's patients at a previously unseen clinic. Consider: A random row split; B leave one clinic out using all six months; C rolling time origins with entire clinics held out and patient overlap excluded. All candidate pipelines initially impute missing values and standardise predictors using the entire dataset. Select a defensible evaluation design, explain what A and B measure, repair preprocessing and describe how to generate new-clinic predictions. State a limitation imposed by the available data.

---

Source: `course/exercises/questions.md:391–395`

### extra.10.4 — A model can improve and still fail

Objectives: L10.O5, L10.O1 · Difficulty: intermediate · Type: communication · Optional practice.

A hypothetical comparison of models A and B supplies five independent held-out unit log-score differences B−A: (0.2,0.4,−0.1,0.5,−0.2). Calculate total difference and approximate paired SE. For B, the observed proportion of counts at least 10 is 0.30; replicated proportions have mean 0.08 and central 90% interval [0.02,0.15]. Calculate the observed-minus-predictive-mean discrepancy and write a 100–160-word memo distinguishing relative prediction from this targeted check. Do not turn five scores into a probability that B is true.

---

Source: `course/exercises/questions.md:401–405`

### extra.11.1 — Robust likelihood contributions

Objectives: L11.O4, L11.O2 · Difficulty: intermediate · Type: derivation · Optional practice.

For one observation with residual $r=y-\mu$, compare a Normal location likelihood with known SD s=2 and a Student-t location likelihood with fixed degrees of freedom $\nu=3$ and scale s=2. Derive each log-likelihood derivative with respect to $\mu$, evaluate at r=2 and r=20, and describe their large-residual behaviour. Give the Student-t observation variance and explain why this score comparison is not a proof that a complete Bayesian estimator is immune to contamination.

---

Source: `course/exercises/questions.md:409–413`

### extra.11.2 — Interval recording versus selected entry

Objectives: L11.O4, L11.O3 · Difficulty: intermediate · Type: numerical · Optional practice.

Let $Y\sim N(\mu,1)$ with known variance 1. Protocol A enrolls a unit regardless of Y but records only that $1<Y<2$. Protocol B includes only units with $Y>1$, fixes the number of included units, and records an exact value Y=1.5 for one included unit; excluded counts are unavailable. Write each unit's likelihood contribution for unknown $\mu$ and evaluate at $\mu=0$. Compare B with the untruncated density. Explain why interval probability and truncated density cannot be interchanged.

---

Source: `course/exercises/questions.md:417–421`

### extra.11.3 — What the missing outcomes could change

Objectives: L11.O5, L11.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Outcomes are observed for 80% of a target population. Among those observed, 60% completed a task. Treat these proportions as exact for this sensitivity exercise. Assumption A says the missing group also has completion probability 0.60; assumption B says it has probability 0.20. Calculate overall completion under each. A policy requires overall completion at least 0.55. Express the threshold condition in terms of an unknown missing-group completion probability q, and propose information that could inform q. Explain why the observed records alone do not choose A over B.

---

Source: `course/exercises/questions.md:425–429`

### extra.11.4 — Calibrate an exact inference experiment

Objectives: L11.O5, L11.O1 · Difficulty: advanced · Type: coding · Optional practice.

Design and implement a small SBC experiment with R=1,000 datasets, $\theta\sim\operatorname{Beta}(2,3)$ and $Y\mid\theta\sim\operatorname{Binomial}(8,\theta)$. For each dataset use M=99 independent exact posterior draws, seed 8114. Define the generating-parameter rank among these draws, collect ten bins each containing ten rank values, and give expected bin counts and their marginal SD under calibration. Use a broad six-SD diagnostic screen, explaining dependence across bins and its limited interpretation. Compare with the expected rank mean. Explain why this experiment cannot establish real-data adequacy or validate an unrelated MCMC implementation.

---

Source: `course/exercises/questions.md:435–439`

### extra.12.1 — A target population can reverse an action

Objectives: L12.O4, L12.O1 · Difficulty: intermediate · Type: numerical · Optional practice.

The posterior expected completion differences B−A in groups 1 and 2 are +0.12 and −0.04. Two possible future target populations have weights (0.8,0.2) and (0.2,0.8). Each contains 1,000 visits; each extra completion is worth 10 utility units and rolling out B costs 200 units. Under linear expected utility, calculate the standardised mean difference, expected incremental utility and preferred action for each population, with A having incremental utility zero. Explain what cannot be learned about downside probability from these means alone.

---

Source: `course/exercises/questions.md:443–447`

### extra.12.2 — A completely enumerated value-of-information problem

Objectives: L12.O4, L12.O2 · Difficulty: advanced · Type: derivation · Optional practice.

A state is favourable F with probability 0.4 and unfavourable U with probability 0.6. Action A has utility zero in either state; action B has utility +100 in F and −60 in U. A possible test has $P(+\mid F)=0.8$ and $P(+\mid U)=0.2$; its result does not otherwise affect payoffs. Derive predictive test probabilities, post-test state probabilities and optimal actions. Calculate current optimal expected utility, expected utility with free sample information, gross EVSI, EVPI and current expected opportunity loss. A test costs 5 utility units: should it be bought? Verify $0\le\mathrm{EVSI}\le\mathrm{EVPI}$ and distinguish a test from perfect state information.

---

Source: `course/exercises/questions.md:451–455`

### extra.12.3 — Expected value is not a realised outcome

Objectives: L12.O5 · Difficulty: intermediate · Type: diagnosis · Optional practice.

A campaign will generate K successes among 20 new independent trials sharing unknown $\theta\sim\operatorname{Beta}(3,2)$ after existing data. Each realised success is worth 5 units; fixed cost is 40. Compare the posterior random quantity $V(\theta)=E(5K-40\mid\theta)=100\theta-40$ with realised utility $R=5K-40$. Calculate their means and variances, $P(V>0)$ and $P(R>0)$, using exact beta and beta-binomial calculations. Diagnose the statement “a posterior interval for V is a predictive interval for realised campaign value.” State the future-outcome assumptions used.

---

Source: `course/exercises/questions.md:459–463`

### extra.12.4 — A decision memo with sensitivity

Objectives: L12.O5, L12.O3 · Difficulty: intermediate · Type: communication · Optional practice.

Write a memo of at most 250 words using this complete hypothetical packet. Target: 2,000 visits next quarter at the same four centres with equal weights. The posterior mean completion difference B−A is 0.04, with central 90% interval [−0.01,0.09]. Value per extra completion is 20 utility units; rollout cost is 1,000. Under two alternative proper priors, mean differences are 0.025 and 0.035. A has incremental utility zero. Computational checks are satisfactory for the required mean precision, but predictive checks concern represented centres only. State expected incremental value, recommendation under risk neutrality, prior sensitivity, break-even effect and a scenario that changes the action. Distinguish the interval for conditional expected incremental value from realised outcomes, and state at least one limitation.

---

Source: `course/exercises/questions.md:473–481`

### adv.approximation.1 — Which directions lose variational uncertainty?

Objectives: A01.O1, A01.O2, A01.O3 · Difficulty: advanced · Type: derivation · Optional practice.

A fully specified posterior for two offsets (in the same units) is $p(\theta\mid y)=N(m,\Sigma)$ with

$$m=(1,-1)^T,\qquad \Sigma=\begin{pmatrix}4&1.8\\1.8&1\end{pmatrix}.$$

Derive its Laplace approximation and the minimiser of $\operatorname{KL}(q\Vert p)$ over $q=N(a_1,v_1)N(a_2,v_2)$, with $v_j>0$. Starting from the definition of KL, explain why maximising the ELBO for this fixed model is the same optimisation. Compute the optimum KL, the exact and approximate variances of $S=\theta_1+2\theta_2$ and $D=\theta_1-2\theta_2$, and $P(S>3)$ under each distribution (six decimal places). Does underdispersion of both marginals imply underdispersion of every contrast? Explain why extra independent draws from the optimal q cannot repair the discrepancy.

---

Source: `course/exercises/questions.md:485–491`

### adv.approximation.2 — A support-respecting approximation can still miss a tail

Objectives: A01.O2 · Difficulty: advanced · Type: coding · Optional practice.

The target is the Gamma posterior $p(\lambda)=b^a\lambda^{a-1}e^{-b\lambda}/\Gamma(a)$ for $\lambda>0$, with shape $a=4$ and rate $b=1.5$. Write runnable Python computing normalised midpoint grids on (0,30) with widths 0.02 and 0.01, and report the mean, variance and $P(\lambda>5)$. Check grid refinement and the omitted upper-tail mass against SciPy's gamma distribution; require absolute error below $2\times10^{-5}$ for all three summaries on the finer grid and justify the truncation.

Derive a Normal Laplace approximation in the rate coordinate and a Normal approximation in $\eta=\log\lambda$, transformed back to a lognormal. Report their rate-scale means, variances and tails above five; also report the rate-Normal's mass below zero. Is the approximation with correct support necessarily more accurate for the requested tail? State scale/rate conventions and distinguish deterministic quadrature error from approximation error.

---

Source: `course/exercises/questions.md:495–501`

### adv.approximation.3 — Two stable fits that disagree about the sign

Objectives: A01.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

A normalised target is $p(\theta)=\tfrac12N(-4,0.36)+\tfrac12N(4,0.36)$. Define the joint density for this diagnostic to equal p, so evidence is one. Two runs fit a single Normal q. Run L ends at $N(-4,0.36)$ and run R at $N(4,0.36)$. Their hypothetical estimated ELBO traces are respectively (-2.4, -0.90, -0.693147) and (-2.0, -0.85, -0.693147); the reports show tiny final gradients. These are supplied diagnostic reports, not newly executed optimiser results.

Calculate the target mean, variance and $P(\theta>0)$, and compare both q distributions. Explain what the traces can and cannot establish, whether the two fits can be called interchangeable for a sign decision, and whether taking more draws or more optimisation steps guarantees repair. Give a concrete diagnostic/reference method and a justified change to the approximation family. Assess whether these reports prove a global variational optimum.

---

Source: `course/exercises/questions.md:508–512`

### adv.model_evidence.1 — Evidence with unequal prior model odds

Objectives: A02.O1 · Difficulty: advanced · Type: derivation · Optional practice.

Two conditionally independent calibration readings are $y=(0.8,1.6)$ in standardised units, with $Y_i\mid\mu\sim N(\mu,1)$. Model $M_0$ fixes $\mu=0$. Model $M_1$ uses the proper prior $\mu\sim N(0,2.25)$. Prior model probabilities are $P(M_1)=1/4$ and $P(M_0)=3/4$. Derive the fully normalised evidence of each model by integration, retaining the constants. Calculate both log evidences, $\log BF_{10}$, posterior odds and $P(M_1\mid y)$ to six decimals. Also derive the conditional posterior for mu under $M_1$. Explain why a Bayes factor exceeding one need not give posterior model probability exceeding one half. Densities are with respect to the same two-dimensional reading measure.

---

Source: `course/exercises/questions.md:516–522`

### adv.model_evidence.2 — A diffuse alternative changes the predictive mixture

Objectives: A02.O2 · Difficulty: advanced · Type: numerical · Optional practice.

Use readings (0.8,1.6), known observation variance one, null $M_0:\mu=0$, and alternative $M_1:\mu\sim N(0,\tau^2)$. Compare three separate sensitivity scenarios $\tau\in\{0.25,1.5,6\}$ with $P(M_1)=1/4$ in every scenario. They are not three alternatives in one model set. A future independent reading has $Y_*\mid\mu\sim N(\mu,1)$.

For each scenario report log Bayes factor, posterior alternative weight, the conditional alternative posterior mean/variance of mu, and the model-averaged predictive mean/variance of $Y_*$. Show the within-model and between-model variance terms, giving six-decimal summaries. Explain the limit of the model weight as $\tau\to\infty$ for these fixed data, and why replacing the prior by an unspecified constant “flat density” does not give a meaningful limiting Bayes factor. Does the scenario with the largest evidence automatically optimise future predictive accuracy?

---

Source: `course/exercises/questions.md:526–532`

### adv.model_evidence.3 — Explain three kinds of model comparison

Objectives: A02.O3 · Difficulty: intermediate · Type: communication · Optional practice.

A hypothetical report compares models A and B. Proper-prior Bayesian model averaging (BMA) gives posterior model weights (0.85,0.15). Leave-one-out total expected log predictive density estimates are -142 for A and -137 for B; the estimated standard error of the paired difference B minus A is 4. Stacking of the same leave-one-out predictive distributions gives weights (0.30,0.70). These are supplied summaries, not quantities to reconstruct from unavailable raw observations. Full-data model-conditional probabilities of a specified future event E are 0.20 and 0.60 respectively; deploy either weighting scheme on these two predictive distributions.

Write a 150–220-word explanation to an analyst who says “B has a 70% probability of being true, and the five-point predictive gain proves B is best.” Include the two mixture event probabilities, what each comparison measures, what the paired SE implies and does not imply, one validation limitation, and why replacing one proper prior by an arbitrary improper prior invalidates the reported BMA odds. No model is assumed to be literally true.

---

Source: `course/exercises/questions.md:539–545`

### adv.observation_process.1 — Recover a latent item without treating its reading as exact

Objectives: A03.O1, A03.O2 · Difficulty: advanced · Type: derivation · Optional practice.

Three independent latent items obey $X_i\mid\mu\sim N(\mu,4)$, readings obey $W_i\mid X_i\sim N(X_i,1)$, and $\mu\sim N(0,9)$. Conditional on the latent items, all measurement errors are independent and independent of mu. Observe $w=(-1,2,3)$ in the same measurement units.

Derive the integrated likelihood for mu and its posterior. Then find the posterior mean and variance of the third latent item $X_3$, and $\operatorname{Cov}(X_1,X_3\mid w)$. Derive the predictive variance of a new independent reading $W_4$. Compare the common-mean posterior with the naive analysis that sets measurement variance to zero while retaining item variance four and the same prior. State which uncertainties the naive fit drops, and why conditional independence given mu does not imply posterior independence after integrating mu.

---

Source: `course/exercises/questions.md:549–555`

### adv.observation_process.2 — A nonresponse shift that the data cannot estimate

Objectives: A03.O2, A03.O3 · Difficulty: advanced · Type: numerical · Optional practice.

An external population register establishes response fraction $r=0.65$ exactly. Five independently sampled respondents have outcomes (4,5,5,6,7). The pattern-mixture model is $Y\mid R=1,\mu\sim N(\mu,4)$ and $Y\mid R=0,\mu,\delta\sim N(\mu+\delta,4)$, with prior $\mu\sim N(5,4)$. There are no nonrespondent outcomes or further information about delta. The target is the superpopulation mean $T=E(Y\mid\mu,\delta)$, not the realised mean of a finite set of missing records.

For the fixed sensitivity scenarios $\delta=-3,0,3$, calculate posterior mean and 90% equal-tail interval for T and $P(T>6\mid y,\delta)$ (six decimals). Prove that the respondent likelihood cannot distinguish these scenarios. Then give delta the independent prior $N(0,9)$ and derive the marginal posterior of T and $P(T>6\mid y)$. Explain why this extra posterior width is prior-driven, whether more respondents alone identify delta, and which kind of additional information would help.

---

Source: `course/exercises/questions.md:559–565`

### adv.observation_process.3 — Four instruments record four different events

Objectives: A03.O1, A03.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

Independently of one another, four instruments sample $Y\sim N(\mu,4)$ with unknown mu and known SD two. Instrument A rounds to the nearest integer and reports 2. Instrument B registers every attempted unit but records only the flag $Y\ge3$ for this unit. Instrument C samples until one value exceeding 3 is admitted and reports the exact value 4; rejected values and their count are unavailable. Instrument D also samples until one value is admitted and reports exactly 4, with known admission probability $s(y)=\operatorname{logistic}(-1+0.5y)$; rejected values/counts are unavailable. There is no additional selection.

Write the likelihood contribution for mu under each record mechanism. Evaluate each at $\mu=1$ to six decimals, using one-dimensional integration for D. Identify which contributions are probabilities and which are densities. Explain how D's contribution changes if all attempted units' admission indicators are recorded, including a particular rejected unit with missing Y. Is ignoring this selection justified merely because its mechanism has no unknown parameters?

---

Source: `course/exercises/questions.md:572–585`

### adv.causal.1 — Standardise to the target population

Objectives: A04.O1, A04.O2 · Difficulty: advanced · Type: numerical · Optional practice.

Let A be binary treatment, Y a binary success and Z a pretreatment binary stratum. Assume consistency, no interference, conditional exchangeability $(Y(0),Y(1))\perp A\mid Z$, positivity, and transportability of the stratum-specific potential-outcome means to a target population with known $P_*(Z=0)=0.7$ and $P_*(Z=1)=0.3$. Observations within cells are independent binomial samples with independent Beta(2,2) priors for $p_{za}=P(Y=1\mid Z=z,A=a)$.

| Z | A | Trials | Successes |
|---|---|---:|---:|
| 0 | 0 | 60 | 12 |
| 0 | 1 | 20 | 8 |
| 1 | 0 | 30 | 18 |
| 1 | 1 | 90 | 63 |

Derive the identification formula for the target average treatment effect $\Delta_*=E_*[Y(1)-Y(0)]$. Give the four posterior beta distributions and the posterior mean and variance of $\Delta_*$ (six decimals). Compare its posterior mean with the crude observed treated-minus-control success proportion, stating that these also differ in prior use. Explain the role of each identification assumption and why the four binomial fits alone cannot verify them. No sampling interval or simulation is required.

---

Source: `course/exercises/questions.md:589–595`

### adv.causal.2 — Adjustment can open a path or remove part of the effect

Objectives: A04.O1, A04.O3 · Difficulty: advanced · Type: diagnosis · Optional practice.

Consider two separate causal DAGs, with exactly the listed arrows and no hidden common causes other than the stated U. In graph C, treatment A is randomised independently of U, and arrows are $A\to Y$, $A\to C$, $U\to C$, $U\to Y$; U is unobserved and C observed. In graph M, A is randomised, and arrows are $A\to Y$, $A\to M$, $M\to Y$; M is observed. For the total effect of A on Y, assess no adjustment versus adjustment for C or M respectively. Explain whether an adjusted coefficient must equal a total effect.

Now consider a different observational setting with pretreatment Z, arrows $Z\to A$, $Z\to Y$, $A\to Y$, consistency, conditional exchangeability and no interference. The target has $P_*(Z=1)=0.3$. Assume all listed risks are known exactly: for Z=0, risks under A=0 and A=1 are 0.2 and 0.4; for Z=1 only A=1 ever occurs and its risk is 0.7. Outcomes are binary. Derive sharp bounds on the target average treatment effect with no restriction on the absent control risk. Exhibit two compatible full-data causal models attaining the endpoints. Can a highly concentrated Bayesian posterior from a strong prior restore data identification?

---

Source: `course/exercises/questions.md:599–607`

### adv.causal.3 — Check a confounding analysis against its generator

Objectives: A04.O2, A04.O3 · Difficulty: advanced · Type: coding · Optional practice.

Simulate n=6,000 independent people using `np.random.default_rng(8603)`. Draw all Z first from Bernoulli(0.4), then all A with probabilities 0.15 for Z=0 and 0.85 for Z=1, then all observed Y using risk matrix $p_{za}=\begin{pmatrix}0.10&0.35\\0.55&0.65\end{pmatrix}$ (rows Z, columns A). This generator represents potential outcomes conditionally independent of assignment given Z; it has no interference and obeys consistency. The fixed target stratum weights are (0.6,0.4).

Using independent Beta(1,1) priors per outcome cell, report cell counts/successes, the crude empirical contrast, the exact adjusted posterior mean/SD and 20,000 independent posterior contrast draws with `default_rng(8604)`. Compute the generator's causal effect and crude population association by enumeration. Check the draw mean within six exact MCSEs of its analytic posterior mean; report, without demanding exact equality, the estimation error relative to the generator's effect in posterior SD units.

As an explicit changed observation design, discard all records with Z=1,A=0 while retaining the same target population. Show that this missing cell's posterior remains its prior. Recompute the adjusted posterior mean with Beta(1,1), Beta(8,2), and Beta(2,8) priors for that missing cell only, keeping other cell priors unchanged. Explain which statements remain model-dependent without overlap. Return runnable code and a short qualified report; no MCMC is needed.

---

Source: `course/exercises/questions.md:614–620`

### adv.time_series.1 — Forecast a process with alternating dependence

Objectives: A05.O1, A05.O2 · Difficulty: advanced · Type: derivation · Optional practice.

The stationary AR(1) model is $Y_t-\mu=\phi(Y_{t-1}-\mu)+\epsilon_t$ with independent innovations $\epsilon_t\sim N(0,\sigma^2)$ and $|\phi|<1$. Parameters are known and future innovations are independent of the observed past. Derive the conditional h-step mean and variance given exact current value $Y_T=y_T$, and derive the stationary marginal variance. State the initial distribution needed for a stationary full likelihood, and distinguish it from a likelihood conditional on $y_0$.

For $\mu=1$, $\phi=-0.5$, $\sigma^2=0.75$ and $y_T=3$, compute means and variances for h=1,2,3 and their limits. Explain the alternation and why innovation variance is not the stationary variance. Finally, if these parameters instead have a posterior distribution, state the two terms needed for parameter-integrated forecast variance and explain why plugging in posterior means is not generally equivalent.

---

Source: `course/exercises/questions.md:624–630`

### adv.time_series.2 — Integrate a two-point parameter posterior

Objectives: A05.O2 · Difficulty: advanced · Type: coding · Optional practice.

The zero-baseline model is $Y_t=\phi Y_{t-1}+\epsilon_t$, with known innovation SD 0.5 and independent Normal innovations. Observe $y_{0:4}=(-0.4,0.2,0.6,1.0,0.7)$. The prior puts equal mass on $\phi=0.2$ and $\phi=0.8$. Use the transition likelihood conditional on $y_0$; do not add a stationary initial density.

Write Python to calculate posterior weights in log space, then exact parameter-integrated means and variances at horizons one and three from time four. Separate the expected conditional variance from the variance of conditional means. Compare with forecasts plugging in $E(\phi\mid y)$, including their means and variances. Independently simulate 100,000 complete future trajectories with `default_rng(8502)`, sampling one posterior phi per trajectory and three fresh innovations. Compare simulated means to exact values within six mean MCSEs, and variances within six MCSEs computed from the exact fourth central moment of the Normal mixture. For mixture weights $w_j$, means $m_j$, variances $v_j$ and overall mean m, you may use $\mu_4=\sum_jw_j[3v_j^2+6v_j(m_j-m)^2+(m_j-m)^4]$ and variance MCSE approximately $\sqrt{(\mu_4-V^2)/N}$, where V is the mixture variance. See the [forecast precision derivation](../advanced/05_time_series.md#numerical-precision-for-a-simulated-forecast-variance). Explain why drawing a fresh phi at every future time would simulate a different model.

---

Source: `course/exercises/questions.md:634–640`

### adv.time_series.3 — Find the future information in a validation pipeline

Objectives: A05.O3 · Difficulty: intermediate · Type: diagnosis · Optional practice.

There are thirty equally spaced records indexed t=0,...,29, with supplied values $y_t=t/10+0.05(-1)^t$. The deployment task is to predict $y_{o+3}$ at origin o immediately after observing $y_o$. A proposed direct-regression evaluation (i) standardises using all thirty readings, (ii) creates a centred three-reading mean $(y_{t-1}+y_t+y_{t+1})/3$, (iii) randomly splits feature/label pairs with label $y_{t+3}$, and (iv) claims its score measures future three-step forecasting. The full-series scale is also used for a purported chronological fit containing all feature origins through 19 when forecasting at 19.

Diagnose each leak, including the latest label in that last fit. Give an executable index schedule for rolling forecast origins (17,20,23,26): every training feature origin, label index, test feature origin and target index. Replace centred features by trailing means over indices max(0,s-2),...,s; fit preprocessing using training features only. State how later origins may use earlier realised test outcomes. Propose a perturbation test that would detect future-data dependence in a forecasting implementation, and a scoring/reporting rule acknowledging dependent errors. No particular regression estimator or fitted accuracy is requested.

---

Source: `course/exercises/questions.md:647–653`

### adv.gaussian_processes.1 — Condition a small GP and audit its kernel

Objectives: A06.O1, A06.O2 · Difficulty: advanced · Type: numerical · Optional practice.

A zero-mean GP has kernel $k(x,x')=1+xx'$ on real inputs. Training inputs are (0,1) and readings (1,2), with independent Normal measurement errors of known variance 0.5. At test input $x_*=2$, derive the training latent covariance K, the reading covariance C, cross-covariance $k_*$ and prior test variance. Use Cholesky solves to compute the predictive mean, latent variance and variance of a new reading with the same measurement noise (six decimals). Cross-check using $f(x)=\beta_0+\beta_1x$ with independent $N(0,1)$ coefficients. Explain the restrictions on functions imposed by this GP.

A colleague proposes a replacement whose latent covariance at two inputs is $K'=\begin{pmatrix}1&1.2\\1.2&1\end{pmatrix}$, arguing that $K'+0.5I$ is positive definite. Decide whether it can define the stated latent GP, with a concrete variance or eigenvalue calculation. Does adding measurement noise validate an invalid latent kernel?

---

Source: `course/exercises/questions.md:657–663`

### adv.gaussian_processes.2 — Separate numerical jitter from measurement noise

Objectives: A06.O2, A06.O3 · Difficulty: advanced · Type: coding · Optional practice.

Use zero GP mean, $k(x,x')=\exp[-(x-x')^2/(2\ell^2)]$ with $\ell=0.7$, training inputs (0,0,$10^{-8}$,1), readings (1,1.02,0.98,-0.2), known scientific noise variance $s_n^2=10^{-6}$, and test inputs (0,0.5,2). Factor $C_j=K+(s_n^2+j)I$ for numerical jitter $j\in\{0,10^{-10},10^{-6},10^{-2}\}$. Return runnable code reporting each condition number, predictive mean vector, latent variance vector and new-reading variance vector. Use Cholesky solves, require finite results and reject latent variances below $-10^{-10}$ rather than silently clipping large errors. Report small numerical negatives if encountered.

Verify that the largest jitter materially changes the test-at-zero latent variance relative to the zero-jitter scientific model. Deliberately attempt Cholesky with both scientific noise and jitter zero, explaining failure for these inputs. Compare the $j=10^{-2}$ calculation with a different scientific model having noise variance 0.010001 and zero jitter. Explain why the training calculations coincide but new-reading uncertainty differs, and why contradictory readings at identical inputs do not justify claiming noiseless observations. Do not reinterpret chosen jitter as estimated scientific noise.

---

Source: `course/exercises/questions.md:667–678`

### adv.gaussian_processes.3 — A kernel prior decides how far a curve can speak

Objectives: A06.O3 · Difficulty: intermediate · Type: communication · Optional practice.

A calibration analysis uses zero-mean squared-exponential GPs with amplitude one and independent observation noise variance 0.04. Training inputs are (-1,0,1), readings (0.2,1.0,0.2). Two competing hyperparameter priors put all mass on length scale 0.3 (S) or 1.8 (L); no length scale is learned within either fit. The following conditional predictions are supplied to six decimals, with SD referring to the latent function:

| Model | Mean at x=0.5 | Latent SD at x=0.5 | Mean at x=3 | Latent SD at x=3 |
|---|---:|---:|---:|---:|
| S | 0.286475 | 0.938548 | 0.000000 | 1.000000 |
| L | 0.614640 | 0.154863 | -0.556519 | 0.773106 |

Write a 150–220-word modelling recommendation. Include each prior's correlation between function values one input unit apart, why the extrapolation at three is assumption-sensitive, the effect of measurement noise on predictive intervals, the far-away mean/variance limits, and a justified way to investigate kernel choice. The response can prefer a candidate conditionally; it must not identify truth from interval width. Address the squared-exponential smoothness/stationarity assumptions and an alternative if a sharp change is scientifically plausible. Add a separate calculation of the decimal GB needed for one dense float64 covariance at n=20,000, and the leading factorisation-time/storage multipliers relative to n=2,000. Ignore overhead when calculating that one matrix's storage.

---

Source: `course/exercises/questions.md:687–691`

### adv.prior_workflow.1 — One seed lot, two kinds of uncertainty

Objectives: A07.O1 · Difficulty: intermediate · Type: derivation · Optional advanced progress.

A horticulturist defines $\theta$ as the probability that a seed from one fixed lot germinates within 14 days under a specified cabinet protocol. Before testing, $\theta\sim\operatorname{Beta}(4,6)$. Twelve randomly selected seeds are conditionally independent given this one probability; $K$ counts germinations. Derive $E(K)$ and the two terms of total predictive variance, with units. Compare with (i) plugging in $E(\theta)$ and (ii) physically drawing an independent $\theta_i\sim\operatorname{Beta}(4,6)$ for each seed. Explain what the three models say about covariance between two germination indicators. Write a four-field elicitation record (quantity, population/protocol, horizon, information provenance) and name one observation that would challenge conditional independence. No real elicitation or seed data is claimed.

---

Source: `course/exercises/questions.md:695–701`

### adv.prior_workflow.2 — Preserve two calibration judgments

Objectives: A07.O2, A07.O3 · Difficulty: advanced · Type: numerical · Optional advanced progress.

For one water sensor using a fixed calibration over the next fortnight, $\theta$ is its probability of passing a prespecified reference comparison. Two fictional specialists independently supply CDF judgments at probabilities $(0.15,0.50,0.85)$. Packet U gives values $(0.40,0.60,0.78)$; packet V gives $(0.16,0.34,0.56)$. Both remember the same maintenance summary; U also recalls bench tests and V recalls field fouling. Neither underlying record is available as a count likelihood.

Fit a separate Beta to each packet by minimizing unweighted squared CDF residuals in log-shape coordinates. You may use Lab 21's `fit_beta_quantiles(values, probabilities)`; retain convergence and starting-point evidence. Return shapes (three decimals), fitted CDF values and quantiles (four decimals), and maximum absolute CDF residual. Independently integrate at least one fitted CDF or predictive mass. For ten future comparisons sharing $\theta$, calculate $P(K<7)$ under each packet (four decimals). Give a feedback plan distinguishing small within-packet fit error from between-specialist disagreement. Identify a question about the target conditions and the shared information; preserve both packets, and describe what evidence would authorize a revised packet. Do not invent agreement, revisions, independent sample sizes, or credibility weights.

---

Source: `course/exercises/questions.md:705–711`

### adv.prior_workflow.3 — A rehearsal decision changes with the weight

Objectives: A07.O3 · Difficulty: intermediate · Type: numerical · Optional advanced progress.

A theatre needs at least five of six wireless microphones to pass one rehearsal. Given a stable pass probability, their results are independent. Two stipulated prior scenarios are H: Beta(9,3) and L: Beta(3,3). Using the existing microphones costs 1 credit plus a 12-credit shortfall loss if fewer than five pass. Hiring a guaranteed set costs 7 credits. These are hypothetical total losses, not estimated market prices.

Calculate each scenario's shortfall probability and expected losses. For a linear prior mixture with weight $w$ on H, calculate the action at $w=0.25,0.50,0.75$ and the switching weight, stating the tie convention. Repeat the action comparison at $w=0.75$ when the shortfall loss is 8 or 20 credits, with the other costs unchanged. Explain why mixing expected losses is appropriate here, why averaging Beta shapes generally changes the problem, and why this sensitivity analysis cannot determine a specialist's credibility. Show at least one direct predictive integral or count-state sum.

---

Source: `course/exercises/questions.md:715–721`

### adv.prior_workflow.4 — An archive already inside the prior

Objectives: A07.O1 · Difficulty: intermediate · Type: diagnosis · Optional advanced progress.

An acoustic detector's archive `detector_archive_R` has 9 detections in 12 exchangeable trials. An analyst started from Beta(3,5), updated with that archive, and handed the resulting distribution to a colleague as an informed prior. A disjoint new trial `detector_new_S` has 2 detections in 4 trials under the same protocol. The colleague proposes applying both R and S as likelihood data to the informed prior.

Calculate the informed prior, the correct posterior after S, and the erroneous posterior after R and S. Report correct and erroneous posterior means and variances. Give two equivalent once-only bookkeeping routes, a provenance ledger with include/exclude decisions, and one check needed before assuming the fresh observations are exchangeable. If the informed prior instead came from undocumented informal recollection of R, explain why subtracting nine successes and three failures is not a generally justified correction.

---

Source: `course/exercises/questions.md:729–733`

### adv.categorical_conjugacy.1 — Derive an accession-count prediction

Objectives: A08.O1 · Difficulty: intermediate · Type: derivation · Optional advanced progress.

Museum accessions have mutually exclusive states digitised, queued and blocked. A stable probability vector has prior Dirichlet(1,3,2); observed counts are $(4,1,2)$. Derive the normalized posterior from the multinomial likelihood and Dirichlet density, explaining where the observed multinomial coefficient cancels. Then derive the normalized joint predictive mass for two future accessions sharing the same probability vector. Enumerate all six possible count vectors and probabilities, checking normalization. Compute the predictive mean and full covariance matrix; explain why each covariance row sums to zero. Distinguish an unordered count from a particular ordered sequence. Keep category order explicit.

---

Source: `course/exercises/questions.md:737–743`

### adv.categorical_conjugacy.2 — Four tickets after a changed update

Objectives: A08.O1, A08.O2 · Difficulty: intermediate · Type: numerical · Optional advanced progress.

A support team's posterior for resolved, follow-up and escalated probabilities is Dirichlet(3,2,5). Predict four future tickets with one shared vector. Derive the probability of at least one escalation by aggregating categories and also by summing the joint count law. Compare it with the plug-in multinomial probability. Compute the escalation-count mean and variance.

Now consider two batches of four tickets. Compare their escalation-count covariance when they share this one uncertain vector with a model where each batch independently draws a vector from Dirichlet(3,2,5), with these shapes fixed. Explain why the two models have identical one-batch predictions but different cross-batch dependence. State how uncertain shared hyperparameters would qualify the independence claim. Report exact fractions or six-decimal values and explain the direction of the plug-in difference.

---

Source: `course/exercises/questions.md:747–753`

### adv.categorical_conjugacy.3 — A probability vector is a joint object

Objectives: A08.O2 · Difficulty: intermediate · Type: diagnosis · Optional advanced progress.

A recycling audit codes objects as reusable, recyclable or unsafe. Its prior is Dirichlet(2,2,1), and its six observations have counts $(2,4,0)$. An analyst fits three unrelated Beta(1,1) category-versus-rest priors, updates them, and presents the three independent posterior draws as a probability vector. Another analyst uses the correct Dirichlet's Beta marginals, but also draws them independently. A third sets the unsafe probability to zero because none was observed.

Diagnose all three proposals. Calculate the first analyst's posterior shapes and sum of posterior means. Give the correct joint posterior, marginal means, full covariance and the variance of the probability sum under the second analyst's construction. Explain why renormalizing independent Beta draws does not generally recover the stated Dirichlet. Distinguish a sampling zero from a scientifically established structural zero, and specify the support change needed for the latter. Describe a numerical relabeling check that permutes counts, shapes and output labels together.

---

Source: `course/exercises/questions.md:761–767`

### adv.multivariate_hierarchy.1 — Covariance priors in physical units

Objectives: A09.O1 · Difficulty: advanced · Type: derivation · Optional advanced progress.

For aquarium stations, let $b_j=(b_{0j},b_{1j})$ be a Gaussian station intercept and temperature-slope deviation. Temperature $x$ is measured in units of ten degrees relative to a fixed reference, and the response is a centered instrument reading in volts. Set $\Sigma=D\Omega D$, independent $\tau_0\sim\operatorname{HalfNormal}(0.8)$ and $\tau_1\sim\operatorname{HalfNormal}(0.25)$ (SD parameters), and a bivariate LKJ(3) prior for $\Omega$. Derive the normalized density of correlation $\rho$ and $P(|\rho|>0.5)$. Explain what changes when LKJ(1) replaces LKJ(3), without treating prior mass as observed evidence.

At the fixed hyperparameter snapshot $(\tau_0,\tau_1,\rho)=(0.8,0.25,-0.4)$, compute $\Sigma$, $b_1\mid b_0=0.4$, and the variance of $b_0+2b_1$. Then rewrite temperature in single degrees $x'=10x$: transform effects, covariance, scale priors and the conditional slope result so every prediction is unchanged. Explain what would change if the old numerical slope prior were used unchanged in the new units. This is a conditional snapshot and prior calculation, not a posterior fit.

---

Source: `course/exercises/questions.md:771–777`

### adv.multivariate_hierarchy.2 — Reuse one draw for one new catchment

Objectives: A09.O2 · Difficulty: advanced · Type: numerical · Optional advanced progress.

A model of stream instrument readings has station/catchment effects $(b_0,b_1)$, within-catchment centered covariate $x$, and catchment mean covariate $q$. At one fixed posterior hyperparameter draw, the population mean is $1.2-0.1x+0.5q$, effects have covariance $\begin{pmatrix}0.36&0.06\\0.06&0.04\end{pmatrix}$, and independent observation-noise SD is 0.3. Predict two readings in one new catchment with $q=0.4$ and $x=(-1,2)$. Give their mean vector, full latent and noisy covariance matrices, and the variance of their difference. Repeat the covariance/difference calculation for code that incorrectly draws an independent effect vector for each reading. Explain the correct draw reuse for a new versus an already observed catchment and how averaging across posterior hyperparameter draws adds uncertainty.

A separate fitted study has only six catchments, many repeated readings near each catchment's mean covariate, and a correlation interval from -0.8 to 0.7 despite small mean MCSE. Discuss weak identification of slope variation/correlation, within- versus between-catchment associations, and two checks before predicting at $x=2$. Do not infer an absent effect or a precise correlation from sampler precision. The interval is a hypothetical supplied diagnostic, not a claimed execution.

---

Source: `course/exercises/questions.md:781–789`

### adv.multivariate_hierarchy.3 — Execute and audit a coordinate repair

Objectives: A09.O3 · Difficulty: advanced · Type: coding · Optional advanced progress.

An instrument calibration fixture has $b=(b_0,b_1)\sim N_2(0,\Sigma)$ with fixed $\Sigma=\begin{pmatrix}0.49&0.126\\0.126&0.09\end{pmatrix}$. Two observations $y=(0.60,0.62)$ at $x=(1,1)$ are independent $N(b_0+b_1,0.015^2)$ given b. Derive exact posterior mean m and covariance V by both a precision update and a conditional-Gaussian calculation. Let L be the lower Cholesky factor of V. Verify the normalized density identity $\log p_b(m+Lz)+\log|L|=\log\phi_2(z)$ at several points. This fixture conditions on covariance; it cannot validate estimation of LKJ hyperparameters.

Execute the following prespecified comparison in the locked environment. Use four independent NumPy `default_rng(90330+c)` streams for chain indices c=0,1,2,3, and starts in z coordinates $(-2,-2),(-2,2),(2,-2),(2,2)$ in that order. For the original run start b at m+Lz, propose b plus 0.12 times a fresh two-vector of standard normals, and evaluate the unnormalized posterior Gaussian log density. For the repair start z at its given value, propose z plus 0.9 times a fresh standard-normal two-vector, and evaluate $-z^Tz/2$. Restart the specified streams for the repair. Each iteration must draw the normal proposal followed by one uniform U and accept exactly when $\log U$ is less than proposed minus current log density. Run 6,000 iterations per chain, discard the first 2,000, and retain repeats after rejection. Transform retained z to b before comparison. Do not adapt, thin, change seeds, or discard an unfavorable chain.

For b0, b1 and b0+b1 in both runs report mean, SD, rank-normalized R-hat, bulk/tail ESS and mean MCSE, along with per-chain retained acceptance rates. Prespecified screens are R-hat < 1.01, both ESS > 400, and mean MCSE < 0.01 for every estimand. Compare each mean with the exact value using five MCSEs. Submit a 250–450-word diagnosis/intervention/re-evaluation memo plus executable code and a complete ledger of seeds, dimensions, versions, checks, failures and output hashes. Record actual screen outcomes, including persistent failures; an unfavorable run is not an excuse to invent success. Distinguish numerical precision from scientific uncertainty. Explain why HMC divergences/BFMI are inapplicable to this Metropolis experiment, and what additional evidence A09's unknown-covariance hierarchy needs. No human or live-tutor evaluation is requested.

---

Source: `course/exercises/continuation_questions.md:7–9`

## Adv outcome regression 1

**Identify a nominal model.** A three-category model has logits (0, log 3, log 2). Calculate its probabilities and prove that adding the same constant to all logits changes none of them. If ready is replaced by service as the baseline, explain why assigning fresh independent Normal priors to the new coefficients need not preserve the original prior model.

---

Source: `course/exercises/continuation_questions.md:15–17`

## Adv outcome regression 2

**Calculate ordered probabilities.** Use cumulative logits c_k − 0.7x with thresholds (−0.8, 0.6). Find the category probabilities at x=0 and x=1. Calculate the common cumulative-odds multiplier and explain why it does not mean a constant change in each category probability.

---

Source: `course/exercises/continuation_questions.md:23–25`

## Adv outcome regression 3

**Diagnose identification and ordering.** An analyst includes an unrestricted intercept in the linear predictor and two unrestricted ordered cutpoints. They claim ordered labels establish proportional odds and that excellent R-hat validates the model. Diagnose the claims, state an identifiable proper-prior alternative, and propose a predictive criticism.

---

Source: `course/exercises/continuation_questions.md:31–33`

## Adv study design 1

**Separate planning from analysis.** A prospective evaluation uses design prior Beta(3,2) and analysis prior Beta(1,1). Explain which prior weights future datasets, which supplies a posterior approval probability, and how each updates after s successes in n tests. Why would multiplying both priors into the analysis be a mistake?

---

Source: `course/exercises/continuation_questions.md:39–41`

## Adv study design 2

**Enumerate a new capped policy.** Use uniform design and analysis priors, reliability threshold 0.5, looks after 2 and 5 tests, success threshold 0.85, and early futility threshold 0.15. At the cap, reject unless successful. Give every terminal (n,s) state and its probability, assurance, and expected sample size. Check independently by trial recursion or rational ordered paths.

---

Source: `course/exercises/continuation_questions.md:47–49`

## Adv study design 3

**Assess an error-rate claim.** A team says, “An approval threshold of 0.95 guarantees at most 5% false approvals, even if we add extra looks.” Assess the claim. Specify what calculation would actually evaluate false approval and what must be fixed before doing it.

---

Source: `course/exercises/continuation_questions.md:55–57`

## Adv survival 1

**Derive a censored exponential likelihood.** Failures occur at three and seven weeks, while a third belt is right-censored at six weeks. Write the likelihood under exponential rate theta and derive the posterior from a Gamma(shape 3, rate 8 weeks) prior. State units and explain the censored record's contribution.

---

Source: `course/exercises/continuation_questions.md:63–65`

## Adv survival 2

**Compute an interval event probability.** A Weibull lifetime has shape 1.5 and scale ten weeks. Calculate survival to eight weeks and the probability of failure during weeks eight–twelve conditional on survival to eight. Explain why the latter is neither a density nor the hazard at week eight.

---

Source: `course/exercises/continuation_questions.md:71–73`

## Adv survival 3

**Question informative withdrawal.** A belt is withdrawn after an unrecorded vibration alarm suggesting imminent failure. An analyst treats this as independent administrative censoring and proposes using more posterior draws to make the conclusion reliable. Critique the analysis and propose a defensible response.

---

Source: `course/exercises/continuation_questions.md:79–81`

## Adv gp hyperparameters 1

Derive total covariance for a two-component predictive mixture with weights w and 1−w, means m1,m2 and covariance matrices V1,V2. Evaluate the scalar case w=.4, means −2 and 1, variances .5 and 2. Explain why a plug-in covariance can differ.

---

Source: `course/exercises/continuation_questions.md:87–89`

## Adv gp hyperparameters 2

Find the 90th percentile of .3N(−1,.5²)+.7N(1,1). Give a bracket, a root and its substituted CDF. Compare with the weighted average of component 90th percentiles and explain the difference.

---

Source: `course/exercises/continuation_questions.md:95–97`

## Adv gp hyperparameters 3

A program draws a fresh length scale at each query, then samples each GP marginal independently. Diagnose the two lost dependencies, repair the hierarchy and propose a covariance-sensitive check.

---

Source: `course/exercises/continuation_questions.md:103–105`

## Adv predictive combination 1

Optimize the stacking weight on probability columns (.8,.2,.6) and(.3,.7,.4). Give the objective, an interior or boundary check, and a numerical independent check. Explain why averaging log probabilities is different.

---

Source: `course/exercises/continuation_questions.md:111–113`

## Adv predictive combination 2

Find leakage in a pipeline that standardizes all rows and estimates each held-out group mean using its outcomes before cross-validation. Repair the workflow for prediction in entirely new groups, including the final evaluation boundary.

---

Source: `course/exercises/continuation_questions.md:119–121`

## Adv predictive combination 3

A stack assigns weight .9 to a complex component but its outer mean log score is below the simpler component. What does the weight mean, what conclusion is justified, and how should an outer-driven revision be evaluated?

---

Source: `course/exercises/continuation_questions.md:127–129`

## Adv variational fit 1

For a zero-mean Gaussian with covariance [[1,−.6],[−.6,1]], derive the reverse-KL mean-field variances. Compare exact and approximate variances of the sum and difference. Explain why “underestimates uncertainty” is incomplete.

---

Source: `course/exercises/continuation_questions.md:135–137`

## Adv variational fit 2

Under a joint Gaussian approximation for (a,b), derive E[(y−a−x exp(b))²] in terms of means, variances and covariance. For y=1, x=2, means (0,0), variances (.25,.16) and covariance −.1, evaluate this expectation and diagnose the error from dropping covariance. State how it enters the sensor-model ELBO and give one independent implementation check.

---

Source: `course/exercises/continuation_questions.md:143–145`

## Adv variational fit 3

An ELBO trace stabilizes but an independently refined posterior reference gives a materially different decision tail. Diagnose optimizer error, family error and scientific model error; propose the next checks without claiming that more draws solve all three.

---

Source: `course/exercises/continuation_questions.md:151–153`

## Adv splines 1

At one input, three active spline basis values are(.1,.6,.3) and their coefficients are(2,−.5,1). Calculate the prediction. Explain linearity in coefficients versus nonlinearity in the predictor and why this distinction helps Gaussian fitting.

---

Source: `course/exercises/continuation_questions.md:159–161`

## Adv splines 2

A proposed spline prior is proportional only to exp(−cᵀRc/(2tau²)), where R has two zero eigenvalues. Explain whether it is proper, identify the derivative-penalty nullspace, and give an explicit proper repair.

---

Source: `course/exercises/continuation_questions.md:167–169`

## Adv splines 3

Repair an additive model with an intercept and two unconstrained smooths whose knots were chosen using all outcomes, including evaluation observations. Explain learned smoothing, boundary behavior and how to compare with a linear baseline.

---

Source: `course/syllabus.md:1–5`

# Course syllabus

**Bayesian Inference: From Evidence to Decisions, expansion draft** offers two guided routes: a selected **twelve-week core** (6–8 hours/week, 72–96 hours, plus preparation) and a **twenty-four-week extended course** (8–10 hours/week, 192–240 hours). These are planning estimates awaiting a learner pilot. Reading every derivation and completing every extra problem will exceed the core estimate. Remediation, unfamiliar programming, slow model compilation and major project revisions may require additional weeks.

The accepted foundation includes six datasets, 25 labs, 13 core chapters, four mathematical appendices, nine advanced readings, three additional cases and 124 assessment items. Seven further advanced modules, labs 25–31 and 21 optional assessments are available in the integrated candidate: 32 labs, 16 advanced readings and 145 assessments in total. Independent candidate review remains pending. The two original routes below retain their second-edition scope; the optional continuation is additional. External books are optional. Start with the readiness work below, then choose one route.

---

Source: `course/syllabus.md:7–18`

## What you will be able to do

By the end, you should be able to define an inferential or decision target, express a generative model, justify a prior through its predictions, calculate simple posteriors analytically, approximate more complex posteriors, investigate computational failures, criticise model predictions, compare models for an appropriate held-out target, and communicate a decision with its assumptions and limitations.

| Outcome | Demonstration | Where assessed |
|---|---|---|
| Distinguish prior, likelihood, posterior, prediction | Update tables and verbal interpretations | Weeks 1–3; midcourse Q1–2 |
| Derive and check exact inference | Beta, gamma and normal posteriors | Weeks 2 and 4; numerical labs |
| Quantify computational error | MCSE, ESS and independent analytic targets | Weeks 5–6; midcourse Q3–4 |
| Specify regression and group structure | Gaussian, logistic and hierarchical models | Weeks 7–9 |
| Criticise and validate predictions | Targeted discrepancies and holdout design | Weeks 10–11; capstone |
| Connect uncertainty with an action | Expected loss, utility and sensitivity | Weeks 3 and 12; capstone |

---

Source: `course/syllabus.md:20–24`

## Preparation and tools

You need elementary algebra, basic probability, and enough Python to use arrays and functions. [Chapter 0](chapters/00_preparation.md) provides a diagnostic and remediation. Integrals are explained as continuous weighted sums; optional matrix formulas add depth without being required for every lab. The course uses Python 3.12 and a locked NumPy/SciPy/PyMC/ArviZ environment. Follow the [installation instructions](../README.md) before starting.

No previous Bayesian course is required. If programming is new, first complete an introductory Python course: the preparation lesson is a bridge, not a replacement for learning to program. If basic probability is new, spend additional time on the linked MIT materials before attempting posterior derivations.

---

Source: `course/syllabus.md:26–46`

## Twelve-week core route

| Week | Read | Lab | Submit |
|---|---|---|---|
| 0, optional | [Preparation](chapters/00_preparation.md) | 00: simulation | Readiness answers |
| 1 | [Bayesian updating](chapters/01_bayes.md) | 01: finite hypotheses | Update table and evidence assumptions |
| 2 | [Beta-binomial inference](chapters/02_beta_binomial.md) | 02: grid and exact answer | Derivation and interval interpretation |
| 3 | [Prediction and decisions](chapters/03_prediction.md) | 03: predictive simulation | Prior comparison and loss table |
| 4 | [Continuous models](chapters/04_continuous.md) | 04: rates and means | Units and conjugate derivations |
| 5 | [Monte Carlo](chapters/05_monte_carlo.md) | 05: Metropolis | Proposal-scale investigation |
| 6 | [HMC and diagnostics](chapters/06_hmc.md) | 06: NUTS and exact reference | Diagnostic memo; midcourse assessment |
| 7 | [Regression](chapters/07_regression.md) | 07: waiting times | Predictive intervals; capstone proposal |
| 8 | [Generalised linear models](chapters/08_glm.md) | 08: completion | Response-scale interpretation |
| 9 | [Hierarchical models](chapters/09_hierarchical.md) | 09: partial pooling | Existing/new-group predictions; project model |
| 10 | [Model checking](chapters/10_model_checking.md) | 10: PPC and LOO | Validation design; project critique |
| 11 | [Robustness and calibration](chapters/11_robustness.md) | 11: sensitivity and SBC | Sensitivity table; project draft |
| 12 | [Decisions](chapters/12_decisions.md) | 12: capstone analysis | Reproducible report and decision memo |

For the capstone and case projects use **attempt → save plan → consult reference → revise**. Save the target, information available, proposed model, priors and evaluation split before opening worked code, executed notebooks or reports. In week 12, this project order takes precedence over the routine lab-first sequence.

Each week: predict an answer before reading; read the selected sections below actively; run the lab unchanged once; modify it to investigate its prompt; answer the three numbered exercises; compare with [worked solutions](solutions.md); write one sentence about what changed in your understanding. Keep a log of modelling choices and corrections.

---

Source: `course/syllabus.md:48–66`

## Select core reading deliberately

Read each chapter’s opening, assumptions, lab, summary/retrieval prompts and original three exercises. The following selection identifies the main worked path and what may wait. Other sections remain available for clarification; do not skip a prerequisite needed to explain an assessed answer. Aim for about 2 hours active reading, 2 hours lab, 1–2 hours exercises and 1–2 hours retrieval/project work. In weeks 6 and 12, reserve additional assessment time or spread submission over a revision week.

| Week | Essential worked path | Defer to extended study |
|---|---|---|
| 0 | Conditioning, mixture moments, density versus mass, simulation arrays and readiness | Formal appendix derivations after the diagnostic identifies a gap |
| 1 | Factory alarm; three machine states; joint-probability derivation; odds; dependence and population transfer | Observation-protocol comparisons after the basic update is secure |
| 2 | Sampling assumptions; beta density and service posterior; summaries; sequential updating; grid masses | Boundary/skewness example and transformed credible sets |
| 3 | Predictive integral and beta-binomial; both layers of variation; prior prediction; expected loss and reserve crew | Detailed variance proof and several-batch forecasting |
| 4 | Gamma-Poisson derivation and exposure example; instrument measurements; precision and predictive intervals | Unknown-scale derivation, unequal precision and Jacobians; marked extended paragraphs |
| 5 | Two uncertainties; MCSE effort example; Markov chains; residence times; dependence; proposal-scale failure | Importance-sampling derivation and weighted-draw example |
| 6 | Energy/leapfrog mechanism; warmup; generative model; diagnostics; exact-reference comparison and debugging | Hand integration arithmetic, transformed-density derivation and funnel geometry |
| 7 | Generative regression; prior units; joint draws; predictive targets; residual failure and domain | Analytic matrix posterior and correlated-coefficient worked calculation |
| 8 | Generative likelihood; prior predictions; odds and probability differences; separation; exposure; causal limits | Algebraic separation analysis and richer count-mixture derivations |
| 9 | Hierarchy; prior predictions; shrinkage example; exchangeability; reparameterisation; existing/new groups | Unknown-hyperparameter variance derivation and detailed identifiability analysis |
| 10 | Four checks; discrepancy example; predictive target; exact LOO example; paired uncertainty; deployment splits | Importance-ratio derivation and predictive averaging |
| 11 | Influence; Student-t example; observation process and selection example; SBC and its limits | Detailed score derivation and rank-variance calculation |
| 12 | Capstone action; expected versus realised value; population/utility sensitivity; information-value example; reproducibility | General EVSI computation and expanded opportunity-loss derivation |

---

Source: `course/syllabus.md:68–68`

The [52 supplemental questions](exercises/questions.md) (`[extra.0.1](exercises/questions.md#extra.0.1)`–`[extra.12.4](exercises/questions.md#extra.12.4)`, four per lesson) are optional on this route. Choose one when a mistake reveals a gap; do not add all four to an already full week. Original exercises remain `0.1`–`12.3`, followed by `mid.Q1`–`mid.Q4` and `capstone`. Browser progress still tracks the original thirteen units; optional practice does not block the tutor’s core route.

---

Source: `course/syllabus.md:70–72`

## Twenty-four-week extended route

This route includes all expanded core sections, all 70 added questions, the six bridges and both cases. Mathematical appendices are usable teaching texts, but one week cannot teach calculus and linear algebra from scratch. If their worked examples are unfamiliar, add preparation weeks before proceeding. Revisit them at the point of use.

---

Source: `course/syllabus.md:74–86`

| Week(s) | Reading and prerequisites | Computation and submitted evidence |
|---|---|---|
| 1 | [Preparation](chapters/00_preparation.md), [probability](appendices/01_probability.md), first [numerical examples](appendices/04_numerics.md) | Lab 00; 0.1–0.3 and [extra.0.1](exercises/questions.md#extra.0.1), [extra.0.2](exercises/questions.md#extra.0.2), [extra.0.3](exercises/questions.md#extra.0.3), [extra.0.4](exercises/questions.md#extra.0.4); readiness corrections |
| 2 | [Calculus](appendices/02_calculus.md), [linear algebra](appendices/03_linear_algebra.md), finish numerics | Work the appendix examples; explain units, shapes and error; appendices add no counted assessments |
| 3–14 | Full chapters 1–12, one per week, following the core table | Labs 01–12; three original plus four supplemental questions each; midcourse in week 8, capstone in week 14 |
| 15 | [A01: approximation](advanced/01_approximation.md); L05/06/07, calculus and linear algebra | Lab 13; [adv.approximation.1](exercises/questions.md#adv.approximation.1), [adv.approximation.2](exercises/questions.md#adv.approximation.2), [adv.approximation.3](exercises/questions.md#adv.approximation.3); compare posterior features, not just optimisation |
| 16 | [A02: evidence and averaging](advanced/02_model_evidence.md); L04/10/12, integration | Lab 14; [adv.model_evidence.1](exercises/questions.md#adv.model_evidence.1), [adv.model_evidence.2](exercises/questions.md#adv.model_evidence.2), [adv.model_evidence.3](exercises/questions.md#adv.model_evidence.3); prior-width sensitivity |
| 17 | [A03: observation process](advanced/03_observation_process.md); L04/08/11, conditioning/integration | Lab 15; [adv.observation_process.1](exercises/questions.md#adv.observation_process.1), [adv.observation_process.2](exercises/questions.md#adv.observation_process.2), [adv.observation_process.3](exercises/questions.md#adv.observation_process.3); separate identified and sensitivity quantities |
| 18 | [A04: causal identification](advanced/04_causal.md); L08/10/12, conditioning | Lab 16; [adv.causal.1](exercises/questions.md#adv.causal.1), [adv.causal.2](exercises/questions.md#adv.causal.2), [adv.causal.3](exercises/questions.md#adv.causal.3); state the estimand and identification assumptions |
| 19 | [A05: dependent data](advanced/05_time_series.md); L04/07/10, covariance | Lab 17; [adv.time_series.1](exercises/questions.md#adv.time_series.1), [adv.time_series.2](exercises/questions.md#adv.time_series.2), [adv.time_series.3](exercises/questions.md#adv.time_series.3); chronological forecasts and validation |
| 20 | [A06: Gaussian processes](advanced/06_gaussian_processes.md); L07/10, matrix conditioning/numerics | Lab 18; [adv.gaussian_processes.1](exercises/questions.md#adv.gaussian_processes.1), [adv.gaussian_processes.2](exercises/questions.md#adv.gaussian_processes.2), [adv.gaussian_processes.3](exercises/questions.md#adv.gaussian_processes.3); latent versus noisy predictions |
| 21–22 | [C01: penguin mass](cases/01_penguins.md); L07/10/11 and A01/03 | Establish provenance, split and priors first; attempt analysis before lab 19/reference report; finish criticism, sensitivity and memo |
| 23–24 | [C02: sensor forecasts](cases/02_sensor_forecasting.md); L04/10 and A03/05 | Freeze the forecast target and temporal split; attempt before lab 20/reference report; finish sensitivity, report and cross-topic revision |

---

Source: `course/syllabus.md:88–90`

For full core weeks allow about 3 hours reading, 2 computation, 2–3 questions and 1–2 revision/project. Advanced coding problems or case revisions can exceed that allocation. Split an overloaded week rather than omitting checks. Recalling an earlier result before opening notes and explaining a new example after feedback are more useful progress measures than pages completed.

The [question bank](exercises/questions.md) labels objectives, difficulty and task type. Its [worked bank](exercises/solutions.md) and the case reports contain answers. The three cases, including optional continuation C03, are extended projects and add no items to the foundation’s 124-item assessment count. Case code and executed notebooks are worked references too. The full self-study website includes answers; only the designated [learner upload bundle](../llm/generated/learner_upload.zip) is answer-free.

---

Source: `course/syllabus.md:92–100`

## Assessment and feedback

Weekly submissions from weeks 1–12 contribute **40%**, equally weighted. Each has ten marks: three for conceptual explanation, three for derivation/calculation, and four for the computational or applied exercise plus lab interpretation. Weeks 0 and browser quizzes are ungraded. The [midcourse assessment](assessment.md) contributes **20%**, and the [capstone](capstone.md) contributes **40%**.

Suggested completion standard: at least 60% overall, at least 50% on both midcourse and capstone, and no unresolved critical capstone flaw (wrong target, data leakage presented as valid evaluation, or unsupported computation). These are course-design criteria, not university credit or accreditation. In self-study, use the rubrics to identify revisions; completion ticks in the browser do not certify mastery.

You may collaborate on interpretation and compare approaches. Write your own final explanation and disclose material assistance, including generated code. You remain responsible for checking assumptions, calculations, citations, and outputs. A correctly explained failed model can earn substantial credit; a polished chart with unsupported claims cannot.

Solutions are available because feedback is part of learning. Attempt the work first and use the solutions to correct your reasoning. In a graded class, an instructor can delay solution distribution without changing the public self-study edition.

---

Source: `course/syllabus.md:102–106`

## Routes and accessibility

The selected core route follows all twelve weeks; the full route follows the twenty-four-week schedule above. A mathematically confident reader may test out of preparation and complete weeks 1–4 faster while retaining their exercises. A theory-focused reader should derive each posterior before running code. A practice-focused reader should still complete exact calculations; they are the checks on later automation.

Lessons are available as Markdown and static HTML with print styling. Charts have surrounding explanations and machine-readable numerical results. Interactive controls have text labels and numeric output; the lesson text does not depend on interaction. Progress is stored only in your browser and is optional. The core site reads offline; software installation and external readings require network access. No accounts are needed for included material.

---

Source: `course/syllabus.md:108–112`

## Scope boundaries

The advanced chapters are scoped bridges with worked experiments, not exhaustive graduate treatments. They introduce approximation, evidence, observation mechanisms, causal identification, dependent data and Gaussian processes. They do not provide measure-theoretic probability, general asymptotic theory or a complete causal-inference curriculum. Appendix familiarity does not replace practice in mathematics or programming.

The [reference and continuation map](reference.md) connects each topic to local readings and further study. The penguin case uses genuine public CC0 data with documented provenance; the service and sensor datasets are synthetic. The accepted foundation’s computational, publication and independent AI review checks use E00–E19 in [expansion validation](../EXPANSION_VALIDATION.md). First- and second-edition reports are historical. Human statistical/teaching review, accessibility studies, learner pilots and live tutor trials remain unperformed.

---

Source: `course/syllabus.md:115–130`

## Optional continuation after prerequisites

This expansion leaves both original route tables and their required assessments unchanged. All ten new advanced questions are optional; C03 and practice are not scorebook items. The estimates below include each reading, lab and its new questions. They are planning allowances, not measured learner timings.

| Unit | Actual prerequisites | Content planning hours |
|---|---|---:|
| [A07: prior workflow](advanced/07_prior_workflow.md) | L01/02/03/05 | 4–6 |
| [A08: categorical conjugacy](advanced/08_categorical_conjugacy.md) | L02/03/04 and APP01 | 4–6 |
| [A09: multivariate hierarchy and computational repair](advanced/09_multivariate_hierarchy.md) | L04/06/07/09 and APP03/04 | 8–12 |
| [C03: omitted-site air quality](cases/03_air_quality.md) | A09, L10/11, A03/05 | 8–12, including 2–3 temporal-instruction hours |

Content totals 24–36 hours. The [diagnostic](practice/diagnostic.md), [six retrieval cards](practice/review_schedule.md) and [guided/scaffolded/independent analyses](practice/analysis_progression.md) add 10–17 hours if all are additive: total 34–53 hours. A tentative six further weeks at about 6–9 hours/week is only a planning option after these prerequisites. Budget unfamiliar prerequisite bridges separately. If C03 replaces the independent instructional stage, count its case hours once; name the displaced activity and subtract it when estimating a personal route. The proposed 1/3/6-week card spacing is unvalidated.

A09 deliberately retains unsuccessful centered fits and the measured repair effort. Its notebook replays authenticated fit evidence; changing a bound input requires a separate expensive recording. Start C03 from its [answer-free worksheet](cases/03_air_quality_starter.md). Reference notebooks contain answers. C03 reports historical conditional predictions using observed weather and concurrent other-site outcomes, not forecasting, exposure or causal effects. C03 received bounded independent AI acceptance for this historical teaching scope. Its four-model comparison retains substantial residual misfit; human scientific review remains unperformed and operational adequacy is unestablished. The SC01 correction uses mixture medians, equal-tailed intervals and marginal log densities; empirical MAE/RMSE evaluate that median without claiming a finite-risk optimum. Final outcomes are now exposed, so new score-informed choices require fresh outer validation.

[Evaluation protocols](../evaluation/README.md) specify future human peer/accessibility review, a selected-core pilot and live tutor trials. No such study has been performed. Their public specifications and offline software tests are not learning, accessibility or tutor-quality results.

---

Source: `course/syllabus.md:132–148`

## Further advanced menu: seven bounded modules

These additions are a flexible menu after the listed prerequisites, not extra required weeks inside either original route. All seven readings and worked labs are available; candidate review is pending. The 21 new questions are optional; they do not change the original assessment weights or 44 required attempts. A full additive pass is an estimated **40–54 hours**, excluding prerequisite repair, spread over a personally paced six-to-nine-week continuation. These are editorial estimates awaiting pilots.

| Module | Actual prerequisites | Planning hours including lab and questions |
|---|---|---:|
| [A10: nominal/ordinal regression](advanced/10_outcome_regression.md) | L06, L08, L10, A08 | 6–8 |
| [A11: study design and stopping](advanced/11_study_design.md) | L02, L03, L05, L12 | 5–7 |
| [A12: censored survival](advanced/12_survival.md) | L04, L08, L10, A03; integration | 6–8 |
| [A13: integrated GP hyperparameters](advanced/13_gp_hyperparameters.md) | A06, L05, Appendices 3–4 | 6–8 |
| [A14: predictive combinations](advanced/14_predictive_combination.md) | L07, L10, A02; L04 unknown-scale bridge | 5–7 |
| [A15: optimized variational inference](advanced/15_variational_fit.md) | A01, L04–L05, L07, Appendices 2–4 | 6–8 |
| [A16: splines and additive regression](advanced/16_splines.md) | L07, L10, Appendices 3–4; A06 helpful | 6–8 |

A10–A12 form a breadth menu of 17–23 hours; A13–A16 form a computational/nonlinear menu of 23–31 hours. A11 can follow core decisions directly. A13 follows A06 and A15 follows A01; numbering does not require every earlier advanced chapter. If A13 replaces a personally planned 6–8-hour optional GP investigation, remove those hours before adding A13's 6–8 hours. That substitution does not remove any original required exercise. Count an independent analysis once if it also serves as a continuation project; name the displaced activity in your plan.

For every project: **attempt → save plan → consult reference → revise**. A saved plan identifies the target, observation units, assumptions and information allowed in evaluation. Complete-book solutions, supplied lab code and executed notebooks are worked references. Distinguish an independent attempt from a revision helped by those references.

---

Source: `course/reference.md:1–1`

# Reference, notation and further study

---

Source: `course/reference.md:3–17`

## Notation

| Symbol | Meaning |
|---|---|
| $y$ | Observed data; context determines scalar, vector or counts |
| $\tilde y$ | Future or replicated data, with its target stated |
| $\theta$ | Unknown parameter or vector of parameters |
| $p(\theta)$ | Prior density or mass |
| $p(y\mid\theta)$ | Sampling model as a function of data; likelihood as a function of parameter |
| $p(\theta\mid y)$ | Posterior conditional on data and modelling assumptions |
| $p(y)$ | Marginal likelihood/evidence under a specified model |
| $E[\cdot]$, $\operatorname{Var}(\cdot)$ | Expectation and variance |
| $\propto$ | Proportional to, with the omitted constant independent of the variable of inference |
| $\mathbb{1}(A)$ | Indicator, equal to one if event A occurs and zero otherwise |
| $\Delta$ | A named contrast, such as equal-centre B–A completion difference |

---

Source: `course/reference.md:19–32`

## Distribution conventions

| Distribution | Mathematical parameters | Mean and variance | Python convention |
|---|---|---|---|
| Bernoulli | probability $p$ | $p$; $p(1-p)$ | `rng.binomial(1,p)` |
| Binomial | trials $n$, probability $p$ | $np$; $np(1-p)$ | `stats.binom(n,p)` |
| Beta | positive shapes $a,b$ | $a/(a+b)$; $ab/[(a+b)^2(a+b+1)]$ | `stats.beta(a,b)` |
| Gamma | shape $a$, **rate** $b$ | $a/b$; $a/b^2$ | `stats.gamma(a,scale=1/b)` |
| Normal | mean $\mu$, **variance** $\sigma^2$ | $\mu$; $\sigma^2$ | `stats.norm(loc=mu,scale=sigma)`; PyMC uses `sigma` |
| Poisson | expected count $\lambda$ | $\lambda$; $\lambda$ | `stats.poisson(mu=lam)` |
| Student-t | degrees of freedom $\nu$, location $\mu$, scale $s$ | mean $\mu$ if $\nu>1$; variance $s^2\nu/(\nu-2)$ if $\nu>2$ | `stats.t(df=nu,loc=mu,scale=s)` |
| Half-normal | positive support, scale $s$ | $s\sqrt{2/\pi}$; $s^2(1-2/\pi)$ | `pm.HalfNormal(...,sigma=s)` |

In PyMC, `Gamma(alpha=a, beta=b)` uses a rate parameter `beta`; in NumPy/SciPy, gamma random generation uses a scale. Check a function's signature rather than inferring its parameterisation from the distribution's name. A Student-t scale is not its SD.

---

Source: `course/reference.md:34–40`

## Formula sheet

Bayesian updating: $p(\theta\mid y)\propto p(y\mid\theta)p(\theta)$, with normalisation required for a probability distribution. Posterior prediction: $p(\tilde y\mid y)=\int p(\tilde y\mid\theta)p(\theta\mid y)d\theta$.

Beta-binomial update: $(a,b)\rightarrow(a+y,b+n-y)$. Gamma-Poisson update with exposure: $(a,b)\rightarrow(a+\sum y_i,b+\sum t_i)$ in shape-rate form. Normal-known-variance update: $s_n^{-2}=s_0^{-2}+n\sigma^{-2}$ and $m_n=s_n^2(m_0s_0^{-2}+\sigma^{-2}\sum y_i)$.

Independent Monte Carlo mean error: approximately $s_g/\sqrt S$. For MCMC, use an appropriate effective sample size or direct MCSE estimate for the quantity of interest. Posterior expected-loss action: $a^*=\arg\min_aE[L(a,\theta)\mid y]$. LOO score: $\sum_i\log p(y_i\mid y_{-i})$.

---

Source: `course/reference.md:42–55`

## Diagnostic reference

| Evidence | What it can reveal | What it cannot establish |
|---|---|---|
| Prior predictive simulation | Implausible joint model implications before outcomes | That a prior is uniquely correct |
| R-hat, rank and trace plots | Differences or instability among explored chains | Exhaustive exploration of every mode |
| Bulk/tail ESS and MCSE | Numerical precision and efficiency for summaries | Scientific uncertainty disappearing with more draws |
| Divergences/BFMI/tree depth | Difficult HMC geometry or inefficient trajectories | Adequacy of the observation model |
| Posterior predictive checks | Failure to reproduce selected features | Universal fit or untouched predictive performance |
| PSIS Pareto k | Reliability concerns for importance approximation | Truth or falsehood of the model by itself |
| Held-out score | Predictive performance for the split's target | Causality or transfer to a different population |
| SBC | Computational self-consistency under simulated models | That those models describe actual data |

Our teaching screens use four chains, R-hat below 1.01, bulk/tail ESS above 400, no divergences, and investigation of BFMI/tree depth. These are starting criteria for scrutiny; required MCSE depends on the decision. Follow [Stan's diagnostic guidance](https://mc-stan.org/learn-stan/diagnostics-warnings.html) and the [modern R-hat paper](https://arxiv.org/abs/1903.08008) for detail.

---

Source: `course/reference.md:57–63`

## Glossary

**Conjugacy:** a prior-likelihood pairing whose posterior stays in the prior family. **Credible interval:** a region with stated posterior probability. **Density:** probability per unit, integrated over a region to obtain probability. **Estimand:** the precise quantity an analysis seeks to learn. **Exchangeability:** joint beliefs unchanged by relabelling units under stated conditioning information. **Generative model:** a probabilistic account capable of simulating observations. **Hyperparameter:** a parameter governing a distribution of other parameters.

**Identifiability:** whether different parameter values imply distinguishable observation distributions. **Likelihood:** data compatibility as a function of parameters, holding observed data fixed. **Marginalisation:** summing or integrating out uncertain quantities. **Partial pooling:** estimating groups through a shared population model. **Posterior predictive distribution:** distribution of future or replicated outcomes averaged over posterior uncertainty. **Regularisation:** constraining unstable estimates, here through a prior or hierarchical structure.

**Sensitivity analysis:** examining changes under alternative defensible assumptions. **Sufficient statistic:** a data summary retaining likelihood information about a parameter within a specified model. **Utility:** numerical representation of consequences for a decision. **Validation leakage:** using information intended to be withheld when fitting, selecting, or preprocessing a model. **Warmup:** early sampler iterations used for adaptation and initial exploration, excluded from retained posterior draws.

---

Source: `course/reference.md:65–80`

## Appendix and advanced notation crosswalk

Mathematical Normal second arguments are variances, including multivariate covariance matrices. Library `scale`/`sigma` arguments generally use standard deviations; Student-t scale is a separate quantity. A rate needs an exposure unit. A vector’s dimension and the conditioning set are part of its definition.

| Notation | Meaning and caution | Local worked reference |
|---|---|---|
| $X$, $x$; $p(x)$, $f(x)$ | Random variable versus realised value; mass versus density | [Probability](appendices/01_probability.md) |
| $J$, $H$, $\nabla$ | Jacobian, Hessian, gradient; specify transformed measure and evaluation point | [Calculus](appendices/02_calculus.md), [approximation](advanced/01_approximation.md) |
| $X\in\mathbb R^{n\times p}$, $\Sigma$, $\Lambda$ | Design matrix, covariance, precision; precision is inverse covariance when nonsingular | [Linear algebra](appendices/03_linear_algebra.md) |
| $q(\theta)$, $\operatorname{KL}(q\Vert p)$ | Approximate density and directed divergence; direction changes the approximation | [A01](advanced/01_approximation.md) |
| $M_k$, $p(y\mid M_k)$ | Model label and model-specific evidence; proper priors and constants matter | [A02](advanced/02_model_evidence.md) |
| $R$, $x^*$ | Recording indicator and latent true measurement; conventions are stated locally | [A03](advanced/03_observation_process.md) |
| $Y(a)$, $\operatorname{do}(A=a)$ | Potential outcome and intervention; neither follows from association alone | [A04](advanced/04_causal.md) |
| $x_t$, $\phi$, $\epsilon_t$ | Latent state, dependence parameter, innovation; innovation variance differs from stationary variance | [A05](advanced/05_time_series.md) |
| $k(x,x')$, $K$, $f_*$ | Covariance kernel, Gram matrix and latent function at test inputs | [A06](advanced/06_gaussian_processes.md) |
| $S$, ESS, MCSE | Draw count, summary-specific effective count and numerical error | [Numerics](appendices/04_numerics.md) |

---

Source: `course/reference.md:82–82`

## Extended glossary and practice map

---

Source: `course/reference.md:84–99`

| Term | Working definition | Practice or case |
|---|---|---|
| Laplace approximation | Gaussian local curvature approximation near a posterior mode | [adv.approximation.1](exercises/questions.md#adv.approximation.1), [adv.approximation.2](exercises/questions.md#adv.approximation.2) |
| Variational family / ELBO | Restricted approximating distributions / an optimisation lower bound on log evidence; convergence need not establish accuracy | [adv.approximation.1](exercises/questions.md#adv.approximation.1), [adv.approximation.2](exercises/questions.md#adv.approximation.2), [adv.approximation.3](exercises/questions.md#adv.approximation.3) |
| Bayes factor | Evidence ratio for two specified models; prior-sensitive and undefined with arbitrary improper-prior constants | [adv.model_evidence.1](exercises/questions.md#adv.model_evidence.1), [adv.model_evidence.2](exercises/questions.md#adv.model_evidence.2) |
| Bayesian model averaging | Prediction averaging using posterior model probabilities under the stated model list | [adv.model_evidence.2](exercises/questions.md#adv.model_evidence.2), [adv.model_evidence.3](exercises/questions.md#adv.model_evidence.3) |
| Stacking | Predictive mixture weights chosen for an evaluation objective, not posterior model truth probabilities | [adv.model_evidence.3](exercises/questions.md#adv.model_evidence.3) |
| Ignorability | Conditions under which the recording mechanism can be omitted for a specified inference; not a synonym for random missingness | [adv.observation_process.2](exercises/questions.md#adv.observation_process.2), [adv.observation_process.3](exercises/questions.md#adv.observation_process.3) |
| Censoring / truncation | An observed interval/event versus exclusion outside a selection region; likelihoods differ | [adv.observation_process.3](exercises/questions.md#adv.observation_process.3) |
| Positivity / overlap | Each relevant treatment is possible within target covariate strata; a prior does not create missing identification | [adv.causal.2](exercises/questions.md#adv.causal.2), [adv.causal.3](exercises/questions.md#adv.causal.3) |
| G-formula | Standardising identified conditional outcome means over a stated target covariate distribution | [adv.causal.1](exercises/questions.md#adv.causal.1); Lab 16 |
| State-space model | A latent evolving process linked to noisy observations | [sensor case](cases/02_sensor_forecasting.md) |
| Rolling-origin evaluation | Repeated chronological training/forecast splits with fixed horizons | [adv.time_series.3](exercises/questions.md#adv.time_series.3); sensor case |
| Kernel / length scale | Covariance rule / characteristic input-distance scale controlling function similarity | [adv.gaussian_processes.1](exercises/questions.md#adv.gaussian_processes.1), [adv.gaussian_processes.2](exercises/questions.md#adv.gaussian_processes.2), [adv.gaussian_processes.3](exercises/questions.md#adv.gaussian_processes.3) |
| Jitter | Small numerical diagonal perturbation used for stable computation; distinct from scientific observation noise | [adv.gaussian_processes.2](exercises/questions.md#adv.gaussian_processes.2) |
| Transport | Applying inference to a different population or measurement context, requiring additional justification | [penguin case](cases/01_penguins.md) |

---

Source: `course/reference.md:101–101`

Find all `extra.*` and `adv.*` prompts in the [question bank](exercises/questions.md); use the [worked bank](exercises/solutions.md) only after an attempt. Original questions remain at the end of each core chapter, with [separate solutions](solutions.md). The [syllabus](syllabus.md) gives prerequisites and both study routes.

---

Source: `course/reference.md:103–117`

## Continue after the capstone

Choose depth based on the next question, not just a list of sophisticated methods.

| Direction | Preparation and motivating question | Starting resource |
|---|---|---|
| Mathematical Bayesian statistics | Probability/calculus; when do posteriors concentrate or remain prior-sensitive? | [Bayesian Data Analysis](https://sites.stat.columbia.edu/gelman/book/) |
| Scientific and causal modelling | Regression and causal graphs; what intervention is identified? | [Statistical Rethinking](https://github.com/rmcelreath/stat_rethinking_2026) |
| Advanced computational workflow | MCMC and prediction; how should a difficult applied model be developed? | [Bayesian Modeling and Computation](https://bayesiancomputationbook.com/welcome.html) |
| Flexible regression and Gaussian processes | Linear algebra and regression; how can nonlinear functions be modelled? | [PyMC examples](https://www.pymc.io/projects/examples/en/latest/) |
| Time series and state-space models | Conditional dependence and regression; how does a latent process evolve? | [Stan User's Guide](https://mc-stan.org/docs/stan-users-guide/index.html) |
| Predictive evaluation | Model checking; what split and score match deployment? | [Cross-validation FAQ](https://users.aalto.fi/~ave/modelselection/CV-FAQ.html) |
| Approximate inference | Optimisation and probability; which posterior features does an approximation lose? | [Aalto chapter notes](https://avehtari.github.io/BDA_course_Aalto/BDA3_notes.html) |

The [research dossier](../research/landscape.md) explains which sources shaped this course and what was actually inspected. External sites may change; the included chapters, code and results remain the self-contained core.

---

Source: `course/reference.md:120–132`

## Seven further methods: choose by target

The [syllabus menu](syllabus.md#further-advanced-menu-seven-bounded-modules) gives prerequisites and 40–54 additional planning hours. The new material is optional and leaves both original routes unchanged. Each lesson includes a fitted worked lab, two scientific figures, a changed-givens investigation and three [optional questions](exercises/continuation_questions.md). Work an attempt before consulting the separate [answer bank](exercises/continuation_solutions.md).

| Target or distinction | Local reading | Scope boundary |
|---|---|---|
| Unordered versus ordered response categories | [Nominal and ordinal regression](advanced/10_outcome_regression.md) | Category order does not establish proportional odds; inspect response probabilities |
| Assurance versus fixed-truth error and expected cost | [Study design](advanced/11_study_design.md) | Separate design and analysis priors; freeze looks, cap and decisions |
| Survival, hazard and event density with censoring | [Event-time regression](advanced/12_survival.md) | Administrative independent censoring; weeks are part of the model |
| Fixed settings, empirical Bayes and posterior integration | [GP hyperparameters](advanced/13_gp_hyperparameters.md) | Mixture quantiles and shared whole-curve draws; finite integration checks |
| Evidence weights versus learned predictive weights | [Predictive combinations](advanced/14_predictive_combination.md) | Fold-contained transforms and untouched outer evaluation; average densities before logs |
| Optimization error versus family error | [Fitted variational inference](advanced/15_variational_fit.md) | Optimize both families; retain termination warnings and tail discrepancies |
| Nonlinear functions linear in coefficients | [Splines and additive regression](advanced/16_splines.md) | Proper nullspace priors, smoothing uncertainty, training centering, bounded prediction domain |

---

Source: `course/reference.md:134–138`

### Continuation glossary

**Assurance** averages a prospective success decision over a declared design prior; it differs from the success probability at one fixed truth. **Proportional odds** uses the same regression slope across cumulative category splits. **Censoring** records an inequality about a time instead of treating the observed limit as an event. **Empirical Bayes** plugs an estimated hyperparameter into a conditional posterior; posterior integration instead averages over its uncertainty. **Stacking** chooses predictive mixture weights using held-out predictive densities; a weight is not a probability that a model is true. **Variational family error** persists when an optimized approximation cannot express the posterior dependence or tails. A spline **nullspace** contains directions unpenalized by a chosen roughness penalty; those directions still need proper priors in this course.

The [covariance experiment](../explorer.html#continuation-covariance) connects dependence to sum/difference uncertainty. The [two-look design experiment](../explorer.html#continuation-study-design) enumerates a small uniform-prior policy, with a numerical table and static alternatives. Its toy priors and thresholds differ from the fitted study-design lab.

---

Source: `data/README.md:1–15`

# Data dictionary and provenance

The three original service CSV files are synthetic teaching data created by [generate.py](generate.py), seed `20260926`. They describe a fictional service; no people, organisations, or actual interventions are represented. The generators and [generating-process reference](generating_processes.md) contain hidden numerical truths and are excluded from ordinary tutor retrieval. Write an analysis plan before inspecting them.

| File | Observation unit | Columns |
|---|---|---|
| waiting.csv | A service visit, 268 total | `centre`: integer 0–7; `load_z`: dimensionless centred workload index in [−2,2]; `wait_minutes`: continuous waiting time in minutes |
| completion.csv | A service user, 160 total | `support_z`: dimensionless centred support index in [−2,2]; `completed`: 0 or 1 |
| experiment.csv | Centre × randomised arm, 16 rows | `centre`: 0–7; `arm`: 0=A, 1=B; `trials` and `successes`: training counts; `holdout_trials` and `holdout_successes`: independent validation counts |

The `_z` variables are already defined on a centred teaching scale; they are not sample-standardised within each file. Waiting times follow a normal model with centre offsets and a common workload slope. That model can theoretically generate negative values, so its scientific plausibility is limited to these ranges. The completion data follow a logistic model. The experiment has differing centre baselines; allocation counts differ by centre but are equal between arms within each centre. Numerical generating coefficients belong to the protected reference.

The experiment's main decision targets an **equal mixture of the eight existing centres**, not the sample's size-weighted mixture and not unseen centres. The holdout is reserved for a final check, not prior selection or model tuning. Synthetic random assignment makes a treatment interpretation coherent within this simulation; it gives no evidence about an actual service.

Generate the files with `python data/generate.py` in the locked environment. Files are included so ordinary study needs no downloads. The three service datasets have no missing values; lesson 11 introduces missingness explicitly rather than silently discarding records. CSV decimals are rounded to eight places. The original service models assume independent visits conditional on their specified predictors and group effects.

---

Source: `data/README.md:17–34`

## Genuine public penguin observations

[penguins.csv](penguins.csv) is an unchanged public-data copy: **344 rows, eight columns**. It is not synthetic. The table concerns sampled adult penguins near Palmer Station in 2007–2009; it is not a random sample of all penguins. Kristen Gorman and Palmer Station LTER collected the observations, and Horst, Hill and Gorman distribute the simplified table in [palmerpenguins](https://allisonhorst.github.io/palmerpenguins/). See [provenance.json](provenance.json) for the immutable commit, raw URL, retrieval date, scientific citations and SHA-256. The [upstream CC0 statement](https://allisonhorst.github.io/palmerpenguins/#license) and [preserved licence](PENGUINS_LICENSE.md) support redistribution. No artwork was copied.

| Column | Meaning / units | Missing marker |
|---|---|---|
| `species` | Adelie, Chinstrap, Gentoo | `NA` |
| `island` | Biscoe, Dream, Torgersen | `NA` |
| `bill_length_mm` | Measured bill length, mm | `NA` |
| `bill_depth_mm` | Measured bill depth, mm | `NA` |
| `flipper_length_mm` | Measured flipper length, mm | `NA` |
| `body_mass_g` | Measured body mass, grams | `NA` |
| `sex` | Recorded female or male | `NA` |
| `year` | Study year, 2007–2009 | `NA` |

The marker policy is documented for every column; not every column actually has missing entries. Raw records retain all missing values. The case computes overlapping per-field counts and separate excluded-row counts. Measured precision is not an estimated measurement-error variance. This simplified table has no nesting identifier. Main-case eligibility requires the four measurements; recorded sex is not required. Training uses 2007–2008 and holdout uses 2009; transformations are fitted only on training records.

Citation: Horst AM, Hill AP, Gorman KB (2020), *palmerpenguins*, doi:10.5281/zenodo.3960218. Original scientific report: Gorman KB, Williams TD, Fraser WR (2014), *Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins*, PLoS ONE 9(3):e90081, doi:10.1371/journal.pone.0090081. The three underlying species-dataset DOIs are retained in provenance. The maintainer's request that researchers preparing publications contact the investigator and follow LTER use guidance is preserved there; no contact or external publication was made in this task.

---

Source: `data/README.md:36–47`

## Original synthetic sensor observations

[sensor_forecasting.csv](sensor_forecasting.csv) contains **120 synthetic readings**, no missing entries, and only these public fields:

| Column | Meaning / units |
|---|---|
| `time_index` | Integer 0–119, equally spaced one-minute observations |
| `reading` | Continuous observation in fictional instrument units, ten decimal places |

The target is future readings from this fictional process. Training is 0–95; final chronological holdout is 96–119. Do not shuffle time. The generator seed is `20260927`, distinct from analysis seed `2020`. Reproduce the CSV with `.venv/bin/python data/generate_sensor_forecasting.py`; ordinary lab execution reads included data without generating or fetching them. Latent truths are not columns in this table. The generator and generating-process notes are protected review references.

`provenance.json` records all six CSV files, including the original synthetic service data. Public dataset licence terms do not establish a licence for the rest of this repository.

---

Source: `data/README.md:50–82`

## Real Beijing daily air-quality observations

[beijing_2016_daily.csv](beijing_2016_daily.csv) contains 4,392 station-days: all
366 dates of 2016 at twelve UCI monitoring sites. This is real observational
data, released after the reference's frozen evaluation. Treat it as exposed if
you inspect the final-site concentrations before planning your own analysis.
See the [attribution and CC BY 4.0 notice](licenses/beijing_CC_BY_4.md). Its
quarantine wording records the original acquisition boundary; the release now
contains the exact frozen complete table. No original archive or license bytes
were changed. The source retrieval was 2026-09-26 UTC, DOI 10.24432/C5RK5G.

| Column | Meaning / units | Missing marker |
|---|---|---|
| `station` | Exact monitoring-site identifier | None |
| `date` | Recorded calendar date; no assumed timezone conversion | None |
| `n_hours` | Source hourly rows, 0–24 | None |
| `n_pm25` | Hours with finite recorded PM2.5, including observed zero | None |
| `n_wspm` | Hours with finite wind, including calm zero | None |
| `n_pair` | Hours with both measurements | None |
| `pm25_ug_m3` | Arithmetic mean PM2.5 over paired hours, µg/m³ | `NA` if no pair |
| `wspm_m_s` | Arithmetic mean wind over the same paired hours, m/s | `NA` if no pair |
| `eligible_18` | 1 when at least 18 paired hours, else 0 | None |
| `eligible_24` | 1 when exactly 24 paired hours, else 0 | None |
| `split` | Identifier-hash training/final assignment | None |

Dongsi and Guanyuan are the fixed final sites. Ten others supply training
outcomes. Both means use identical paired hours. Ineligible records remain in
the table and may have observed means; eligibility is distinct from missingness.
The base rule is a teaching assumption, not an environmental standard. Complete
hours can change the measured population and do not repair informative missingness.
Weather is matched to the nearest meteorological station, not necessarily
measured at the pollution monitor. No coordinates or adjacency are inferred.
Ordinary reference execution is offline and never redownloads or substitutes data.

---

Source: `course/appendices/01_probability.md:1–1`

# Appendix 1 · Probability and conditioning

---

Source: `course/appendices/01_probability.md:3–7`

## How to use this bridge

Probability notation becomes useful when it identifies what is uncertain, what has been observed, and which population a statement concerns. This appendix develops those distinctions with small examples you can reconstruct by hand. Only algebra is required; an integral can initially be read as a continuous weighted sum. The examples are invented teaching situations, not empirical claims about equipment or services.

**Required bridge.** Read through the shared-probability example if conditioning, density, or predictive variation is unfamiliar. It supports [Chapter 0, Events, support, and conditioning](../chapters/00_preparation.md#events-support-and-conditioning), [Chapter 1, Deriving the update from joint probability](../chapters/01_bayes.md#deriving-the-update-from-joint-probability), and [Chapter 3, Conditional independence does not imply marginal independence](../chapters/03_prediction.md#conditional-independence-does-not-imply-marginal-independence). The last section is optional depth for hierarchical predictions and decisions. The short prompts are retrieval practice, not additional graded exercises.

---

Source: `course/appendices/01_probability.md:9–24`

## Random quantities and their realised values

A random variable is a rule assigning a numerical value to each possible outcome of an experiment. Before an inspection, the number of faults is uncertain; after inspection, its observed value is fixed. Probability describes the former, while a likelihood uses the latter as an input. A parameter can be unknown without physically changing between observations: Bayesian randomness represents uncertainty about it within a specified model.

| Appendix notation | Meaning and connection to the chapters |
|---|---|
| $Y$, $y$ | Random observation and observed value; chapters often suppress the capital when writing a distribution |
| $\Theta$, $\theta$ | Uncertain parameter and a possible parameter value; chapter notation commonly uses $\theta$ for both, distinguished by context |
| $\widetilde Y$, $\tilde y$ | Future random outcome and possible future value, with the prediction target stated |
| $P(A)$ | Probability of event $A$, a dimensionless number between zero and one |
| $p(y\mid\theta)$ | Conditional mass or density, evaluated at specified values; as a function of $\theta$ with $y$ fixed, the likelihood |
| $E[Y\mid\Theta]$ | A random function of the still-uncertain parameter; at $\Theta=\theta$ it becomes $E[Y\mid\Theta=\theta]$ |

For example, if $Y\mid\Theta=\theta\sim\operatorname{Binomial}(5,\theta)$, the expression $E[Y\mid\Theta]=5\Theta$ is itself random before learning the parameter. The observed count $y=3$ has no posterior variance: it is already recorded. We can still be uncertain about a latent true count behind an imperfect recording, but that requires another random variable and an observation model. Distinguishing those variables prevents uncertainty from being attached to the wrong target.

Conditioning on information does not make everything in that information's causal neighbourhood fixed. Knowing the inspection result leaves the machine's hidden state uncertain. Conversely, fixed design inputs can be conditioned on without giving them a probability distribution. Regression in this course often treats workloads this way.

---

Source: `course/appendices/01_probability.md:26–37`

## Mass, density, support, and normalisation

A discrete probability mass function assigns probabilities to possible values. Its nonnegative entries sum to one over its support, the set of allowed values. For a Bernoulli observation, the support is zero and one; a negative count is impossible under that model. A model may be inappropriate if actual recording errors create values outside its intended support.

A continuous density instead gives probability per unit of the variable:

$$P(a<Y<b)=\int_a^b f_Y(t)\,dt,\qquad
\int_{-\infty}^{\infty}f_Y(t)\,dt=1.$$

If a waiting time is measured in minutes, its density has units of inverse minutes. The integration width contributes minutes, leaving a dimensionless probability. A uniform wait between zero and half a minute has density two per minute. That height exceeds one legitimately; the area over the full interval is one. At any single point the continuous probability is zero, even where the density is large. [Appendix 2](02_calculus.md#probability-as-an-integral) develops this area calculation and its behaviour under changes of units.

The likelihood need not sum or integrate to one over parameter values. Its normalisation property concerns possible data values at a fixed parameter. A posterior must normalise over the parameter instead. Confusing these directions can turn a useful likelihood curve into a falsely labelled probability distribution.

---

Source: `course/appendices/01_probability.md:39–72`

## Worked example: a joint table and two conditionals

Suppose a hypothetical component is worn with probability one quarter and sound otherwise. An alarm sounds with probability 0.40 for a worn component and 0.08 for a sound component. Let $W$ indicate worn and $A$ indicate alarm. Multiplying each state probability by its conditional alarm probability produces this joint distribution:

| State | Alarm | No alarm | State total |
|---|---:|---:|---:|
| Worn | 0.10 | 0.15 | 0.25 |
| Sound | 0.06 | 0.69 | 0.75 |
| Outcome total | 0.16 | 0.84 | 1.00 |

Marginalising means adding over a variable we are no longer distinguishing. The alarm probability is the column sum 0.16. Conditioning restricts attention to a column or row, then renormalises its entries. Among alarm cases, the worn fraction is $0.10/0.16=0.625$. Among worn components, the alarm fraction remains $0.10/0.25=0.40$. These calculations answer different questions despite sharing the same numerator.

Bayes' rule follows by writing that joint numerator in two ways:

$$P(W,A)=P(A\mid W)P(W)=P(W\mid A)P(A),$$

$$P(W\mid A)=\frac{P(A\mid W)P(W)}{P(A)},\qquad P(A)>0.$$

The prior odds of wear are one to three. The alarm's likelihood ratio is five, so posterior odds are five to three, equivalent to probability five eighths. The high posterior does not mean alarms cause wear. Nor can we transfer it unchanged to a population with a different worn fraction.

```python
import numpy as np

joint = np.array([[0.10, 0.15], [0.06, 0.69]])
state_mass = joint.sum(axis=1)       # one entry per state
alarm_mass = joint.sum(axis=0)       # one entry per alarm outcome
worn_given_alarm = joint[0, 0] / alarm_mass[0]
assert np.isclose(joint.sum(), 1.0)
assert np.isclose(worn_given_alarm, 0.625)
```

The axis labels are part of the calculation. Swapping them can return valid-looking probabilities about the wrong variable. Before using an array operation, describe in words which labels disappear when you sum.

**Check your understanding.** Find the worn probability after no alarm. Which table entries form its denominator? Explain why multiplying two alarm probabilities would require an additional assumption about two inspections.

---

Source: `course/appendices/01_probability.md:74–85`

## Conditional densities and independence

For continuous variables with a joint density, the analogous construction is

$$f_X(x)=\int f_{X,Y}(x,y)\,dy,\qquad
f_{Y\mid X}(y\mid x)=\frac{f_{X,Y}(x,y)}{f_X(x)},\quad f_X(x)>0.$$

This defines a conditional density at a value where the marginal density is positive; it does not divide by the zero probability of the point event. One intuition is conditioning on progressively smaller neighbourhoods around that value. Formal conditioning for more general distributions is beyond this bridge.

Independence means the joint distribution factorises into the marginal distributions. Conditional independence means it factorises after particular information is given. The conditioning clause matters: observations sharing an uncertain probability can be independent given that probability and dependent after averaging over it. Neither separate rows in a dataset nor the absence of an obvious causal connection establishes independence.

For repeated measurements, write the shared quantities explicitly before multiplying likelihood contributions. A common calibration offset, day effect, or centre effect can create dependence. Conditioning on that effect may justify a product; omitting the effect from the model does not make the dependence disappear.

---

Source: `course/appendices/01_probability.md:87–107`

## Deriving total expectation and total variance

Assume the moments below exist. For discrete $G$, expand the joint distribution and regroup a sum:

$$E[Y]=\sum_g\sum_y y\,p(y\mid g)p(g)
=\sum_g E[Y\mid G=g]p(g)=E[E[Y\mid G]].$$

For continuous variables use integrals, with integrability conditions permitting the regrouping. This is the law of total expectation. First average within each group; then weight those group averages by the group's probability. An unweighted average answers the same question only when the group weights are equal.

For variance, write the deviation from the overall mean as

$$Y-E[Y]=\{Y-E[Y\mid G]\}+\{E[Y\mid G]-E[Y]\}.$$

Squaring and averaging gives two squared terms and a cross term. Conditional on $G$, the first bracket has expectation zero and the second is fixed. Consequently the cross term vanishes, giving

$$\operatorname{Var}(Y)=E[\operatorname{Var}(Y\mid G)]
+\operatorname{Var}(E[Y\mid G]).$$

The first term measures variation within the conditional distributions; the second measures variation between their centres. Both have squared outcome units. The formula does not assume that $Y$ and $G$ are independent.

For an original numerical example, suppose a repair is routine with probability 0.75 and difficult otherwise. Conditional mean duration is two or six hours; conditional variance is one or four squared hours. The overall mean is three hours. Average conditional variance is $0.75(1)+0.25(4)=1.75$. Variation between conditional means is $0.75(2-3)^2+0.25(6-3)^2=3$. Total variance is therefore 4.75 squared hours, much larger than 1.75. These moments describe a mixture of duration distributions; they do not assert that the mixture is Normal.

---

Source: `course/appendices/01_probability.md:109–138`

## Worked example: dependence from a shared probability

Let a future batch share one uncertain success probability $\Theta\sim\operatorname{Beta}(3,2)$. Its mean is 0.6 and variance is 0.04. Given that probability, five Bernoulli outcomes are independent. Marginally each individual outcome is Bernoulli with probability 0.6, hence variance 0.24. However, two outcomes have joint success probability

$$P(Y_1=1,Y_2=1)=E[\Theta^2]
=\operatorname{Var}(\Theta)+E[\Theta]^2=0.40.$$

Independent marginal outcomes would instead give 0.36. Their covariance is therefore 0.04 and their correlation is $0.04/0.24=1/6$. Observing one success changes the second success probability to $0.40/0.60=2/3$. The first outcome supplies evidence about their shared parameter; it need not physically influence the second.

Calculate the variance of their total $K$ in two ways. Summing variances and pairwise covariances gives

$$\operatorname{Var}(K)=5(0.24)+5(4)(0.04)=2.$$

Alternatively, conditional variance is $5\Theta(1-\Theta)$ and conditional mean is $5\Theta$. Since $E[\Theta(1-\Theta)]=0.60-0.40=0.20$, total variance gives $5(0.20)+25(0.04)=2$ again. The mean count is three. Redrawing an independent probability for each observation would define a different model, with count variance only 1.2.

SciPy's beta-binomial distribution integrates the shared probability analytically. The following enumeration verifies both moments without simulation error:

```python
import numpy as np
from scipy import stats

k = np.arange(6)
mass = stats.betabinom.pmf(k, n=5, a=3, b=2)
mean = k @ mass
variance = ((k - mean) ** 2) @ mass
assert np.isclose(mean, 3.0)
assert np.isclose(variance, 2.0)
```

**Check your understanding.** To predict two batches from the same installation, should a simulation draw one probability or two? State what additional assumption would justify two independent probabilities.

---

Source: `course/appendices/01_probability.md:140–158`

## Optional depth: covariance, mixtures, and decisions

**Extended route.** The same zero-cross-term argument yields total covariance:

$$\operatorname{Cov}(Y,Z)
=E[\operatorname{Cov}(Y,Z\mid G)]
+\operatorname{Cov}(E[Y\mid G],E[Z\mid G]).$$

Thus conditional independence removes the first term but need not remove the second. [Chapter 9, Existing and new groups need different predictions](../chapters/09_hierarchical.md#existing-and-new-groups-need-different-predictions) uses this distinction when several future visits share an unseen centre effect. Preserve that common effect in each simulated batch.

Linearity of expectation requires no independence: the expected sum of costs is the sum of expected costs. Variance of a sum does require covariance accounting. Nonlinear functions require still more care. For squared loss around a proposed value $a$,

$$E[(Y-a)^2]=\operatorname{Var}(Y)+(E[Y]-a)^2.$$

Plugging the mean into the loss drops the variance term. For the repair example, squared error around three hours averages 4.75 squared hours even though the error at the mean is zero. This explains why substituting a posterior mean before applying nonlinear utility can misrepresent consequences.

Finally, averaging must match the target population. Giving each centre equal weight differs from giving each visitor equal weight when centre sizes differ. [Chapter 12, Population weights can change the answer](../chapters/12_decisions.md#population-weights-can-change-the-answer) applies this principle to actions. A conditional bar, a weight, and an observation unit are modelling choices with substantive meaning; calculation cannot supply them automatically.

**Check your understanding.** Explain, without a formula, why uncertainty about a shared centre mean does not vanish when predicting an average over many future visitors at that centre. Then identify the surviving term in total variance.

---

Source: `course/appendices/02_calculus.md:1–1`

# Appendix 2 · Calculus, transformations, and integration

---

Source: `course/appendices/02_calculus.md:3–16`

## How to use this bridge

Bayesian calculations repeatedly multiply densities, integrate out unknown quantities, and change coordinates. This appendix explains why those operations have the forms used in the chapters. It assumes algebra and the distinction between probability and density from [Appendix 1](01_probability.md#mass-density-support-and-normalisation). You can work through the examples without having taken a complete calculus course.

**Required bridge.** Read the integration, normalisation, square-completion, and transformation sections alongside [Chapter 2, A prior density on a probability](../chapters/02_beta_binomial.md#a-prior-density-on-a-probability), [Chapter 4, Complete the normal square and interpret precision](../chapters/04_continuous.md#complete-the-normal-square-and-interpret-precision), and [Chapter 6, Constrained parameters need the right density](../chapters/06_hmc.md#constrained-parameters-need-the-right-density). Curvature and unknown-scale integration are explicitly optional depth. The aim is to understand the operation before delegating it to numerical software.

| Notation here | Crosswalk to chapter and software conventions |
|---|---|
| $f_X(x)$, $p(x)$ | Density evaluated at a possible value; either notation appears in the course |
| $Z$ | Integral of an unnormalised kernel, distinct from a random variable called $Z$ in a transformation |
| $a,b$ | Beta shapes are dimensionless; gamma uses shape $a$ and rate $b$ |
| $v=\sigma^2$ | Normal observation variance; SciPy's `scale` is $\sigma$ |
| $s^2$ | Sample variance in the unknown-scale derivation, distinct from the resulting Student-t scale |
| $h=g^{-1}$ | Inverse coordinate map, whose derivative supplies the Jacobian |

---

Source: `course/appendices/02_calculus.md:18–29`

## Probability as an integral

An integral adds contributions across an interval. Divide the interval into small cells of width $\Delta_j$ and evaluate a density at a representative point $x_j$. The cell probability is approximately $f(x_j)\Delta_j$. Adding these products and refining the partition leads to the integral. On an uneven partition, widths must remain in the calculation: a density height alone is never a cell probability.

For a concrete density, let $X$ represent a dimensionless fraction with $f(x)=2x$ for $0<x<1$ and zero elsewhere. Since an antiderivative of $2x$ is $x^2$, the probability between one quarter and three quarters is

$$\int_{1/4}^{3/4}2x\,dx
=\left[x^2\right]_{1/4}^{3/4}=\frac12.$$

The integral across the support is one. The mean weights each cell by its possible value, so $E[X]=\int_0^1 x(2x)dx=2/3$. A density plot's peak near one therefore differs from its mean. Expectations of other functions replace the first factor by that function; for example, $E[X^2]=1/2$ and the variance is $1/2-4/9=1/18$.

If instead the variable measured time, the density and differential would carry reciprocal units. Always include the support when normalising. Integrating a positive-rate model over negative rates creates a different, often undefined calculation.

---

Source: `course/appendices/02_calculus.md:31–58`

## Beta and gamma normalising integrals

A posterior initially appears as a nonnegative kernel $q(\theta)$. It defines a density only if its integral $Z$ is positive and finite, in which case $p(\theta)=q(\theta)/Z$. Two named integrals make the course's conjugate examples tractable:

$$B(a,b)=\int_0^1 t^{a-1}(1-t)^{b-1}dt,
\qquad \Gamma(a)=\int_0^\infty u^{a-1}e^{-u}du.$$

Positive shape parameters make these integrals finite. Integration by parts gives $\Gamma(a+1)=a\Gamma(a)$, and for positive integers $\Gamma(a)=(a-1)!$. The beta integral satisfies $B(a,b)=\Gamma(a)\Gamma(b)/\Gamma(a+b)$. It is a normalising constant, not an extra assumption about the observations.

For example, $B(3,2)=1/12$, so the Beta(3,2) density is $12\theta^2(1-\theta)$. Ratios of normalisers derive its moments:

$$E[\Theta]=\frac{B(a+1,b)}{B(a,b)}=\frac{a}{a+b},\qquad
E[\Theta^2]=\frac{a(a+1)}{(a+b)(a+b+1)}.$$

Subtracting squared mean from second moment yields the beta variance used in [Chapter 3, Work out both layers of predictive variation](../chapters/03_prediction.md#work-out-both-layers-of-predictive-variation). Multiplying a beta prior by a binomial likelihood adds success and failure counts to the exponents. Integration then supplies the beta-binomial predictive mass:

$$P(K=k)=\binom{m}{k}\frac{B(a+k,b+m-k)}{B(a,b)}.$$

The binomial coefficient cannot be discarded here: it varies with the possible count whose probability is being calculated. A factor constant in the parameter during updating can still matter for prediction or evidence.

For a gamma kernel with shape $a$ and rate $b$, substitute $u=b\lambda$. Because $d\lambda=du/b$, its integral is

$$\int_0^\infty\lambda^{a-1}e^{-b\lambda}d\lambda
=b^{-a}\Gamma(a).$$

Thus the density includes $b^a/\Gamma(a)$. The same substitution and gamma recurrence give mean $a/b$ and variance $a/b^2$. When $\lambda$ is incidents per hour, the gamma rate parameter $b$ has units of hours, while the shape is dimensionless. It is consequently sensible that total observation exposure adds to $b$ in [Chapter 4, Derive the gamma-Poisson update](../chapters/04_continuous.md#derive-the-gamma-poisson-update).

In SciPy, use `stats.gamma(a, scale=1/b)`: its scale has the same units as the random rate. For large shapes, evaluate normalising constants with `special.gammaln` or `special.betaln` in log calculations, avoiding enormous intermediate gamma values.

---

Source: `course/appendices/02_calculus.md:60–75`

## Completing a square derives a Normal posterior

Suppose independent readings satisfy $Y_i\mid\mu\sim\operatorname{Normal}(\mu,\sigma^2)$, with known observation variance, and the prior is $\mu\sim\operatorname{Normal}(m_0,s_0^2)$. The chapter notation uses variance as the second Normal argument; SciPy's `scale` is standard deviation. Keeping only terms that depend on the unknown mean, the log posterior is

$$-\frac12\left[\frac{(\mu-m_0)^2}{s_0^2}
+\sum_i\frac{(y_i-\mu)^2}{\sigma^2}\right]
=-\frac12(Q\mu^2-2h\mu)+\text{constant},$$

$$Q=s_0^{-2}+n\sigma^{-2},\qquad
h=m_0s_0^{-2}+\sigma^{-2}\sum_i y_i.$$

The identity $Q\mu^2-2h\mu=Q(\mu-h/Q)^2-h^2/Q$ identifies a Normal kernel. Therefore posterior mean is $h/Q$ and variance is $1/Q$. The omitted term is constant in the unknown mean, making it irrelevant to this posterior's shape. It is not necessarily constant across models; evidence calculations must retain all required normalisation factors.

Consider an instrument with prior mean eight millimetres and prior standard deviation two millimetres. Two readings are eleven and fourteen millimetres, each with known error standard deviation three millimetres. Here $Q=17/36$ inverse squared millimetres and $h=43/9$ inverse millimetres. Posterior mean is $172/17\approx10.117647$ millimetres and variance is $36/17\approx2.117647$ squared millimetres. The prior pulls the result below the sample mean of 12.5; it has greater precision than the two-reading mean.

**Check your understanding.** What changes if the two readings share an unknown calibration error? Identify exactly which product of likelihood terms would require reconsideration before reusing the precision formula.

---

Source: `course/appendices/02_calculus.md:77–83`

## Transformations preserve probability, not density height

Let $Z=g(X)$ be a differentiable, one-to-one transformation with inverse $x=h(z)$. A small width on the transformed axis corresponds to width $|h'(z)|dz$ on the original axis. Equating probability in corresponding intervals gives

$$f_Z(z)=f_X(h(z))\left|\frac{dh}{dz}\right|.$$

The absolute derivative is the one-dimensional Jacobian. It must use the inverse map because we are expressing the old differential in terms of the new integration variable. For a decreasing transformation the derivative is negative, while probabilities remain positive. With several inverse branches, their contributions must be added; the single-branch formula is insufficient for transformations such as squaring across both signs.

---

Source: `course/appendices/02_calculus.md:85–92`

### Worked example: rates in hours and minutes

Suppose the uncertain hourly incident rate is $\Lambda\sim\operatorname{Gamma}(3,\text{rate}=2)$. The numerical rate per minute is $R=\Lambda/60$. Hence $\lambda=60r$ and

$$f_R(r)=60f_\Lambda(60r),\qquad
R\sim\operatorname{Gamma}(3,\text{rate}=120).$$

The mean changes from 1.5 incidents per hour to 0.025 incidents per minute. Variance changes from 0.75 to $0.75/60^2$ in the corresponding squared rate units. The event between one and two incidents per hour is identical to the event between one sixtieth and two sixtieths per minute. Both have probability approximately 0.438573111. A two-hour exposure becomes 120 minutes, so expected counts given the rate are also invariant: $2\lambda=120r$.

---

Source: `course/appendices/02_calculus.md:94–104`

### Worked example: a dimensionless log rate

Logarithms need a dimensionless argument. Choose reference rate $\lambda_{\mathrm{ref}}=1$ incident per hour and define $\eta=\log(\lambda/\lambda_{\mathrm{ref}})$. Its inverse has derivative $\lambda_{\mathrm{ref}}e^\eta=\lambda$. For a shape-rate gamma density,

$$\log f_\eta(\eta)
=a\log(b\lambda_{\mathrm{ref}})-\log\Gamma(a)+a\eta
-b\lambda_{\mathrm{ref}}e^\eta.$$

The product of gamma rate and reference incident rate is dimensionless, so every logarithm now has an explicitly dimensionless argument. The Jacobian adds one power of the original rate. Omitting it would leave exponent $a-1$ and target the wrong transformed distribution. In the numerical example, the density mode on the rate axis is one incident per hour, whereas the log-density mode maps back to 1.5 incidents per hour. Density modes are coordinate dependent; probabilities of matched events are invariant.

If you instead declare a Normal distribution for a log rate and define the rate as its exponential, you have directly specified a generative model. You do not manually add another Jacobian to that declaration. The adjustment is needed when expressing an already-specified density with respect to a different integration variable. This distinction also explains [Chapter 9, Reparameterisation changes geometry](../chapters/09_hierarchical.md#reparameterisation-changes-geometry).

---

Source: `course/appendices/02_calculus.md:106–117`

## Derivatives for HMC and local curvature

**Core HMC support.** A derivative measures change per unit input. At an interior smooth maximum of a log density, its first derivative is zero; negative second derivative indicates local downward curvature. For the Normal posterior above, the gradient is $-Q(\mu-m_n)$ and curvature is $-Q$. Greater precision means steeper log density, narrower uncertainty, and a shorter coordinate scale for numerical exploration.

For Chapter 6, the following differentiation rules are required support; manipulating a full multivariate Hessian is extended-route depth. For differentiable scalar functions, the product rule is $(fg)'=f'g+fg'$ and the chain rule is $(f\circ g)'(x)=f'(g(x))g'(x)$. For example, differentiating $x e^{-x^2/2}$ gives $e^{-x^2/2}(1-x^2)$: the product contributes one term, and the derivative of the inner exponent contributes $-x$. Also $(\log x)'=1/x$ for $x>0$. Taking logs turns likelihood products into sums before differentiation, reducing algebra and underflow.

**Worked gradient for HMC.** A Beta($a,b$) density on $0<\theta<1$ has log density $\ell(\theta)=(a-1)\log\theta+(b-1)\log(1-\theta)+C$. The chain rule gives

$$\ell'(\theta)=\frac{a-1}{\theta}-\frac{b-1}{1-\theta},\qquad
\ell''(\theta)=-\frac{a-1}{\theta^2}-\frac{b-1}{(1-\theta)^2}.$$

For Beta(3,5) at $\theta=1/2$, these are $-4$ and $-24$. HMC uses the potential $U=-\ell$, so its gradient has the opposite sign; the momentum force $-U'$ points towards increasing log density. This constrained-coordinate derivative is an illustration. With unconstrained log odds $z$, $\theta=1/(1+e^{-z})$ and $d\theta/dz=\theta(1-\theta)$. Including the density's Jacobian gives $\ell_z(z)=a\log\theta+b\log(1-\theta)+C$, hence $d\ell_z/dz=a-(a+b)\theta$. For the same Beta distribution at $z=0$, this is $-1$, not $-4$: derivatives depend on the coordinate and reference measure.

---

Source: `course/appendices/02_calculus.md:119–125`

### Extended-route depth: vector gradients and Hessians

For a vector $\beta$, the **gradient** $\nabla\ell$ is the column of first partial derivatives; its jth component changes $\beta_j$ while holding the others fixed. The **Hessian** $H$ has entries $H_{jk}=\partial^2\ell/(\partial\beta_j\partial\beta_k)$. Mixed entries describe coupled curvature. If $Q$ is symmetric and $\ell=-\tfrac12(\beta-m)^TQ(\beta-m)+C$, expansion or the product rule gives $\nabla\ell=-Q(\beta-m)$ and $H=-Q$. With $Q=\begin{pmatrix}2&1\\1&3\end{pmatrix}$ and displacement $(1,-1)^T$, the gradient is $(-1,2)^T$. For any nonzero displacement, the potential increases by a positive quadratic because the leading minor is two and determinant is five. Its positive curvature defines a proper local Gaussian approximation.

**Check before coding.** Approximate each partial derivative by $[\ell(\beta+he_j)-\ell(\beta-he_j)]/(2h)$ at an interior point. Try several moderate step sizes: large h has truncation error and tiny h loses digits to subtraction. Compare with the analytic gradient, then differentiate that gradient to check the Hessian. A successful local check detects implementation mistakes; it does not establish global posterior geometry.

A second-order Taylor expansion around a mode replaces a smooth log density locally by a quadratic. Exponentiating gives a Gaussian approximation if the negative Hessian is positive definite. This motivates Laplace approximation and connects to [Chapter 6, Energy connects the target to a trajectory](../chapters/06_hmc.md#energy-connects-the-target-to-a-trajectory). Local curvature cannot reveal an unvisited second mode, guarantee tail accuracy, or repair a boundary maximum. Coordinates and Jacobians must be settled before taking derivatives.

---

Source: `course/appendices/02_calculus.md:127–139`

## Optional depth: integrating an unknown Normal variance

**Extended route.** The exact reference in [Chapter 4, Unknown scale changes the problem](../chapters/04_continuous.md#unknown-scale-changes-the-problem) uses the improper prior $p(\mu,v)\propto1/v$ with respect to $d\mu\,dv$, where $v=\sigma^2>0$. This is not a probability distribution and is not interchangeable with the same expression relative to $d\mu\,d\sigma$.

Let $S=\sum_i(y_i-\bar y)^2>0$. The identity $\sum_i(y_i-\mu)^2=S+n(\mu-\bar y)^2=A(\mu)$ gives

$$p(\mu\mid y)\propto\int_0^\infty
v^{-(n/2+1)}\exp\{-A(\mu)/(2v)\}\,dv
=\Gamma(n/2)\{2/A(\mu)\}^{n/2}.$$

The substitution is $u=A/(2v)$; its absolute differential is $A/(2u^2)du$. Matching the resulting kernel to a Student-t gives degrees of freedom $n-1$, location $\bar y$, and scale $s/\sqrt n$, where $s^2=S/(n-1)$. This posterior is proper when $n>1$ and $S>0$. Its scale is not its standard deviation; the latter exists only when the degrees of freedom exceed two.

For readings eight, ten, twelve, and fourteen millimetres, the mean is eleven, sample variance is $20/3$, and posterior t scale is approximately 1.290994 millimetres. The central 95% interval is approximately [6.891479, 15.108521] millimetres. Its tails incorporate scale uncertainty. A proper posterior here does not rescue marginal likelihoods based on the improper prior: its arbitrary multiplicative constant makes absolute evidence, and ordinary Bayes-factor use of it, undefined without further justified construction.

---

Source: `course/appendices/02_calculus.md:141–164`

## Numerical integration and a practical check

Analytic integration identifies an exact mathematical result. Quadrature approximates the integral by selected function evaluations. Monte Carlo approximates an expectation by random draws. These methods have different error mechanisms, so agreement between them is useful evidence.

```python
import numpy as np
from scipy import integrate, stats

hourly = stats.gamma(a=3, scale=1/2)
minute = stats.gamma(a=3, scale=1/120)
p_hour, error_estimate = integrate.quad(hourly.pdf, 1, 2)
p_minute = minute.cdf(2/60) - minute.cdf(1/60)
assert np.isclose(p_hour, p_minute, rtol=0, atol=1e-12)

readings = np.array([8., 10., 12., 14.])
interval = stats.t.ppf(
    [0.025, 0.975], df=3, loc=readings.mean(),
    scale=readings.std(ddof=1) / np.sqrt(readings.size),
)
```

SciPy's [`quad` documentation](https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.quad.html) describes its estimated absolute integration error and tolerances. That estimate concerns numerical integration under the supplied function, not uncertainty about the model or the observations. Narrow peaks, singular boundaries, and omitted tails need deliberate investigation. Refine the domain or tolerances and compare with an independent identity when available.

**Check your understanding.** Explain why increasing quadrature accuracy cannot justify a questionable prior. Then transform a uniform density under a decreasing linear map and identify where the absolute Jacobian enters.

---

Source: `course/appendices/03_linear_algebra.md:1–1`

# Appendix 3 · Linear algebra and multivariate Normals

---

Source: `course/appendices/03_linear_algebra.md:3–7`

## How to use this bridge

Several uncertain coefficients belong to one joint distribution. Linear algebra keeps their relationships visible while expressing regression and prediction compactly. This appendix builds the notation from dimensions, then derives the covariance calculations used in the course. You need scalar Normal distributions and elementary algebra; no previous matrix calculus is assumed.

**Required bridge.** Read the sections on dimensions, covariance, and correlated predictions for [Chapter 7, Joint draws preserve relationships](../chapters/07_regression.md#joint-draws-preserve-relationships). The regression derivation expands [Chapter 7, A useful analytic connection](../chapters/07_regression.md#a-useful-analytic-connection). Conditional multivariate Normals and geometry provide optional depth for hierarchy, HMC, and later Gaussian-process work. Keeping them here lets the main route use their consequences without requiring every matrix derivation at first encounter.

---

Source: `course/appendices/03_linear_algebra.md:9–27`

## Vectors, matrices, dimensions, and units

A vector collects ordered numbers. A matrix is a rectangular array representing a transformation or a collection of such vectors. Matrix multiplication combines rows with columns; it is not elementwise multiplication. Before interpreting a result, check both its array dimensions and its physical units.

| Mathematical object | Dimensions | Meaning and NumPy counterpart |
|---|---|---|
| $y$ | $n\times1$ | Outcomes; commonly stored as shape `(n,)` |
| $\beta$ | $p\times1$ | Coefficients, including an intercept if present; shape `(p,)` |
| $X$ | $n\times p$ | Design matrix; one observation per row, one predictor per column |
| $X\beta$ | $n\times1$ | Conditional mean vector; `X @ beta` |
| $V$ | $p\times p$ | Coefficient covariance; `V[i, j]` relates coefficients $i$ and $j$ |
| $r_*$ | $p\times1$ | New predictor vector; scalar prediction is $r_*^T\beta$ |
| $I_p$ | $p\times p$ | Identity matrix; `np.eye(p)` |

Here $X$ is a fixed design matrix, whereas capital letters in [Appendix 1](01_probability.md#random-quantities-and-their-realised-values) denote random variables. Context determines which convention applies. For a line, the coefficient vector is $(\alpha,\beta_1)^T$; the chapter sometimes writes its slope simply as $\beta$. The subscript and vector notation prevent that scalar slope from being mistaken for the entire coefficient vector.

For waiting time in minutes and workload in jobs, the intercept has units of minutes and the slope has units of minutes per job. Multiplying a workload by the slope gives minutes, so the terms can be added. Covariance entries then have different units: intercept variance is squared minutes, slope variance is squared minutes per squared job, and their covariance is squared minutes per job. A covariance matrix is therefore more than an unlabelled square of numbers.

In NumPy, transposing a one-dimensional array does not make it a column: `beta.T` still has shape `(p,)`. Use `beta[:, None]` when a two-dimensional column is needed. Broadcasting can silently create a whole matrix from a column minus a one-dimensional vector. Printing shapes at a new calculation's boundaries is often more informative than inspecting a final scalar.

---

Source: `course/appendices/03_linear_algebra.md:29–42`

## Covariance, quadratic forms, and positive definiteness

For a random vector $B$ with mean $m$, define

$$V=E[(B-m)(B-m)^T].$$

Its diagonal contains variances and its off-diagonal entries contain covariances. Symmetry follows because exchanging the two factors in a scalar product changes nothing. For a linear combination $c^TB$,

$$E[c^TB]=c^Tm,\qquad
\operatorname{Var}(c^TB)=c^TVc.$$

The second expression is a quadratic form: expand it to see squared coefficients multiplying variances and paired coefficients multiplying covariances. Every variance is nonnegative, so a covariance matrix must be positive semidefinite. It is positive definite when every nonzero linear combination has strictly positive variance. Positive definiteness permits an inverse and an ordinary full-dimensional Normal density.

For two standardized variables with unit variances and correlation $\rho$, variance of their difference is $2-2\rho$. If someone proposes correlation 1.2, that variance becomes negative. This exposes an impossible covariance matrix without requiring an eigensolver. At correlation one, the difference has zero variance; the joint distribution lives on a line and is singular.

---

Source: `course/appendices/03_linear_algebra.md:44–55`

## Multivariate Normal density and precision

A $p$-dimensional Normal with mean $m$ and positive-definite covariance $V$ has density

$$p(b)=(2\pi)^{-p/2}|V|^{-1/2}
\exp\left\{-\frac12(b-m)^TV^{-1}(b-m)\right\}.$$

The determinant $|V|$ measures the scale of the covariance ellipsoid, while the quadratic form measures squared distance after accounting for scale and correlation. Ordinary Euclidean distance would count a one-unit deviation equally along a precisely known direction and a very uncertain direction. The covariance-adjusted distance does not.

The inverse covariance $Q=V^{-1}$ is called precision. In multiple dimensions, its diagonal generally is not the reciprocal of the corresponding marginal variance. Conditional relationships involve the off-diagonal entries too. The quadratic form is dimensionless: deviations, inverse covariance units, and deviations cancel. The density has reciprocal product units of the coordinates, as a joint density must.

A Cholesky factorisation writes $V=LL^T$ with a lower triangular $L$ and positive diagonal. If $z$ contains independent standard Normal draws, then $b=m+Lz$ has covariance $LL^T=V$. Conversely, solving $Lu=b-m$ gives a standardized vector with squared length equal to the density's quadratic form. The log determinant is $2\sum_j\log L_{jj}$, avoiding a potentially huge or tiny determinant before taking its logarithm.

---

Source: `course/appendices/03_linear_algebra.md:57–88`

## Worked example: conditioning a joint Normal

**Extended route.** Partition a jointly Normal vector into $A$ and $B$, with dimensions $r$ and $s$:

$$\begin{pmatrix}A\\B\end{pmatrix}
\sim\operatorname{Normal}\left[
\begin{pmatrix}m_A\\m_B\end{pmatrix},
\begin{pmatrix}V_{AA}&V_{AB}\\V_{BA}&V_{BB}\end{pmatrix}\right].$$

Assume the joint covariance is positive definite. Set $C=V_{AB}V_{BB}^{-1}$ and form the residual $E=A-m_A-C(B-m_B)$. Direct covariance multiplication gives

$$\operatorname{Cov}(E,B)=V_{AB}-CV_{BB}=0,$$

$$\operatorname{Var}(E)=V_{AA}-V_{AB}V_{BB}^{-1}V_{BA}.$$

Linear transformations preserve joint Normality, and uncorrelated jointly Normal vectors are independent. Thus observing $B=b$ changes the fitted component but leaves this residual distribution unchanged:

$$A\mid B=b\sim\operatorname{Normal}\left(
m_A+V_{AB}V_{BB}^{-1}(b-m_B),
V_{AA}-V_{AB}V_{BB}^{-1}V_{BA}\right).$$

The covariance expression is a Schur complement. Its dimensions are $r\times r$, and conditioning subtracts a positive-semidefinite matrix. The independence step is specifically Gaussian: zero covariance does not imply independence for arbitrary distributions.

For a numerical example, model two instruments' offsets in millimetres with means ten and twenty and covariance matrix

$$V=\begin{pmatrix}4&3\\3&9\end{pmatrix}.$$

Its determinant is 27, so it is positive definite. If the second offset is observed exactly as 23 millimetres, the first conditional mean is $10+(3/9)(23-20)=11$ millimetres and its conditional variance is $4-3^2/9=3$ squared millimetres. Correlation predicts the direction of the shift, while remaining variation prevents exact determination.

Observing the second offset with measurement error is a different conditioning problem. Independent measurement variance four adds to the bottom-right covariance entry, giving conditional mean $10+9/13$ and variance $4-9/13$ after the same reading. Less reliable information causes less updating. This is a small prototype of noisy Gaussian regression and Gaussian-process prediction.

**Check your understanding.** What happens when the cross-covariance is zero? Why is the numerical observation value absent from the conditional covariance in this fixed-covariance Gaussian model?

---

Source: `course/appendices/03_linear_algebra.md:90–102`

## Gaussian regression by square completion

Suppose $y\mid\beta\sim\operatorname{Normal}(X\beta,R)$, where the observation covariance $R$ is known and positive definite. Give the coefficients a proper prior $\beta\sim\operatorname{Normal}(m_0,V_0)$ with positive-definite covariance. Expanding the likelihood and prior quadratic forms and collecting coefficient terms gives

$$\log p(\beta\mid y)=-\frac12\beta^TQ_n\beta+h_n^T\beta+
\text{constant},$$

$$Q_n=V_0^{-1}+X^TR^{-1}X,\qquad
h_n=V_0^{-1}m_0+X^TR^{-1}y.$$

Completing the matrix square gives posterior covariance $V_n=Q_n^{-1}$ and mean $m_n=Q_n^{-1}h_n$. Each precision contribution has dimensions $p\times p$; the information vector has length $p$. For independent equal-variance observations, $R=\sigma^2I_n$, which yields the chapter's formula. For correlated readings, use their full covariance instead of counting them as independent sources of information.

These are conditional formulas when the observation variance is unknown. Averaging over its posterior uncertainty generally produces a mixture of Normals. Substituting one fitted variance does not perform that averaging and can misrepresent coefficient and predictive uncertainty.

---

Source: `course/appendices/03_linear_algebra.md:104–140`

## Worked example: correlated coefficients change prediction

Use dimensionless workloads zero, one, and two; outcomes two, three, and five minutes; known residual standard deviation one minute; and independent zero-mean coefficient priors with variance four in their appropriate squared units. The design matrix includes an intercept column. Then

$$Q_n=\begin{pmatrix}3.25&3\\3&5.25\end{pmatrix},\qquad
m_n=\frac1{129}\begin{pmatrix}216\\196\end{pmatrix},\qquad
V_n=\frac1{129}\begin{pmatrix}84&-48\\-48&52\end{pmatrix}.$$

Posterior intercept and slope means are approximately 1.674419 and 1.519380. Their negative covariance represents compensating changes: a higher intercept can partly offset a lower slope across the observed workloads.

At workload one, the fitted mean has posterior mean $412/129\approx3.193798$ minutes and variance

$$\operatorname{Var}(\alpha+\beta_1\mid y)
=\frac{84+52-96}{129}=\frac{40}{129}\approx0.310078.$$

Dropping covariance would instead give $136/129\approx1.054264$, more than three times as large. At workload three, beyond the observed range, mean uncertainty is $264/129\approx2.046512$. Extrapolation amplifies slope uncertainty. A new individual outcome adds residual variance one to either value; uncertainty about the fitted mean and variation around it answer different questions.

The following solves linear systems using Cholesky factors. The small covariance is computed for teaching and prediction; a large problem can calculate a requested quadratic form through a solve without materialising the full inverse. SciPy documents the factor-and-solve interface in [`cho_solve`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.cho_solve.html).

```python
import numpy as np
from scipy.linalg import cho_factor, cho_solve

x = np.array([0., 1., 2.])
X = np.column_stack([np.ones(x.size), x])
y = np.array([2., 3., 5.])
prior_precision = np.eye(2) / 4
Q = prior_precision + X.T @ X    # observation variance is one
factor = cho_factor(Q, lower=True)
mean = cho_solve(factor, X.T @ y)
covariance = cho_solve(factor, np.eye(2))
r = np.array([1., 1.])
mean_variance = r @ cho_solve(factor, r)
assert np.isclose(mean_variance, 40/129)
```

For several new rows collected in $X_*$, covariance of their fitted means is $X_*V_nX_*^T$. Add their conditional residual covariance to predict outcomes. Off-diagonal entries remain because future observations share the same uncertain coefficients. Simulate one joint coefficient draw per future batch, preserving its components together, then add the appropriate observation noise.

---

Source: `course/appendices/03_linear_algebra.md:142–152`

## Optional depth: singularity, scaling, and geometry

**Extended route.** Duplicated predictor columns make the likelihood unable to distinguish some coefficient combinations. A proper positive-definite Normal prior still makes the posterior precision positive definite, but mathematical invertibility does not mean the data identify each coefficient. Report which directions depend heavily on prior information. A singular covariance describes uncertainty confined to a subspace; it has no ordinary full-dimensional density of the displayed form.

Near-singularity makes small numerical or data perturbations potentially consequential. Inspect predictor scales, column dependence, and eigenvalues or condition numbers. A condition number depends on units, so use it as a computational diagnostic in a stated parameterisation. Blindly adding a diagonal constant changes the model and may hide the reason for instability. If a documented numerical adjustment is necessary, assess the results' sensitivity to its magnitude.

Centering a predictor can reduce intercept-slope dependence. If $x'=x-c$, the same line has intercept $\alpha'=\alpha+c\beta_1$ and unchanged slope. Its prior must also be transformed if the intent is to preserve beliefs; independently reassigning the old marginal priors defines another model. More generally, a nonsingular coordinate change $b=m+Lz$ scales volume by $|\det L|$. This is the multivariate Jacobian counterpart of [Appendix 2](02_calculus.md#transformations-preserve-probability-not-density-height).

Standardized coordinates can help numerical exploration, connecting to [Chapter 6, Warmup, geometry, and NUTS](../chapters/06_hmc.md#warmup-geometry-and-nuts) and [Chapter 9, Reparameterisation changes geometry](../chapters/09_hierarchical.md#reparameterisation-changes-geometry). Better coordinates aid computation; they do not create scientific information absent from the observations.

**Check your understanding.** Explain why independently shuffling posterior slope draws destroys predictions even though the slope histogram stays unchanged. Then derive the variance of an average of ten future outcomes at one fixed workload, separating shared coefficient uncertainty from independent residual noise.

---

Source: `course/appendices/04_numerics.md:1–1`

# Appendix 4 · Numerical stability, simulation, and reproducibility

---

Source: `course/appendices/04_numerics.md:3–7`

## How to use this bridge

A mathematically correct expression can still produce a misleading numerical answer. Products can underflow, arrays can align along unintended axes, and a simulation can return many dependent draws without estimating the desired quantity precisely. This appendix supplies practical habits for converting the course's probability statements into inspectable computations.

**Required bridge.** The log-weight and grid sections support [Chapter 0, Stable computation and a readiness check](../chapters/00_preparation.md#stable-computation-and-a-readiness-check) and [Chapter 2, Grid inference: densities become cell masses](../chapters/02_beta_binomial.md#grid-inference-densities-become-cell-masses). Simulation error supports [Chapter 5, Two uncertainties with different remedies](../chapters/05_monte_carlo.md#two-uncertainties-with-different-remedies). Read the reproducibility section before any lab. The final error-budget discussion is optional depth. Examples use the repository's pinned NumPy/SciPy environment; the code is short enough to inspect before running.

---

Source: `course/appendices/04_numerics.md:9–21`

## A notation crosswalk for computation

| Mathematical object | Numerical representation and interpretation |
|---|---|
| $\ell_j=\log q_j$ | Log unnormalised weight, which may be a log mass or log density |
| $w_j$ | Normalised discrete mass; nonnegative entries sum to one |
| $\Delta_j$ | Grid cell width, with the parameter's units |
| $S$ | Number of simulation draws, distinct from the observed sample size $n$ |
| $g(\theta^{(s)})$ | The quantity calculated from one draw; choose it before estimating MCSE |
| MCSE | Monte Carlo standard error, measured in the same units as the estimated expectation |
| ESS | Effective sample size for a particular estimate; definitions depend on sampling method |

Posterior standard deviation describes uncertainty under the model. MCSE describes error from estimating a posterior summary with finite simulation. Grid resolution and floating-point rounding introduce other approximation errors. Recording these separately prevents an increase in computer effort from being mistaken for an increase in real-world information.

---

Source: `course/appendices/04_numerics.md:23–53`

## Worked example: likelihoods that underflow

Floating-point numbers cover only a finite range. Imagine three hypotheses with equal prior weights and log likelihoods minus one thousand, minus one thousand and one, and minus one thousand and three. Their likelihood ratios are meaningful, but directly exponentiating these numbers in ordinary float64 arithmetic yields zeros. Dividing those zeros by their sum produces an invalid posterior.

Let $a=\max_j\ell_j$. Factoring out $e^a$ gives

$$\log\sum_j e^{\ell_j}
=a+\log\sum_j e^{\ell_j-a},\qquad
w_j=\exp\left(\ell_j-\operatorname{logsumexp}(\ell)\right).$$

At least one shifted exponent is zero, so its exponential is one. The normalisation calculation remains on a useful scale. For the example, the log normaliser is approximately minus 999.650988 and the posterior weights are approximately 0.705385, 0.259496, and 0.035119. Subtracting any common finite constant from the log weights leaves those probabilities unchanged. SciPy's [`logsumexp`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.special.logsumexp.html) implements the stable reduction.

```python
import numpy as np
from scipy.special import logsumexp

def normalise_log_weights(log_weights):
    values = np.asarray(log_weights, dtype=float)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("Expected a nonempty vector of log weights")
    if np.isnan(values).any() or np.isposinf(values).any():
        raise ValueError("NaN and positive infinity need investigation")
    if not np.isfinite(values).any():
        raise ValueError("No finite positive-mass candidate remains")
    return np.exp(values - logsumexp(values))

weights = normalise_log_weights([-1000., -1001., -1003.])
assert np.isclose(weights.sum(), 1.0)
```

Negative infinity legitimately represents zero mass, so the function accepts it alongside finite entries. An entirely negative-infinite vector cannot be normalised. Positive infinity may indicate an endpoint singularity in a density or an overflow; neither is a finite cell mass to normalise blindly. A NaN is an undefined computation, not evidence for zero probability. Replacing all such values with zero would erase information about the failure.

---

Source: `course/appendices/04_numerics.md:55–69`

## Evaluate log densities directly

Use a distribution's `logpdf` or `logpmf` instead of taking the logarithm of an already-underflowed density. For conditionally independent observations, add log likelihood contributions along the observation axis. Constants may be dropped when they are independent of the inferred parameter and only posterior shape is required. Keep them for normalised predictive densities and marginal likelihoods.

For example, a Normal log density is

$$\log p(y\mid\mu,\sigma)
=-\frac12\log(2\pi)-\log\sigma
-\frac12\left(\frac{y-\mu}{\sigma}\right)^2.$$

Standardising the residual makes its square dimensionless. The density still has inverse outcome units. Log-density values use a chosen numerical measurement unit; comparing models is meaningful only when they describe the same observations on a consistent scale. Changing minutes to seconds shifts the density normalisation even though matched event probabilities remain unchanged. [Appendix 2](02_calculus.md#transformations-preserve-probability-not-density-height) explains the corresponding Jacobian.

Stable links matter as well. For a Bernoulli observation with linear predictor $\eta$, evaluate the probability with `scipy.special.expit`. The log success probability is `-np.logaddexp(0, -eta)` and the log failure probability is `-np.logaddexp(0, eta)`. Choose the appropriate branch for the observed zero or one. At a predictor of one thousand, the success probability rounds to one, but the failure log probability remains about minus one thousand. Taking the log of one minus that rounded success probability would lose this information.

**Check your understanding.** Why is a negative-infinite log mass sometimes valid, while a vector containing only negative infinities is not a posterior? What separate problem remains if a stable calculation normalises a likelihood from the wrong model?

---

Source: `course/appendices/04_numerics.md:71–104`

## Worked example: a nonuniform grid and an exact reference

Approximate a Beta(4,7) density on the unit interval. Its exact mean is $4/11\approx0.363636364$. Construct cell edges by squaring equally spaced numbers, creating narrower cells near zero. If $q_j$ is the density at cell midpoint $\theta_j$, use

$$\log \widetilde w_j=\log q_j+\log\Delta_j,\qquad
E[\Theta]\approx\sum_j w_j\theta_j.$$

The width converts density into approximate cell mass. Normalising density heights alone gives each grid point equal geometric weight and overrepresents the region with more points. Refining that wrong rule does not repair its target.

```python
import numpy as np
from scipy import stats
from scipy.special import logsumexp

def grid_mean(cells):
    edges = np.linspace(0.0, 1.0, cells + 1) ** 2
    widths = np.diff(edges)
    midpoint = (edges[:-1] + edges[1:]) / 2
    log_mass = stats.beta.logpdf(midpoint, 4, 7) + np.log(widths)
    mass = np.exp(log_mass - logsumexp(log_mass))
    return midpoint @ mass

means = [grid_mean(cells) for cells in (8, 16, 32)]
```

| Cells | Mean using cell widths | Mean if widths are omitted |
|---:|---:|---:|
| 8 | 0.363745555 | 0.332862315 |
| 16 | 0.363637071 | 0.333202526 |
| 32 | 0.363636367 | 0.333300722 |

The correct result approaches the exact mean quickly in this smooth example. The incorrect calculation approaches a different value. Under this edge construction, point density is proportional to the inverse square root of the parameter, effectively tilting the beta density to a Beta(3.5,7), whose mean is one third.

An accurate mean alone does not establish accurate tail probabilities. A cell can straddle a decision threshold, and midpoint classification of the whole cell can distort a tail estimate. Refine near the threshold, split that cell, or integrate its contribution. Likewise, a grid limited to a convenient interval can miss substantial posterior mass outside it while still normalising perfectly within its truncated domain.

---

Source: `course/appendices/04_numerics.md:106–129`

## Independent simulation and Monte Carlo error

For independent draws from a target distribution and a finite-variance function $g$, the sample average estimates its expectation:

$$\widehat E[g]=\frac1S\sum_{s=1}^Sg(\theta^{(s)}),\qquad
\operatorname{Var}(\widehat E[g])=\frac{\operatorname{Var}(g(\Theta))}{S}.$$

Estimate MCSE by the sample standard deviation of the function values divided by the square root of the number of draws. These are the values of the function being averaged, not necessarily the raw parameter draws. For a tail probability the function is an indicator; for expected utility it is utility.

```python
import numpy as np
from scipy import stats

rng = np.random.default_rng(42017)
draws = rng.beta(4, 7, size=40_000)
estimate = draws.mean()
mcse = draws.std(ddof=1) / np.sqrt(draws.size)
tail_estimate = (draws > 0.5).mean()
exact_tail = stats.beta.sf(0.5, 4, 7)
```

In the checked pinned environment, the mean estimate is approximately 0.364587 with MCSE 0.000698. Its difference from the exact mean is about 1.36 MCSEs. The estimated tail probability is 0.174925, compared with the exact 0.171875. The posterior's own standard deviation is about 0.139; it does not shrink just because the computer generates more draws. Four times as many independent draws approximately halves MCSE, leaving the target distribution unchanged.

For MCMC, consecutive draws are dependent, so this independent-draw formula can be optimistic. Preserve chains and draw order for the diagnostics in [Chapter 6, Read agreement, efficiency, and precision separately](../chapters/06_hmc.md#read-agreement-efficiency-and-precision-separately). Use an appropriate ESS or direct MCSE estimator for the actual summary. Good numerical precision within one visited mode does not prove that a sampler found all modes.

---

Source: `course/appendices/04_numerics.md:131–149`

## Random streams and array axes carry assumptions

A pseudorandom generator has state; each call advances it. Recreating a generator with the same seed inside every loop restarts the same sequence. Such repeated output is not new independent simulation. Passing a generator explicitly makes ownership of that state visible.

For reproducible separate tasks, spawn child seed sequences and keep a stable mapping from task labels to children. NumPy's [parallel random-generation documentation](https://numpy.org/doc/stable/reference/random/parallel.html) describes spawning streams intended to be independent with very high probability. This is an algorithmic construction, not a proof of mathematical independence for every finite output.

```python
import numpy as np

children = np.random.SeedSequence(31029).spawn(4)
generators = [np.random.default_rng(child) for child in children]
# Independent toy draws, arranged like chain, draw, and group axes.
theta = np.stack([rng.beta(3, 2, size=(100, 3)) for rng in generators])
group_means = theta.mean(axis=(0, 1))
assert theta.shape == (4, 100, 3)
assert group_means.shape == (3,)
```

This layout imitates sampling output; it does not run four Markov chains or establish convergence. Averaging over the last axis would combine groups and answer another question. In a real hierarchical posterior, group components within one draw may be dependent and must stay together. For repeated future visits in the same new group, generate one group effect per posterior draw and share it across those visits. Independent residual draws then represent variation within that group.

---

Source: `course/appendices/04_numerics.md:151–159`

## What reproducibility can and cannot guarantee

A seed helps replay a random stream under a specified generator and execution pattern. It does not by itself guarantee identical results across package versions, hardware, compiler settings, numerical libraries, or changed sequences of calls. NumPy's [random compatibility policy](https://numpy.org/doc/stable/reference/random/compatibility.html) states the conditions and limitations of stream reproducibility. Adaptive samplers can follow different trajectories after small floating-point differences even when their resulting distributions agree to useful precision.

Keep enough context to reconstruct the analysis: data provenance and preprocessing, source code, dependency lock, root seed and child mapping, sampler configuration, retained draws or summaries, and the exact command used. A source or data SHA-256 hash identifies a particular byte sequence. It can reveal that today's inputs differ from those used for a saved output; it does not certify model correctness, provenance claims, or execution by itself.

There are several useful standards of reproduction. An identical-environment rerun may reproduce exact arrays. A different supported environment may reproduce summary statistics within declared numerical tolerances. An independent implementation may reproduce the inferential conclusion while using different random draws. State which standard a check addresses, and set tolerances from mathematical error or Monte Carlo precision rather than adjusting them to accept a preferred result.

For notebooks, start a fresh kernel and run cells in order. An output created before a model edit can look plausible while referring to a different analysis. The course's source scripts are the maintainable authority; regenerate derived notebooks and reports after source changes. Record failures and diagnostic warnings as part of the evidence instead of repeatedly changing seeds until an attractive run appears.

---

Source: `course/appendices/04_numerics.md:161–167`

## Optional depth: budget error for the question

**Extended route.** Suppose a probability estimate informs an action near a threshold. Reducing MCSE below the distance to that threshold may clarify the calculation under the chosen model, but uncertainty in costs or a plausible alternative likelihood can still change the action. Report these sensitivity changes separately from numerical error. [Chapter 12, Freeze, check, and examine sensitivity](../chapters/12_decisions.md#freeze-check-and-examine-sensitivity) puts those checks into the decision workflow.

Rare events need particular care. Zero occurrences among simulated draws does not establish zero probability, and the naive indicator-based MCSE estimate is then zero as well. Seek an analytic tail calculation, a justified rare-event method, or more informative simulation before claiming precision. Heavy-tailed functions may lack finite variance, invalidating the usual square-root error argument even when a finite run looks stable.

**Check your understanding.** For a reported posterior mean, name one check for arithmetic stability, one for Monte Carlo precision, one for model sensitivity, and one for input reproducibility. Explain why passing any one of those checks cannot substitute for the others.

---

Source: `course/capstone.md:1–3`

# Capstone · Should the service adopt design B?

Your task is to produce a reproducible Bayesian analysis and a decision memo for a fictional onboarding service. Use [experiment.csv](../data/experiment.csv) and its [data dictionary](../data/README.md). The data are synthetic, with randomised A/B assignments within eight centres. Do not use the generator's hidden parameters as evidence in your fit. You may inspect them after completing the analysis as an additional recovery check.

---

Source: `course/capstone.md:5–9`

## Decision and estimand

The next 10,000 visits will be equally distributed across the **eight existing centres**. An additional completion is worth 5 utility units. Adopting B costs 1,000 utility units; keeping A has zero incremental utility. Assume these values are fixed for the primary analysis, then vary the rollout cost.

Estimate $\Delta=\frac18\sum_j(\theta_{jB}-\theta_{jA})$ and the posterior distribution of **conditional expected incremental value** $V(\theta)=50000\Delta-1000$. This is the expected value of future outcomes conditional on the completion probabilities; its posterior uncertainty is not the predictive distribution of realised rollout consequences. State the assumptions required to transfer training completion probabilities to future visits. This target is an absolute probability difference, not an odds ratio. Clearly separate inference, prediction, and the choice of action.

---

Source: `course/capstone.md:11–15`

## Data contract

Each row is a centre-arm cell. `trials` and `successes` are training data. `holdout_trials` and `holdout_successes` describe an independently generated validation batch. Every success count must lie between zero and its trial count; every centre has both arms. Centre sizes differ, but the decision uses equal-centre weights.

Before revealing holdout outcomes, write your modelling and checking plan. For convenience both sets are in one local file; enforce the separation in your code. You may read the column names and planned holdout sizes when designing the analysis. Do not use holdout success counts to choose priors, tune models, or select the primary report. If you change the analysis after viewing them, disclose the change.

---

Source: `course/capstone.md:17–27`

## Required work

1. Define the observation unit, population, estimand, actions, utility and assignment assumptions. Validate data ranges and counts.
2. Fit a transparent baseline: pooled beta-binomial arm rates. Explain what pooling assumes and what population contrast its estimate represents.
3. Fit a model that represents centre differences: independent centre-arm beta models or a justified hierarchical binomial/logistic model. Explain the pooling tradeoff and predict for the stated existing-centre target.
4. Specify proper priors and simulate observable implications before using outcomes. Use at least three defensible prior settings in the sensitivity analysis. Do not select a prior by the desired decision.
5. Verify computation. For conjugate models, compare Monte Carlo summaries with analytic moments and record numerical error. For MCMC, report chains, draws, R-hat, bulk/tail ESS, relevant MCSE, divergences and relevant geometry diagnostics.
6. Perform at least one targeted posterior predictive check and explain its limitations. Compare the primary model with the pooled baseline. Report held-out predictive scores or intervals only after freezing the analysis.
7. Calculate posterior improvement, 90% interval, probability of positive improvement, probability of positive conditional expected incremental value, its posterior expectation, expected opportunity losses, and EVPI under the stated risk-neutral utility. Explain why EVPI is not the value of a particular trial or perfect foreknowledge of random future outcomes. A realised-outcome extension must specify future arm allocation, shared centre effects and any dependence before simulating counts; it is not required for the primary expected-value action.
8. Change prior assumptions, population weights, and rollout cost. Identify which changes would reverse the action and which merely alter its strength.
9. Write a decision memo and provide all code, software versions, seeds, data provenance, and generated results needed to reproduce it.

---

Source: `course/capstone.md:29–33`

## Deliverables and milestones

In week 7, submit a 300-word question and data plan. In week 9, submit the model equations, priors, and prior predictions. In week 10, submit the first fit and critique. In week 11, exchange a draft for review, including a reproducibility check. In week 12, submit a 1,500–2,500-word report, a maximum 250-word decision memo, and an executable notebook or script with no hidden manual steps.

Suggested report order: decision and target; data and assumptions; models and priors; computation; predictions and validation; decision and sensitivity; limitations; reproducibility. Figures must have captions, labelled axes, and units. Report useful precision rather than every available decimal.

---

Source: `course/capstone.md:35–46`

## Rubric, 100 marks

| Criterion | Marks | Full-credit evidence |
|---|---:|---|
| Question, target and data | 15 | Correct equal-centre estimand, data validation, stated future population and assignment assumptions |
| Models and priors | 20 | Two clear model specifications, proper priors, observable prior implications, justified pooling choice |
| Computational reliability | 15 | Independent analytic checks or appropriate sampler diagnostics, numerical error tied to the estimand |
| Criticism and validation | 20 | Targeted posterior checks, appropriate holdout use, comparison with limitations |
| Decision and sensitivity | 20 | Correct utilities and expected-value versus realised-outcome distinction, uncertainty propagation, opportunity loss/EVPI, meaningful scenario changes |
| Communication and reproducibility | 10 | Clear memo, honest limitations, runnable code, seeds and environment |

Partial credit: a correct computation with an unexplained modelling choice earns at most half the marks for that criterion. A credible diagnosis of a failed model can earn high criticism marks if supported by evidence. A report using the wrong target or leaked validation outcomes must be revised before course completion; a high overall numerical score does not override those flaws.

---

Source: `course/capstone.md:48–52`

## Extensions after the required work

Fit a hierarchical logistic model with centre intercepts and treatment effects. Investigate an unseen-centre target using group holdouts. Put a distribution on the value per completion. Estimate sample-information value for a fixed proposed additional sample. These are optional extensions, not prerequisites for a complete primary analysis.

The [reference solution](capstone_solution.md) and [Lab 12](../notebooks/12_capstone.ipynb) are available after your attempt. The reference chooses a simple exact model so every decision quantity is easy to audit.

---

Source: `course/cases/01_penguins.md:1–5`

# Case 01 — Predict body mass for a restricted penguin population

**Public learner brief · C01 · extended route.** Prerequisites: regression, model checking, robustness, and advanced approximation/observation-process bridges. Allow approximately four to six hours for an initial analysis and revision. This is an additional project, outside the 114 registered assessment items.

A field team has measured flipper length and bill dimensions and wants a prediction of body mass, with an interval for an individual adult. Build an analysis that could support that limited prediction. Do not infer that changing a penguin's flipper length would change its mass, or that a successful prediction transports to other species, life stages, locations or eras.

---

Source: `course/cases/01_penguins.md:7–11`

## Data and target

Use the genuine public [penguins.csv](../../data/penguins.csv). The byte-preserved table has 344 records with species, island, bill dimensions, flipper length, mass, recorded sex and study year. Missing values remain `NA`. Consult the [dictionary](../../data/README.md), [provenance](../../data/provenance.json) and [CC0 licence](../../data/PENGUINS_LICENSE.md). The data were collected by Kristen Gorman and Palmer Station LTER; the simplified table is distributed by Horst, Hill and Gorman's [palmerpenguins project](https://allisonhorst.github.io/palmerpenguins/).

Define your target as another measured adult resembling the sampled population, conditional on the measured predictors and their observed support. The table is observational. It does not establish a random population sample or independent nesting units. The simplified file contains no nest identifier; do not manufacture one from row order.

---

Source: `course/cases/01_penguins.md:13–19`

## Analysis protocol

Reserve 2009 for a final temporal check, and fit on 2007–2008. State exclusions by missing field and by row; counts by field may overlap. Fit predictor transformations on training data only. Use all three numerical predictors and an intercept, and explain whether species or sex is a predictor, a diagnostic grouping, or unused. Different eligibility rules imply different prediction populations.

Write a generative model and proper coefficient priors in explicit units. Compare a Gaussian residual model with a Student-t residual model. A small conditional analysis with fixed residual scale and degrees of freedom is acceptable if you disclose what uncertainty it omits. Prior prediction must examine impossible masses as well as central intervals. Specify a computational reference, diagnostics suitable for your inference method, and at least one posterior predictive discrepancy sensitive to residual structure.

Report individual-level held-out log density, RMSE in grams, and interval coverage/width. State whether your scores are marginal or joint. Vary a prior assumption and the missing-data eligibility rule. Keep model selection separate from claims about ecological mechanisms; explain why choosing a model after examining 2009 would require fresh validation.

---

Source: `course/cases/01_penguins.md:21–25`

## Deliverable

Submit a reproducible script or notebook, a table of results, a predictive figure, and a stakeholder memo of no more than 250 words. Identify one concrete model weakness and a justified next data collection or modelling step. Distinguish calculation accuracy from scientific adequacy.

After your attempt, compare the [worked report](01_penguins_solution.md), [reference script](../../labs/19_case_penguins.py), and [notebook](../../notebooks/19_case_penguins.ipynb). Those three resources and their generated results contain answers and are excluded from ordinary tutor retrieval. Reproduction is offline in the pinned environment.

---

Source: `course/cases/02_sensor_forecasting.md:1–5`

# Case 02 — Forecast a noisy sensor process

**Public learner brief · C02 · extended route.** Prerequisites: Normal conditioning, posterior prediction, dependent data, and numerical quadrature. Allow approximately four to six hours. This additional project is outside the 114 registered assessment items.

An operator needs forecasts for the next 24 equally spaced one-minute readings. Readings fluctuate around a nominal baseline of 10 instrument units. Sensor noise and changes in the underlying process are different uncertainty sources. Your task is to predict future observations, not simply reconstruct already observed values.

---

Source: `course/cases/02_sensor_forecasting.md:7–11`

## Data and question

The included [sensor_forecasting.csv](../../data/sensor_forecasting.csv) contains 120 **original synthetic** records. There are no real sensors, people or organisations behind these numbers. Columns are `time_index`, increasing from 0 to 119, and `reading`, in fictional instrument units. The [dictionary and provenance](../../data/README.md) document the observation units. The generator and its hidden parameters are protected review references: make your analysis plan before inspecting them.

Use times 0–95 for training and reserve 96–119 for a final forecast check from origin 95. Within training, compare horizons one and five at rolling origins 60–90. Do not randomly shuffle the series or estimate transformations from the future. Decide whether your target is a latent state, a future noisy reading, or both.

---

Source: `course/cases/02_sensor_forecasting.md:13–19`

## Analysis protocol

Fit a latent stationary AR(1) model with Gaussian observation noise. For a small reference analysis, treat the centre as 10, process variance as 0.16 and measurement variance as 0.09; infer persistence with a proper prior supported inside the stationary region. Treat the supplied scales as hypothetical calibration assumptions. Compare with an explicitly specified independent-reading baseline using the same centre and scales.

Check prior trajectories, including persistence, dispersion and plausible readings. Use the Kalman likelihood on a refined grid, or justify another numerical method. Independently verify a tiny fixed-parameter calculation and the zero-measurement-noise limit. Keep initial-state treatment explicit. Distinguish grid error, state uncertainty, innovation noise, sensor noise and uncertainty in persistence.

Evaluate training dynamics with posterior predictive trajectories. Report chronological forecast score, coverage and width; explain why multiple horizons from one origin are dependent. Vary both a persistence prior and fixed noise assumptions, reporting a concrete forecast consequence. Document whether the final holdout affected any modelling decision.

---

Source: `course/cases/02_sensor_forecasting.md:21–25`

## Deliverable

Provide a runnable analysis, a forecast plot distinguishing fitted history from held-out readings, a numerical verification table, and a stakeholder memo of at most 250 words. A useful conclusion may say that a model is inadequate or that calibration uncertainty prevents a deployment decision.

After an attempt, consult the [worked report](02_sensor_forecasting_solution.md), [reference script](../../labs/20_case_sensor_forecasting.py), and [notebook](../../notebooks/20_case_sensor_forecasting.ipynb). These answer-bearing resources, the generator and result artifacts must stay outside ordinary tutor retrieval. The entire reference run uses local data and the pinned environment.

---

Source: `course/cases/03_air_quality.md:1–13`

# Case 03 — Predict air quality at an omitted monitoring site

**Public learner brief · C03 · expansion draft pending human review.** Prerequisites:
A09 (including computational repair), L10/L11, A03 and A05. Plan 8–12 hours,
including 2–3 hours of temporal instruction below. Prerequisite study is extra.
This case adds no scorebook exercise or learner-state field.

How well can we predict an eligible daily PM2.5 measurement at an omitted
Beijing monitoring site, given its recorded wind and concurrent measurements
at ten other sites? Your target is **historical conditional prediction** in
2016. Smoothing may use later measurements from the other sites within that
year. It cannot support a future forecast, resident exposure estimate or
causal wind effect. State exactly what would be available at prediction time.

---

Source: `course/cases/03_air_quality.md:15–49`

## Data, units and access

Use the frozen offline `data/beijing_2016_daily.csv` when the custodian releases
it after the reference evaluation. For an unexposed learner analysis, use only
the training partition and the permitted weather/eligibility table until your
plan is frozen. A hash identifies a version; it does not prevent access.
If you have already seen final concentrations or reference scores, record that
exposure and call subsequent work development. Repeating this published case
does not create a new unseen evaluation.

The [official UCI dataset](https://archive.ics.uci.edu/dataset/501/beijing+multi+site+air+quality+data)
is *Beijing Multi-Site Air Quality*, Chen (2017), DOI
[10.24432/C5RK5G](https://doi.org/10.24432/C5RK5G). Air quality comes from the
Beijing Municipal Environmental Monitoring Center; weather from the China
Meteorological Administration is matched to the nearest weather station.
The hourly source spans March 2013–February 2017, twelve monitoring sites,
and records missing values as `NA`. The adaptation selects calendar 2016.
Credit and changes are in the [CC BY 4.0 notice](../../data/licenses/beijing_CC_BY_4.md).
No endorsement is implied.

The complete daily grid has 366 dates × 12 sites. Each row retains `station`,
`date`, `n_hours`, `n_pm25`, `n_wspm`, `n_pair`, `pm25_ug_m3`, `wspm_m_s`,
`eligible_18`, `eligible_24`, and `split`. `n_pair` counts hours with both
measurements; both means use precisely those paired hours. Concentration is
in µg/m³ and wind in m/s. Base eligibility requires at least 18 paired hours;
the sensitivity requires all 24. Preserve all dates and ineligible rows.
Use the source calendar; a timezone conversion has not been established.

These means summarize available measurements, not an error-free full day's
exposure. Completeness can depend on weather or pollution; a complete-case
analysis is not a missing-data correction. Weather matching can induce shared
measurement error. Do not infer coordinates or adjacency from station names.
Check uniqueness, support, counts and missingness before a log transform.
Zero is an observed concentration, not missingness: never drop it or add an
unreported offset to fit a log model.

---

Source: `course/cases/03_air_quality.md:51–82`

## C03.T1 — Distinguish four kinds of uncertainty

Let $z_{jt}=\log(c_{jt}/c_{\rm ref})$, with $c_{\rm ref}=1\,\mu\mathrm{g/m^3}$.
A proposed observation model is

$$z_{jt}=\alpha+\beta x_{jt}+\gamma_s S_t+\gamma_c C_t
          +b_{0j}+b_{1j}x_{jt}+u_t+\epsilon_{jt},\qquad
\epsilon_{jt}\sim N(0,\sigma_y^2).$$

Standardize wind using only eligible base-training rows, with population SD.
Reuse those constants in every comparison. Center annual sine and cosine
over all 366 calendar days, not over the available observations. Compare a
pooled model with $b_j=0$ to a hierarchy $b_j\sim N_2(0,\Sigma)$ with
learned intercept/slope covariance.

The shared process is

$$u_0\sim N\!\left(0,\frac{\sigma_u^2}{1-\phi^2}\right),\qquad
u_t\mid u_{t-1}\sim N(\phi u_{t-1},\sigma_u^2),\quad -1<\phi<1.$$

Initial-state uncertainty is the distribution of $u_0$; state uncertainty
remains after observing noisy training measurements; parameter uncertainty
concerns $\phi,\sigma_u,\sigma_y$ and the regression/hierarchy; observation
uncertainty adds a new residual. At an omitted site, integrate a new station
effect as well. These sources must reach prediction, even if states are
analytically marginalized during fitting. Drawing one independent station
effect every day loses within-site dependence. Trajectories need one effect
vector per site and one shared state path per posterior draw.

Checkpoint: draw a diagram showing which quantities are shared across two
sites on one day and across two days at one site. Explain which uncertainty
disappears if you predict the latent state rather than a new measurement.

---

Source: `course/cases/03_air_quality.md:84–124`

## C03.T2 — Learn and check a bounded temporal model

Estimate persistence, innovation SD and residual SD. One convenient stationary
parameterization sets $a_u=\sigma_u/\sqrt{1-\phi^2}$, so

$$u_0\sim N(0,a_u^2),\qquad \sigma_u=a_u\sqrt{1-\phi^2}.$$

A prior on $a_u$ induces a prior on innovation SD; it is not an independent
prior on $\sigma_u$. Record which you use. The latent process has zero
population mean, with no extra free level or trend. Proper priors do not make
its realized path orthogonal to the intercept or annual pair. Inspect their
posterior dependence and vary persistence, state amplitude and seasonal
priors using training data. Interpret a poorly identified decomposition with
care. Stationarity is an assumption to criticize, not a proof of adequacy.

For a day with $n_t$ residual observations, let $\bar r_t$ and $SS_t$
be their mean and within-day sum of squares, and write $R=\sigma_y^2$.
Conditional on the state, the exact likelihood contribution can be factored as

$$N(\bar r_t\mid u_t,R/n_t)
\exp\!\left[-\frac{n_t-1}{2}\log(2\pi R)
-\frac12\log n_t-\frac{SS_t}{2R}\right].$$

Retain the second factor when learning residual scale. For no observations,
perform a state transition and no observation update. Start from the stationary
variance. A Kalman filter integrates the Gaussian states; a smoother conditions
on the full training year; conditional forward-filter/backward-sampling (FFBS)
recovers joint paths. Never substitute a smoothed point path as observed data.

Before real fits, compare a tiny normalized dense Gaussian likelihood with the
filter, including gaps, repeated observations per day, $\phi=0$, very small
process noise and an intentionally wrong initial variance. Then integrate a
tiny unknown-scale posterior over a stated bounded domain with refined
independent quadrature and compare actual sampler estimands within MCSE.
Agreement at one fixed parameter vector cannot certify posterior integration.

Use prior trajectories and multiplicative effects to inspect assumptions.
After fitting, check stationwise residual autocorrelation using adjacent
calendar days, dispersion and skewness against replicated training data.
Keep diagnostics distinct: R-hat, ESS, divergences, tree depth and MCSE assess
numerical evidence; posterior predictive discrepancies assess the model.

---

Source: `course/cases/03_air_quality.md:126–180`

### Worked synthetic bridge: from a filter to learned scales

The following small calculation uses invented, dimensionless residuals, with
known regression mean zero. It is separate from Beijing and from the protected
reference solution. On day 0 observe residuals 0 and 1; day 1 is entirely
missing; on day 2 observe 0.5. We will learn three parameters
$\theta=(\phi,\sigma_u,\sigma_y)$ and predict a new measurement on day 3.
There are no station effects in this fixture. Start with A05's Gaussian
conditioning and L04's normalized posterior; the steps below connect them.

**First retain the whole likelihood.** For observations $r_1,\ldots,r_n$ on
one day, expand the quadratic as

$$\sum_i(r_i-u)^2=SS+n(\bar r-u)^2.$$

Thus the product of $n$ normal densities is
$(2\pi R)^{-n/2}\exp[-SS/(2R)-n(\bar r-u)^2/(2R)]$.
Dividing this expression by the normal density of $\bar r$, whose variance
is $R/n$, gives exactly the second factor above. The factor includes
$n^{-1/2}$, not $n^{1/2}$. Dropping $SS/(2R)$ would throw away the difference
between the two day-0 measurements, which is evidence about residual noise.
For $n=1$ the extra factor is one. For $n=0$ neither factor is evaluated.
Our daily sufficient statistics are $(n,\bar r,SS)=(2,.5,.5)$, no observations,
and $(1,.5,0)$.

**Next work one parameter component.** Set
$(\phi,\sigma_u,\sigma_y)=(.5,.5,.5)$ temporarily, so $Q=R=.25$.
Initialize the day-0 state with mean zero and variance $P_0^-=Q/(1-\phi^2)=1/3$.
For a nonempty day, let $S_t=P_t^-+R/n_t$ and $K_t=P_t^-/S_t$.
Add $\log N(\bar r_t\mid m_t^-,S_t)$ and the retained within-day log factor
to the log likelihood. Then update

$$m_t=m_t^-+K_t(\bar r_t-m_t^-),\qquad P_t=(1-K_t)P_t^-.$$

Propagate every subsequent calendar day with
$m_{t+1}^-=\phi m_t$ and $P_{t+1}^-=\phi^2P_t+Q$.
Here $K_0=8/11$, giving $m_0=4/11$ and $P_0=1/11$.
Day 1 has no update: its mean is $2/11$ and variance $3/11$.
Propagating again to day 2 gives mean $1/11$, variance $7/22$;
the day-2 gain is $14/25$, and the updated mean and variance are **0.32 and
0.14**. Skipping the missing date would give the wrong transition and
covariance. Equivalently, a two-day transition has coefficient $\phi^2$
and innovation variance $Q(1+\phi^2)$. The component log likelihood, including
all constants, is **−3.157505826**. The day-3 measurement distribution for
this component is $N(.16,.535)$; .535 includes new observation noise.

**Now learn the parameters instead of fixing them.** For an exact, small
example, assign independent equal prior mass to $\phi\in\{0,.5\}$,
$\sigma_u\in\{.5,1\}$ and $\sigma_y\in\{.5,1\}$. This is a stated finite
prior with eight equally likely atoms, not an approximation to the Beijing
prior. Run the same filter at each atom. If its log likelihood is $\ell_k$,
then

$$\log Z=\operatorname{logsumexp}_k(\ell_k-\log8),\qquad
w_k=\exp(\ell_k-\log8-\log Z).$$

---

Source: `course/cases/03_air_quality.md:182–232`

| $(\phi,\sigma_u,\sigma_y)$ | Log likelihood | Posterior probability |
|---|---:|---:|
| $(0,.5,.5)$ | −3.156587 | .198756 |
| $(0,.5,1)$ | −3.587787 | .129137 |
| $(0,1,.5)$ | −3.791816 | .105304 |
| $(0,1,1)$ | −4.048529 | .081462 |
| $(.5,.5,.5)$ | −3.157506 | .198573 |
| $(.5,.5,1)$ | −3.629350 | .123880 |
| $(.5,1,.5)$ | −3.939068 | .090885 |
| $(.5,1,1)$ | −4.171947 | .072004 |

The probabilities sum to one before rounding and $\log Z=-3.620349415$.
They differ from the prior probabilities 1/8: the data have updated
persistence and both scales. None of these components alone represents the
posterior. The [synthetic calculation](../../scripts/temporal_teaching.py)
reproduces this table using the independent dense covariance

$$\operatorname{Cov}(r_i,r_j\mid\theta)=
\frac{Q}{1-\phi^2}\phi^{|t_i-t_j|}+R\,\mathbf1\{i=j\}.$$

Repeated measurements on day 0 share a state but have distinct residuals.
Comparing this normalized three-observation density with the filter tests the
within-day factor, initial variance and missing-day transition together.

**Integrate parameter uncertainty into prediction.** If component $k$ gives
day-3 measurement mean $a_k$ and variance $v_k$, the predictive distribution
is $\sum_kw_kN(a_k,v_k)$. Draw one parameter atom from $w$, then a state/path
conditional on that atom and the data, then new observation noise. Do not
plug posterior mean parameters into a single filter. In this bounded,
Gaussian teaching model the predictive mean is **0.073039837** and

$$\operatorname{Var}(r_3\mid r)=
\underbrace{\sum_kw_kv_k}_{1.096467561}
+\underbrace{\sum_kw_k(a_k-\bar a)^2}_{.006708116}
=1.103175678.$$

These dimensionless residual moments exist in this finite example. They do
not establish physical concentration moments for the unbounded scale mixtures
in C03.T3. For a predictive quantile, invert the weighted sum of component
CDFs; averaging the component quantiles is not the required operation.

**Move to continuous scales with a bounded reference.** As a separate model,
use independent normalized uniforms on $\phi\in[-.2,.8]$,
$\sigma_u\in[.3,1.2]$, $\sigma_y\in[.4,1.1]$.
The posterior density is $p(\theta\mid r)=L(r\mid\theta)p(\theta)/Z$, where
$Z$ is the three-dimensional integral of the numerator. Map Gauss–Legendre
nodes from $[-1,1]$ into each interval. For each axis the transformation
Jacobian times its uniform density gives quadrature weights $w_i/2$.
Multiply the three axis weights by the likelihood and normalize using
log-sum-exp. Omitting the weights, or placing a uniform prior on log SD
without its Jacobian, computes a different posterior.

---

Source: `course/cases/03_air_quality.md:234–260`

The script computes quadrature orders 12, 24 and 40 per axis. At order 40,
$\log Z=-3.607293025$, the day-3 mean is **0.086354994**, and variance is
**1.125938004**. Order 12 to 24 changes these by less than $5\times10^{-12}$;
24 to 40 changes them by less than $2\times10^{-15}$ here. Refinement is an
error check for this smooth, bounded fixture, not a universal guarantee.
A sampler targeting this same bounded model can be compared with these
posterior estimands using predeclared MCSE tolerances. This validates a small
unknown-scale integration problem; it does not certify the larger hierarchy.

**Recover states jointly.** Filtering on day 1 used only day 0; smoothing
also uses day 2. At the fixed component above, smoothed day-1 mean/variance
are **.28 and .24**, different from $2/11$ and $3/11$.
For FFBS, first draw $u_2\sim N(m_2,P_2)$, then step backward with

$$J_t=\frac{P_t\phi}{P_{t+1}^-},\qquad
u_t\mid u_{t+1},r_{0:t},\theta\sim
N\left(m_t+J_t(u_{t+1}-m_{t+1}^-),\ P_t-J_t^2P_{t+1}^-\right).$$

The draw of $u_{t+1}$ is shared with the previous step. For this component,
$\operatorname{Cov}(u_1,u_2\mid r)=.06$; independently drawing each smoothed
marginal would incorrectly make that covariance zero. With learned parameters,
choose one posterior parameter draw and use it for the entire path, then
propagate to day 3 and add residual noise. For C03's omitted sites, the
additional station-effect vector is also shared across that site's days.
These Gaussian recursions are developed further in Särkkä and Svensson's
[Bayesian Filtering and Smoothing](https://users.aalto.fi/~ssarkka/pub/bfs_book_2023_online.pdf),
particularly its linear filtering, smoothing and parameter-estimation chapters.

---

Source: `course/cases/03_air_quality.md:262–285`

### Scaffolded checkpoint with changed givens

In a new synthetic panel observe residuals **−.2 and .6 on day 0**, no data
on day 1, and **.8 on day 2**. Retain the eight-atom prior above. Work in a
blank script before consulting the numerical helper.

1. Construct the three daily counts, means and within-day sums of squares.
   Explain which factor of the likelihood is lost if you retain means alone.
2. At $(.5,.5,.5)$, initialize with the stationary variance, update day 0,
   propagate through the empty day and update day 2. Record each mean and
   variance; variances must remain nonnegative.
3. Repeat the log-likelihood calculation at all eight atoms. Normalize the
   probabilities, then check them against a separately constructed dense
   three-observation Gaussian density. State the tolerance before comparing.
4. Form the day-3 mixture CDF and its median. Keep the parameter atom fixed
   within each simulated path. Compare the resulting day-1/day-2 covariance
   with the covariance obtained by independently drawing smoothed marginals.
5. Replace the finite prior with the stated continuous bounded prior. Compare
   orders 12/24/40 before using it as a sampler reference. Explain why neither
   this exercise nor a fixed-parameter match establishes Beijing adequacy.

Use the operations above to complete starter steps 3–4. If Gaussian
conditioning, log-sum-exp or array axes are unfamiliar, return to A05, L04
and APP04 first. These checkpoints have no scorebook IDs or mastery updates.

---

Source: `course/cases/03_air_quality.md:287–328`

## C03.T3 — Protect the final sites and define the scores

The two sites selected by a hash of identifiers are **Dongsi and Guanyuan**.
Keep them fixed. Their weather and eligibility flags are permitted; their
concentrations cannot update transformations, priors, states or models. Develop
with the other ten sites; any model selection by validation stays inside them.

Before either final site's outcomes or scores are inspected, freeze all four
comparisons: pooled base, hierarchical base, hierarchical covariance-prior
alternative and hierarchical completeness alternative. Freeze numerical priors,
transforms, seeds, sampler, eligibility, metrics and failure rules as well.
Seal every candidate's predictions before the single final comparison. Keep
unfavourable results. Any subsequent score-informed repair is development and
requires fresh outer validation for a new performance claim.

Use **posterior predictive mixture medians**, equal-tailed 90% marginal
predictive intervals and marginal log predictive densities in numerical µg/m³.
For component log means $m_r$ and variances $v_r$, solve

$$\frac1M\sum_r\Phi\!\left(\frac{q_p-m_r}{\sqrt{v_r}}\right)=p,
\qquad c_p=c_{\rm ref}\exp(q_p),\quad p\in\{.05,.5,.95\}.$$

Neither exponentiating the average log concentration nor averaging component
medians gives the mixture median. Unbounded scale priors can produce infinite
physical mixture moments even when every conditional lognormal has finite
moments. Finite simulated averages do not establish existence of a mean.
Report empirical MAE and RMSE **of the predictive median** on the finite test
set. They do not establish finite posterior expected loss or Bayes optimality.

Report native eligible rows site by site, then all four models on the identical
common station/date intersection. Include all denominators, interval widths,
coverage and numerical precision. Marginal intervals are not simultaneous
trajectory bands; sums of marginal log scores are not a joint trajectory
density. Days share states and sites share fitted parameters. Do not report
independent-day standard errors or infer a population of sites from two cases.
Numerical MCSE is separate from predictive uncertainty and external validity.

An eligible nonpositive outcome is a model-support failure; unexpected missing
eligible input is an integrity failure. Preserve the row and mark unavailable
aggregates explicitly. Failed sampler or prescore precision checks keep the
outcomes sealed. Failed observed-score precision must be reported without
score-informed refitting.

---

Source: `course/cases/03_air_quality.md:330–358`

## Deliverable and anchored rubric

Start from the [answer-free worksheet](03_air_quality_starter.md) and a blank
script. Submit your frozen plan, runnable analysis, independent fixture,
diagnosis/repair ledger, prior and posterior checks, all four comparisons,
an accessible figure, exposure/assistance log, and a memo of at most 250 words.
The reference budget target is 5–20 minutes for a fit and at most 60 minutes
for all four, including cold setup, diagnostics and scoring; RAM ≤2 GB and
retained evidence ≤100 MB, excluding raw archive/environment. Measure these
costs. Targets are not observations and do not justify fewer chains or draws.

Use the capstone dimensions below. Within each, 0 means absent or invalid;
1 means a consequential omission; 2 meets the stated evidence anchor; 3 adds
a justified sensitivity or independently checked consequence. Multiply the
dimension's weight by level/3. These are case review anchors, not new exercises.

| Dimension | Weight | Level 2 anchor | Level 3 anchor |
|---|---:|---|---|
| Question, target and data | 15 | States historical omitted-site target, units, eligibility and support audit | Explains how weather availability and paired missingness limit transfer |
| Models and priors | 20 | Same temporal structure in both models; proper initial law and meaningful priors | Checks concentration implications and seasonal/state competition |
| Computational reliability | 15 | Independent normalized fixture, four-chain diagnostics and estimand MCSE | Unknown-scale integration and documented diagnosis/intervention/recheck |
| Criticism and validation | 20 | Training temporal PPC and one sealed grouped final comparison | Interprets failures and all native/common sitewise results without selective reporting |
| Decision and sensitivity | 20 | Reports covariance-prior and completeness alternatives | Separates changed population from model sensitivity and limits any operational recommendation |
| Communication and reproducibility | 10 | Runnable offline code, hashes, costs, accessible figure and qualified memo | Clear exposure chronology and honest uncertainty/failure account |

A wrong target, leaked evaluation treated as unseen, or unsupported computation
requires revision regardless of the total. A well-supported diagnosis of an
inadequate model can earn high criticism marks. Numerical success alone cannot
establish environmental adequacy or authorize deployment.

---

Source: `course/cases/03_air_quality_starter.md:1–5`

# Case 03 — Answer-free analysis worksheet

**C03.starter · learner material.** Read the [brief](03_air_quality.md), complete
its prerequisites, and begin in a blank script before opening reference assets.
This worksheet contains no fitted results or preferred model conclusion.

---

Source: `course/cases/03_air_quality_starter.md:7–14`

## 1. Record the target and exposure

Write one sentence naming the unit predicted, reference year, information
available and population to which you will generalize. List what your answer
cannot establish. Record any prior access to final concentrations, reference
code, figures or scores, with date and assistance received. If exposed, label
this attempt development; do not manufacture a fresh holdout by hiding rows
you have already seen.

---

Source: `course/cases/03_air_quality_starter.md:16–23`

## 2. Audit only authorized data

Record archive/derived hashes and attribution. Confirm site/date uniqueness and
the 366-day grid. Explain `n_pair`, paired-hour means, concentration/wind units,
`NA`, observed zeros, the 18-hour rule and 24-hour alternative. Tabulate missing
and ineligible training rows by site/month. Determine whether the proposed
likelihood supports every eligible training outcome. Do not access Dongsi or
Guanyuan concentrations. Keep transformations restricted to base-training rows.

---

Source: `course/cases/03_air_quality_starter.md:25–35`

## 3. Explain the temporal model before fitting

First complete the brief’s [worked synthetic bridge and changed-givens checkpoint](03_air_quality.md#worked-synthetic-bridge-from-a-filter-to-learned-scales). Its finite-prior normalization and continuous bounded quadrature prepare the independent checks in step 4. Then draw the C03.T1 uncertainty diagram. Derive stationary initial variance and the
transition variance after a missing day. Describe the difference between a
filter, smoother and joint state-path simulation. Explain how you will retain
one station effect across dates and one shared day process across sites.

Specify regression, annual pair, station covariance, state and residual priors.
Which scales have independent priors? Which are induced? Show prior implications
on log and physical scales without assuming physical mixture moments exist.
Explain why zero-mean priors do not imply realized sample orthogonality.

---

Source: `course/cases/03_air_quality_starter.md:37–43`

## 4. Verify computation independently

Build a small dense Gaussian fixture with missing calendar observations. Include
all normalizers and initial-state uncertainty. Compare likelihood, conditional
state moments and gradients. Create a separate bounded unknown-scale integration
reference and specify refinement and MCSE tolerances before running the sampler.
State which model this fixture can and cannot validate.

---

Source: `course/cases/03_air_quality_starter.md:45–52`

## 5. Develop on training sites

Use four chains, 1,000 warmup and 1,000 retained draws for the initial benchmark.
Record settings, seed, versions, hardware, time scopes, peak RAM and retained
bytes. Preserve every failed attempt. Write a ledger with observation, diagnosis,
intervention, changed assumptions and reevaluation. Check stationwise temporal
dependence, dispersion and skewness. Inspect intercept/season/state confounding
and training-only persistence, amplitude and seasonal-prior sensitivity.

---

Source: `course/cases/03_air_quality_starter.md:54–70`

## 6. Freeze every final comparison

Complete this table before outcome access; fill all blank specifications in
your own plan and hash the result.

| Role | Eligibility | Station effects | Numeric prior/specification | Seed | Diagnostic/precision status |
|---|---|---|---|---|---|
| Pooled base | ≥18 paired hours | None | To specify | To specify | To measure |
| Hierarchical base | ≥18 paired hours | Correlated intercept/slope | To specify | To specify | To measure |
| Covariance alternative | ≥18 paired hours | Same hierarchy | Change covariance prior only | To specify | To measure |
| Completeness alternative | 24 paired hours | Same hierarchy | Same base priors/transforms | To specify | To measure |

Declare mixture-median prediction, .05/.95 quantiles, empirical MAE/RMSE of
that median, marginal log density, coverage and width. Specify numerical units,
CDF inversion, MCSE rules, native/common row sets and failure policy. Protect
all final outcomes until every model and predictive distribution is sealed.
If any required prescore gate fails, record the reason and keep them sealed.

---

Source: `course/cases/03_air_quality_starter.md:72–82`

## 7. Evaluate once and communicate

Record the first outcome-access time and all prediction hashes. Show every
frozen model for each final site, native and common denominators, and paired
differences on identical keys. Distinguish predictive spread, numerical error,
model uncertainty and uncertainty about transport to other sites. Explain why
days are dependent and why two sites cannot certify general calibration.

Use the brief's rubric to review the memo and evidence. Identify your strongest
remaining limitation and what genuinely new validation would be needed for
a revised model. Keep reference access and assistance in the final record.

---

Source: `course/practice/diagnostic.md:1–9`

# Diagnostic practice: choose the next useful repair

These twelve short probes support learning; they are not new assessments, admission tests or mastery rules. Use only clusters whose prerequisites you have studied (or can demonstrate from prior experience). Before preparation, use the five unscored readiness prompts in [Preparation](../chapters/00_preparation.md#stable-computation-and-a-readiness-check); later probes are not a baseline measure of whole-course knowledge. An unfamiliar topic is a reason to defer, not a failed learner.

Try one probe with its repair covered. Write your reasoning, units and confidence. If you are stuck, follow **error → existing explanation → worked operation → fresh retest**. An instructor or tutor should describe the observed reasoning, identify the first consequential error, help repair it and then ask the fresh check. Record help honestly; a correct answer after seeing a repair is assisted practice. Revisit a fresh problem before claiming independence.

The answered repair blocks are public self-study references, visibly labelled below. They are excluded from ordinary tutor retrieval and the learner upload by the existing `tutor-reference` boundaries. Ask explicitly to consult a repair after attempting its probe. These boundaries control tutoring, not secrecy: no production assessment keys or unreleased transfer forms appear here. Fresh retest prompts remain available without the answers. The scheduling sidecar is `evaluation/practice_map.json`; no scores or learner-state fields are added.

To see a practice repair, open its labelled reference in this source or the self-study site/PDF when published. The existing tutor solution API has no diagnostic or retrieval-card IDs; a tutor should direct you to the reference and record assistance, not invent a solution call or treat a viewed repair as independent work.

---

Source: `course/practice/diagnostic.md:11–13`

## Conditioning and reference populations

Prerequisites: L00 for the table operation; L01 for transfer of evidence. Allow 6–10 minutes per probe including a repair.

---

Source: `course/practice/diagnostic.md:15–17`

### Diagnostic 01

In an original fictional inspection table, 12 damaged parcels trigger an alert and 8 do not; 18 intact parcels trigger an alert and 162 do not. Among alerted parcels, what fraction are damaged? A colleague divides 12 by 20. State what that calculation answers.

---

Source: `course/practice/diagnostic.md:25–25`

**Fresh retest:** a different inspection has 6 alerted damaged parcels, 4 nonalerted damaged parcels and 24 alerted intact parcels. Find damage given alert and explain why the nonalerted count is absent from its denominator.

---

Source: `course/practice/diagnostic.md:27–29`

### Diagnostic 02

Two sites share P(alert | fault)=0.8 and P(alert | no fault)=0.1. Fault prevalence is 0.05 at site East and 0.25 at site West. Can P(fault | alert) be transported unchanged? Explain before calculating.

---

Source: `course/practice/diagnostic.md:37–37`

**Fresh retest:** compute fault given alert at a third site with prevalence 0.10. Name one assumption you would investigate before reusing either conditional alert rate.

---

Source: `course/practice/diagnostic.md:39–41`

## Density, probability and units

Prerequisites: L00 and the probability bridge for Diagnostic 03; L04 for Diagnostic 04.

---

Source: `course/practice/diagnostic.md:43–45`

### Diagnostic 03

A continuous waiting time is uniform between 0 and 0.25 hours. Its density is 4 per hour. Is that invalid because four exceeds one? Give the probability of a wait shorter than 0.10 hours and distinguish a point from an interval.

---

Source: `course/practice/diagnostic.md:53–53`

**Fresh retest:** under the same model, find P(0.15 < wait < 0.20 hours). Explain how your calculation has no units even though the density does.

---

Source: `course/practice/diagnostic.md:55–57`

### Diagnostic 04

An incident rate is Gamma(shape 3, **rate** 2 hours), so its mean is 1.5 incidents/hour. You express incidents per minute. What happens to the random rate and to the Gamma rate parameter? A proposed conversion divides both by 60.

---

Source: `course/practice/diagnostic.md:65–65`

**Fresh retest:** convert Gamma(shape 4, rate 3 hours) to incidents/minute, then find the expected count during 30 minutes. State the shape/rate convention.

---

Source: `course/practice/diagnostic.md:67–69`

## Expectation, variance and shared uncertainty

Prerequisites: L00 and APP01 for Diagnostic 05; L03 for Diagnostic 06.

---

Source: `course/practice/diagnostic.md:71–73`

### Diagnostic 05

Two equally likely machine regimes have conditional means 2 and 8 units and conditional variance 1 unit squared each. A learner reports overall mean 5 and variance 1. Which missing component matters?

---

Source: `course/practice/diagnostic.md:81–81`

**Fresh retest:** two equally likely regimes have means 1 and 5 and conditional variances 4 each. Find the marginal mean and variance; label both sources of variation.

---

Source: `course/practice/diagnostic.md:83–85`

### Diagnostic 06

One shared unknown success probability has posterior Beta(3,2). You predict a pair of deliveries. Compare drawing one probability for the pair with drawing a fresh independent probability for each delivery. Which preserves the stated model?

---

Source: `course/practice/diagnostic.md:93–93`

**Fresh retest:** repeat for a shared Beta(2,2) probability and explain why matching each delivery's marginal success probability does not validate the joint prediction.

---

Source: `course/practice/diagnostic.md:95–97`

## Array axes and numerical error

Prerequisites: L00 and APP04 for Diagnostic 07; L05 for Diagnostic 08.

---

Source: `course/practice/diagnostic.md:99–101`

### Diagnostic 07

A predictive array has shape `(4, 500, 6)`: chains, draws and six future deliveries. State the shape after summing over deliveries and the operation that estimates the mean batch count. Why is summing all axes wrong?

---

Source: `course/practice/diagnostic.md:109–109`

**Fresh retest:** a `(3,800,10)` array contains delays for ten visits in each predictive replicate. Produce the shape and operation for the average delay per ten-visit group, retaining chain and draw axes.

---

Source: `course/practice/diagnostic.md:111–113`

### Diagnostic 08

An estimand has posterior standard deviation 6 minutes and effective sample size 900. Approximate its mean's Monte Carlo standard error. Would quadrupling effective sample size make the posterior standard deviation three minutes?

---

Source: `course/practice/diagnostic.md:121–121`

**Fresh retest:** posterior SD is 2 and ESS 400. What is the approximate MCSE, and what ESS would halve it? Give one reason this calculation alone cannot certify a sampler.

---

Source: `course/practice/diagnostic.md:123–125`

## Prior, likelihood and prediction

Prerequisites: L02 for Diagnostic 09; L03 for Diagnostic 10.

---

Source: `course/practice/diagnostic.md:127–129`

### Diagnostic 09

A fictional label scanner has prior Beta(4,3). Independent exchangeable checks give 7 successes and 2 failures. A learner proposes Beta(13,12) because nine checks were observed. Identify the likelihood powers before updating.

---

Source: `course/practice/diagnostic.md:137–137`

**Fresh retest:** start afresh with Beta(2,5) and observe 3 successes in 6 checks. Write both likelihood powers and both posterior shapes.

---

Source: `course/practice/diagnostic.md:139–141`

### Diagnostic 10

Before seeing new outcomes, you simulate p from a stated prior and then a count of on-time parcels conditional on p. After seeing observations, you repeat with the posterior. Name each prediction and describe one question the first can expose that posterior fitting might conceal.

---

Source: `course/practice/diagnostic.md:149–149`

**Fresh retest:** an analyst draws only p from its posterior and calls its 90% interval the prediction interval for the next 20-parcel count. Identify the missing operation and the incompatible units.

---

Source: `course/practice/diagnostic.md:151–153`

## Computation versus adequacy

Prerequisites: L06 for Diagnostic 11; L09 and L10 for Diagnostic 12. Defer these at baseline unless prior learning supports them.

---

Source: `course/practice/diagnostic.md:155–157`

### Diagnostic 11

All reported R-hat values are 1.00 and estimand MCSE is small, but simulated groups rarely contain an extreme delay as large as the observed one. Can the model be declared adequate? Separate what each observation supports.

---

Source: `course/practice/diagnostic.md:165–165`

**Fresh retest:** a sampler reports divergences while its predictive histogram looks plausible. What evidence must be repaired or qualified before trusting its tail probability?

---

Source: `course/practice/diagnostic.md:167–169`

### Diagnostic 12

You promise performance at an unseen depot. A random row split leaves visits from every depot in both training and test sets. A narrow uncertainty interval is offered as proof that this validates the promise. Identify the target mismatch and propose a validation unit.

---

Source: `course/practice/diagnostic.md:177–177`

**Fresh retest:** the target changes to next month's visits at a known depot with observed history. What chronological split is suitable, and why is this no longer an unseen-depot test?

---

Source: `course/practice/review_schedule.md:1–16`

# Retrieval practice after instruction

Use each card only after its prerequisites. Close the notes, answer its **three questions**, then explain your reasoning aloud or in writing. Check the labelled self-study reference only after the attempt; log whether you needed it. Work a fresh diagnostic retest after a consequential error. These are original practice questions, outside the production scorebook, and do not automatically establish mastery.

Revisit at **1, 3 and 6 weeks after first instruction**, not three arbitrary calendar weeks for everyone. The first-use weeks below refer to the unchanged 12-week core; on a slower route schedule relative to actual instruction. The intervals are a proposed pilot schedule, not a proven optimum. Record late and missed revisits as such. For a week-12 card, the final revisit falls after the selected-core pilot's week-16 measurement; do not move that measurement or count an unobserved revisit as completed.

| Card | First use after instruction | Prerequisites | Revisit offsets |
|---|---|---|---|
| retrieval.01 | week 1 | L00, L01 | +1, +3, +6 weeks |
| retrieval.02 | week 3 | L02, L03 | +1, +3, +6 weeks |
| retrieval.03 | week 4 | L04 | +1, +3, +6 weeks |
| retrieval.04 | week 6 | L05, L06 | +1, +3, +6 weeks |
| retrieval.05 | week 10 | L09, L10 | +1, +3, +6 weeks |
| retrieval.06 | week 12 | L11, L12 | +1, +3, +6 weeks |

Allow about 12 minutes per card attempt, plus remediation when needed. Record the date, card, three answers, first consequential error, explanation consulted, assistance and fresh-check result in a personal study note. Keep measurement forms separate: no pilot form-specific feedback until delayed measurement closes. Ordinary practice on these different examples continues.

---

Source: `course/practice/review_schedule.md:18–22`

## Retrieval 01

1. A positive sensor signal occurs in 9 faulty and 21 sound items. State the reference population and compute fault given a signal. What extra count would you need for signal given fault?
2. Someone forwards the same sensor report twice. What dependence assumption would be needed to multiply two likelihood ratios, and why is it doubtful here?
3. Explain how a different fault prevalence can change fault given a signal even with unchanged conditional signal probabilities.

---

Source: `course/practice/review_schedule.md:30–34`

## Retrieval 02

1. A shared unknown pass probability has posterior Beta(2,3). Construct a simulation for the number passing in the next five checks without naming a predictive distribution.
2. Why does replacing that probability with its posterior mean lose some predictive variation? Identify the missing source of variance.
3. In a fictional inspection decision, one action costs 6 units now and avoids a 20-unit loss if any check fails. Write the expected-loss comparison; do not choose solely because failure is more likely than success.

---

Source: `course/practice/review_schedule.md:42–46`

## Retrieval 03

1. A rate is 0.2 events/hour. Change both rate and exposure units to minutes for a three-hour observation and show the invariant expected count.
2. Why is an interval for a population mean typically narrower than one for a new individual observation under the same model?
3. A continuous density has height 5 per metre across an interval of width 0.04 metres. Find its probability over that interval and identify the density's units.

---

Source: `course/practice/review_schedule.md:54–58`

## Retrieval 04

1. Your posterior SD stays near 4 as effective sample size rises from 400 to 1600. Is this evidence of a failed simulation? Estimate both mean MCSEs.
2. A report offers R-hat=1.00 as its only reason to trust a rare-event probability. Name two different checks still required and what each addresses.
3. A predictive array is `(chain, draw, patient)`. Describe the reductions for expected total events across patients, preserving axes until diagnostics are complete.

---

Source: `course/practice/review_schedule.md:66–70`

## Retrieval 05

1. You have 5,000 visits from three clinics. Which kind of uncertainty is primarily informed by the three, and which by the visits?
2. Construct predictions for two patients at one new clinic. Which latent quantity must they share? Contrast an existing clinic with data.
3. Without being told a model name, design validation for new clinics and a discrepancy that could reveal systematic clinic misfit. State what must remain inside each training split.

---

Source: `course/practice/review_schedule.md:78–82`

## Retrieval 06

1. A proposed rollout probably helps, but its expected benefit is 12 units and its cost is 15. Under linear net benefit, which action is supported and what population must be stated?
2. Missing outcomes may be more common after poor service. What sensitivity analysis would reveal a dependence on the unobserved outcomes rather than disguise it as identified evidence?
3. Write two sentences for a stakeholder separating a model-based recommendation, uncertainty about realised outcomes and one assumption whose failure could change the action.

---

Source: `course/practice/review_schedule.md:90–90`

After any repair, answer a fresh question with different conditions, explain the target and mark the attempt as independent or assisted. Remembering this reference's words is not evidence of transfer.

---

Source: `course/practice/analysis_progression.md:1–3`

# From a guided analysis to an independent one

These three stages progressively remove help. They are instructional work, not the six private measurement forms. Keep the original attempt, sources consulted, assistance, revision and fresh check. Feedback should follow observed reasoning → first consequential error → repair → fresh check. No stage changes course mastery automatically. Worked references below are public self-study help; ordinary tutor retrieval and upload omit the marked answer blocks.

---

Source: `course/practice/analysis_progression.md:5–16`

## Guided courier

Start after L03 (L01/L02 included). Allow 60–90 minutes. The following data and costs are invented for teaching and do not duplicate a production assessment.

A small courier wants to choose whether to buy an extra reserve service for tomorrow's four deliveries on one route. Model each delivery as on time or late. A fictional planning prior for the shared on-time probability is Beta(3,2). A distinct exchangeable historical batch contains six on-time and two late deliveries. A late delivery costs 10 units. Reserve service costs 14 units for the batch and, **for this decision exercise only**, eliminates all late-delivery losses. No other effect or cost is assumed. The historical batch is not already included in the prior.

1. Write the quantity, population and horizon: tomorrow's four deliveries on this route. Separate the shared probability p, observed outcomes and future count K of on-time deliveries. Explain the exchangeability assumption and one plausible violation.
2. Multiply prior and likelihood kernels and identify the two posterior shapes. Check their sum against prior concentration plus new observations.
3. Construct a full predictive replicate: draw one posterior p, then four conditional outcomes sharing it. Sum them. Explain why drawing an independent p for each delivery changes the joint model.
4. Derive E(K) and Var(K) using conditional expectation and variance. Compare the variance to the fixed-p calculation, and compute the expected late count.
5. Write expected loss for each action. Choose under the stipulated costs, then change the reserve cost to 8. Explain why more Monte Carlo draws cannot resolve an unrealistic reserve-service assumption.
6. Freeze a prior check and a posterior discrepancy before simulating. For example, examine extreme batch counts under the prior and clustering by route/day under posterior predictions. You have no route/day breakdown here: name what cannot be checked from the aggregate counts.

---

Source: `course/practice/analysis_progression.md:28–28`

**Fresh check before moving on:** a new fictional service has posterior Beta(4,6), three future jobs, late loss 5/job and perfect-prevention cost 7. Explain the shared draw and decide under expected loss. Then explain one observation you would need before applying this toy policy to actual deliveries. Ask for help if needed and record it; no answer is required from memory.

---

Source: `course/practice/analysis_progression.md:30–73`

## Scaffolded depot

Start after L09 and L10, with L05–L08 and the relevant probability/numerics bridges available. Allow 2–3 hours. This original synthetic mini-dataset records minutes late (negative means early) for five fictional depots on comparable operating days:

```text
depot,delay_minutes
A,-1
A,2
A,0
B,3
B,4
B,2
B,5
C,-2
C,1
D,7
D,9
D,6
E,0
E,2
E,1
E,3
```

Before fitting, select **one** target: a next comparable delivery at observed depot C, or two deliveries at one as-yet unobserved exchangeable depot. State why the target is conditional on comparable operations, not a causal effect of moving depots. Your chosen target determines which effect distribution and which validation unit you need. Defend what “exchangeable depots” means here; five groups give little evidence about its generality.

Complete this analysis outline; the blanks are choices to justify, not hidden grading keys:

```text
Target and horizon: ___
Data-generation / observation assumptions: ___
Initial likelihood and group structure: ___
Prior implications in minutes and between-depot variation: ___
Validation unit and transformations fitted inside training: ___
Prediction algorithm, including which draws are shared: ___
Numerical checks for the reported estimand: ___
Predictive discrepancy selected before seeing its result: ___
First consequential mismatch, proposed repair, full re-check: ___
Limitation that remains after repair: ___
```

As a starting family, consider Normal delays with depot mean alpha_j, common residual SD sigma, alpha_j drawn from Normal(mu,tau²). A **candidate**, not an elicited truth, is mu∼Normal(0,10²) minutes, tau∼HalfNormal(5) minutes, sigma∼HalfNormal(5) minutes. Check its prior predictions before adopting it. A normal delay is permissible because earliness is negative. Do not choose a positive-only likelihood and silently delete early arrivals. Compare pooled and partially pooled predictions without claiming five depots identify a precise population distribution.

Write a blank script and implement the model or a justified simpler starting model. Keep numerical warnings and failed attempts. A plotting or sampling failure is an analysis result to diagnose, not permission to fabricate output. Your report must distinguish a coordinate repair (same target) from changing a likelihood/prior (new target). After any repair, repeat numerical checks, prior implications, prediction and the originally chosen discrepancy. Do not keep trying alternatives on a held-out group and call its later score unseen validation.

---

Source: `course/practice/analysis_progression.md:83–83`

Finish with a five-minute explanation without code: identify the target, why the predictive draws are shared or separate, one held-out unit and one unresolved limitation. Have a peer ask for a fresh two-delivery construction at a different target; record any assistance.

---

Source: `course/practice/analysis_progression.md:85–95`

## Independent blank script

After the prerequisites of the chosen case, use the [existing capstone](../capstone.md), [penguin case brief](../cases/01_penguins.md) or [sensor forecasting brief](../cases/02_sensor_forecasting.md). The available [C03 air-quality case](../cases/03_air_quality.md) is another option, with independent AI acceptance for its bounded historical conditional task; human evaluation remains unperformed. Save your plan before opening any worked script, notebook or report: **attempt → save plan → consult reference → revise**. Respect the selected case's real/synthetic provenance, target, support and holdout restrictions. C03's shared temporal process requires its local temporal teaching as well as its listed prerequisites; the depot toy above does not replace them.

Before opening a reference solution, saved notebook, result or figure, start from a blank script and freeze a dated plan: population/horizon, observation process, estimand, units/support, models/priors, training-only transformations, validation units, predictive checks, numerical evidence required, sensitivity variants and reporting rules. Save a hash or immutable copy with the initial script. The provided starter can orient data access but is assistance, and using it must be logged. For C03, follow its independent freeze and outcome-custody rules; this exercise cannot authorize viewing sealed outcomes.

Retain a ledger with original attempt, assistance source and date, observed problem, proposed intervention, whether it changes the target, and reevaluation evidence. Keep failed runs. Do not retrospectively describe exploratory work as a prospective test. After final scores have been seen, label revised model comparisons development and require fresh outer evaluation for a new validation claim. Do not open saved answer-bearing outputs simply to choose a model that agrees with them.

Deliver a reproducible script, data/provenance note, model/target statement, predictive report with uncertainty, full repair ledger and a short decision or interpretation memo. Defend one limitation individually: what the data cannot identify, what the computation cannot certify, or what a deployment shift would invalidate. Consult a reference only after saving the independent attempt, marking all subsequent revisions assisted. Transfer measurement uses separate unreleased forms and occurs without this assistance.

Budget the whole additive practice package at 10–17 planning hours after prerequisites, including diagnostics/revisits, these stages and a fresh transfer analysis. Log actual time; this estimate has no learner-study validation. If the capstone or a case already occupies your route, count its independent stage once and record the substitution instead of adding its full duration twice. Original 12/24-week routes remain unchanged; advanced continuation content has its own 24–36-hour estimate.


# EXTENSION01 — optional upload-only companion

These twelve ext01.* prompts are unregistered self-study. No executable tools, stored extension mastery, hint service or reference keys are supplied. Feedback without a key is unverified. The original tool runtime remains unchanged.


Source: extensions/next_revision_v1/chapters/E01_gaussian_mrp.md

# E01 — Population estimates from an unrepresentative sample

A sample can be measured carefully and still answer the wrong question. Imagine a housing register with 900 dwellings. Eighteen residents supply an indoor-temperature reading, expressed as a deviation from a reference temperature. Their observed average is −0.3167°C. Does that describe the register? Eight responses come from one relatively cold cell; another cell, containing 220 dwellings, supplies none. The sample’s composition is itself a reason to hesitate.

Our question is the expected temperature deviation across this specified register. We will fit a multilevel regression for cell means, then average those means using known population counts. This is multilevel regression and poststratification, or MRP. The response is continuous and signed, so a Gaussian likelihood is deliberate. This chapter does not fit binary logistic MRP, infer survey inclusion probabilities, or establish that the respondents represent nonrespondents within each cell.

This optional route assumes [Gaussian updating](../../../course/chapters/04_continuous.md), [regression](../../../course/chapters/07_regression.md), and [hierarchical models](../../../course/chapters/09_hierarchical.md). Consult the accepted book’s [observation-process discussion](../../../course/advanced/03_observation_process.md) for selection concerns. Allow an unpiloted 6–8 hours for reading, the executable lab, investigation, and four optional questions. This can replace a second optional GP/spline application; it adds no required core hours. The lab and notebook contain worked examples. The optional assessment instances have separate protected reference material and are unregistered with the original tutor.

## Begin with the register, not the regression

The register is partitioned by district A, B, or C and heating category 0 or 1. The fixed predictor is −0.5 for category 0 and +0.5 for category 1. These labels describe stipulated fictional data, not observations from a real housing study. Every sampled dwelling belongs to the register; repeated measurements of one dwelling are not being counted as different members. Counts and classifications are treated as exact.

The observed responses, in cell order, are:

- A/0: −1.8, −1.1, −1.4, −0.7, −1.2, −1.6, −0.9, −1.3.
- A/1: 0.0, 0.6, 0.3.
- B/0: −0.4, 0.2, −0.1, 0.5.
- B/1: 1.0, 1.4.
- C/0: 0.8.
- C/1: no sampled response.

Let \(N_j\) be the population count, \(n_j\) the sample count, and \(\mu_j\) the outcome mean in cell \(j\). Define the population mean parameter

\[
M=\sum_{j=1}^6w_j\mu_j,\qquad w_j=N_j/900.
\]

This is an average of latent means. It is not yet the average of all 900 realised temperatures. It also differs from the model-based sample-composition mean, \(\sum_j(n_j/18)\mu_j\). Writing these weights before fitting prevents a well-computed posterior from being attached to the wrong estimand.

Figure description: Sample and population proportions differ; the empty cell retains broad posterior uncertainty.. The numerical equivalent follows; figure source locator: ../outputs/figures/E01_01.svg.

Figure E01-1 compares composition and cell inference. Its numerical equivalent follows. Intervals are central 90% posterior intervals for cell means, not individual outcomes; all temperatures are deviations in °C.

| Cell | x | N | n | Population share | Sample share | Observed mean | Posterior mean | 90% interval |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| A/0 | −0.5 | 120 | 8 | 0.1333 | 0.4444 | −1.2500 | −1.0019 | [−1.5986, −0.4170] |
| A/1 | 0.5 | 80 | 3 | 0.0889 | 0.1667 | 0.3000 | 0.3563 | [−0.4697, 1.1696] |
| B/0 | −0.5 | 160 | 4 | 0.1778 | 0.2222 | 0.0500 | −0.1083 | [−0.8374, 0.6663] |
| B/1 | 0.5 | 140 | 2 | 0.1556 | 0.1111 | 1.2000 | 0.7895 | [−0.1481, 1.7980] |
| C/0 | −0.5 | 180 | 1 | 0.2000 | 0.0556 | 0.8000 | 0.0797 | [−0.9879, 1.3979] |
| C/1 | 0.5 | 220 | 0 | 0.2444 | 0.0000 | Not observed | 0.4030 | [−1.3310, 2.0792] |

A/0 supplies almost half the responses but only about one seventh of the population. C/1 supplies almost a quarter of the population and none of the responses. Dropping its row would redefine the population. Filling its raw mean with zero would invent data. The model instead makes an uncertain prediction for its mean.

## A complete, deliberately modest model

For response \(y_i\) in cell \(c_i\), use

\[
y_i\mid\mu\sim N(\mu_{c_i},1),\qquad
\mu_j=\beta_0+\beta_1x_j+u_j,
\]

\[
\beta_0\sim N(0,4),\quad\beta_1\sim N(0,1),\quad
u_j\mid\tau\overset{ind}{\sim}N(0,\tau^2),\quad
\tau\sim\operatorname{HalfNormal}(1).
\]

Every Normal second argument is a variance. The residual SD is known and fixed at 1°C. The pooling SD \(\tau\) is unknown and integrated; its prior is the positive half of a zero-centred Normal with SD 1°C. Coefficients and cell effects are independent in the prior conditional on that scale. Responses are conditionally independent given their cell means.

The predictor coding was fixed before seeing outcomes. The prior SD for the intercept is 2°C; for the category contrast it is 1°C. Because the predictor levels differ by one, \(\beta_1\) represents the regression difference between categories before cell deviations. The six deviations are exchangeable conditional on this predictor. In particular, the two C cells do not share an additional district effect. A richer district-by-category model could encode that structure, but would ask more of eighteen observations and would be a different analysis.

Small \(\tau\) favours cell means close to the common regression; large \(\tau\) allows greater deviations. The empty cell’s own deviation is not observed. Its conditional mean deviation remains zero, but its conditional variance remains \(\tau^2\). Information about the regression and scale arrives through the other cells. “Borrowing information” therefore means using shared assumptions with uncertainty, not creating a local observation.

## Worked step 1: condition exactly, then learn the scale

Stack coefficients and deviations as \(\theta=(\beta_0,\beta_1,u_1,\ldots,u_6)^T\). Let \(H\) map this vector to six cell means and let \(A\) select the rows corresponding to observed responses. For fixed \(\tau\), the prior covariance is \(D_\tau=\operatorname{diag}(4,1,\tau^2,\ldots,\tau^2)\). With \(C_\tau=I+AD_\tau A^T\), Gaussian conditioning gives

\[
m_\tau=D_\tau A^TC_\tau^{-1}y,\qquad
V_\tau=D_\tau-D_\tau A^TC_\tau^{-1}AD_\tau.
\]

The implementation solves these systems by Cholesky factorisation; the inverse notation describes the algebra. These formulas even define the complete-pooling limit \(\tau=0\). As a small independent check, one observation 2 with variance 1 and prior \(N(0,4)\) produces precision \(1+1/4\), variance \(4/5\), and mean \(8/5\). The regression calculation is the corresponding matrix update.

To learn the scale, marginalise the coefficients:

\[
p(\tau\mid y)\propto N(y;0,C_\tau)\,p(\tau).
\]

The lab integrates this density over its full positive support, using \(\tau=t/(1-t)\), \(0<t<1\), and its Jacobian. It averages conditional cell moments and inverts the resulting mixture CDF for intervals. It does not replace \(\tau\) by a fitted point or average component interval endpoints.

The measured posterior mean of \(\tau\) is 0.7557°C, with SD 0.4245°C. Its prior mean is 0.7979°C. A similar prior and posterior mean does not imply the scale was held fixed: likelihood weighting has occurred, and appreciable scale uncertainty remains. For example, the C/0 posterior mean is pulled substantially toward the regression, while its interval remains broad. A single reading cannot establish its cell mean precisely.

## Worked step 2: propagate a joint posterior through the weights

For each posterior draw, take one scale and one conditional vector of six means. Then compute \(M^{(r)}=w^T\mu^{(r)}\). Do not choose a separate scale draw for each cell or shuffle the columns independently: both operations destroy dependence created by the shared regression and pooling scale.

The deterministic calculation makes that dependence explicit:

\[
\Sigma_\mu=E_\tau[HV_\tau H^T]+\operatorname{Cov}_\tau(Hm_\tau),
\qquad\operatorname{Var}(M\mid y)=w^T\Sigma_\mu w.
\]

For this population, the first variance contribution is 0.1376814°C² and the second is 0.0078810°C², totaling 0.1455624°C². A diagonal-only calculation gives 0.1082197°C². Here it understates uncertainty by losing cross-cell covariance. Individual off-diagonal entries need not all be positive; the full quadratic form determines the net effect. The between-scale term measures changing conditional means. Scale uncertainty also affects the average conditional covariance, so that term alone is not the entire consequence of learning \(\tau\).

Figure description: Population targets are higher and less precise than the sample-composition mean; the changed-target contrast uses paired cells.. The numerical equivalent follows; figure source locator: ../outputs/figures/E01_02.svg.

Figure E01-2 compares means and central 90% intervals, with the observed sample average marked separately. These two tables provide its numerical equivalent. All target means and SDs are in °C; variances are in °C².

| Target | Mean | SD | 90% interval |
|---|---:|---:|---|
| Sample-composition mean | −0.3178 | 0.2341 | [−0.7029, 0.0673] |
| Population parameter M | 0.1161 | 0.3815 | [−0.4771, 0.7646] |
| Realised finite-population mean | 0.1161 | 0.3802 | [−0.4745, 0.7626] |
| Changed population M′ | 0.2493 | 0.4527 | [−0.4601, 1.0062] |
| Paired contrast M′−M | 0.1332 | 0.1247 | [−0.0775, 0.3269] |

| Target | Average conditional variance | Variance of conditional means | Remaining-outcome variance |
|---|---:|---:|---:|
| Sample composition | 0.0548246 | 0.0000009 | 0 |
| M | 0.1376814 | 0.0078810 | 0 |
| Realised population | 0.1355426 | 0.0078844 | 0.0010889 |
| M′ | 0.2007706 | 0.0041313 | 0 |
| M′−M | 0.0149365 | 0.0006048 | 0 |

The population parameter is higher than the sample-composition mean because warmer predicted cells receive more population weight. Its larger SD reflects uncertainty about those cells, especially the empty one. Neither sign is securely established by the 90% interval. More population members do not supply more observed outcomes: knowing 220 addresses in an empty cell does not give 220 temperature readings.

## A finite population is not a new individual

Eighteen temperatures are already known for members of this population. To infer its realised mean, keep their sum, −5.7°C, fixed and predict only the other 882 temperatures. Conditional on cell means,

\[
E[\bar Y_{fin}\mid\mu,y]
=\frac{-5.7+\sum_j(N_j-n_j)\mu_j}{900},\qquad
\operatorname{Var}(\bar Y_{fin}\mid\mu,y)=\frac{882}{900^2}.
\]

Integrating the first expression’s uncertainty and adding the second gives the realised-mean row above. Its mean is 0.1161188°C, compared with 0.1160960°C for \(M\). The near equality is a feature of this fit, not an identity. Its SD is slightly smaller despite residual noise, because observed members are held fixed and parameter weights change. Simply adding noise to \(M\) would miss that accounting.

For a new individual in C/1, add residual variance 1 to that cell mean’s posterior variance. The predicted mean is 0.4030°C, SD 1.4573°C, and 90% interval [−1.9786, 2.7570]°C. This is wider than uncertainty about the cell mean. Selecting a random cell with population probabilities would define another individual prediction and add variation across cell means; it is not the C/1 prediction just reported.

## Change the target, then challenge the assumptions

Before reading the following result, consider increasing the empty cell’s weight. Would you expect a narrower population interval? What joint quantities would you retain to compare two targets?

Keep the fitted posterior and change population counts to \(N'=(80,120,100,180,120,300)\). Both totals are 900. This investigation changes the target distribution while assuming the same cell response laws; it does not describe new observed data or a new fit. The table reports \(M'\) and the draw-wise difference \(M'-M\). Their covariance is 0.1674616°C². Using it gives contrast variance 0.0155413°C², much smaller than adding the two marginal variances as though the targets were independent.

The empty-cell weight rises from 220/900 to 300/900. Its contribution to the change in posterior mean is 0.0358193°C; other weight changes supply the remainder of the 0.1331828°C total. The enlarged empty-cell weight also exposes more extrapolation uncertainty. This measured direction belongs to these data and this model; changing weights is not guaranteed to increase a target or its uncertainty.

Now keep the original population and use the prospectively specified HalfNormal(0.5) pooling prior. This requires refitting. The empty-cell mean becomes 0.4295°C, SD 0.7799°C, interval [−0.8452, 1.6793]°C. The population mean becomes 0.0627°C, SD 0.3302°C, interval [−0.4589, 0.6227]°C. The stronger pooling assumption narrows uncertainty, particularly for the empty cell. It does not supply evidence that the stronger assumption is correct.

Poststratification corrects composition only under adequate response modeling and appropriate within-cell selection assumptions. Suppose nonresponding dwellings are systematically warmer even after conditioning on category and district. Their outcomes are absent, so the observed likelihood cannot estimate that discrepancy. As an explicit sensitivity assumption, shift every unsampled member’s conditional mean upward by 0.5°C. The realised population mean and both interval endpoints shift by \(0.5(882/900)=0.49\)°C. This is an imposed scenario, not a learned correction or a causal effect of heating.

## What the computation establishes

The frozen data, priors, seeds and tolerances precede execution. The lab compares 192- and 384-node quadrature: the largest checked moment discrepancy is \(7.55\times10^{-15}\). An adaptive integral on the original scale, using independently implemented coefficient precision and a separate Normal density, differs by \(2.87\times10^{-15}\). Its numerical error estimate is \(2.83\times10^{-11}\) for the scaled integral. The log normalizer is −23.96662475; adaptive integration differs by \(2.49\times10^{-14}\). Scaling uses that log normalizer as an offset to keep integrands well-sized. Fixed-scale regression, prior recovery and population accounting also have independent tests.

Forty thousand joint draws with frozen seed 41001 give population mean 0.1177405°C and MCSE 0.0019034°C; the deterministic answer is 0.1160960°C. The difference is comfortably within the predeclared six-MCSE allowance. Predictive simulation uses seed 41002. These are independent simulation draws from the quadrature approximation, not an MCMC chain. Quadrature agreement and Monte Carlo precision address computational error separately; neither tests whether the housing model is scientifically adequate.

The empty cell lacks direct outcome overlap. Unknown residual variation, uncertain register counts, omitted predictors, district correlation and within-cell selection could all matter in an actual study. Those possibilities need further data or explicitly justified modeling. This bounded example shows how to carry stated assumptions into population uncertainty, and how to expose dependence on assumptions where the sample is silent.


Source: extensions/next_revision_v1/chapters/E02_poisson_mixture.md

# E02 — Learn a finite mixture without mistaking labels for knowledge

This optional module asks what heterogeneous counts can teach us when the labels attached to components have no scientific meaning. Work through [Bayes updates](../../../course/chapters/01_bayes.md), conjugacy, posterior prediction and computational checking first; the accepted book's categorical-conjugacy and model-evidence extensions are useful bridges. Consult the [companion route](../README.md) for the authoritative prerequisite IDs. Allow an unpiloted six to eight hours for reading, the executable lab, the changed-data investigation and four questions. It can replace a second optional approximation or model-comparison project. It adds no required core hours.

Our target is a future count distribution and uncertainty about which observations share a statistical component. It is not a claim that a machine has two discovered physical modes. That distinction will matter even when the fitted rates appear well separated. The complete reference lab and notebook contain worked examples; the optional questions use different givens and have separate instructor references.

## A count model with three genuinely unknown parameters

A fictional instrument records interruptions during twelve independent windows of equal duration. The stipulated counts, in observation order, are

\[
y=(0,0,1,1,2,2,3,7,8,9,10,12).
\]

These are original fictional observations, not simulated measurements from a hidden “true” parameter. No data-generation seed is required. Each window has exposure one. Conditional independence and equal exposure are assumptions; a temporal trend, common disturbance or changing exposure would require a different likelihood.

We stipulate exactly two components and write

\[
\pi\sim\mathrm{Beta}(1,1),\qquad
\lambda_0,\lambda_1\overset{ind}{\sim}\mathrm{Gamma}(2,0.5),
\]
\[
z_i\mid\pi\sim\mathrm{Bernoulli}(\pi),\qquad
y_i\mid z_i,\lambda\sim\mathrm{Poisson}(\lambda_{z_i}).
\]

Gamma parameters here are shape and **rate**, so each rate has prior mean four. NumPy's sampler instead takes scale, requiring the reciprocal rate. The weight is defined as the probability of component 1. It is shared across windows, although every window receives its own allocation. Both rates and this weight are learned and integrated; none is estimated once and then treated as known.

Before computing, ask where uncertainty enters. Even if the parameters were given, allocations could remain uncertain because Poisson components overlap. Even if allocations were given, a finite number of counts would leave uncertainty about the parameters. The posterior must retain both layers. Choosing the most plausible allocation and stopping would discard the uncertainty between allocations.

## Worked step one: integrate a proposed allocation

For any binary allocation vector, let \(n_k\) count its windows and \(S_k\) sum their counts. As a concrete worked allocation, assign the first seven windows to component 0 and the last five to component 1. Then

\[
(n_0,S_0)=(7,9),\qquad(n_1,S_1)=(5,46).
\]

Under this allocation the conditional posterior is

\[
\pi\mid z,y\sim\mathrm{Beta}(6,8),\quad
\lambda_0\mid z,y\sim\mathrm{Gamma}(11,7.5),\quad
\lambda_1\mid z,y\sim\mathrm{Gamma}(48,5.5).
\]

The count sum augments the shape; the number of unit exposures augments the rate. This calculation is one component of the posterior, not the final fit. For example, allocating a count of three to the other component gives a different conditional posterior and has its own posterior mass.

For general symmetric Beta shape \(\alpha\) and Gamma shape/rate \((a,b)\), conjugate integration gives

\[
\begin{aligned}
\log p(y,z)={}&\log B(\alpha+n_1,\alpha+n_0)-\log B(\alpha,\alpha)\\
&+\sum_{k=0}^1\{a\log b-\log\Gamma(a)+\log\Gamma(a+S_k)
 -(a+S_k)\log(b+n_k)\}\\
&-\sum_i\log\Gamma(y_i+1).
\end{aligned}
\]

The factorial terms are constant across allocations but belong in the evidence. Dropping them would preserve normalized allocation probabilities while changing the marginal likelihood. This is one reason a normalization test alone is insufficient.

There are only 4,096 allocations. We compute every log joint mass, subtract their log-sum-exp, and exponentiate to obtain normalized posterior masses. Subtracting the maximum inside log-sum-exp avoids exponentiating unnecessarily small unnormalized numbers. It changes numerical representation, not the statistical model.

Empty components must remain in this list. When no windows are assigned to a component, its integrated likelihood contribution is one and its rate posterior is its proper prior. Deleting such allocations changes the prior and the posterior. Proper Gamma priors make this case straightforward; an improper rate prior would not provide the same guarantee.

## What the component names conceal

A component name is a coordinate in the model. Exchanging the two component names, including the associated allocations and weight, leaves the distribution of observations unchanged under these symmetric priors. Consequently each labelled rate has the same marginal posterior distribution, and every individual allocation has marginal probability one half of carrying label 1.

That identity is not ignorance about all useful quantities. Consider a draw with one small rate and one large rate. Its relabelled counterpart has the same predictive behavior. Averaging the first coordinate across such draws combines both roles; averaging the second does the same. Two equal coordinate means therefore cannot describe the separation present within draws. Nor should an analyst suppress half the posterior merely to obtain attractive labelled summaries.

For interpretation we report the lower and higher rate within each draw. If their weights are used, the weight travels with the rate when sorting. We also report the random mixture mean

\[
M=(1-\pi)\lambda_0+\pi\lambda_1.
\]

This is a conditional expected count for a future window at a parameter draw. Its posterior spread differs from the predictive spread of an actual future count. A future count additionally varies through its allocation and Poisson sampling.

Figure description: Labelled rate densities coincide, while sorted rates separate and the mixture mean remains identifiable.. The numerical equivalent follows; figure source locator: ../outputs/figures/E02_01.svg.

| Summary | Mean | SD | Central 90% interval | MCSE of mean |
| --- | --- | --- | --- | --- |
| Lower rate | 1.422624 | 0.472993 | [0.733733, 2.264475] | 0.002365 |
| Higher rate | 8.419173 | 1.335643 | [6.334890, 10.693319] | 0.006678 |
| Mixture mean | 4.556041 | 1.079756 | [2.922558, 6.448671] | 0.005399 |
| Rate separation | 6.996548 | 1.371164 | [4.846413, 9.328953] | 0.006856 |
| Weight on higher rate | 0.450623 | 0.135719 | [0.233634, 0.681552] | 0.000679 |

Exact symmetry checks: E(pi|y) = 0.500000000000; maximum labelled-density difference = 1.67e-16.

The left panel evaluates both labelled densities analytically by averaging conditional Gamma densities. Their maximum discrepancy is below the declared symmetry tolerance. The right panel uses 40,000 independent joint posterior draws. The displayed intervals are empirical central 90% intervals, not uncertainty intervals around a computed mean. Each reported draw mean has a separate Monte Carlo standard error. Increasing simulation effort reduces that numerical error but does not remove scientific posterior uncertainty.

To produce a draw, first sample a fresh allocation from its normalized mass, then sample the weight and both rates from their conditional distributions. Repeat independently. These are independent posterior draws across rows; the three parameters within a row are independent only conditional on its allocation. There is no Markov-chain burn-in or autocorrelation correction to hide here. Sampling all parameters from their separate marginal distributions would break the joint posterior needed for prediction.

## Worked step two: predict by integrating uncertainty

Under the worked allocation above, the posterior probability that a new window uses component 1 is \(6/14\). The component rate means are \(11/7.5\) and \(48/5.5\). Thus its conditional predictive mean is

\[
\frac8{14}\frac{11}{7.5}+\frac6{14}\frac{48}{5.5}
=4.578355.
\]

Its conditional next-zero probability is

\[
\frac8{14}\left(\frac{7.5}{8.5}\right)^{11}
+\frac6{14}\left(\frac{5.5}{6.5}\right)^{48}.
\]

These formulas integrate the weight and rates while conditioning on this single allocation. To finish, average such answers over **all** allocation masses. The measured full predictive mean is 4.566364 counts, with predictive variance 17.419690. The variance of the random mixture mean is only 1.187300. Those quantities answer different uncertainty questions and should not share an unlabeled error bar.

More generally a Gamma posterior with shape \(r_k=a+S_k\) and rate \(b_k=b+n_k\) produces a negative-binomial predictive mass

\[
g_k(m)=\frac{\Gamma(r_k+m)}{\Gamma(r_k)m!}
\left(\frac{b_k}{b_k+1}\right)^{r_k}
\left(\frac1{b_k+1}\right)^m.
\]

Multiply by the integrated allocation weight \((\alpha+n_k)/(2\alpha+N)\), sum over the two components, then average over allocations. This order makes the conditioning explicit and avoids replacing an expectation of a nonlinear function by that function of a mean.

If predicting three future windows, keep one parameter draw for the whole replicate dataset and draw a separate allocation for each window. Their counts are conditionally independent given those parameters. After integrating parameters they are generally dependent. In contrast, choosing one component for an entire dataset imposes a common allocation and defines a different model, like a simple whole-model mixture. Neither procedure can be substituted silently for the other.

## Shared allocation without arbitrary labels

Co-clustering asks whether two windows have the same allocation:

\[
C_{ij}=\sum_z p(z\mid y)\,1[z_i=z_j].
\]

The diagonal equals one, the matrix is symmetric, and exchanging component names leaves every entry unchanged. It summarizes pairwise posterior relationships rather than certifying a partition. Thresholding all entries need not produce a logically consistent clustering, because separate pairwise decisions need not obey transitivity.

Figure description: Integrated co-clustering and predictive count probabilities, compared with a changed largest count.. The numerical equivalent follows; figure source locator: ../outputs/figures/E02_02.svg.

The following numerical equivalent includes the full matrix. Row and column numbers refer to the original observation order, so repeated counts remain distinct windows. Rounding to three decimals is for reading only; the results file retains full precision.

Columns 1–6:

| Window (count) | 1 | 2 | 3 | 4 | 5 | 6 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 (0) | 1.000 | 0.996 | 0.987 | 0.987 | 0.946 | 0.946 |
| 2 (0) | 0.996 | 1.000 | 0.987 | 0.987 | 0.946 | 0.946 |
| 3 (1) | 0.987 | 0.987 | 1.000 | 0.979 | 0.940 | 0.940 |
| 4 (1) | 0.987 | 0.987 | 0.979 | 1.000 | 0.940 | 0.940 |
| 5 (2) | 0.946 | 0.946 | 0.940 | 0.940 | 1.000 | 0.911 |
| 6 (2) | 0.946 | 0.946 | 0.940 | 0.940 | 0.911 | 1.000 |
| 7 (3) | 0.794 | 0.794 | 0.793 | 0.793 | 0.788 | 0.788 |
| 8 (7) | 0.021 | 0.021 | 0.030 | 0.030 | 0.071 | 0.071 |
| 9 (8) | 0.008 | 0.008 | 0.016 | 0.016 | 0.058 | 0.058 |
| 10 (9) | 0.004 | 0.004 | 0.012 | 0.012 | 0.054 | 0.054 |
| 11 (10) | 0.003 | 0.003 | 0.011 | 0.011 | 0.053 | 0.053 |
| 12 (12) | 0.002 | 0.002 | 0.011 | 0.011 | 0.053 | 0.053 |

Columns 7–12:

| Window (count) | 7 | 8 | 9 | 10 | 11 | 12 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 (0) | 0.794 | 0.021 | 0.008 | 0.004 | 0.003 | 0.002 |
| 2 (0) | 0.794 | 0.021 | 0.008 | 0.004 | 0.003 | 0.002 |
| 3 (1) | 0.793 | 0.030 | 0.016 | 0.012 | 0.011 | 0.011 |
| 4 (1) | 0.793 | 0.030 | 0.016 | 0.012 | 0.011 | 0.011 |
| 5 (2) | 0.788 | 0.071 | 0.058 | 0.054 | 0.053 | 0.053 |
| 6 (2) | 0.788 | 0.071 | 0.058 | 0.054 | 0.053 | 0.053 |
| 7 (3) | 1.000 | 0.222 | 0.210 | 0.207 | 0.206 | 0.206 |
| 8 (7) | 0.222 | 1.000 | 0.977 | 0.980 | 0.981 | 0.981 |
| 9 (8) | 0.210 | 0.977 | 1.000 | 0.993 | 0.994 | 0.995 |
| 10 (9) | 0.207 | 0.980 | 0.993 | 1.000 | 0.998 | 0.998 |
| 11 (10) | 0.206 | 0.981 | 0.994 | 0.998 | 1.000 | 0.999 |
| 12 (12) | 0.206 | 0.981 | 0.995 | 0.998 | 0.999 | 1.000 |

Low counts have high co-clustering probabilities with other low counts, while many low/high pairs have small probabilities. A count near the region of component overlap can remain ambiguous. These associations concern the stipulated statistical allocations. Unmeasured causes, excess zeros, overdispersion within a single process, or dependencies between windows could explain heterogeneous counts differently.

The second panel's numerical equivalent lists every displayed predictive count and an explicit tail. The tail is computed by integrating negative-binomial survival probabilities. The displayed masses are never rescaled to conceal unplotted probability.

| Future count | Original probability | Last count changed to 4 |
| --- | --- | --- |
| 0 | 0.14476425 | 0.13318195 |
| 1 | 0.18093891 | 0.17940753 |
| 2 | 0.12928412 | 0.1445792 |
| 3 | 0.075935556 | 0.10024165 |
| 4 | 0.050732543 | 0.075990662 |
| 5 | 0.047132609 | 0.06777356 |
| 6 | 0.052121932 | 0.064445116 |
| 7 | 0.056778321 | 0.059306618 |
| 8 | 0.057115427 | 0.050871906 |
| 9 | 0.052617722 | 0.040438689 |
| 10 | 0.044650663 | 0.029926539 |
| 11 | 0.035178027 | 0.020760564 |
| 12 | 0.025920685 | 0.013590892 |
| 13 | 0.017976508 | 0.0084459311 |
| 14 | 0.011797789 | 0.0050077817 |
| 15 | 0.0073612435 | 0.0028453419 |
| 16 | 0.0043843279 | 0.0015550508 |
| 17 | 0.0025013753 | 0.00082014145 |
| 18 | 0.0013712517 | 0.00041860239 |
| 19 | 0.00072427449 | 0.0002072868 |
| 20 | 0.00036948204 | 9.9808272e-05 |
| 21 | 0.00018244633 | 4.682269e-05 |
| 22 | 8.7374223e-05 | 2.1440398e-05 |
| 23 | 4.0654918e-05 | 9.5990442e-06 |
| 24 | 1.840904e-05 | 4.2085578e-06 |
| 25 | 8.1242834e-06 | 1.8097635e-06 |
| 26 | 3.4992209e-06 | 7.6449984e-07 |
| 27 | 1.4727957e-06 | 3.1778738e-07 |
| 28 | 6.0647555e-07 | 1.3024324e-07 |
| 29 | 2.4460595e-07 | 5.2761276e-08 |
| 30 | 9.6730088e-08 | 2.1198399e-08 |
| >30 | 6.0332437e-08 | 1.4438816e-08 |

## Change a datum, then change an assumption

The prospective changed-data investigation replaces only the final count, twelve, with four. Priors, seeds and computation remain fixed. The fitted predictive mean becomes 3.952320, and the probability of a count above ten falls from 0.107928 to 0.053837. The sorted-rate separation mean changes from 6.996548 to 5.574720; its Monte Carlo standard errors are 0.006856 and 0.006980 respectively. These are observed outcomes of the specified comparison, not a general monotonicity rule about mixture fitting.

The last window's co-clustering probability with window seven rises from 0.205719 to 0.596517, while its probability with window eleven falls from 0.999458 to 0.569648. Its co-clustering relationships change; the results JSON contains both complete matrices. In the lab, compare its row before and after replacement and explain which other windows now share its allocation more plausibly. This is a refit to changed new-module data. It is distinct from E01's changed target weights, which required no change to the fitted response model.

A separate investigation changes the symmetric weight prior from Beta(1,1) to Beta(0.5,0.5), retaining both Gamma priors and all observations. This places more prior mass near extreme weights. The posterior empty-component probability changes from 0.000007368 to 0.000023065. The predictive mean becomes 4.538462, and the probability above ten becomes 0.106831. The small prediction change and larger relative empty-component change show why a sensitivity conclusion must name its target. Relative changes in tiny probabilities can sound dramatic while having little influence on the prediction of interest.

## How the calculation earns its numerical claims

The primary allocation enumeration is checked with a separate dynamic program. It counts subsets by their size and count sum, accumulating the number of ways each sufficient-statistic pair can occur. Each pair receives its independently computed integrated mass multiplied by its multiplicity. The counts sum to 4,096. Agreement of evidence, predictive masses and predictive mean checks more than agreement of normalized labels.

A further tiny anchor uses exponential rate priors and a uniform weight. With no observations, the next-zero probability is one half. After one zero, it is eleven eighteenths. With two zeros, the evidence is eleven thirty-sixths and co-clustering is eight elevenths. Direct integration of the ordinary mixture likelihood, using two Laguerre dimensions and one Jacobi dimension, agrees at both frozen orders. This checks the collapsed algebra without using its allocation-weight routine.

The scientific run passed twenty recorded checks. The maximum discrepancy among its deterministic checks was about \(7.11\times10^{-15}\). The draw-based mixture-mean estimate, 4.556041, differs from the exact mean by 0.010323, compared with Monte Carlo standard error 0.005399. It passes the predeclared six-standard-error comparison. Numerical agreement does not validate the fictional model's assumptions, and “exact” here means analytic integration plus exhaustive finite summation in floating arithmetic, not a universal scalable inference engine.

The helper rejects negative, fractional or nonfinite counts, invalid priors and more than twelve observations. It also tests empty data, empty components, fractional proper prior shapes, observation permutations and shared predictive parameters. For larger samples, allocation enumeration grows exponentially. Approximate methods then require their own diagnostics, especially around label symmetry. This module does not select a component count, infer physical regimes, or claim that a two-component fit is the only useful explanation.

Continue with [E03](E03_binary_hmm.md) to make latent states depend on their predecessors. Before moving on, describe one predictive summary that survives relabelling and one modelling assumption that none of our numerical checks can establish. Then attempt the four [optional questions](../assessments/E02_questions.md) without consulting the protected reference material.


Source: extensions/next_revision_v1/chapters/E03_binary_hmm.md

# E03 — Hidden states change with time

A noisy observation can tell us about an underlying condition without revealing it. Repeated observations add another possibility: the condition may persist, and the chance of switching may itself be uncertain. This optional module develops a small hidden Markov model in which both transition probabilities are learned. Its central question is which observations are allowed to influence each answer.

Prerequisites are Bayes updating, prediction, continuous parameters, Monte Carlo checking and the accepted [time-series extension](../../../course/advanced/05_time_series.md). [E02](E02_poisson_mixture.md) is helpful for marginalizing latent discrete variables. Allow an unpiloted six to eight hours including the lab and questions. Substitute it for an optional sensor-forecasting revisit, rather than adding required core hours. The [route guide](../README.md) records the complete prerequisite IDs and limitations.

We distinguish filtering at a particular time, smoothing after the sequence has finished, forecasting beyond it, and choosing a joint state path. Each is a legitimate target. They differ in conditioning information or in the object summarized; one cannot be substituted for another merely because their plots look similar.

## What is fixed, and what is learned?

A fictional inspection instrument reports the ten successive binary alerts

\[
y=(0,0,1,1,1,0,0,1,1,0).
\]

The data are stipulated, not generated from a concealed true model. The initial state distribution is fixed at \(P(S_1=1)=0.4\). The alert probabilities are also fixed:

\[
P(Y_t=1\mid S_t=0)=0.15,\qquad
P(Y_t=1\mid S_t=1)=0.80.
\]

These informative emissions anchor the state names: state 1 is the condition associated with more alerts. That is a modelling convention, not an observed state label. An alert is compatible with either state. Fixed emissions could come from external knowledge in an application, but here they are disclosed pedagogical givens whose uncertainty is not fitted.

Let \(a=P(S_{t+1}=1\mid S_t=0)\) and \(b=P(S_{t+1}=0\mid S_t=1)\). The transition matrix, with origins as rows, is

\[
T(a,b)=\begin{pmatrix}1-a&a\\b&1-b\end{pmatrix},\qquad
 a,b\overset{ind}{\sim}\mathrm{Beta}(2,5).
\]

The two rows have separate uncertain switching probabilities. Conditional on this matrix, the next state depends only on the current state; conditional on the states, alerts are independent with the stipulated emission laws. These assumptions rule out duration effects, time-varying transitions and correlated measurement errors. The initial law is for the state at the first inspection. There is **no transition before the first observation**, and we do not replace that law with a stationary distribution depending on the unknown matrix.

## Worked step one: the first look and a path update

At time one, the no-alert likelihood contributions are \(0.6(0.85)=0.51\) from state 0 and \(0.4(0.20)=0.08\) from state 1. Their sum is 0.59, so

\[
P(S_1=1\mid Y_1=0)=0.08/0.59=0.135593.
\]

Neither transition probability appears in this likelihood. Therefore after the first observation their posterior distributions remain exactly their Beta(2,5) priors. The state distribution has changed while the transition distributions have not. With no observations at all, the next-state prediction concerns \(S_1\), with probability 0.4, again without applying a transition.

Now consider the particular proposed path \((0,0,1,1)\) through the first four times. Its transitions are one 0-to-0, one 0-to-1 and one 1-to-1. Conditional on that path, conjugacy gives

\[
a\mid s,y\sim\mathrm{Beta}(3,6),\qquad
b\mid s,y\sim\mathrm{Beta}(2,6).
\]

The stay in state 1 augments the second shape for \(b\), because \(b\) denotes leaving state 1. Counting all changes as successes for both rows would be wrong. The emissions determine how plausible this path is, but once the path is given they contribute no additional transition counts.

For the observed alerts, many paths remain possible. Transition learning averages their conditional Beta posteriors with their posterior path masses. This is actual learning of transitions, not a fixed matrix chosen because its state plot looks reasonable. It also introduces dependence between the final state and the transition parameters, which forecasting must preserve.

## Messages at a fixed transition pair

At fixed \((a,b)\), a forward message accumulates joint probability of the observations seen so far and the current state. Write \(e_s(y)\) for the emission probability. Then

\[
\alpha_1(s)=\rho_s e_s(y_1),\qquad
\alpha_t(s)=e_s(y_t)\sum_r\alpha_{t-1}(r)T_{rs}.
\]

Normalize each vector to obtain its conditional filter. Retain the normalizing constants as the prefix likelihood; throwing them away would prevent correct parameter learning. Our implementation uses log messages and log-sum-exp, so a possible but extremely small probability is not confused with impossible evidence.

The backward message starts at one after the final observation and moves toward the beginning:

\[
\beta_T(s)=1,\qquad
\beta_t(r)=\sum_s T_{rs}e_s(y_{t+1})\beta_{t+1}(s).
\]

Multiply forward and backward messages at a time and normalize to obtain its conditional smoother. Notice that the backward update includes the **next** emission. Reusing the current emission would count one observation twice and omit another.

A filter can be used at the time of an inspection. A smoother reconstructs earlier conditions after later observations have arrived. Smoothing is useful for retrospective interpretation, but its access to the future must not be hidden when evaluating a real-time procedure. Uncertainty about transition parameters does not relax this information boundary.

## Integrate the right parameter posterior

We integrate fixed-parameter calculations with tensor Beta-weighted Gauss–Jacobi quadrature. For a Beta(A,B) prior, Jacobi's shape arguments are \((B-1,A-1)\) after mapping its nodes to \([0,1]\). Reversing this convention would replace the intended prior by a different one. The normalized prior node masses are denoted \(v_q\).

For every node retain its prefix likelihood \(L_t(q)\) and conditional filter \(f_t(q)\). The integrated filter is

\[
P(S_t=1\mid y_{1:t})=
\frac{\sum_q v_qL_t(q)f_t(q)}{\sum_q v_qL_t(q)}.
\]

Thus each time has its own parameter posterior. A calculation that updates states from a prefix but weights transition parameters using the full sequence still uses future information. Correct smoothing instead averages full-data conditional smoothers with weights proportional to \(v_qL_T(q)\). It requires both the full-data parameter posterior and the backward state message.

For short sequences the likelihood and unnormalized probability numerators are polynomials in \(a,b\). Orders 12 and 24 agree within the frozen tolerance for this ten-observation sequence and three-step forecast. Polynomial integration explains the strong agreement; it does not make every nonlinear functional or quantile an exact quadrature output. Our transition intervals come from continuous Beta-mixture CDF inversion, not quantiles of a sparse set of quadrature nodes.

## Independent paths and a changed future

An independent calculation enumerates all 1,024 paths. For each path count \(n_{00},n_{01},n_{10},n_{11}\), multiply its initial and emission probabilities, and integrate transitions using

\[
\frac{B(2+n_{01},5+n_{00})}{B(2,5)}
\frac{B(2+n_{10},5+n_{11})}{B(2,5)}.
\]

Normalizing these masses gives the integrated full-path posterior. Summing paths containing state 1 at a time gives smoothing. To check filtering independently, enumerate **each prefix separately**. Summing early states from the final path posterior would reproduce smoothing, not validate the filter.

The frozen investigation leaves the first six alerts unchanged and replaces the suffix with four alerts:

\[
y'=(0,0,1,1,1,0,1,1,1,1).
\]

This deliberately changes the evidence available only later. The earlier filters and their parameter node weights must remain identical. Earlier smoothers may change because their conditioning information includes the replacement suffix.

Figure description: Changing the suffix leaves prefix filters fixed through time six but changes full-sequence smoothers.. The numerical equivalent follows; figure source locator: ../outputs/figures/E03_01.svg.

The numerical equivalent lists both sequences and all four probability columns. “Original filter” conditions only on the original prefix ending at that row; “changed smoother” conditions on all ten changed alerts.

| Time | y / changed y | Original filter | Changed filter | Original smoother | Changed smoother |
| --- | --- | --- | --- | --- | --- |
| 1 | 0 / 0 | 0.135593 | 0.135593 | 0.115532 | 0.114145 |
| 2 | 0 / 0 | 0.109758 | 0.109758 | 0.230948 | 0.271222 |
| 3 | 1 / 1 | 0.699596 | 0.699596 | 0.845721 | 0.879961 |
| 4 | 1 / 1 | 0.877645 | 0.877645 | 0.906449 | 0.948941 |
| 5 | 1 / 1 | 0.922491 | 0.922491 | 0.858113 | 0.931997 |
| 6 | 0 / 0 | 0.396692 | 0.396692 | 0.325537 | 0.665837 |
| 7 | 0 / 1 | 0.196743 | 0.847370 | 0.321204 | 0.937270 |
| 8 | 1 / 1 | 0.772796 | 0.923243 | 0.828921 | 0.964676 |
| 9 | 1 / 1 | 0.899361 | 0.941071 | 0.833379 | 0.965860 |
| 10 | 0 / 1 | 0.363720 | 0.948564 | 0.363720 | 0.948564 |

The recorded maximum early-filter discrepancy is exactly zero in floating arithmetic. The largest early smoothing change is 0.340300, at time six: its probability rises from 0.325537 to 0.665837. The late alerts can suggest that the instrument was already in the alert-prone condition earlier. They cannot change what a correctly defined earlier filter had learned at that time. This is a falsifiable implementation property: change unseen observations and compare the prefix outputs, rather than trusting a function named “filter.”

## Worked step two: forecast a state and an alert

At a fixed parameter node, let \(f_T(q)\) be the final filtered state-1 probability. One transition gives

\[
h(q)=(1-f_T(q))a_q+f_T(q)(1-b_q).
\]

Integrate this whole expression using the full-data node weights. Multiplying separately averaged state and transition probabilities generally loses their posterior dependence. The next alert probability is then

\[
P(Y_{T+1}=1\mid y)=0.15\{1-E[h(q)\mid y]\}+0.80E[h(q)\mid y].
\]

State prediction and observation prediction differ because the measurement is noisy. Reporting a state probability as an alert probability would skip the emission model. The table below gives both integrated predictions and a deliberately labelled plug-in comparison using the posterior mean transition pair, rerunning fixed-parameter filtering at that pair.

| Method / data | P(next state 1) | P(next alert 1) |
| --- | --- | --- |
| Integrated / original | 0.500466 | 0.475303 |
| Plug-in / original | 0.468904 | 0.454788 |
| Integrated / changed suffix | 0.794289 | 0.666288 |

For three future alerts, compute all eight pattern probabilities by applying a transition and the appropriate emission matrix at each future time. The same node is used throughout the three-step product before averaging. An independent future-state expansion obtains the same answer using Beta-ratio moments from every observed-path component. The pattern probabilities sum to one, and summing those whose first digit is one recovers the one-step alert prediction.

Figure description: Continuous transition learning and integrated three-alert patterns compared with a plug-in calculation.. The numerical equivalent follows; figure source locator: ../outputs/figures/E03_02.svg.

| Transition | Prior mean | Posterior mean | Central 90% interval | Changed mean | Changed 90% interval |
| --- | --- | --- | --- | --- | --- |
| p01 | 0.285714 | 0.351074 | [0.121309, 0.617811] | 0.357690 | [0.119790, 0.633673] |
| p10 | 0.285714 | 0.289999 | [0.076752, 0.557017] | 0.187056 | [0.036280, 0.416298] |

The independent-draw transition means are p01: 0.350754 (MCSE 0.000753), p10: 0.289396 (MCSE 0.000736). These MCSEs describe simulation accuracy, separately from the continuous posterior intervals above.

| Next alerts | Integrated | Plug-in | Simulation frequency | MCSE |
| --- | --- | --- | --- | --- |
| 000 | 0.192067 | 0.186693 | 0.191425 | 0.001967 |
| 001 | 0.117572 | 0.130442 | 0.116400 | 0.001604 |
| 010 | 0.096250 | 0.099811 | 0.094375 | 0.001462 |
| 011 | 0.118808 | 0.128266 | 0.118050 | 0.001613 |
| 100 | 0.103993 | 0.107687 | 0.105050 | 0.001533 |
| 101 | 0.091662 | 0.087583 | 0.092650 | 0.001450 |
| 110 | 0.105299 | 0.106438 | 0.104550 | 0.001530 |
| 111 | 0.174348 | 0.153079 | 0.177500 | 0.001910 |

The transition table uses central 90% intervals. It shows substantial remaining uncertainty despite the informative emissions. The pattern comparison measures the consequences of a plug-in approximation for these particular givens. It is not evidence that every integrated probability must exceed its plug-in counterpart, nor a guarantee that a wider or narrower prediction is empirically better. We have no held-out real inspections here.

For simulation, first draw an observed state path from its integrated posterior, then draw both transition probabilities from that path's conditional Beta distributions. Start from that same path's final state and retain the sampled pair for the entire future trajectory. Repeating gives independent posterior predictive trajectories. Redrawing transitions independently at every future step changes the model and removes some of the dependence we are trying to propagate.

## Paths, marginal probabilities, and numerical failure

A sequence of marginally most probable states need not be the single most probable joint path. The lab records both the integrated MAP path and the marginal modal sequence, along with the MAP path's posterior mass. Neither is a substitute for the uncertainty shown by the smoothing probabilities. Choosing a decoded path is a decision rule about an entire trajectory; its suitability depends on the loss assigned to different mistakes.

A fixed-parameter reference check uses initial state-1 probability one half, switching probabilities one quarter, emissions one fifth and four fifths, and observations (1,0). Its filters are \((4/5,13/41)\), its smoothers \((28/41,13/41)\), and its evidence is \(41/200\). One-step state and alert predictions are \(67/164\) and \(73/164\). The browser experiment uses this separate worked anchor and keeps its parameters fixed; the present lab learns them. Changing a browser input explores a conditional calculation, not a new learned transition posterior.

Boundary cases are part of the mathematics. Equal emissions supply no information about transitions or states, although unconditional state probabilities can still evolve with time. Deterministic emissions can identify a path if that path is supported. Absorbing or alternating matrices can make some observation sequences impossible. If all reachable states give the next observation probability zero, the evidence is zero and the requested posterior is undefined. The API returns a structured failure with the first impossible time, rather than NaN or a fabricated fallback. A displayed earlier result must be labelled as belonging to previous valid inputs.

All 37 recorded scientific checks passed; the largest deterministic discrepancy was about \(4.44\times10^{-15}\). The integrated MAP path for the original sequence equals its marginal modal sequence, but carries only 0.104537 posterior probability. Agreement of those two summaries is therefore compatible with considerable path uncertainty. The executable checks compare quadrature orders, collapsed paths, separately enumerated prefixes, future-state expansions, rational anchors, interval support, and shared-parameter simulation. Parameter and forecast simulation summaries use 40,000 independent draws with their actual Monte Carlo standard errors. The first numerical run exposed a Boolean-array quantile reporting error; its failed command was retained, the indicator summary was converted to numeric values, and settings were unchanged. A successful rerun does not erase that provenance.

This is a deliberately finite laboratory, limited to twelve observations and a three-step forecast. It does not learn emissions, implement particle filtering, infer a changing number of states, or establish physical states in an instrument. Extending the model requires revisiting both identifiability and computation. Before attempting the [four optional questions](../assessments/E03_questions.md), explain why a single alert can change a state posterior without learning a transition, and why a later alert can change a smoother without changing an earlier filter.


Source: extensions/next_revision_v1/assessments/questions.md

# E01 optional self-study questions

Unregistered with the original tool-backed tutor; no stored extension mastery. Attempt before consulting protected reference materials.

## ext01.e01.1

Complete a conditional update. A group mean has prior Normal(3,9), with Normal second arguments denoting variances. Two independent responses have known observation variance 4 and sample mean 7. Find the posterior mean and variance of the group mean, showing the likelihood precision. Then state the distribution for an otherwise identical group with no responses when these prior parameters are fixed.

## ext01.e01.2

Audit this variance calculation. Two cell means have joint posterior covariance [[4,1],[1,9]] and target weights (1/4,3/4). An analyst uses only the diagonal terms to report uncertainty in the weighted mean. Derive the correct variance, calculate the omitted contribution, and explain why posterior marginal intervals alone do not determine target uncertainty.

## ext01.e01.3

Identify the estimand. A finite register has cell counts (4,6). The observed members have outcomes 2 in cell 1 and 4,6 in cell 2. At one posterior parameter draw, the cell means are (3,5) and the residual SD is 2. Calculate the population mean parameter, the conditional expected realised finite-population mean, and its conditional variance from unobserved outcomes. Explain what uncertainty is still missing from a calculation at only one parameter draw.

## ext01.e01.4

Diagnose an identification claim. Hold two fitted cell means at (-1,2) and change target weights from (0.8,0.2) to (0.3,0.7). Calculate both target means and explain whether a refit is required. An analyst says the new weights also correct outcome-dependent nonresponse within each cell. Evaluate this claim, distinguishing target composition, outcome overlap, and an unsupported selection assumption. Describe what an imposed shift for nonrespondents would mean.


# E02: optional self-study questions

These IDs are optional, upload-only and unregistered; no stored extension mastery.

## ext01.e02.1

Collapse a tiny allocation posterior. For counts (1,0), use pi~Beta(2,2) and independent rates Gamma(shape=1, rate=2), with pi=P(z=1). Find the marginal evidence and posterior probability that the two allocations coincide. Then give the conditional posterior of pi and both rates when both observations are assigned to component 1. Show the contribution of an empty component.

## ext01.e02.2

Audit a relabelling proposal at one parameter/allocation configuration: pi=0.7, lambda0=2, lambda1=6 and z=(0,1,1) for three windows. An analyst swaps the two rates and complements z but leaves pi unchanged. Give the complete valid relabelling, compare the next-zero probability before and after that valid transformation, and explain why a co-cluster matrix is unchanged. Under symmetric priors, does equality of the two labelled posterior rate means establish that there is only one rate?

## ext01.e02.3

Derive a conditional predictive probability. An allocation has n1=2,S1=5,n0=1,S0=0. The priors are Beta(1,1) for pi and Gamma(shape=2,rate=1) for each rate. Integrate the weight and both rates conditional on this allocation to find the next count mean and probability of zero. Explain the extra averaging required if this allocation is uncertain.

## ext01.e02.4

Compare two generative mechanisms for two zero counts, using fixed rates log(2) and log(4) with equal weights. In mechanism A, choose a component independently for each observation. In mechanism B, choose a single component for the whole dataset. Calculate both probabilities and explain how the unit of allocation relates to whole-model averaging.


# E03: optional self-study questions

These IDs are optional, upload-only and unregistered; no stored extension mastery.

## ext01.e03.1

Trace fixed-parameter HMM messages. Initially state 0 is certain. Let p01=1/3,p10=1/4 and alert probabilities in states 0 and 1 be (1/4,3/4). For observations (0,1,0), calculate every filtered state-1 probability, every smoothed state-1 probability, and the sequence evidence. State whether a transition occurs before the first observation.

## ext01.e03.2

Audit this temporal calculation for observations (1,0,0,1,0). The emissions and initial law are fixed, and q indexes transition pairs with prior node masses v[q]. Code computes W[q]=normalize(v[q]*L5[q]), then reports F[t]=sum_q W[q]*f[t,q] for every t, where f[t,q] uses only observations through t. Identify the erroneous line and write the correct parameter-weight formula. Specify an executable test comparing this sequence with (1,0,0,0,1), including which outputs must agree and which may differ. Explain whether the original F is a filter or a smoother.

## ext01.e03.3

Derive a joint forecast with shared uncertain transitions. Deterministic emissions reveal states (0,0,1). Independent priors are p01~Beta(3,2) and p10~Beta(2,4). Derive both transition posteriors and the probability that the next two states are both 1. Compare with squaring the posterior mean stay probability and explain which generative procedure that square describes.

## ext01.e03.4

Specify impossible-evidence behavior. Initially state 0 is certain; p01=0,p10=0.4; state alert probabilities are (0,1). Observations are (0,1). Locate the first impossible prefix, say whether the full-data posterior and forecast exist, and specify what a numerical API and an interface with an earlier valid result should display.
